package com.seungjae.speechclaritylab;

import android.app.Activity;
import android.os.Bundle;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URLEncoder;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javax.net.ssl.HttpsURLConnection;

public class MainActivity extends Activity {
    private WebView webView;
    private final ExecutorService executor = Executors.newFixedThreadPool(3);
    private volatile String apiKey = null; // RAM only
    private File ttsCacheDir;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ttsCacheDir = new File(getCacheDir(), "eleven_tts");
        if (!ttsCacheDir.exists()) ttsCacheDir.mkdirs();

        webView = new WebView(this);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(false);
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient());
        webView.addJavascriptInterface(new NativeBridge(), "AndroidBridge");
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override protected void onDestroy() {
        executor.shutdownNow();
        if (webView != null) webView.destroy();
        apiKey = null;
        super.onDestroy();
    }

    private void callback(final String id, final JSONObject obj) {
        runOnUiThread(() -> {
            String payload = JSONObject.quote(obj.toString());
            webView.evaluateJavascript("window.NativeCallbacks && window.NativeCallbacks.resolve(" + JSONObject.quote(id) + "," + payload + ");", null);
        });
    }

    private void callbackError(String id, Exception e) {
        try {
            JSONObject o = new JSONObject();
            o.put("error", e.getMessage() == null ? e.toString() : e.getMessage());
            callback(id, o);
        } catch (Exception ignored) {}
    }

    private byte[] http(String method, String endpoint, String body, String accept) throws Exception {
        if (apiKey == null || apiKey.trim().length() < 8) throw new Exception("ElevenLabs API 키를 먼저 연결하세요.");
        URL u = new URL(endpoint);
        HttpsURLConnection c = (HttpsURLConnection) u.openConnection();
        c.setRequestMethod(method);
        c.setConnectTimeout(20000);
        c.setReadTimeout(90000);
        c.setRequestProperty("xi-api-key", apiKey);
        c.setRequestProperty("Accept", accept == null ? "application/json" : accept);
        c.setRequestProperty("User-Agent", "SpeechClarityLab-Android/0.4");
        if (body != null) {
            c.setDoOutput(true);
            c.setRequestProperty("Content-Type", "application/json; charset=utf-8");
            try (OutputStream os = c.getOutputStream()) { os.write(body.getBytes(StandardCharsets.UTF_8)); }
        }
        int code = c.getResponseCode();
        InputStream in = (code >= 200 && code < 300) ? c.getInputStream() : c.getErrorStream();
        byte[] bytes = readAll(in);
        if (code < 200 || code >= 300) {
            String msg = new String(bytes, StandardCharsets.UTF_8);
            throw new Exception("ElevenLabs HTTP " + code + ": " + (msg.length() > 500 ? msg.substring(0,500) : msg));
        }
        return bytes;
    }

    private byte[] readAll(InputStream in) throws Exception {
        if (in == null) return new byte[0];
        try (InputStream x = in; ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] b = new byte[8192]; int n;
            while ((n = x.read(b)) != -1) out.write(b,0,n);
            return out.toByteArray();
        }
    }

    private String sha256(String s) throws Exception {
        MessageDigest d = MessageDigest.getInstance("SHA-256");
        byte[] x = d.digest(s.getBytes(StandardCharsets.UTF_8));
        StringBuilder sb = new StringBuilder();
        for (byte v : x) sb.append(String.format(Locale.US, "%02x", v));
        return sb.toString();
    }

    private String dataUrl(File f) throws Exception {
        byte[] bytes;
        try (FileInputStream in = new FileInputStream(f)) { bytes = readAll(in); }
        return "data:audio/mpeg;base64," + Base64.encodeToString(bytes, Base64.NO_WRAP);
    }

    public class NativeBridge {
        @JavascriptInterface public void setApiKey(String key, String callbackId) {
            executor.execute(() -> {
                try {
                    String k = key == null ? "" : key.trim();
                    if (k.length() < 8) throw new Exception("API 키가 너무 짧습니다.");
                    String old = apiKey; apiKey = k;
                    try { http("GET", "https://api.elevenlabs.io/v1/models", null, "application/json"); }
                    catch (Exception e) { apiKey = old; throw e; }
                    JSONObject o = new JSONObject(); o.put("ok", true); o.put("message", "연결 성공 · 키는 앱 메모리에만 유지됩니다."); callback(callbackId,o);
                } catch (Exception e) { callbackError(callbackId,e); }
            });
        }

        @JavascriptInterface public void clearApiKey(String callbackId) {
            apiKey = null;
            try { JSONObject o = new JSONObject(); o.put("ok",true); callback(callbackId,o); } catch(Exception e){ callbackError(callbackId,e); }
        }

        @JavascriptInterface public void getModels(String callbackId) {
            executor.execute(() -> {
                try {
                    JSONArray raw = new JSONArray(new String(http("GET","https://api.elevenlabs.io/v1/models",null,"application/json"), StandardCharsets.UTF_8));
                    JSONArray arr = new JSONArray();
                    for(int i=0;i<raw.length();i++){
                        JSONObject m=raw.getJSONObject(i);
                        if(!m.optBoolean("can_do_text_to_speech",false)) continue;
                        JSONObject x=new JSONObject(); x.put("model_id",m.optString("model_id")); x.put("name",m.optString("name",m.optString("model_id")));
                        JSONArray langs=m.optJSONArray("languages"); boolean ko=false;
                        if(langs!=null) for(int j=0;j<langs.length();j++){JSONObject l=langs.optJSONObject(j); if(l!=null && ("ko".equals(l.optString("language_id")) || "korean".equalsIgnoreCase(l.optString("name")))) ko=true;}
                        x.put("korean",ko); arr.put(x);
                    }
                    JSONObject o=new JSONObject();o.put("models",arr);callback(callbackId,o);
                }catch(Exception e){callbackError(callbackId,e);}
            });
        }

        @JavascriptInterface public void getVoices(String search, String callbackId) {
            executor.execute(() -> {
                try {
                    String endpoint="https://api.elevenlabs.io/v2/voices?page_size=100&include_total_count=false";
                    if(search!=null && !search.trim().isEmpty()) endpoint += "&search="+URLEncoder.encode(search.trim(),"UTF-8");
                    JSONObject raw=new JSONObject(new String(http("GET",endpoint,null,"application/json"),StandardCharsets.UTF_8));
                    JSONArray vs=raw.optJSONArray("voices"); JSONArray out=new JSONArray();
                    if(vs!=null) for(int i=0;i<vs.length();i++){
                        JSONObject v=vs.getJSONObject(i),x=new JSONObject();x.put("voice_id",v.optString("voice_id"));x.put("name",v.optString("name","(이름 없음)"));x.put("category",v.optString("category",""));x.put("labels",v.optJSONObject("labels"));out.put(x);
                    }
                    JSONObject o=new JSONObject();o.put("voices",out);callback(callbackId,o);
                }catch(Exception e){callbackError(callbackId,e);}
            });
        }

        @JavascriptInterface public void tts(String text, String voiceId, String modelId, String settingsJson, String callbackId) {
            executor.execute(() -> {
                try {
                    if(text==null || text.trim().isEmpty() || voiceId==null || voiceId.trim().isEmpty()) throw new Exception("문장과 Voice가 필요합니다.");
                    JSONObject body=new JSONObject();body.put("text",text);body.put("model_id",modelId==null||modelId.isEmpty()?"eleven_multilingual_v2":modelId);body.put("voice_settings",new JSONObject(settingsJson));
                    String cacheKey=sha256(voiceId+"|"+body.toString());File f=new File(ttsCacheDir,cacheKey+".mp3");boolean cached=f.exists()&&f.length()>1000;
                    if(!cached){String endpoint="https://api.elevenlabs.io/v1/text-to-speech/"+URLEncoder.encode(voiceId,"UTF-8")+"?output_format=mp3_44100_128";byte[] mp3=http("POST",endpoint,body.toString(),"audio/mpeg");try(FileOutputStream os=new FileOutputStream(f)){os.write(mp3);}}
                    JSONObject o=new JSONObject();o.put("ok",true);o.put("cached",cached);o.put("data_url",dataUrl(f));callback(callbackId,o);
                }catch(Exception e){callbackError(callbackId,e);}
            });
        }
    }
}
