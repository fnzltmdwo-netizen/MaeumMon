말소리 Focus Lab - Android v0.4

핵심
- ElevenLabs API Key: 앱 프로세스 메모리에만 보관 (파일 저장 X)
- ElevenLabs Voice/Model 목록 조회
- 생성 MP3는 앱 내부 cache/eleven_tts에 캐시
- 작은 말: 0 ~ -21 dB 상대 감쇠
- 자음 흐림: 8 kHz ~ 1.5 kHz low-pass
- 음량 × 자음 단서 2D 지도
- 적응형 훈련: >=85% 난도 상승, <60% 난도 하강

안드로이드 폰에서 빌드
1. ZIP 압축 해제
2. AndroidIDE 또는 AIDE에서 프로젝트 폴더 열기
3. Gradle Sync/Build APK
4. 생성 APK 설치

PC가 있다면 Android Studio에서도 프로젝트 폴더를 그대로 Open → Build APK 가능합니다.

빌드 설정
- package: com.seungjae.speechclaritylab
- minSdk 26
- targetSdk 35
- compileSdk 35
- 외부 라이브러리 없음

주의
- 의료 진단 도구가 아닙니다.
- 앱의 dB는 임상 dB HL/SPL이 아니라 동일 디지털 음원의 상대 감쇠입니다.
- 검사 중 미디어 볼륨과 이어폰/헤드폰을 고정하세요.
- ElevenLabs 사용량/과금은 본인 계정 정책을 따릅니다.
