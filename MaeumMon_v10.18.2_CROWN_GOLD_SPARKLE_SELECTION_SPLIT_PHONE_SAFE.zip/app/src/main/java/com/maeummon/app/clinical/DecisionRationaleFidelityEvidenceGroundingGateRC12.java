package com.maeummon.app.clinical;

import android.content.Context;
import org.json.*;

public final class DecisionRationaleFidelityEvidenceGroundingGateRC12 {
    private DecisionRationaleFidelityEvidenceGroundingGateRC12(){}

    public enum State {
        PASS,
        REPAIRED,
        BLOCKED
    }

    public static final class Result {
        public boolean evaluated=false;
        public boolean repaired=false;
        public boolean blocked=false;
        public boolean moveMismatch=false;
        public boolean policyOverclaim=false;
        public boolean unsupportedCertainty=false;
        public boolean internalJargonLeak=false;
        public boolean evidenceMismatch=false;
        public State state=State.PASS;
        public String original="";
        public String finalRationale="";
        public String reason="";
        public String summary="";
    }

    public static Result validate(
            Context c,
            ClinicalDecisionRC7 d,
            PolicyExplainabilityDecisionRationaleRC12.Result rationale){

        Result r=new Result();
        if(c==null||d==null||rationale==null){
            r.evaluated=true;
            r.blocked=true;
            r.state=State.BLOCKED;
            r.reason="MISSING_INPUT";
            r.summary="BLOCKED | MISSING_INPUT";
            return r;
        }

        r.evaluated=true;
        r.original=safe(rationale.rationale);
        r.finalRationale=r.original;

        JSONObject f=CentralTherapyProfile.loadFormulation(c);
        String move=safe(d.move);
        String mechanism=safe(d.centralMechanism);

        if(r.original.isEmpty()){
            r.blocked=true;
            r.state=State.BLOCKED;
            r.reason="EMPTY_RATIONALE";
            r.finalRationale="";
            return finish(r);
        }

        // 1) Rationale must describe the actual move.
        if("ASK".equals(move)
                && !containsAny(r.original,
                    "질문","확인","알아야","방향")){

            r.moveMismatch=true;
        }

        if("INTERVENE".equals(move)
                && !containsAny(r.original,
                    "방법","고른","직접","시도","중요")){

            r.moveMismatch=true;
        }

        if("REVIEW".equals(move)
                && !containsAny(r.original,
                    "확인","영향","다음","효과")){

            r.moveMismatch=true;
        }

        // 2) Policy memory must never be described as proof/current fact.
        if(rationale.policyReferenced
                && containsAny(r.original,
                    "확실히","분명히","반드시","항상",
                    "너한테 맞는 방법","검증된 정답")){

            r.policyOverclaim=true;
        }

        // 3) Current hypothesis cannot be stated as settled fact.
        if(!mechanism.isEmpty()
                && !"HIGH".equals(
                    f.optString("central_insight_confidence",""))
                && containsAny(r.original,
                    "원인이야","틀림없어","확실한 건",
                    "분명한 건","무조건")){

            r.unsupportedCertainty=true;
        }

        // 4) Internal implementation jargon must not leak user-facing.
        if(containsAny(r.original,
                "policyKey","policy key",
                "confidence=",
                "RC11","RC12",
                "canonical_learning_key",
                "GENERAL_POLICY_",
                "CURRENT_ONLY",
                "CONTEXT_SPECIFIC",
                "HIERARCHY",
                "PROVENANCE")){

            r.internalJargonLeak=true;
        }

        // 5) If current evidence says policy cannot influence,
        // rationale may not claim past-policy support.
        boolean policyActuallyAllowed =
                d.policyRetrievalApplicable
                && !d.policySelectionSuppressed
                && !"CURRENT_ONLY".equals(
                    safe(d.policyHierarchyWinner));

        if(rationale.policyReferenced
                && !policyActuallyAllowed){

            r.evidenceMismatch=true;
        }

        if(r.moveMismatch
                ||r.policyOverclaim
                ||r.unsupportedCertainty
                ||r.internalJargonLeak
                ||r.evidenceMismatch){

            r.repaired=true;
            r.state=State.REPAIRED;
            r.finalRationale=repair(d,f,rationale,r);
            r.reason=reasonString(r);
            return finish(r);
        }

        r.state=State.PASS;
        r.reason="RATIONALE_GROUNDED";
        return finish(r);
    }

    public static String instruction(Result r){
        if(r==null||!r.evaluated)return "";

        if(r.state==State.BLOCKED){
            return "DECISION_RATIONALE_FIDELITY=BLOCKED. 설명 근거가 불충분하므로 사용자에게 WHY 설명을 강제로 추가하지 않는다.";
        }

        if(r.state==State.REPAIRED){
            return "DECISION_RATIONALE_FIDELITY=REPAIRED. 사용자에게 설명할 WHY는 다음 문구를 우선 사용한다: "
                    +r.finalRationale;
        }

        if(r.state==State.PASS){
            return "DECISION_RATIONALE_FIDELITY=PASS. 현재 decision/evidence와 WHY 설명이 일치한다.";
        }

        return "";
    }

    private static String repair(
            ClinicalDecisionRC7 d,
            JSONObject f,
            PolicyExplainabilityDecisionRationaleRC12.Result rationale,
            Result issue){

        String move=safe(d.move);
        String target=safe(d.targetVariable);
        String intervention=safe(d.selectedInterventionId);

        if(d.safetyOverride)
            return "지금은 더 분석하기보다 먼저 안전과 안정화를 확인하는 게 우선이야.";

        if(d.allianceRupture)
            return "지금은 해결책을 밀기보다 내가 네 말을 제대로 이해했는지 다시 맞추는 게 먼저야.";

        if("ASK".equals(move)){
            if(target.isEmpty())target="지금 상담 방향을 가르는 핵심 정보";
            return "바로 결론내리기보다 "+humanize(target)
                    +"을 확인해야 다음 판단이 달라질 수 있어서 이 질문을 고른 거야.";
        }

        if("FORMULATE".equals(move))
            return "지금까지 나온 사실과 해석을 보면 이 흐름이 현재 문제를 설명하는 유력한 가설이야. 아직 확정된 사실이라기보다 지금 기준에서 가장 설명력이 높은 쪽으로 보고 있어.";

        if("INTERVENE".equals(move)){
            String base="지금까지 확인된 흐름을 직접 건드리면서 부담이 과하지 않은 방법이라 이 개입을 골랐어.";

            boolean policyAllowed =
                    d.policyRetrievalApplicable
                    &&!d.policySelectionSuppressed
                    &&!"CURRENT_ONLY".equals(
                        safe(d.policyHierarchyWinner));

            if(policyAllowed
                    &&rationale.policyReferenced)
                base+=" 비슷한 상황의 과거 기록은 보조 근거로만 참고했어.";

            return base;
        }

        if("REVIEW".equals(move))
            return "지금은 새 방법을 더 추가하기보다 방금 해본 방식이 실제로 어떤 영향을 줬는지 확인한 뒤 다음 선택을 정하는 게 더 정확해.";

        if("STABILIZE".equals(move))
            return "지금은 문제를 더 밀어붙이기보다 긴장을 조금 낮추고 버틸 수 있는 상태를 만드는 게 먼저야.";

        return "지금까지 확인된 정보와 현재 상담 단계에 맞춰 다음 움직임을 정했어.";
    }

    private static String reasonString(Result r){
        StringBuilder sb=new StringBuilder();

        if(r.moveMismatch)append(sb,"MOVE_MISMATCH");
        if(r.policyOverclaim)append(sb,"POLICY_OVERCLAIM");
        if(r.unsupportedCertainty)append(sb,"UNSUPPORTED_CERTAINTY");
        if(r.internalJargonLeak)append(sb,"INTERNAL_JARGON_LEAK");
        if(r.evidenceMismatch)append(sb,"POLICY_EVIDENCE_MISMATCH");

        return sb.toString();
    }

    private static void append(StringBuilder sb,String x){
        if(sb.length()>0)sb.append(",");
        sb.append(x);
    }

    private static String humanize(String s){
        return safe(s).replace("_"," ");
    }

    private static boolean containsAny(String s,String... xs){
        if(s==null)return false;
        for(String x:xs)
            if(x!=null&&!x.isEmpty()&&s.contains(x))
                return true;
        return false;
    }

    private static Result finish(Result r){
        r.summary=r.state.name()
                +" | repaired="+r.repaired
                +" | blocked="+r.blocked
                +" | moveMismatch="+r.moveMismatch
                +" | policyOverclaim="+r.policyOverclaim
                +" | unsupportedCertainty="+r.unsupportedCertainty
                +" | jargonLeak="+r.internalJargonLeak
                +" | evidenceMismatch="+r.evidenceMismatch
                +" | reason="+r.reason;
        return r;
    }

    private static String safe(String s){
        return s==null?"":s;
    }
}
