package com.maeummon.app;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.security.MessageDigest;
import java.util.Locale;

public class LiveMindManager {
    private static final String PREF = "maeummon_live_mind";
    private static final String K_CONTEXT_HASH = "context_hash";
    private static final String K_AI_HASH = "ai_hash";
    private static final String K_LIVE_LETTER = "live_letter";
    private static final String K_LIVE_WORDS = "live_words";
    private static final String K_UPDATED_AT = "updated_at";

    private static SharedPreferences p(Context c) {
        return c.getSharedPreferences(PREF, Context.MODE_PRIVATE);
    }

    public static synchronized void onMindChanged(Context c) {
        String ctx = recentContext(c);
        String hash = hash(ctx);
        p(c).edit()
                .putString(K_CONTEXT_HASH, hash)
                .remove(K_AI_HASH)
                .remove(K_LIVE_LETTER)
                .remove(K_LIVE_WORDS)
                .apply();
        recalculatePetState(c, ctx);
    }

    public static synchronized void recalculatePetState(Context c) {
        recalculatePetState(c, recentContext(c));
    }

    private static void recalculatePetState(Context c, String ctx) {
        String t = (ctx == null ? "" : ctx).toLowerCase(Locale.KOREA);
        int positive = count(t, "좋", "행복", "즐거", "편안", "고마", "괜찮", "뿌듯", "웃");
        int anxiety = count(t, "불안", "걱정", "긴장", "무서", "두려", "초조", "공포", "패닉");
        int sad = count(t, "슬프", "울고", "우울", "눈물", "속상", "허무", "무의미", "힘들");
        int tired = count(t, "피곤", "지침", "지쳤", "졸", "잠", "무기력", "귀찮", "번아웃");
        int anger = count(t, "화나", "짜증", "분노", "열받", "억울");
        int lonely = count(t, "외롭", "혼자", "무시", "거절", "버려", "연락 안", "답장 안");
        int overload = count(t, "벅차", "압도", "너무 많", "복잡", "정신없", "못하겠", "아무것도 할 수 없");
        int rest = count(t, "쉬", "휴식", "산책", "숨", "심호흡", "잠깐", "천천히");

        int mood = 70 + positive * 3 - sad * 5 - anxiety * 2 - anger * 3 - tired * 2;
        int energy = 70 + positive - tired * 6 - overload * 3;
        int calm = 74 + rest * 2 - anxiety * 6 - anger * 4 - overload * 4;
        int lonelyScore = 20 + lonely * 8 + sad * 2 - positive * 2;

        // 오늘 감정 일기의 명시적 라벨은 일반 키워드보다 조금 더 강하게 반영한다.
        JSONObject today = EmotionDiaryStorage.getEntryByDate(c, EmotionDiaryStorage.today());
        if (today != null) {
            String label = today.optString("label", "");
            if ("불안".equals(label)) { calm -= 16; mood -= 6; }
            else if ("슬픔".equals(label)) { mood -= 16; lonelyScore += 8; }
            else if ("지침".equals(label) || "잠옴".equals(label)) { energy -= 18; }
            else if ("화남".equals(label)) { calm -= 12; mood -= 8; }
            else if ("좋음".equals(label)) { mood += 14; calm += 6; energy += 5; }
        }

        PetStateManager.setFromContext(c, clamp(mood), clamp(energy), clamp(calm), clamp(lonelyScore));
    }

    public static String recentContext(Context c) {
        StringBuilder sb = new StringBuilder();
        String therapy = TherapyMemoryManager.compactForLiveMind(c);
        if (!therapy.isEmpty()) {
            sb.append("[최근 변화상담에서 이어가는 것]\n").append(therapy).append("\n\n");
        }
        sb.append("[최근 상담에서 승재가 말한 내용]\n");
        JSONArray records = ChatStorage.getDiaryRecords(c);
        int chatMax = Math.min(records.length(), 12);
        for (int i = 0; i < chatMax; i++) {
            JSONObject r = records.optJSONObject(i);
            if (r == null) continue;
            String text = r.optString("text", "").trim();
            if (text.isEmpty()) continue;
            sb.append("- ").append(shorten(text, 220)).append("\n");
        }

        sb.append("\n[최근 감정 일기]\n");
        JSONArray diaries = EmotionDiaryStorage.getEntries(c);
        int start = Math.max(0, diaries.length() - 6);
        for (int i = diaries.length() - 1; i >= start; i--) {
            JSONObject o = diaries.optJSONObject(i);
            if (o == null) continue;
            sb.append("- ").append(o.optString("date", ""))
                    .append(" / ").append(o.optString("label", ""));
            String cause = o.optString("cause", "").trim();
            if (!cause.isEmpty()) sb.append(" / 원인: ").append(cause);
            String text = o.optString("text", "").trim();
            if (!text.isEmpty()) sb.append(" / ").append(shorten(text, 220));
            sb.append("\n");
        }

        String out = sb.toString().trim();
        if (out.length() > 5000) out = out.substring(out.length() - 5000);
        return out;
    }

    public static String contextHash(Context c) {
        return hash(recentContext(c));
    }

    public static boolean aiRefreshNeeded(Context c) {
        String current = contextHash(c);
        String done = p(c).getString(K_AI_HASH, "");
        if (!current.equals(done)) return true;
        long age = System.currentTimeMillis() - p(c).getLong(K_UPDATED_AT, 0L);
        return age > 30L * 60L * 1000L; // 같은 내용이어도 30분 뒤엔 새 표현 허용
    }

    public static void saveAiContent(Context c, String letter, String words) {
        p(c).edit()
                .putString(K_AI_HASH, contextHash(c))
                .putString(K_LIVE_LETTER, clean(letter))
                .putString(K_LIVE_WORDS, clean(words))
                .putLong(K_UPDATED_AT, System.currentTimeMillis())
                .apply();
    }

    public static void saveAiLetter(Context c, String letter) {
        p(c).edit().putString(K_LIVE_LETTER, clean(letter)).putLong(K_UPDATED_AT, System.currentTimeMillis()).apply();
    }

    public static void saveAiWords(Context c, String words) {
        p(c).edit().putString(K_LIVE_WORDS, clean(words)).putLong(K_UPDATED_AT, System.currentTimeMillis()).apply();
    }

    public static String getLiveLetter(Context c) {
        String v = p(c).getString(K_LIVE_LETTER, "").trim();
        return v.isEmpty() ? YoungSeungjaeHome.regenerateDailyLetter(c) : v;
    }

    public static String getLiveWords(Context c) {
        return p(c).getString(K_LIVE_WORDS, "").trim();
    }

    public static String localWords(Context c) {
        String shared = UnifiedTherapyProfile.mascotLine(c);
        PetStateManager.State s = PetStateManager.get(c);
        if (!shared.isEmpty() && s.energy >= 38 && s.calm >= 40 && s.mood >= 42) {
            return "승재야, 요즘 우리 같이 보고 있는 걸 기억하자.\n" + shared
                    + "\n오늘도 네 마음을 남의 반응보다 먼저 챙겨보자.\n"
                    + "한 번에 다 바꾸려 하지 않아도 돼.\n내가 계속 같이 볼게.";
        }
        if (s.energy < 38) return "승재야, 오늘은 힘을 너무 많이 썼어.\n"
                + "지금 지친 건 네가 약해서가 아니야.\n"
                + "오늘 다 끝내는 것보다 덜 지치는 게 더 중요해.\n"
                + "물 한 잔 마시고 잠깐 기대어 쉬어도 돼.\n"
                + "남은 시간은 네 편으로 써도 괜찮아.";
        if (s.calm < 40) return "승재야, 지금 마음이 많이 팽팽하구나.\n"
                + "그때 바로 말 못했어도 네가 약한 건 아니야.\n"
                + "마음이 놀라면 말이 늦게 나올 수도 있어.\n"
                + "다음엔 '그 말은 불편해' 한마디만 해도 돼.\n"
                + "오늘은 네 잘못처럼 다 안고 있지 말자.";
        if (s.mood < 42) return "승재야, 오늘 마음이 꽤 무거웠지.\n"
                + "그 감정을 빨리 없애려 하지 않아도 돼.\n"
                + "힘든 날에도 네가 버틴 장면은 분명 있어.\n"
                + "오늘 전체를 가장 힘든 순간 하나로 정하지 말자.\n"
                + "나는 지금의 네 마음을 같이 보고 있을게.";
        return "승재야, 최근 네 이야기를 다시 보고 있어.\n"
                + "좋았던 것과 버거웠던 것이 같이 있었지.\n"
                + "둘 다 네 하루라는 걸 잊지 않았으면 해.\n"
                + "오늘은 필요한 것만 하고 남은 건 내일로 넘겨도 돼.\n"
                + "내가 계속 네 옆에서 같이 볼게.";
    }

    private static int count(String text, String... keys) {
        int total = 0;
        for (String key : keys) {
            int from = 0;
            while (true) {
                int idx = text.indexOf(key, from);
                if (idx < 0) break;
                total++;
                from = idx + key.length();
            }
        }
        return Math.min(total, 10);
    }

    private static int clamp(int v) { return Math.max(0, Math.min(100, v)); }
    private static String shorten(String s, int n) { return s.length() <= n ? s : s.substring(0, n) + "..."; }
    private static String clean(String s) { return s == null ? "" : s.trim(); }

    private static String hash(String text) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] b = md.digest((text == null ? "" : text).getBytes("UTF-8"));
            StringBuilder sb = new StringBuilder();
            for (byte x : b) sb.append(String.format(Locale.US, "%02x", x));
            return sb.toString();
        } catch (Exception e) {
            return String.valueOf(text == null ? 0 : text.hashCode());
        }
    }
}
