package com.maeummon.app;

import java.util.Locale;

/**
 * v5.0 intervention selector.
 * Chooses one small technique family only after formulation/need selection.
 * Technique names are internal; output should sound like normal counseling.
 */
public final class TherapyInterventionSelectorV5 {
    private TherapyInterventionSelectorV5() {}

    public static String buildContext(String userMessage) {
        String m = userMessage == null ? "" : userMessage.toLowerCase(Locale.KOREA);
        StringBuilder b = new StringBuilder();
        b.append("[INTERVENTION_SELECTOR_V5 — 기법은 formulation 다음]\n");
        b.append("기법 이름을 사용자에게 나열하지 않는다. 이번 턴 RESPONSE_NEED와 formulation에서 직접 이어지는 한 가지 도구만 기본 선택한다. 여러 기법을 뷔페처럼 쌓지 않는다.\n");

        if (containsAny(m, "너무 불안", "숨막", "심장이", "공황", "폭발", "감정이 너무", "못 견디")) {
            b.append("우선 후보: DBT/CFT/현재감각 안정화 요소. 높은 정서에서는 논박보다 안정·행동중단·고통감내를 먼저.\n");
        }
        if (containsAny(m, "무시", "싫어하", "분명", "확실", "답장", "연락", "일부러", "내가 잘못")) {
            b.append("우선 후보: CBT/MBCT 현실검증 요소. FACT-해석-예측을 분리하고, 안심 반복 대신 검증 가능한 행동증거를 본다.\n");
        }
        if (containsAny(m, "거절", "경계", "뭐라고 말", "말해야", "부탁", "참아", "폭발")) {
            b.append("우선 후보: DBT 대인효과/Assertiveness 요소. 욕구·경계를 짧은 실제 문장 하나로 연습한다.\n");
        }
        if (containsAny(m, "알지만 못", "바꾸고 싶은데", "하고 싶은데", "양가", "망설")) {
            b.append("우선 후보: MI + ACT 요소. 설득하지 말고 바꾸려는 마음/그대로 있고 싶은 마음을 함께 인정한 뒤 가치에 맞는 아주 작은 선택을 찾는다.\n");
        }
        if (containsAny(m, "회피", "무서워서 안", "피하고", "전화 무서", "못 가", "못 하겠")) {
            b.append("우선 후보: gentle exposure/행동실험. 위험하지 않은 일상 회피에만 작은 단계로 접근하고, 강한 트라우마 재경험은 앱에서 하지 않는다.\n");
        }
        if (containsAny(m, "죽", "사별", "그리워", "잃었", "애도")) {
            b.append("우선 후보: grief-support/CFT. 슬픔 제거보다 의미·죄책감·현재 기능을 분리하고 자기돌봄을 돕는다.\n");
        }
        if (containsAny(m, "자책", "내 탓", "내탓", "나는 왜", "쓸모", "나쁜 사람", "수치")) {
            b.append("우선 후보: CFT/자기자비 + responsibility split. 자기공격을 낮추되 실제 책임은 정확히 남긴다.\n");
        }
        if (containsAny(m, "해야 하는데", "귀찮", "시작", "미루", "일하기", "집중")) {
            b.append("우선 후보: 행동활성화/실행기능 지원. 의지 평가보다 시작장벽·작업크기·피로·환경을 줄여 다음 행동 1개로 만든다.\n");
        }

        b.append("기본 fallback: Person-centered 정확한 반영 + 필요 시 SFBT식 작은 예외/다음 행동. 사용자가 행동을 원하지 않으면 기법을 억지로 적용하지 않는다.\n");
        b.append("[선택 금지] formulation이 불충분한데 Schema/Attachment/Psychodynamic 원인을 확정하지 않는다. EMDR식 기억 재처리나 강한 노출은 앱에서 시행하지 않는다. 진단/약 처방은 전문가 영역이다.\n");
        return b.toString();
    }

    public static String prompt() {
        return "[INTERVENTION_SELECTOR_V5 SYSTEM] 먼저 RESPONSE_NEED와 formulation을 정한 뒤 가장 적합한 상담기법 요소 한 가지를 선택한다. "
                + "CBT/MBCT=사실-해석-예측 분리, DBT=고감정 안정/경계표현, ACT=감정 제거보다 가치행동, MI=양가감정, CFT=자기비난 완화, SFBT=예외/작은 변화, gentle exposure=안전한 일상 회피, 행동활성화=시작장벽 축소, grief support=애도와 기능 분리. "
                + "기법 이름을 대화에 나열하지 말고 자연스러운 말과 행동으로 번역한다. 한 턴에 여러 기법을 과시하지 않는다.";
    }

    private static boolean containsAny(String text, String... needles) {
        for (String n : needles) if (text.contains(n.toLowerCase(Locale.KOREA))) return true;
        return false;
    }
}
