package com.maeummon.app.clinical;

import android.content.Context;
import org.json.*;

public final class GoalDriftCompletionRC8 {
    private GoalDriftCompletionRC8(){}

    public static final class Result {
        public String status="UNCHANGED"; // UNCHANGED / COMPLETED / SWITCHED / DRIFT_SUSPECTED / ARCHIVED
        public String previousGoal="";
        public String activeGoal="";
        public String reason="";
        public boolean shouldArchive=false;
        public boolean shouldSwitch=false;
    }

    public static Result evaluate(Context c,String userText){
        Result r=new Result();
        if(c==null)return r;
        JSONObject p=CentralTherapyProfile.loadProfile(c);
        String t=userText==null?"":userText;
        String oldGoal=p.optString("active_therapy_goal","");
        int progress=p.optInt("goal_progress_score",50);

        r.previousGoal=oldGoal;
        r.activeGoal=oldGoal;

        if(oldGoal.isEmpty())return r;

        // User explicitly says the old goal is no longer needed / sufficiently resolved.
        if(containsAny(t,
                "이건 이제 괜찮아","이건 거의 괜찮아","이건 많이 좋아졌어",
                "이 문제는 해결된 것 같아","이건 이제 됐어","이건 졸업해도 될 것 같아")){
            r.status="COMPLETED";
            r.reason="explicit user completion";
            r.shouldArchive=true;
            return r;
        }

        // Strong progress plus maintenance language suggests completion candidate.
        if(progress>=80 && containsAny(t,
                "이젠 별로 안 흔들려","이제는 잘 견뎌","요즘은 괜찮아",
                "계속 유지되고 있어","이제 거의 문제 없어")){
            r.status="COMPLETED";
            r.reason="high progress with maintenance";
            r.shouldArchive=true;
            return r;
        }

        // Explicit switch to new goal.
        if(containsAny(t,
                "이제 다른 걸 바꾸고 싶","새 목표는","이제는 이걸 해보고 싶",
                "이 문제 말고","다음 목표는","이제 집중하고 싶은 건")){
            r.status="SWITCHED";
            r.reason="explicit new goal requested";
            r.shouldSwitch=true;
            return r;
        }

        // Drift suspicion: repeated current topic appears unrelated to stored goal.
        if(topicMismatch(oldGoal,t) && t.length()>=35){
            r.status="DRIFT_SUSPECTED";
            r.reason="current topic appears weakly related to active goal";
            return r;
        }

        return r;
    }

    public static void apply(Context c,Result r,String userText){
        if(c==null||r==null)return;
        try{
            JSONObject p=CentralTherapyProfile.loadProfile(c);

            if(r.shouldArchive){
                JSONArray archive=p.optJSONArray("goal_archive");
                if(archive==null)archive=new JSONArray();
                JSONObject item=new JSONObject();
                item.put("goal",r.previousGoal);
                item.put("final_progress",p.optInt("goal_progress_score",50));
                item.put("status","COMPLETED");
                item.put("reason",r.reason);
                item.put("time",System.currentTimeMillis());
                archive.put(item);
                p.put("goal_archive",tail(archive,20));

                p.put("active_therapy_goal","");
                p.put("goal_source","");
                p.put("goal_progress_score",50);
                p.put("goal_progress_history",new JSONArray());
            }

            if(r.shouldSwitch){
                JSONArray archive=p.optJSONArray("goal_archive");
                if(archive==null)archive=new JSONArray();
                JSONObject item=new JSONObject();
                item.put("goal",r.previousGoal);
                item.put("final_progress",p.optInt("goal_progress_score",50));
                item.put("status","SWITCHED");
                item.put("reason",r.reason);
                item.put("time",System.currentTimeMillis());
                archive.put(item);
                p.put("goal_archive",tail(archive,20));

                String newGoal=extractNewGoal(userText);
                p.put("active_therapy_goal",newGoal);
                p.put("goal_source","EXPLICIT_USER_GOAL");
                p.put("goal_started_at",System.currentTimeMillis());
                p.put("goal_progress_score",50);
                p.put("goal_progress_history",new JSONArray());
                r.activeGoal=newGoal;
            }

            p.put("last_goal_status",r.status);
            p.put("last_goal_transition_reason",r.reason);
            p.put("updated_at",System.currentTimeMillis());
            CentralTherapyProfile.replaceProfile(c,p);
        }catch(Exception ignored){}
    }

    public static String instruction(Result r){
        if(r==null)return "";
        if("COMPLETED".equals(r.status)){
            return "기존 목표가 충분히 좋아졌다고 사용자가 보고했다. 성취를 짧게 인정하고 옛 목표를 계속 문제처럼 끌어오지 않는다.";
        }
        if("SWITCHED".equals(r.status)){
            return "사용자가 목표를 바꾸었다. 이전 목표를 억지로 연결하지 말고 새 목표를 기준으로 formulation을 다시 정렬한다.";
        }
        if("DRIFT_SUSPECTED".equals(r.status)){
            return "현재 주제가 기존 목표와 약하게 연결된다. 억지로 옛 목표를 끌어오지 말고 현재 문제 자체를 먼저 다룬다.";
        }
        return "";
    }

    private static boolean topicMismatch(String goal,String text){
        String g=goal==null?"":goal;
        String t=text==null?"":text;
        String gt=topic(g),tt=topic(t);
        return !gt.isEmpty()&&!tt.isEmpty()&&!gt.equals(tt);
    }

    private static String topic(String s){
        if(containsAny(s,"답장","관계","거절","버려","친구","연락"))return "relationship";
        if(containsAny(s,"회사","직장","상사","업무","평가"))return "work";
        if(containsAny(s,"회피","피하지","접근 행동","약속"))return "avoidance";
        if(containsAny(s,"회복","번아웃","지쳐","무리"))return "recovery";
        if(containsAny(s,"불안","공황","긴장"))return "anxiety";
        return "";
    }

    private static String extractNewGoal(String t){
        if(t==null)return "";
        String x=t.trim();
        if(x.length()>180)x=x.substring(0,180);
        return x;
    }

    private static JSONArray tail(JSONArray src,int max){
        JSONArray out=new JSONArray();
        int start=Math.max(0,src.length()-max);
        for(int i=start;i<src.length();i++)out.put(src.opt(i));
        return out;
    }

    private static boolean containsAny(String s,String... xs){
        for(String x:xs)if(s.contains(x))return true;
        return false;
    }
}
