package com.maeummon.app;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationManager;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Locale;

public class ContextWeather {
    public static String getWeather(Context context) {
        try {
            if (context.checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED
                    && context.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                return "위치 권한 없음";
            }
            LocationManager lm = (LocationManager) context.getSystemService(Context.LOCATION_SERVICE);
            if (lm == null) return "날씨 확인 안 됨";
            Location best = null;
            for (String provider : lm.getProviders(true)) {
                try {
                    Location l = lm.getLastKnownLocation(provider);
                    if (l != null && (best == null || l.getTime() > best.getTime())) best = l;
                } catch (Exception ignored) {}
            }
            if (best == null) return "날씨 확인 안 됨";

            String u = String.format(Locale.US,
                    "https://api.open-meteo.com/v1/forecast?latitude=%.5f&longitude=%.5f&current=temperature_2m,apparent_temperature,precipitation,rain,snowfall,weather_code,wind_speed_10m&timezone=auto",
                    best.getLatitude(), best.getLongitude());
            HttpURLConnection c=(HttpURLConnection)new URL(u).openConnection();
            c.setConnectTimeout(7000); c.setReadTimeout(7000);
            BufferedReader br=new BufferedReader(new InputStreamReader(c.getInputStream()));
            StringBuilder sb=new StringBuilder(); String line;
            while((line=br.readLine())!=null) sb.append(line);
            br.close();
            JSONObject cur=new JSONObject(sb.toString()).optJSONObject("current");
            if(cur==null) return "날씨 확인 안 됨";
            double temp=cur.optDouble("temperature_2m",999);
            double feels=cur.optDouble("apparent_temperature",999);
            double rain=cur.optDouble("rain",0);
            double snow=cur.optDouble("snowfall",0);
            int code=cur.optInt("weather_code",-1);
            String desc=describe(code,rain,snow);
            if(temp==999) return desc;
            return String.format(Locale.KOREA, "%s, %.0f도(체감 %.0f도)", desc,temp,feels==999?temp:feels);
        } catch(Exception e){
            return "날씨 확인 안 됨";
        }
    }

    private static String describe(int code,double rain,double snow){
        if(snow>0 || code==71 || code==73 || code==75 || code==77 || code==85 || code==86) return "눈 오는 중";
        if(rain>0 || (code>=51 && code<=67) || (code>=80 && code<=82) || code>=95) return "비 오는 중";
        if(code==0) return "맑음";
        if(code==1 || code==2) return "구름 조금";
        if(code==3) return "흐림";
        if(code==45 || code==48) return "안개";
        return "보통 날씨";
    }
}
