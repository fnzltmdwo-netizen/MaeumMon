package com.maeummon.app;
import android.app.Activity;import android.os.Bundle;import android.widget.EditText;import android.widget.TextView;import android.widget.Toast;import java.util.Calendar;
public class FollowUpActivity extends Activity{
 private EditText input;private TextView pending;
 @Override protected void onCreate(Bundle b){super.onCreate(b);setContentView(R.layout.activity_follow_up);UiInsets.apply(this,findViewById(R.id.followRoot));input=findViewById(R.id.followTextInput);pending=findViewById(R.id.followPendingText);findViewById(R.id.follow3HoursButton).setOnClickListener(v->save(System.currentTimeMillis()+3*60*60*1000L,"3시간 후"));findViewById(R.id.followEveningButton).setOnClickListener(v->save(evening(),"오늘 저녁"));findViewById(R.id.followTomorrowButton).setOnClickListener(v->save(System.currentTimeMillis()+24*60*60*1000L,"내일"));findViewById(R.id.follow3DaysButton).setOnClickListener(v->save(System.currentTimeMillis()+3*24*60*60*1000L,"3일 후"));refresh();}
 private long evening(){Calendar c=Calendar.getInstance();c.set(Calendar.HOUR_OF_DAY,20);c.set(Calendar.MINUTE,0);c.set(Calendar.SECOND,0);if(c.getTimeInMillis()<=System.currentTimeMillis())c.add(Calendar.DAY_OF_MONTH,1);return c.getTimeInMillis();}
 private void save(long due,String label){String s=input.getText().toString().trim();if(s.isEmpty()){Toast.makeText(this,"나중에 다시 물어볼 내용을 적어줘.",Toast.LENGTH_SHORT).show();return;}MemoryManager.addFollowUp(this,s,due);input.setText("");Toast.makeText(this,label+"에 어린 승재가 다시 물어볼게 💚",Toast.LENGTH_LONG).show();refresh();}
 private void refresh(){pending.setText("기다리는 약속 "+MemoryManager.pendingCount(this)+"개");}
}
