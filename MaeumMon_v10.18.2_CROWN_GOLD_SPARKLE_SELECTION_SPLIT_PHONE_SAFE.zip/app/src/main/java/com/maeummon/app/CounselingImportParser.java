package com.maeummon.app;

import java.util.ArrayList;
import java.util.List;

public final class CounselingImportParser {
    public static class Parsed {
        public String title = "";
        public String currentConcern = "";
        public String formulation = "";
        public String priorityDirection = "";
        public String muscleName = "";
        public String trainingText = "";
        public String successCriterion = "";
        public String caution = "";
        public String lastUserTurn = "";
        public String lastAssistantTurn = "";
        public boolean fullTranscript = false;
    }

    private CounselingImportParser() {}

    public static Parsed parse(String raw) {
        Parsed p = new Parsed();
        if (raw == null) return p;

        String normalized = raw.replace("\r", "").trim();
        if (normalized.isEmpty()) return p;

        // 1) 기존 구조화 포맷이 들어오면 그대로 읽는다.
        parseStructured(normalized, p);

        // 2) 특별한 포맷을 요구하지 않고, 통째로 붙여넣은 대화에서 마지막 사용자/ChatGPT 턴을 찾아본다.
        parseTranscript(normalized, p);

        if (p.title.isEmpty()) {
            if (!p.lastUserTurn.isEmpty()) p.title = excerpt(p.lastUserTurn, 42);
            else p.title = firstMeaningfulLine(normalized.split("\n"));
        }

        // 구조화된 사례개념화가 없으면 ChatGPT의 마지막 답변을 "참고 원문"으로만 보관한다.
        // 이를 확정적 진단/사례개념화로 취급하지 않는다.
        if (p.formulation.isEmpty() && !p.lastAssistantTurn.isEmpty()) {
            p.formulation = excerpt(p.lastAssistantTurn, 420);
        }
        if (p.currentConcern.isEmpty() && !p.lastUserTurn.isEmpty()) {
            p.currentConcern = excerpt(p.lastUserTurn, 300);
        }

        return p;
    }

    private static void parseStructured(String normalized, Parsed p) {
        String[] lines = normalized.split("\n");
        String currentKey = "";
        StringBuilder buffer = new StringBuilder();

        for (String line : lines) {
            String trimmed = clean(line);
            String key = detectKey(trimmed);
            if (!key.isEmpty()) {
                flush(p, currentKey, buffer.toString().trim());
                buffer.setLength(0);
                currentKey = key;
                String remainder = removeLabel(trimmed);
                if (!remainder.isEmpty()) buffer.append(remainder);
            } else if (!currentKey.isEmpty()) {
                // 다음 발화 라벨을 구조화 필드 내용으로 삼지 않는다.
                if (speakerType(trimmed) != 0) {
                    flush(p, currentKey, buffer.toString().trim());
                    currentKey = "";
                    buffer.setLength(0);
                } else {
                    if (buffer.length() > 0) buffer.append('\n');
                    buffer.append(trimmed);
                }
            }
        }
        flush(p, currentKey, buffer.toString().trim());
    }

    private static void parseTranscript(String normalized, Parsed p) {
        String[] lines = normalized.split("\n");
        List<String> userTurns = new ArrayList<>();
        List<String> assistantTurns = new ArrayList<>();

        int currentSpeaker = 0; // 1 user, 2 assistant
        StringBuilder current = new StringBuilder();
        boolean foundSpeakerLabel = false;

        for (String original : lines) {
            String line = original == null ? "" : original.trim();
            int detected = speakerType(line);
            if (detected != 0) {
                foundSpeakerLabel = true;
                flushTurn(currentSpeaker, current, userTurns, assistantTurns);
                current.setLength(0);
                currentSpeaker = detected;
                String remainder = removeSpeakerLabel(line);
                if (!remainder.isEmpty()) current.append(remainder);
            } else if (currentSpeaker != 0) {
                if (current.length() > 0) current.append('\n');
                current.append(original == null ? "" : original.trim());
            }
        }
        flushTurn(currentSpeaker, current, userTurns, assistantTurns);

        p.fullTranscript = foundSpeakerLabel && (!userTurns.isEmpty() || !assistantTurns.isEmpty());
        if (!userTurns.isEmpty()) p.lastUserTurn = userTurns.get(userTurns.size() - 1).trim();
        if (!assistantTurns.isEmpty()) p.lastAssistantTurn = assistantTurns.get(assistantTurns.size() - 1).trim();

        // UI에서 복사한 텍스트가 라벨 없이 한 덩어리여도 원본은 그대로 저장된다.
        // 마지막 부분은 확정적 해석이 아니라 추천엔진의 약한 참고자료로만 쓸 수 있게 둔다.
        if (!foundSpeakerLabel) {
            p.lastAssistantTurn = tailExcerpt(normalized, 1200);
        }
    }

    private static void flushTurn(int speaker, StringBuilder current, List<String> userTurns, List<String> assistantTurns) {
        String text = current.toString().trim();
        if (text.isEmpty()) return;
        if (speaker == 1) userTurns.add(text);
        else if (speaker == 2) assistantTurns.add(text);
    }

    private static int speakerType(String line) {
        if (line == null) return 0;
        String compact = line.trim().replace("**", "").replace("##", "").replace("#", "").trim();
        String lower = compact.toLowerCase();

        if (startsWithAny(lower,
                "나의 말:", "나의말:", "사용자:", "user:", "me:", "you:", "승재:", "나:")) return 1;
        if (startsWithAny(lower,
                "chatgpt의 말:", "chatgpt의말:", "chatgpt:", "gpt:", "assistant:", "상담 완전판:", "상담완전판:")) return 2;
        return 0;
    }

    private static boolean startsWithAny(String value, String... prefixes) {
        for (String p : prefixes) if (value.startsWith(p)) return true;
        return false;
    }

    private static String removeSpeakerLabel(String line) {
        int colon = line.indexOf(':');
        if (colon < 0) colon = line.indexOf('：');
        return colon >= 0 && colon + 1 < line.length() ? line.substring(colon + 1).trim() : "";
    }

    private static String clean(String s) {
        if (s == null) return "";
        return s.trim().replace("**", "").replace("##", "").replace("#", "").trim();
    }

    private static String detectKey(String line) {
        String compact = line.replace(" ", "");
        if (compact.startsWith("제목:") || compact.startsWith("상담제목:")) return "title";
        if (compact.startsWith("현재고민:") || compact.startsWith("핵심고민:")) return "concern";
        if (compact.startsWith("현재이해:") || compact.startsWith("핵심유지기제:") || compact.startsWith("사례개념화:") || compact.startsWith("핵심이해:")) return "formulation";
        if (compact.startsWith("지금우선할것:") || compact.startsWith("지금우선:") || compact.startsWith("우선방향:")) return "priority";
        if (compact.startsWith("키울마음근육:") || compact.startsWith("마음근육:")) return "muscle";
        if (compact.startsWith("첫훈련:") || compact.startsWith("이번훈련:") || compact.startsWith("오늘훈련:")) return "training";
        if (compact.startsWith("성공기준:") || compact.startsWith("성공조건:")) return "criterion";
        if (compact.startsWith("주의:") || compact.startsWith("주의점:")) return "caution";
        return "";
    }

    private static String removeLabel(String line) {
        int colon = line.indexOf(':');
        if (colon < 0) colon = line.indexOf('：');
        return colon >= 0 && colon + 1 < line.length() ? line.substring(colon + 1).trim() : "";
    }

    private static void flush(Parsed p, String key, String value) {
        if (key == null || key.isEmpty() || value == null || value.isEmpty()) return;
        if ("title".equals(key)) p.title = value;
        else if ("concern".equals(key)) p.currentConcern = value;
        else if ("formulation".equals(key)) p.formulation = value;
        else if ("priority".equals(key)) p.priorityDirection = value;
        else if ("muscle".equals(key)) p.muscleName = value;
        else if ("training".equals(key)) p.trainingText = value;
        else if ("criterion".equals(key)) p.successCriterion = value;
        else if ("caution".equals(key)) p.caution = value;
    }

    private static String firstMeaningfulLine(String[] lines) {
        for (String line : lines) {
            String s = clean(line);
            if (!s.isEmpty()) return excerpt(s, 42);
        }
        return "상담 완전판 기록";
    }

    private static String excerpt(String s, int max) {
        String one = s == null ? "" : s.replace('\n', ' ').replaceAll("\\s+", " ").trim();
        if (one.length() <= max) return one;
        return one.substring(0, max).trim() + "…";
    }

    private static String tailExcerpt(String s, int max) {
        String one = s == null ? "" : s.trim();
        if (one.length() <= max) return one;
        return "…" + one.substring(one.length() - max).trim();
    }
}
