package com.maeummon.app.clinical;

import android.content.Context;
import org.json.*;

public final class PostReinstatementCorrectionVerificationRC14 {
    private PostReinstatementCorrectionVerificationRC14(){}

    public enum State {
        NONE,
        VERIFY_REQUIRED,
        VERIFIED_KEEP,
        REQUARANTINED,
        NO_RECENT_REINSTATEMENT
    }

    public static final class Result {
        public boolean evaluated=false;
        public boolean verifyRequired=false;
        public boolean verifiedKeep=false;
        public boolean requarantined=false;
        public State state=State.NONE;
        public String transitionKey="";
        public String reinstatedCause="";
        public String currentCause="";
        public String reason="";
        public String summary="";
    }

    public static Result evaluate(
            Context c,
            ClinicalDecisionRC7 d){

        Result r=new Result();
        if(c==null||d==null){
            r.summary="NONE | MISSING_INPUT";
            return r;
        }

        r.evaluated=true;

        JSONObject p=CentralTherapyProfile.loadProfile(c);

        String recentTransition=
                p.optString(
                        "last_correction_provenance_reinstatement_transition",
                        "");

        long reinstatedAt=
                p.optLong(
                        "last_correction_provenance_reinstatement_at",
                        0L);

        if(recentTransition.isEmpty()||reinstatedAt<=0L){
            r.state=State.NO_RECENT_REINSTATEMENT;
            r.reason="NO_RECENT_REINSTATEMENT";
            return finish(r);
        }

        long age=System.currentTimeMillis()-reinstatedAt;
        long verificationWindow=30L*24L*60L*60L*1000L;

        if(age>verificationWindow){
            r.state=State.NO_RECENT_REINSTATEMENT;
            r.reason="REINSTATEMENT_OUTSIDE_VERIFICATION_WINDOW";
            return finish(r);
        }

        r.transitionKey=
                recentTransition;

        r.currentCause=
                safe(d.transitionExplanationCorrectedCause);

        JSONArray h=
                p.optJSONArray(
                        "transition_correction_commit_provenance_history");

        if(h==null){
            r.state=State.NO_RECENT_REINSTATEMENT;
            r.reason="NO_PROVENANCE_HISTORY";
            return finish(r);
        }

        for(int i=h.length()-1;i>=0;i--){
            JSONObject row=h.optJSONObject(i);
            if(row==null)continue;

            if(!recentTransition.equals(
                    row.optString("transition_key","")))
                continue;

            if(row.optLong(
                    "correction_provenance_reinstated_at",
                    0L)<=0L)
                continue;

            r.reinstatedCause=
                    row.optString(
                            "corrected_cause","");
            break;
        }

        if(r.reinstatedCause.isEmpty()){
            r.state=State.NO_RECENT_REINSTATEMENT;
            r.reason="NO_REINSTATED_CAUSE_FOUND";
            return finish(r);
        }

        if(!d.transitionExplanationCorrectionApplied){
            r.state=State.NONE;
            r.reason="NO_FRESH_CORRECTION_TO_VERIFY";
            return finish(r);
        }

        r.verifyRequired=true;
        r.state=State.VERIFY_REQUIRED;

        if(r.reinstatedCause.equals(r.currentCause)){
            r.verifiedKeep=true;
            r.verifyRequired=false;
            r.state=State.VERIFIED_KEEP;
            r.reason="FRESH_CORRECTION_CONFIRMS_REINSTATED_CAUSE";
            persistVerification(c,p,r,false);
            return finish(r);
        }

        r.requarantined=true;
        r.verifyRequired=false;
        r.state=State.REQUARANTINED;
        r.reason="FRESH_CORRECTION_CONTRADICTS_REINSTATED_CAUSE";
        requarantineMatchingRows(c,p,r);
        return finish(r);
    }

    private static void requarantineMatchingRows(
            Context c,
            JSONObject p,
            Result r){

        try{
            JSONArray h=
                    p.optJSONArray(
                            "transition_correction_commit_provenance_history");

            if(h==null)return;

            for(int i=0;i<h.length();i++){
                JSONObject row=h.optJSONObject(i);
                if(row==null)continue;

                if(!r.transitionKey.equals(
                        row.optString("transition_key","")))
                    continue;

                if(!r.reinstatedCause.equals(
                        row.optString("corrected_cause","")))
                    continue;

                if(row.optLong(
                        "correction_provenance_reinstated_at",
                        0L)<=0L)
                    continue;

                row.put(
                        "correction_provenance_integrity_state",
                        "QUARANTINED");
                row.put(
                        "correction_provenance_quarantined",
                        true);
                row.put(
                        "correction_provenance_integrity_reason",
                        "POST_REINSTATEMENT_CONTRADICTION");
                row.put(
                        "correction_provenance_requarantined_at",
                        System.currentTimeMillis());
                row.put(
                        "correction_provenance_post_reinstatement_schema",
                        "6.9.3");
            }

            p.put(
                    "transition_correction_commit_provenance_history",
                    h);

            persistVerification(c,p,r,true);
        }catch(Exception ignored){}
    }

    private static void persistVerification(
            Context c,
            JSONObject p,
            Result r,
            boolean requarantined){

        try{
            JSONArray audit=
                    p.optJSONArray(
                            "post_reinstatement_verification_history");

            if(audit==null)audit=new JSONArray();

            JSONObject item=new JSONObject();
            item.put("transition_key",r.transitionKey);
            item.put("reinstated_cause",r.reinstatedCause);
            item.put("current_cause",r.currentCause);
            item.put("state",r.state.name());
            item.put("requarantined",requarantined);
            item.put("reason",r.reason);
            item.put("time",System.currentTimeMillis());
            item.put("schema_version","6.9.3");
            audit.put(item);

            JSONArray trimmed=new JSONArray();
            int start=Math.max(0,audit.length()-40);
            for(int i=start;i<audit.length();i++)
                trimmed.put(audit.opt(i));

            p.put(
                    "post_reinstatement_verification_history",
                    trimmed);
            p.put(
                    "last_post_reinstatement_verification_state",
                    r.state.name());
            p.put(
                    "last_post_reinstatement_verification_at",
                    System.currentTimeMillis());

            CentralTherapyProfile.replaceProfile(c,p);
        }catch(Exception ignored){}
    }

    public static String instruction(Result r){
        if(r==null||!r.evaluated)return "";

        if(r.state==State.VERIFIED_KEEP)
            return "POST_REINSTATEMENT_VERIFY=KEEP. 복구된 correction provenance가 새 명시적 사용자 교정과 일치해 유지한다.";

        if(r.state==State.REQUARANTINED)
            return "POST_REINSTATEMENT_VERIFY=REQUARANTINE. 복구된 correction provenance가 새 사용자 교정과 충돌해 즉시 다시 격리한다.";

        return "";
    }

    private static Result finish(Result r){
        r.summary=r.state.name()
                +" | transition="+r.transitionKey
                +" | reinstatedCause="+r.reinstatedCause
                +" | currentCause="+r.currentCause
                +" | verifyRequired="+r.verifyRequired
                +" | keep="+r.verifiedKeep
                +" | requarantined="+r.requarantined
                +" | reason="+r.reason;
        return r;
    }

    private static String safe(String s){
        return s==null?"":s;
    }
}
