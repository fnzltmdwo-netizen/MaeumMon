package com.maeummon.app.clinical;

import android.content.Context;
import org.json.*;
import java.util.*;

public final class ClinicalReleaseResponseIntegrityRC9 {
    private ClinicalReleaseResponseIntegrityRC9(){}

    public static final class Check {
        public boolean pass=true;
        public boolean blockResponse=false;
        public String repairedMove="";
        public String repairInstruction="";
        public final List<String> failures=new ArrayList<>();

        public void fail(String code){
            pass=false;
            failures.add(code);
        }
    }

    public static Check validate(Context c,ClinicalDecisionRC7 d){
        Check x=new Check();
        if(d==null){
            x.fail("DECISION_NULL");
            x.blockResponse=true;
            return x;
        }

        // 1. Safety must dominate.
        if(d.safetyOverride && !d.isStabilize()){
            x.fail("SAFETY_NOT_STABILIZE");
            x.repairedMove="STABILIZE";
            x.repairInstruction="안전 신호가 활성화되어 일반 상담 route보다 STABILIZE가 우선이다.";
        }

        // 2. Alliance rupture must outrank normal content work.
        if(d.allianceRupture && !d.safetyOverride && !d.isAllianceRepair()){
            x.fail("RUPTURE_NOT_REPAIRED");
            x.repairedMove="ALLIANCE_REPAIR";
            x.repairInstruction="사용자가 상담 방식의 불일치를 말했으므로 내용 해결보다 상담관계 복구가 우선이다.";
        }

        // 3. ASK must contain exactly one real question.
        if(d.isAsk()){
            String q=d.directText==null?"":d.directText.trim();
            int qm=count(q,'?');
            if(q.isEmpty()){
                x.fail("ASK_EMPTY");
                x.blockResponse=true;
            }else if(qm!=1){
                x.fail("ASK_QUESTION_COUNT_"+qm);
                x.repairedMove="FORMULATE";
                x.repairInstruction="질문 예산 위반이다. 여러 질문을 던지지 말고 현재까지 이해한 내용을 먼저 정리한다.";
            }
        }

        // 4. ASK budget must respect therapeutic phase.
        if(d.isAsk() && d.phaseQuestionBudget<=0){
            x.fail("ASK_PHASE_BUDGET_ZERO");
            x.repairedMove="FORMULATE";
            x.repairInstruction="현재 session phase에서는 추가 질문보다 formulation/review가 우선이다.";
        }

        // 5. INTERVENE requires a selected intervention.
        if(d.isIntervene()){
            if(d.selectedInterventionId==null||d.selectedInterventionId.trim().isEmpty()){
                x.fail("INTERVENE_WITHOUT_INTERVENTION");
                x.repairedMove="FORMULATE";
                x.repairInstruction="개입 route가 선택됐지만 실제 intervention이 없다. 행동조언을 만들지 말고 formulation으로 되돌린다.";
            }
        }

        // 6. Central bridge cannot be ignored when it is ready during intervention.
        if(d.isIntervene() && d.centralBridgeReady){
            if(!d.centralBridgeInterventionId.equals(d.selectedInterventionId)){
                x.fail("INTERVENTION_BRIDGE_MISMATCH");
                x.repairInstruction="central mechanism과 intervention을 일치시킨다.";
            }
        }

        // 7. Completed goal must not stay active.
        JSONObject p=CentralTherapyProfile.loadProfile(c);
        String goalStatus=p.optString("last_goal_status","UNCHANGED");
        String activeGoal=p.optString("active_therapy_goal","");
        if("COMPLETED".equals(goalStatus) && !activeGoal.isEmpty()){
            x.fail("COMPLETED_GOAL_STILL_ACTIVE");
            x.repairInstruction="완료된 목표를 active target으로 유지하지 않는다.";
        }

        // 8. Hypothesis board constraints.
        JSONObject f=CentralTherapyProfile.loadFormulation(c);
        JSONArray hs=f.optJSONArray("alternative_hypotheses");
        int active=0;
        if(hs!=null){
            for(int i=0;i<hs.length();i++){
                JSONObject h=hs.optJSONObject(i);
                if(h!=null&&h.optBoolean("active",true))active++;
            }
        }
        if(active>4){
            x.fail("TOO_MANY_ACTIVE_HYPOTHESES");
            x.repairInstruction="active competing hypotheses를 최대 4개로 제한한다.";
        }

        // 9. A reopened formulation cannot simultaneously claim high certainty.
        if(d.formulationReopened){
            String band=d.evidenceCalibrationBand==null?"":d.evidenceCalibrationBand;
            if("HIGH".equalsIgnoreCase(band)){
                x.fail("REOPEN_WITH_HIGH_CONFIDENCE");
                x.repairInstruction="reopen 상태에서는 높은 확신을 사용자에게 제시하지 않는다.";
            }
        }

        // 10. Context-blocked memory cannot drive central insight.
        if(d.contextBlockedMemoryCount>0 && d.centralInsightUsable){
            x.fail("BLOCKED_MEMORY_WITH_USABLE_INSIGHT");
            x.repairInstruction="현재 맥락에서 사용할 수 없는 장기기억이 central insight를 지지하지 않도록 한다.";
        }

        return x;
    }

    public static void applyRepair(ClinicalDecisionRC7 d,Check x){
        if(d==null||x==null)return;

        if(x.repairedMove!=null&&!x.repairedMove.isEmpty()){
            d.move=x.repairedMove;
            if("FORMULATE".equals(x.repairedMove)){
                d.directText="";
            }
        }

        if(x.repairInstruction!=null&&!x.repairInstruction.isEmpty()){
            d.responseInstruction=(d.responseInstruction==null?"":d.responseInstruction+" ")
                    +"[RELEASE_REPAIR] "+x.repairInstruction;
        }
    }

    public static String summary(Check x){
        if(x==null)return "release_integrity=null";
        if(x.pass)return "PASS";
        return "FAIL "+x.failures.toString()
                +(x.repairedMove.isEmpty()?"":" -> "+x.repairedMove);
    }

    public static String instruction(Check x){
        if(x==null||x.pass)return "";
        return "RELEASE_INTEGRITY_FAIL=true. 내부 임상 흐름 규칙이 깨졌다. "
                +"깨진 규칙을 먼저 복구한 뒤 응답을 생성한다. failures="+x.failures;
    }

    private static int count(String s,char c){
        int n=0;
        if(s==null)return 0;
        for(int i=0;i<s.length();i++)if(s.charAt(i)==c)n++;
        return n;
    }
}
