package com.maeummon.app;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.Random;

public class RoutineMissionManager {

    private static final String[] MISSIONS = {
            "물 한 잔 천천히 마시기",
            "어깨와 목 3분 스트레칭하기",
            "창밖이나 먼 곳 1분 바라보기",
            "오늘 잘한 일 하나 적기",
            "5분 동안 아무것도 하지 않고 쉬기",
            "답장 미뤄둔 것 하나만 처리하기",
            "내가 지금 원하는 것 한 문장 적기",
            "좋아하는 노래 한 곡 끝까지 듣기",
            "방이나 책상에서 작은 것 하나 정리하기",
            "오늘 고마웠던 순간 하나 떠올리기",
            "밖에 나갈 수 있으면 5분 걷기",
            "배고프다면 간단하게라도 챙겨 먹기"
    };

    public static String today() {
        return new SimpleDateFormat("yyyy-MM-dd", Locale.KOREA).format(new Date());
    }

    public static String currentSlot() {
        int hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
        if (hour < 6) return "새벽";
        if (hour < 11) return "아침";
        if (hour < 14) return "점심";
        if (hour < 18) return "오후";
        if (hour < 22) return "저녁";
        return "밤";
    }

    public static String routineLine(Context context) {
        String slot = currentSlot();
        SharedPreferences p = context.getSharedPreferences(AppPrefs.PREFS, Context.MODE_PRIVATE);
        int score = p.getInt(AppPrefs.KEY_LAST_CHECKIN_SCORE, 0);

        if ("새벽".equals(slot)) return "승재야, 지금은 생각보다 잠이 더 필요한 시간이야. 결론은 내일의 너에게 넘겨도 돼.";
        if ("아침".equals(slot)) return score > 0 && score <= 2
                ? "좋은 아침이야. 오늘 컨디션이 낮게 시작했으니 목표를 평소보다 작게 잡자."
                : "좋은 아침이야, 승재야. 오늘 몸이랑 마음 중 어느 쪽 컨디션이 더 좋은지 한번 느껴봐.";
        if ("점심".equals(slot)) return "점심 시간이네. 배고픔이나 피곤함을 마음 문제로 착각하고 있진 않은지 한번 챙겨보자.";
        if ("오후".equals(slot)) return "오후엔 에너지가 떨어질 수 있어. 지금 꼭 해야 하는 것과 미뤄도 되는 걸 나눠보자.";
        if ("저녁".equals(slot)) return "오늘 하루 거의 다 왔어. 잘한 것 하나랑 힘들었던 것 하나만 남겨도 충분해.";
        return "오늘을 더 잘하려고 애쓰지 않아도 돼. 이제 몸이 쉬는 쪽으로 천천히 넘어가자.";
    }

    public static boolean shouldShowRoutine(Context context) {
        SharedPreferences p = context.getSharedPreferences(AppPrefs.PREFS, Context.MODE_PRIVATE);
        String today = today();
        String slot = currentSlot();
        return !today.equals(p.getString(AppPrefs.KEY_ROUTINE_LAST_DATE, ""))
                || !slot.equals(p.getString(AppPrefs.KEY_ROUTINE_LAST_SLOT, ""));
    }

    public static void markRoutineShown(Context context) {
        context.getSharedPreferences(AppPrefs.PREFS, Context.MODE_PRIVATE).edit()
                .putString(AppPrefs.KEY_ROUTINE_LAST_DATE, today())
                .putString(AppPrefs.KEY_ROUTINE_LAST_SLOT, currentSlot())
                .apply();
    }

    public static String getMission(Context context) {
        SharedPreferences p = context.getSharedPreferences(AppPrefs.PREFS, Context.MODE_PRIVATE);
        String today = today();
        if (today.equals(p.getString(AppPrefs.KEY_DAILY_MISSION_DATE, ""))) {
            int id = p.getInt(AppPrefs.KEY_DAILY_MISSION_ID, 0);
            return MISSIONS[Math.max(0, Math.min(MISSIONS.length - 1, id))];
        }

        int seed = today.hashCode() ^ CompanionProfile.getAffection(context);
        Random r = new Random(seed);
        int id = r.nextInt(MISSIONS.length);
        p.edit()
                .putString(AppPrefs.KEY_DAILY_MISSION_DATE, today)
                .putInt(AppPrefs.KEY_DAILY_MISSION_ID, id)
                .apply();
        return MISSIONS[id];
    }

    public static boolean missionDone(Context context) {
        SharedPreferences p = context.getSharedPreferences(AppPrefs.PREFS, Context.MODE_PRIVATE);
        return today().equals(p.getString(AppPrefs.KEY_DAILY_MISSION_DONE_DATE, ""));
    }

    public static boolean completeMission(Context context) {
        if (missionDone(context)) return false;
        context.getSharedPreferences(AppPrefs.PREFS, Context.MODE_PRIVATE).edit()
                .putString(AppPrefs.KEY_DAILY_MISSION_DONE_DATE, today())
                .apply();
        CompanionProfile.addAffection(context, 2);
        PetStateManager.onTodoSaved(context, true);
        return true;
    }

    public static String missionSummary(Context context) {
        return (missionDone(context) ? "완료 ✓  " : "오늘의 미션 · ") + getMission(context);
    }

    public static int diaryStreak(Context context) {
        JSONArray entries = EmotionDiaryStorage.getEntries(context);
        if (entries.length() == 0) return 0;
        int streak = 0;
        Calendar cal = Calendar.getInstance();
        SimpleDateFormat fmt = new SimpleDateFormat("yyyy-MM-dd", Locale.KOREA);
        for (int i = 0; i < 31; i++) {
            String d = fmt.format(cal.getTime());
            if (EmotionDiaryStorage.getEntryByDate(context, d) != null) {
                streak++;
            } else if (i == 0) {
                // 오늘 기록 전이면 어제부터 계산
            } else {
                break;
            }
            cal.add(Calendar.DATE, -1);
        }
        return streak;
    }

    public static String specialEvent(Context context) {
        int affection = CompanionProfile.getAffection(context);
        int streak = diaryStreak(context);
        if (streak >= 30) return "한 달 동안 마음을 돌아봤네. 승재야, 이건 꽤 큰 일이야. 네 마음을 계속 외면하지 않았다는 뜻이니까.";
        if (streak >= 14) return "속마음 일기를 2주나 이어왔네. 완벽하게 쓰는 것보다 다시 돌아오는 힘이 더 중요해.";
        if (streak >= 7) return "일주일 연속 마음을 남겼어! 어린 승재가 진짜 기특해하고 있어 🌱";
        if (affection >= 80) return "우리 친밀도가 Lv.5까지 왔어. 이제 나는 승재가 어떤 날에 조금 더 조용한 위로가 필요한지도 알아가는 중이야.";
        if (affection >= 55) return "우리 꽤 많이 친해졌네. 지금까지 쌓인 기록이 그냥 숫자가 아니라 승재의 시간이야.";
        return "";
    }

    public static boolean shouldShowSpecialEvent(Context context) {
        String event = specialEvent(context);
        if (event.isEmpty()) return false;
        SharedPreferences p = context.getSharedPreferences(AppPrefs.PREFS, Context.MODE_PRIVATE);
        return !event.equals(p.getString(AppPrefs.KEY_SPECIAL_EVENT_SEEN, ""));
    }

    public static void markSpecialEventSeen(Context context) {
        String event = specialEvent(context);
        if (!event.isEmpty()) {
            context.getSharedPreferences(AppPrefs.PREFS, Context.MODE_PRIVATE).edit()
                    .putString(AppPrefs.KEY_SPECIAL_EVENT_SEEN, event).apply();
        }
    }
}
