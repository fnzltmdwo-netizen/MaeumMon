package com.maeummon.app.clinical;

import android.content.Context;
import org.json.*;

public final class StableMemoryPromotionDemotionRC8 {
    private StableMemoryPromotionDemotionRC8(){}

    public static final class Result {
        public int promoted=0;
        public int demoted=0;
        public int held=0;
        public String summary="";
    }

    public static Result sync(Context c){
        Result r=new Result();
        if(c==null)return r;

        JSONObject f=CentralTherapyProfile.loadFormulation(c);
        JSONObject p=CentralTherapyProfile.loadProfile(c);

        JSONArray ledger=f.optJSONArray("evidence_ledger");
        if(ledger==null)return r;

        JSONArray stable=p.optJSONArray("stable_profile");
        if(stable==null)stable=new JSONArray();

        // 1) Promote only explicit PROMOTE evidence.
        for(int i=0;i<ledger.length();i++){
            JSONObject e=ledger.optJSONObject(i);
            if(e==null)continue;

            String status=e.optString("admission_status","");
            boolean eligible=e.optBoolean("eligible_for_stable_promotion",false);
            String text=e.optString("text","");
            String source=e.optString("source_type","UNKNOWN");
            double confidence=e.optDouble("confidence",0.0);

            if("PROMOTE".equals(status) && eligible && !text.isEmpty()){
                if(!containsStable(stable,text)){
                    JSONObject item=new JSONObject();
                    try{
                        item.put("text",text);
                        item.put("source","evidence_gate:"+source);
                        item.put("confidence",Math.max(0.70,Math.min(0.90,confidence)));
                        item.put("status","ACTIVE");
                        item.put("promoted_from_evidence",true);
                        item.put("time",System.currentTimeMillis());
                        stable.put(item);
                        r.promoted++;
                    }catch(Exception ignored){}
                }
            }
        }

        // 2) Demote stable items when newer evidence contradicts or source became invalid.
        JSONArray conflicts=f.optJSONArray("evidence_conflict_matrix");
        for(int i=0;i<stable.length();i++){
            JSONObject s=stable.optJSONObject(i);
            if(s==null)continue;

            String text=s.optString("text","");
            if(text.isEmpty())continue;

            boolean contradicted=hasStrongContradiction(ledger,text);
            boolean unresolvedConflict=isConflicted(conflicts,text);
            boolean stale=isStale(s);

            if(contradicted){
                try{
                    s.put("status","DEMOTED");
                    s.put("demotion_reason","newer strong contradiction");
                    s.put("confidence",Math.max(0.35,s.optDouble("confidence",0.70)-0.30));
                    s.put("demoted_at",System.currentTimeMillis());
                    r.demoted++;
                }catch(Exception ignored){}
            }else if(unresolvedConflict){
                try{
                    s.put("status","HOLD");
                    s.put("demotion_reason","unresolved evidence conflict");
                    s.put("confidence",Math.max(0.45,s.optDouble("confidence",0.70)-0.15));
                    r.held++;
                }catch(Exception ignored){}
            }else if(stale){
                try{
                    s.put("status","HOLD");
                    s.put("demotion_reason","stale stable memory");
                    s.put("confidence",Math.max(0.50,s.optDouble("confidence",0.70)-0.10));
                    r.held++;
                }catch(Exception ignored){}
            }
        }

        stable=tailStable(stable,24);

        try{
            p.put("stable_profile",stable);
            p.put("stable_memory_sync_summary",
                    "promoted="+r.promoted+", demoted="+r.demoted+", held="+r.held);
            p.put("stable_memory_sync_updated_at",System.currentTimeMillis());
            CentralTherapyProfile.replaceProfile(c,p);
        }catch(Exception ignored){}

        r.summary="promoted="+r.promoted+", demoted="+r.demoted+", held="+r.held;
        return r;
    }

    public static String instruction(Result r){
        if(r==null)return "";
        return "STABLE_MEMORY_SYNC=true. stable_profile에는 PROMOTE evidence만 승격한다. "
                +"새로운 강한 반증이나 unresolved conflict가 생기면 기존 장기기억을 고집하지 않고 HOLD/DEMOTED 처리한다. "
                +r.summary;
    }

    private static boolean containsStable(JSONArray stable,String text){
        for(int i=0;i<stable.length();i++){
            JSONObject o=stable.optJSONObject(i);
            if(o!=null&&text.equals(o.optString("text",""))
                    &&!"DEMOTED".equals(o.optString("status","ACTIVE")))return true;
        }
        return false;
    }

    private static boolean hasStrongContradiction(JSONArray ledger,String stableText){
        for(int i=ledger.length()-1;i>=0;i--){
            JSONObject e=ledger.optJSONObject(i);
            if(e==null)continue;
            String source=e.optString("source_type","");
            String status=e.optString("admission_status","");
            String text=e.optString("text","");

            if(!("USER_CORRECTION".equals(source)||"USER_DIRECT".equals(source)))continue;
            if(!("ADMIT".equals(status)||"PROMOTE".equals(status)))continue;

            if(opposes(stableText,text))return true;
        }
        return false;
    }

    private static boolean opposes(String oldText,String newText){
        if(oldText==null||newText==null)return false;

        if(containsAny(oldText,"항상","늘","매번","자주")
                && containsAny(newText,"항상 그런 건 아니","이번만","가끔","그건 내 패턴 아니"))
            return true;

        if(containsAny(oldText,"싸움","갈등","다툼")
                && containsAny(newText,"싸운 일 없어","갈등 없어","다툰 적 없어"))
            return true;

        if(containsAny(oldText,"원래 느려","늘 느려")
                && containsAny(newText,"최근부터","예전엔 빨랐","갑자기 느려"))
            return true;

        if(containsAny(oldText,"나한테만","유독 나한테")
                && containsAny(newText,"누구에게나","모두한테"))
            return true;

        return false;
    }

    private static boolean isConflicted(JSONArray conflicts,String text){
        if(conflicts==null)return false;
        for(int i=0;i<conflicts.length();i++){
            JSONObject c=conflicts.optJSONObject(i);
            if(c==null||!c.optBoolean("unresolved",false))continue;
            String key=c.optString("key","");
            if("relationship_baseline".equals(key)
                    &&containsAny(text,"원래","최근","예전","답장"))return true;
            if("recent_conflict".equals(key)
                    &&containsAny(text,"싸","갈등","다툼"))return true;
            if("selective_change".equals(key)
                    &&containsAny(text,"나한테만","모두한테","누구에게나"))return true;
            if("work_stressor".equals(key)
                    &&containsAny(text,"회사","업무","평가","상사"))return true;
        }
        return false;
    }

    private static boolean isStale(JSONObject s){
        long time=s.optLong("time",0);
        if(time<=0)return false;
        long days=Math.max(0,(System.currentTimeMillis()-time)/(24L*60L*60L*1000L));
        return days>180;
    }

    private static JSONArray tailStable(JSONArray src,int max){
        JSONArray out=new JSONArray();
        int start=Math.max(0,src.length()-max);
        for(int i=start;i<src.length();i++)out.put(src.opt(i));
        return out;
    }

    private static boolean containsAny(String s,String... xs){
        if(s==null)return false;
        for(String x:xs)if(s.contains(x))return true;
        return false;
    }
}
