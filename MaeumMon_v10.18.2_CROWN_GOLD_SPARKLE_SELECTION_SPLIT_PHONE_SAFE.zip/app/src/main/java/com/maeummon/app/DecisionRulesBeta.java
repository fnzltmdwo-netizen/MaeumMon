package com.maeummon.app;

import android.content.Context;

import java.util.Locale;

/**
 * v5.0 Decision Router.
 * Public counseling-case coding distilled into next-move rules.
 * These are reasoning/sequence rules, not an identity or diagnosis clone.
 */
public final class DecisionRulesBeta {
    private DecisionRulesBeta() {}

    public static String buildContext(Context c, String userMessage) {
        String m = userMessage == null ? "" : userMessage.toLowerCase(Locale.KOREA);
        String thread = TherapyThreadManager.snapshot(c);
        boolean hasThread = !thread.contains("없음.");
        boolean safety = containsAny(m, "죽고", "죽고싶", "자해", "해치", "폭력", "때렸", "칼", "흉기", "차도로", "뛰어내");
        boolean root = containsAny(m, "왜 나는", "왜이래", "왜 이래", "근본", "뿌리", "어릴 때", "어렸을 때", "어렸을때부터", "트라우마");
        boolean label = containsAny(m, "adhd", "우울증", "공황", "애착", "회피형", "나르시", "피해의식", "완벽주의", "성격", "mbti", "t야", "f야");
        boolean relation = containsAny(m, "엄마", "아빠", "친구", "연인", "남친", "여친", "남편", "아내", "상대", "회사", "사수", "동료");
        boolean intentGuess = containsAny(m, "일부러", "나 싫어", "무시", "만만", "미워", "마음이", "호감", "의도", "왜 저래");
        boolean change = containsAny(m, "어떻게 바꿔", "어떻게 고쳐", "어케 고쳐", "어케 바꿔", "뭘 해야", "방법", "연습");

        StringBuilder b = new StringBuilder();
        b.append("[Decision Router v5.0 — 300 CASE V4 다음 상담수 선택]\n");
        b.append("이 라우터는 300개 공개 상담 DEEP 사례에서 정리된 V4 판단순서를 앱용으로 일반화한 것이다. 사실보다 우선하지 않으며 실존 상담가의 정체성/비공개 판단을 복제하지 않는다.\n");
        if (safety) {
            b.append("PRIORITY 1 SAFETY: 현재 메시지에 위험 신호가 있다. 해석/뿌리보다 LIMIT·안전 확인을 먼저 하고 필요한 최소 질문만 한다.\n");
        }
        if (hasThread) {
            b.append("PRIORITY 2 CONTINUITY: ACTIVE_THERAPY_THREAD가 살아 있다. 사용자가 명확히 다른 주제로 옮기지 않았다면 새 상담으로 재시작하지 말고 같은 줄기에서 아직 비어 있는 핵심 슬롯 하나를 채운다.\n");
            b.append("- 질문은 정보가치가 가장 높은 1개만. 이미 답한 것을 재질문하지 않는다.\n");
            b.append("- 탐색 중간에 매번 조언으로 닫지 않는다. 핵심 구조가 충분할 때만 FORMULATE/CHANGE로 넘어간다.\n");
        }
        if (label) {
            b.append("PRIORITY 3 REASSESS LABEL: 사용자가 진단/성격/라벨을 제시했다. 라벨을 원인으로 확정하지 말고 현재 기능·맥락·상호작용으로 설명력이 충분한지 검사한다. 설명되지 않는 정보가 있으면 가설을 수정한다.\n");
        }
        if (relation && intentGuess) {
            b.append("PRIORITY 4 RELATIONSHIP REALITY: FACT / 상대 INTENT 추정 / 사용자에게 미친 IMPACT를 분리한다. 선의·호감·악의 어느 쪽도 근거 없이 확정하지 않는다.\n");
        }
        if (root) {
            b.append("PRIORITY 5 DEPTH MODE: 현재 사건→그 사건에 붙는 의미→핵심 두려움→핵심 욕구→보호행동→단기 이득/장기 비용 순으로 내려간다. 과거는 현재 강도를 더 잘 설명하는 단서가 생겼을 때 한 장면만 연다.\n");
            b.append("- '트라우마/애착문제' 같은 라벨부터 붙이지 않는다. 먼저 현재에서 뿌리로 연결한다.\n");
        }
        if (change) {
            b.append("PRIORITY 6 CHANGE: 충분한 사례개념화가 이미 있다면 핵심 재정의 1문장 → 가능하면 정체성 재해석 1문장 → 현실 행동/문장 1개로 끝낸다.\n");
        }
        b.append("PRIORITY 7 TURNING POINT: 새 정보가 기존 가설과 충돌하면 이전 해석을 방어하지 말고 TURNING_POINT로 기록하고 가설을 폐기/수정한다.\n");
        b.append("PRIORITY 8 LIVE INTERACTION: 상담 중 반복되는 화법/회피/압박이 관찰되면 내용만 분석하지 말고 대화 기능 자체를 피드백한다. 한 문장으로 성격 낙인은 금지한다.\n");
        b.append("PRIORITY 9 FOLLOWUP: 이전 행동실험/연습이 있으면 '했어?'보다 EXPECTED vs ACTUAL을 먼저 회수해 formulation을 업데이트한다.\n");
        b.append("\n[현재 스레드]\n").append(thread).append("\n");
        b.append("[이번 턴 목표] 답변을 완결된 에세이처럼 만들지 말고, 현재 세션 단계에 필요한 다음 한 수만 정확히 고른다.\n");
        return b.toString();
    }

    private static boolean containsAny(String text, String... needles) {
        for (String n : needles) if (text.contains(n.toLowerCase(Locale.KOREA))) return true;
        return false;
    }
}
