package com.maeummon.app.clinical;

import android.content.Context;
import org.json.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

public final class ClinicalKnowledgeRC7 {
    private ClinicalKnowledgeRC7(){}
    private static volatile List<Unit> CACHE;
    private static volatile String LOAD_ERROR="";
    private static volatile boolean FALLBACK_USED=false;

    public static final class Unit{
        public String id="",type="",title="",domain="",target="",question="",intervention="",principle="";
        public double weight=.5;
        public final List<String> signals=new ArrayList<>();
    }

    public static List<Unit> all(Context c){
        if(CACHE!=null)return CACHE;
        synchronized(ClinicalKnowledgeRC7.class){
            if(CACHE!=null)return CACHE;
            ArrayList<Unit> out=new ArrayList<>();
            LOAD_ERROR=""; FALLBACK_USED=false;
            try{
                String raw=readAsset(c,"clinical/rc7_units.json");
                JSONArray a=new JSONArray(raw);
                for(int i=0;i<a.length();i++){
                    JSONObject o=a.optJSONObject(i); if(o==null)continue;
                    Unit u=new Unit();
                    u.id=o.optString("id",""); u.type=o.optString("type",""); u.title=o.optString("title","");
                    u.domain=o.optString("domain",""); u.target=o.optString("target_variable","");
                    u.question=o.optString("question",""); u.intervention=o.optString("intervention","");
                    u.principle=o.optString("derived_principle",""); u.weight=o.optDouble("evidence_weight",.5);
                    JSONArray s=o.optJSONArray("signals");
                    if(s!=null)for(int j=0;j<s.length();j++){String x=s.optString(j,"");if(!x.isEmpty())u.signals.add(x);}
                    if(!u.id.isEmpty())out.add(u);
                }
                if(out.isEmpty()) throw new IllegalStateException("rc7_units.json parsed but contained 0 usable units");
            }catch(Exception e){
                LOAD_ERROR=e.getClass().getSimpleName()+": "+String.valueOf(e.getMessage());
                FALLBACK_USED=true;
                addFallback(out,"RC7_FALLBACK_BASELINE","baseline_relationship_change","그 사람이 원래도 답장이 느린 편이었어, 아니면 최근에 달라진 거야?");
                addFallback(out,"RC7_FALLBACK_CONFLICT","recent_conflict","최근 둘 사이에 싸우거나 서운할 만한 일이 있었어?");
                addFallback(out,"RC7_FALLBACK_MEANING","meaning_attribution","그 답장 지연이 너한테는 어떤 의미처럼 느껴졌어?");
                addFallback(out,"RC7_FALLBACK_GOAL","goal_agreement","지금 네가 원하는 건 먼저 이해받는 거야, 해결책을 같이 찾는 거야?");
                addFallback(out,"RC7_FALLBACK_TASK","task_agreement","지금 질문 방식이 너무 많은 게 제일 답답했던 거야?");
                addFallback(out,"RC7_FALLBACK_RUPTURE","rupture_point","내가 방금 한 말 중에서 제일 안 맞거나 답답했던 부분이 뭐였어?");
            }
            CACHE=Collections.unmodifiableList(out); return CACHE;
        }
    }

    public static String loadError(){return LOAD_ERROR;}
    public static boolean fallbackUsed(){return FALLBACK_USED;}
    public static boolean loadedNormally(){return CACHE!=null && !CACHE.isEmpty() && !FALLBACK_USED;}
    public static void clearCache(){synchronized(ClinicalKnowledgeRC7.class){CACHE=null;LOAD_ERROR="";FALLBACK_USED=false;}}

    public static boolean hasTarget(Context c,String target){
        for(Unit u:all(c)) if(target!=null && target.equals(u.target) && "QDU".equals(u.type) && !u.question.isEmpty()) return true;
        return false;
    }

    public static boolean hasUsableTarget(Context c,String target){
        return hasTarget(c,target) || fallbackForTarget(target)!=null;
    }

    public static Unit fallbackForTarget(String target){
        if(target==null)return null;
        if("baseline_relationship_change".equals(target))return fallback("RC7_FALLBACK_BASELINE",target,"그 사람이 원래도 답장이 느린 편이었어, 아니면 최근에 달라진 거야?");
        if("recent_conflict".equals(target))return fallback("RC7_FALLBACK_CONFLICT",target,"최근 둘 사이에 싸우거나 서운할 만한 일이 있었어?");
        if("meaning_attribution".equals(target))return fallback("RC7_FALLBACK_MEANING",target,"그 답장 지연이 너한테는 어떤 의미처럼 느껴졌어?");
        if("goal_agreement".equals(target))return fallback("RC7_FALLBACK_GOAL",target,"지금 네가 원하는 건 먼저 이해받는 거야, 해결책을 같이 찾는 거야?");
        if("task_agreement".equals(target))return fallback("RC7_FALLBACK_TASK",target,"지금 질문 방식이 너무 많은 게 제일 답답했던 거야?");
        if("rupture_point".equals(target))return fallback("RC7_FALLBACK_RUPTURE",target,"내가 방금 한 말 중에서 제일 안 맞거나 답답했던 부분이 뭐였어?");
        return null;
    }

    private static Unit fallback(String id,String target,String question){
        Unit u=new Unit();u.id=id;u.type="QDU";u.title="RC7 built-in target fallback";u.domain="fallback";
        u.target=target;u.question=question;u.weight=.40;return u;
    }

    private static void addFallback(List<Unit> out,String id,String target,String question){
        Unit u=new Unit(); u.id=id;u.type="QDU";u.title="RC7 built-in fallback";u.domain="fallback";
        u.target=target;u.question=question;u.weight=.40;out.add(u);
    }

    private static String readAsset(Context c,String path)throws Exception{
        if(c==null)throw new IllegalArgumentException("Context is null");
        InputStream in=c.getAssets().open(path); ByteArrayOutputStream out=new ByteArrayOutputStream(); byte[] b=new byte[8192]; int n;
        while((n=in.read(b))!=-1)out.write(b,0,n); in.close(); return out.toString(StandardCharsets.UTF_8.name());
    }
}
