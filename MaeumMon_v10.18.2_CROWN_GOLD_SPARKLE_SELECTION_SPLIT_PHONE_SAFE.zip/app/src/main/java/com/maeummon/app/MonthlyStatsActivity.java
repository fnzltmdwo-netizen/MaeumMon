package com.maeummon.app;

import com.maeummon.app.clinical.TherapySurfaceContext;

import com.maeummon.app.clinical.CentralTherapyProfile;

import android.app.Activity;
import android.os.Bundle;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.Calendar;
import java.util.LinkedHashMap;
import java.util.Map;

public class MonthlyStatsActivity extends Activity {
    private int year;
    private int month;
    private final String[] labels = {"좋음", "잔잔", "지침", "슬픔", "불안", "화남", "위로", "잠옴"};
    private final String[] emojis = {"😊", "🙂", "😮‍💨", "😢", "😟", "😠", "🥹", "😴"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (DiarySecurity.redirectToUnlockIfNeeded(this)) return;
        setContentView(R.layout.activity_monthly_stats);
        UiInsets.apply(this, findViewById(R.id.statsRoot));

        Calendar c = Calendar.getInstance();
        year = c.get(Calendar.YEAR);
        month = c.get(Calendar.MONTH);

        findViewById(R.id.statsPrevMonthButton).setOnClickListener(v -> {
            month--;
            if (month < 0) {
                month = 11;
                year--;
            }
            render();
        });
        findViewById(R.id.statsNextMonthButton).setOnClickListener(v -> {
            month++;
            if (month > 11) {
                month = 0;
                year++;
            }
            render();
        });
        render();
    }

    private void render() {
        TextView monthText = findViewById(R.id.statsMonthText);
        TextView summaryText = findViewById(R.id.statsSummaryText);
        TextView causeText = findViewById(R.id.causeStatsText);
        TextView keywordText = findViewById(R.id.keywordStatsText);
        TextView adviceText = findViewById(R.id.statsAdviceText);
        LinearLayout rows = findViewById(R.id.statsRowsContainer);

        monthText.setText(year + "년 " + (month + 1) + "월");
        rows.removeAllViews();

        JSONArray arr = EmotionDiaryStorage.getEntriesForMonth(this, year, month);
        Map<String, Integer> counts = new LinkedHashMap<>();
        for (String label : labels) counts.put(label, 0);

        for (int i = 0; i < arr.length(); i++) {
            JSONObject obj = arr.optJSONObject(i);
            if (obj == null) continue;
            String label = obj.optString("label", "잔잔");
            if (counts.containsKey(label)) counts.put(label, counts.get(label) + 1);
        }

        String topEmotion = EmotionDiaryStorage.topKey(counts);
        int max = 1;
        for (int n : counts.values()) max = Math.max(max, n);

        summaryText.setText(
                "기록한 날 " + arr.length() + "일\n"
                        + "대표 감정: " + topEmotion + "\n"
                        + "사진 일기: " + countPhotos(arr) + "일"
        );

        for (int i = 0; i < labels.length; i++) {
            addRow(rows, emojis[i] + " " + labels[i], counts.get(labels[i]), max);
        }

        Map<String, Integer> causes = EmotionDiaryStorage.countCauses(arr);
        Map<String, Integer> tags = EmotionDiaryStorage.countTags(arr);
        causeText.setText(formatMap("마음을 흔든 일 TOP", causes));
        keywordText.setText(formatMap("자주 나온 키워드 TOP", tags));

        if (arr.length() == 0) {
            adviceText.setText("승재야, 이번 달은 아직 기록이 없어. 마음 한 줄과 이유 하나부터 시작해보자.");
        } else {
            String topCause = EmotionDiaryStorage.topKey(causes);
            String monthly = "승재야, 이번 달엔 '" + topEmotion + "' 마음이 자주 보였고, '"
                    + topCause + "' 때문에 흔들린 날이 많았어. "
                    + "감정을 없애려 하기보다, 그 상황을 어떻게 덜 힘들게 만들지 보는 게 더 중요해.";
            String centralMonthlyHint = CentralTherapyProfile.reportHint(this, "월간");
            adviceText.setText(
                    UnifiedTherapyProfile.monthlyAdvice(this, monthly)
                            + (centralMonthlyHint.isEmpty() ? "" : "\n\n" + centralMonthlyHint));
        }
    }

    private int countPhotos(JSONArray arr) {
        int n = 0;
        for (int i = 0; i < arr.length(); i++) {
            JSONObject obj = arr.optJSONObject(i);
            if (obj != null && !obj.optString("photoUri", "").isEmpty()) n++;
        }
        return n;
    }

    private String formatMap(String title, Map<String, Integer> map) {
        if (map.isEmpty()) return title + "\n아직 기록 없음";

        StringBuilder sb = new StringBuilder(title).append("\n");
        int n = 0;
        for (Map.Entry<String, Integer> e : map.entrySet()) {
            sb.append("• ")
                    .append(e.getKey())
                    .append("  ")
                    .append(e.getValue())
                    .append("회\n");
            if (++n >= 6) break;
        }
        return sb.toString().trim();
    }

    private void addRow(LinearLayout parent, String label, int count, int max) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.VERTICAL);
        row.setPadding(0, dp(7), 0, dp(7));

        TextView text = new TextView(this);
        text.setText(label + "  " + count + "회");
        text.setTextColor(0xFF4F5569);
        text.setTextSize(14f);

        ProgressBar bar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        bar.setMax(max);
        bar.setProgress(count);
        bar.setProgressDrawable(getDrawable(R.drawable.progress_affection));

        row.addView(text, new LinearLayout.LayoutParams(-1, -2));
        LinearLayout.LayoutParams barParams = new LinearLayout.LayoutParams(-1, dp(12));
        barParams.topMargin = dp(5);
        row.addView(bar, barParams);
        parent.addView(row);
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }
}
