package com.maeummon.app;

import com.maeummon.app.clinical.TherapySurfaceContext;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class MoodCalendarActivity extends Activity {
    private int currentYear;
    private int currentMonth;
    private String selectedDate;
    private TextView selectedDateTitle, selectedMoodLabel, insightStatus, insightSummary, insightPrescription, insightMeta, insightLoading;
    private ImageView selectedMoodIcon;
    private Button prevRecordButton, nextRecordButton;
    private TextView recordPagerText, selectedRecordText;
    private JSONArray selectedRecords = new JSONArray();
    private int selectedRecordIndex = 0;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (DiarySecurity.redirectToUnlockIfNeeded(this)) return;
        setContentView(R.layout.activity_mood_calendar);
        UiInsets.apply(this, findViewById(R.id.calendarRoot));

        selectedDateTitle = findViewById(R.id.selectedDateTitle);
        selectedMoodLabel = findViewById(R.id.selectedMoodLabel);
        selectedMoodIcon = findViewById(R.id.selectedMoodIcon);
        insightStatus = findViewById(R.id.insightStatus);
        insightSummary = findViewById(R.id.insightSummary);
        insightPrescription = findViewById(R.id.insightPrescription);
        insightMeta = findViewById(R.id.insightMeta);
        insightLoading = findViewById(R.id.insightLoading);
        prevRecordButton = findViewById(R.id.prevRecordButton);
        nextRecordButton = findViewById(R.id.nextRecordButton);
        recordPagerText = findViewById(R.id.recordPagerText);
        selectedRecordText = findViewById(R.id.selectedRecordText);

        prevRecordButton.setOnClickListener(v -> moveRecord(-1));
        nextRecordButton.setOnClickListener(v -> moveRecord(1));

        Calendar now = Calendar.getInstance();
        currentYear = now.get(Calendar.YEAR);
        currentMonth = now.get(Calendar.MONTH);
        selectedDate = new SimpleDateFormat(EmotionDiaryStorage.DATE_FORMAT, Locale.KOREA).format(now.getTime());

        findViewById(R.id.prevMonthButton).setOnClickListener(v -> {
            currentMonth--; if (currentMonth < 0) { currentMonth = 11; currentYear--; }
            selectFirstRelevantDate(); renderCalendar();
        });
        findViewById(R.id.nextMonthButton).setOnClickListener(v -> {
            currentMonth++; if (currentMonth > 11) { currentMonth = 0; currentYear++; }
            selectFirstRelevantDate(); renderCalendar();
        });
        renderCalendar();
        showInsight(selectedDate, true);
    }

    @Override protected void onResume() {
        super.onResume();
        renderCalendar();
        if (selectedDate != null) showInsight(selectedDate, false);
    }

    private void selectFirstRelevantDate() {
        Calendar today = Calendar.getInstance();
        if (today.get(Calendar.YEAR) == currentYear && today.get(Calendar.MONTH) == currentMonth) {
            selectedDate = formatDate(currentYear, currentMonth, today.get(Calendar.DAY_OF_MONTH));
            return;
        }
        Calendar c = Calendar.getInstance(); c.set(currentYear, currentMonth, 1);
        int max = c.getActualMaximum(Calendar.DAY_OF_MONTH);
        for (int d = max; d >= 1; d--) {
            String date = formatDate(currentYear, currentMonth, d);
            if (DailyMoodInsightManager.hasRecords(this, date)) { selectedDate = date; return; }
        }
        selectedDate = formatDate(currentYear, currentMonth, 1);
    }

    private void renderCalendar() {
        GridLayout grid = findViewById(R.id.calendarGrid);
        TextView summary = findViewById(R.id.monthSummary);
        TextView month = findViewById(R.id.currentMonthText);
        grid.removeAllViews();
        month.setText(currentYear + "년 " + (currentMonth + 1) + "월");
        for (String w : new String[]{"일","월","화","수","목","금","토"}) grid.addView(headerCell(w));

        Calendar first = Calendar.getInstance(); first.set(currentYear,currentMonth,1);
        int firstDay = first.get(Calendar.DAY_OF_WEEK) - 1;
        int maxDay = first.getActualMaximum(Calendar.DAY_OF_MONTH);
        for (int i=0;i<firstDay;i++) grid.addView(dayCell(0,null,false,false));
        Calendar today=Calendar.getInstance();
        Map<String,Integer> counts = new LinkedHashMap<>();
        int recorded = 0;
        for(int day=1;day<=maxDay;day++){
            String date = formatDate(currentYear,currentMonth,day);
            boolean has = DailyMoodInsightManager.hasRecords(this,date);
            DailyMoodInsightManager.Insight insight = has ? DailyMoodInsightManager.cachedOrLocal(this,date) : null;
            if (insight != null) { recorded++; counts.put(insight.label, counts.containsKey(insight.label)?counts.get(insight.label)+1:1); }
            boolean isToday=today.get(Calendar.YEAR)==currentYear&&today.get(Calendar.MONTH)==currentMonth&&today.get(Calendar.DAY_OF_MONTH)==day;
            boolean isSelected=date.equals(selectedDate);
            grid.addView(dayCell(day,insight,isToday||isSelected,true));
        }
        if(recorded==0) summary.setText("이번 달 상담 기록이 아직 없어. 마음몬과 이야기하면 그날 마음 흐름이 자동으로 정리돼.");
        else summary.setText("이번 달 상담 기록이 남은 날은 " + recorded + "일이야. 가장 자주 보인 마음은 ‘" + topKey(counts) + "’이었어. 상담 내용이 달라지면 아이콘도 다시 읽어줘.");
    }

    private TextView headerCell(String text){
        TextView tv=new TextView(this);tv.setText(text);tv.setTextSize(14f);tv.setTypeface(Typeface.DEFAULT_BOLD);tv.setGravity(Gravity.CENTER);tv.setPadding(dp(4),dp(8),dp(4),dp(8));
        GridLayout.LayoutParams lp=new GridLayout.LayoutParams();lp.width=0;lp.columnSpec=GridLayout.spec(GridLayout.UNDEFINED,1f);tv.setLayoutParams(lp);return tv;
    }

    private View dayCell(int day, DailyMoodInsightManager.Insight insight, boolean highlighted, boolean clickable){
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setGravity(Gravity.CENTER);box.setPadding(dp(2),dp(6),dp(2),dp(6));box.setMinimumHeight(dp(70));
        if(day>0) box.setBackgroundResource(highlighted?R.drawable.bg_calendar_day_today:(insight!=null?R.drawable.bg_calendar_day_selected:R.drawable.bg_calendar_day));
        TextView date=new TextView(this);date.setText(day==0?"":String.valueOf(day));date.setTextSize(12f);date.setGravity(Gravity.CENTER);date.setTextColor(0xFF707782);box.addView(date,new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,dp(22)));
        if(insight!=null){
            ImageView iv=new ImageView(this);iv.setScaleType(ImageView.ScaleType.FIT_CENTER);iv.setImageResource(MoodStickerResources.imageForLabel(insight.label));
            LinearLayout.LayoutParams ip=new LinearLayout.LayoutParams(dp(40),dp(40));ip.gravity=Gravity.CENTER;box.addView(iv,ip);
        } else if(day>0){View spacer=new View(this);box.addView(spacer,new LinearLayout.LayoutParams(dp(40),dp(40)));}
        GridLayout.LayoutParams lp=new GridLayout.LayoutParams();lp.width=0;lp.columnSpec=GridLayout.spec(GridLayout.UNDEFINED,1f);lp.setMargins(dp(2),dp(2),dp(2),dp(2));box.setLayoutParams(lp);
        if(clickable&&day>0) box.setOnClickListener(v->{selectedDate=formatDate(currentYear,currentMonth,day);renderCalendar();showInsight(selectedDate,true);});
        return box;
    }

    private void showInsight(String date, boolean refreshAi) {
        loadRecordPager(date);
        boolean has = DailyMoodInsightManager.hasRecords(this,date);
        selectedDateTitle.setText(date + (date.equals(DailyMoodInsightManager.today()) ? " · 오늘" : ""));
        if(!has){
            DailyMoodInsightManager.Insight empty = DailyMoodInsightManager.localInsight(this,date);
            renderInsight(empty);
            insightLoading.setText("이 날에는 아직 상담 기록이 없어.");
            return;
        }
        DailyMoodInsightManager.Insight i = DailyMoodInsightManager.cachedOrLocal(this,date);
        renderInsight(i);
        DailyMoodInsightManager.Insight cached = DailyMoodInsightManager.getCached(this,date);
        if(cached != null || !refreshAi) {
            insightLoading.setText(cached != null ? "상담 내용을 바탕으로 정리했어 ✓" : "상담 기록을 바탕으로 먼저 정리해봤어.");
            return;
        }
        SharedPreferences prefs=getSharedPreferences(AppPrefs.PREFS,Context.MODE_PRIVATE);
        String apiKey=prefs.getString(AppPrefs.KEY_API_KEY,"").trim();
        if(apiKey.isEmpty()) { insightLoading.setText("API Key가 없어서 기기 안에서 먼저 정리해봤어."); return; }
        insightLoading.setText("그날 상담을 다시 읽고, 뭐가 힘들었고 지금 뭐가 필요한지 정리하는 중…");
        String context = DailyMoodInsightManager.contextForDate(this,date);
        new Thread(() -> {
            try {
                String therapy = TherapyMemoryManager.buildContext(this)
                        + "\n\n" + TherapySurfaceContext.forSurface(this, TherapySurfaceContext.DIARY_SUMMARY);
                JSONObject result = OpenAiClient.getDailyMoodAnalysis(apiKey,date,context,therapy);
                DailyMoodInsightManager.saveCached(this,date,result);
                // 사용자가 읽는 카드가 갑자기 바뀌지 않도록 자동 교체하지 않는다.
                // 새 요약은 저장만 하고, 같은 날짜를 다시 누르면 사용자가 원할 때 반영된다.
                runOnUiThread(() -> {
                    if (date.equals(selectedDate)) {
                        insightLoading.setText("새 정리본이 준비됐어 ✓ 이 날짜를 다시 누르면 반영돼.");
                        renderCalendar();
                    }
                });
            } catch (Exception e) {
                runOnUiThread(() -> { if(date.equals(selectedDate)) insightLoading.setText("지금은 GPT 연결이 어려워서 기기 안에서 정리한 내용으로 보여주고 있어."); });
            }
        }).start();
    }


    private void loadRecordPager(String date) {
        JSONArray raw = DailyMoodInsightManager.userRecordsForDate(this, date);
        selectedRecords = buildDisplayRecords(raw);
        selectedRecordIndex = Math.max(0, selectedRecords.length() - 1);
        renderRecordPager();
    }

    private JSONArray buildDisplayRecords(JSONArray raw) {
        JSONArray result = new JSONArray();
        if (raw == null || raw.length() == 0) return result;

        List<JSONObject> meaningful = new ArrayList<>();
        for (int i = 0; i < raw.length(); i++) {
            JSONObject item = raw.optJSONObject(i);
            if (item == null) continue;
            String text = item.optString("text", "").trim();
            if (text.isEmpty()) continue;
            String lower = text.toLowerCase(Locale.ROOT);
            boolean technical = lower.contains("api key") || lower.contains("api키")
                    || lower.contains("gpt랑 여기 연동") || lower.contains("연동 됐")
                    || lower.contains("네트워크") || lower.contains("테스트")
                    || lower.contains("저장되고") || lower.contains("상담 진행되는거 맞");
            if (!technical) meaningful.add(item);
        }

        if (meaningful.isEmpty()) {
            for (int i = 0; i < raw.length(); i++) {
                JSONObject item = raw.optJSONObject(i);
                if (item != null) meaningful.add(item);
            }
        }

        final int MAX_RECORDS = 5;
        if (meaningful.size() <= MAX_RECORDS) {
            for (JSONObject item : meaningful) result.put(item);
            return result;
        }

        // 하루 대화를 문장마다 잘게 쪼개 10개 넘게 보여주지 않고,
        // 상담 흐름을 대표하는 최대 5개 장면만 시간 순서대로 고른다.
        int lastIndex = meaningful.size() - 1;
        int previous = -1;
        for (int i = 0; i < MAX_RECORDS; i++) {
            int index = Math.round(i * lastIndex / (float) (MAX_RECORDS - 1));
            if (index == previous) continue;
            result.put(meaningful.get(index));
            previous = index;
        }
        return result;
    }

    private void moveRecord(int delta) {
        if (selectedRecords == null || selectedRecords.length() == 0) return;
        int next = selectedRecordIndex + delta;
        if (next < 0 || next >= selectedRecords.length()) return;
        selectedRecordIndex = next;
        renderRecordPager();
    }

    private void renderRecordPager() {
        int total = selectedRecords == null ? 0 : selectedRecords.length();
        if (total == 0) {
            recordPagerText.setText("0 / 0");
            selectedRecordText.setText("이 날 직접 남긴 상담 기록이 아직 없어.");
            prevRecordButton.setEnabled(false);
            nextRecordButton.setEnabled(false);
            return;
        }
        JSONObject item = selectedRecords.optJSONObject(selectedRecordIndex);
        String time = item == null ? "" : item.optString("time", "");
        String text = item == null ? "" : item.optString("text", "");
        String shortTime = time.length() >= 16 ? time.substring(11, 16) : time;
        recordPagerText.setText((selectedRecordIndex + 1) + " / " + total);
        selectedRecordText.setText((shortTime.isEmpty() ? "" : shortTime + "\n") + text);
        prevRecordButton.setEnabled(selectedRecordIndex > 0);
        nextRecordButton.setEnabled(selectedRecordIndex < total - 1);
        prevRecordButton.setAlpha(prevRecordButton.isEnabled() ? 1f : 0.35f);
        nextRecordButton.setAlpha(nextRecordButton.isEnabled() ? 1f : 0.35f);
    }

    private void renderInsight(DailyMoodInsightManager.Insight i){
        selectedMoodLabel.setText(i.label + " · 그날 상담 기록을 바탕으로 봤어");
        selectedMoodIcon.setImageResource(MoodStickerResources.imageForLabel(i.label));
        insightStatus.setText(i.status);
        insightSummary.setText(i.summary);
        insightPrescription.setText(i.prescription);
        insightMeta.setText("오늘 마음을 흔든 것 · " + i.trigger + "\n지금 필요한 것 · " + i.need + "\n오늘 그래도 남아 있는 힘 · " + i.strength);
    }

    private String formatDate(int year,int month,int day){Calendar c=Calendar.getInstance();c.set(year,month,day);return new SimpleDateFormat(EmotionDiaryStorage.DATE_FORMAT,Locale.KOREA).format(c.getTime());}
    private String topKey(Map<String,Integer> map){String top="잔잔";int n=0;for(Map.Entry<String,Integer> e:map.entrySet())if(e.getValue()>n){top=e.getKey();n=e.getValue();}return top;}
    private int dp(int v){return Math.round(v*getResources().getDisplayMetrics().density);}
}
