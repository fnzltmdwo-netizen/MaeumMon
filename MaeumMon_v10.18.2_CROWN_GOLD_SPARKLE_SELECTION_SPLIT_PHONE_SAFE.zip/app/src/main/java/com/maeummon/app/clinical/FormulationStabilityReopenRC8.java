package com.maeummon.app.clinical;

import android.content.Context;
import org.json.*;

public final class FormulationStabilityReopenRC8 {
    private FormulationStabilityReopenRC8(){}

    public static final class Result {
        public boolean reopen=false;
        public String reason="";
        public double topConfidence=0.0;
        public double secondConfidence=0.0;
        public double separation=0.0;
        public int activeHypotheses=0;
        public String recommendedMove="";
    }

    public static Result evaluate(Context c){
        Result r=new Result();
        if(c==null)return r;

        JSONObject f=CentralTherapyProfile.loadFormulation(c);
        JSONArray hs=f.optJSONArray("alternative_hypotheses");
        if(hs==null||hs.length()==0){
            r.reopen=true;
            r.reason="NO_ACTIVE_HYPOTHESES";
            r.recommendedMove="ASK";
            return r;
        }

        r.activeHypotheses=hs.length();
        for(int i=0;i<hs.length();i++){
            JSONObject h=hs.optJSONObject(i);
            if(h==null)continue;
            double v=h.optDouble("confidence",0.0);
            if(v>r.topConfidence){
                r.secondConfidence=r.topConfidence;
                r.topConfidence=v;
            }else if(v>r.secondConfidence){
                r.secondConfidence=v;
            }
        }
        r.separation=Math.max(0.0,r.topConfidence-r.secondConfidence);

        String adaptive=f.optString("adaptive_plan_action","");
        String outcome=f.optString("last_intervention_outcome","");
        String confidence=f.optString("confidence","LOW");
        String answerEvidence=f.optString("last_answer_evidence","");

        if("REOPEN_FORMULATION".equals(adaptive)){
            r.reopen=true;
            r.reason="ADAPTIVE_PLANNER_REQUESTED_REOPEN";
            r.recommendedMove="ASK";
            return r;
        }

        if("WORSE".equals(outcome)){
            r.reopen=true;
            r.reason="INTERVENTION_WORSENED_EXPERIENCE";
            r.recommendedMove="FORMULATE";
            return r;
        }

        if(r.activeHypotheses>=3 && r.topConfidence<0.40){
            r.reopen=true;
            r.reason="DIFFUSE_HYPOTHESES";
            r.recommendedMove="ASK";
            return r;
        }

        if(r.activeHypotheses>=3 && r.separation<0.06){
            r.reopen=true;
            r.reason="INSUFFICIENT_HYPOTHESIS_SEPARATION";
            r.recommendedMove="ASK";
            return r;
        }

        if("LOW".equalsIgnoreCase(confidence) && r.activeHypotheses>=3){
            r.reopen=true;
            r.reason="LOW_FORMULATION_CONFIDENCE";
            r.recommendedMove="ASK";
            return r;
        }

        // If the latest answer strongly contradicts previous interpretation, reopen.
        if(answerEvidence!=null && (
                answerEvidence.contains("-0.3") ||
                answerEvidence.contains("-0.4") ||
                answerEvidence.contains("-0.5"))){
            r.reopen=true;
            r.reason="STRONG_CONTRADICTORY_ANSWER_EVIDENCE";
            r.recommendedMove="FORMULATE";
            return r;
        }

        return r;
    }

    public static void apply(Context c,Result r){
        if(c==null||r==null||!r.reopen)return;
        try{
            JSONObject f=CentralTherapyProfile.loadFormulation(c);
            f.put("confidence","LOW");
            f.put("leading_hypothesis","");
            f.put("formulation_reopened",true);
            f.put("formulation_reopen_reason",r.reason);
            f.put("next_clinical_move",r.recommendedMove);
            f.put("updated_at",System.currentTimeMillis());

            JSONArray hs=f.optJSONArray("alternative_hypotheses");
            if(hs!=null){
                for(int i=0;i<hs.length();i++){
                    JSONObject h=hs.optJSONObject(i);
                    if(h!=null)h.put("active",true);
                }
                f.put("alternative_hypotheses",hs);
            }

            CentralTherapyProfile.replaceFormulation(c,f);
        }catch(Exception ignored){}
    }

    public static String instruction(Result r){
        if(r==null||!r.reopen)return "";
        return "FORMULATION_REOPEN=true. 기존 해석을 고집하지 않는다. "
                +"현재 competing hypotheses와 반대 증거를 다시 검토하고, "
                +"가설들을 가장 잘 가르는 정보만 추가로 확인한다. "
                +"이전 해석을 확정사실처럼 반복하지 않는다. reopen_reason="+r.reason;
    }
}
