package com.maeummon.app.clinical;

import android.content.Context;
import org.json.*;
import java.util.*;

public final class FormulationCompressionCentralInsightRC8 {
    private FormulationCompressionCentralInsightRC8(){}

    public static final class Result {
        public String insight="";
        public String mechanism="";
        public String evidenceAnchor="";
        public String uncertainty="";
        public String nextMove="";
        public boolean usable=false;
        public int activeHypotheses=0;
        public double topConfidence=0.0;
        public double separation=0.0;
    }

    public static Result build(Context c){
        Result r=new Result();
        if(c==null)return r;

        JSONObject f=CentralTherapyProfile.loadFormulation(c);
        JSONArray hs=f.optJSONArray("alternative_hypotheses");
        if(hs==null||hs.length()==0){
            r.uncertainty="아직 핵심 구조를 압축할 만큼 정보가 충분하지 않다.";
            return r;
        }

        JSONObject top=null;
        double second=0.0;

        for(int i=0;i<hs.length();i++){
            JSONObject h=hs.optJSONObject(i);
            if(h==null||!h.optBoolean("active",true))continue;
            r.activeHypotheses++;

            double conf=h.optDouble("confidence",0.0);
            if(top==null || conf>r.topConfidence){
                if(top!=null)second=r.topConfidence;
                top=h;
                r.topConfidence=conf;
            }else if(conf>second){
                second=conf;
            }
        }

        if(top==null)return r;

        r.separation=Math.max(0.0,r.topConfidence-second);
        String id=top.optString("id","");
        r.mechanism=mechanismFor(id);
        r.evidenceAnchor=bestEvidence(top);
        r.nextMove=f.optString("next_clinical_move","");

        int unresolved=f.optInt("unresolved_evidence_conflicts",0);
        boolean reopened=f.optBoolean("formulation_reopened",false);
        String confidence=f.optString("confidence","LOW");

        if(reopened){
            r.uncertainty="현재 formulation이 다시 열린 상태라 핵심 해석은 잠정적이다.";
        }else if(unresolved>0){
            r.uncertainty="서로 충돌하는 정보가 남아 있어 한 가지 설명으로 확정할 수 없다.";
        }else if("LOW".equalsIgnoreCase(confidence) || r.separation<0.08){
            r.uncertainty="현재는 여러 설명 가능성이 비슷해 이 해석은 잠정적이다.";
        }else{
            r.uncertainty="현재 정보 기준으로 가장 잘 맞는 잠정 설명이다.";
        }

        r.insight=compose(id,r.evidenceAnchor,r.uncertainty);

        // User-facing central insight should only be used when there is
        // enough structure and the selected hypothesis is not context-blocked.
        r.usable=
                r.topConfidence>=0.45
                && r.activeHypotheses>=1
                && !r.mechanism.isEmpty()
                && !contextBlocked(c,id);

        return r;
    }

    public static void apply(Context c,Result r){
        if(c==null||r==null)return;
        try{
            JSONObject f=CentralTherapyProfile.loadFormulation(c);
            f.put("central_insight",r.insight);
            f.put("central_mechanism",r.mechanism);
            f.put("central_evidence_anchor",r.evidenceAnchor);
            f.put("central_uncertainty",r.uncertainty);
            f.put("central_insight_usable",r.usable);
            f.put("central_insight_updated_at",System.currentTimeMillis());
            CentralTherapyProfile.replaceFormulation(c,f);
        }catch(Exception ignored){}
    }

    public static String instruction(Result r){
        if(r==null)return "";
        if(!r.usable){
            return "CENTRAL_INSIGHT_READY=false. 핵심 해석을 억지로 만들지 않는다. "
                    +"불확실성이 높으면 여러 가능성을 짧게 유지하고 필요한 정보만 확인한다.";
        }
        return "CENTRAL_INSIGHT_READY=true. 사용자에게 formulation을 설명할 때 competing hypotheses 전체를 나열하지 말고 "
                +"핵심 구조 1개 + 근거 1개 + 불확실성 1문장으로 압축한다. "
                +"전문용어/점수/내부 confidence 수치를 사용자에게 그대로 노출하지 않는다. "
                +"central_insight="+r.insight;
    }

    private static String compose(String id,String evidence,String uncertainty){
        String core;
        if("rejection_interpretation_amplification".equals(id)){
            core="지금 힘든 핵심은 애매한 관계 신호 자체보다, 그 애매함을 곧바로 거절의 의미로 확정하면서 불안이 커지는 흐름에 가깝다.";
        }else if("relationship_distance_change".equals(id)){
            core="지금은 단순한 불안만 보기보다 실제 관계의 거리감이 최근 달라졌는지를 함께 보는 게 중요하다.";
        }else if("actual_rejection_or_conflict".equals(id)){
            core="현재는 해석의 문제만이 아니라 실제 갈등이나 거절 신호가 있었는지를 중심으로 봐야 한다.";
        }else if("normal_response_variation".equals(id)){
            core="현재 정보만 보면 상대 반응의 정상적인 변동을 거절 신호로 크게 해석했을 가능성도 충분히 남아 있다.";
        }else if("evaluation_threat".equals(id)){
            core="지금 불안을 크게 만드는 건 업무량 자체보다 '내가 무능하게 보일 수 있다'는 평가 위협에 더 가까울 수 있다.";
        }else if("workload_stress".equals(id)){
            core="지금 문제의 중심은 능력 부족이라기보다 감당해야 할 업무량과 회복 부족의 누적에 더 가까워 보인다.";
        }else if("interpersonal_work_stress".equals(id)){
            core="지금 스트레스는 일의 양뿐 아니라 직장 관계에서 느끼는 긴장과 위협이 함께 유지시키는 것으로 보인다.";
        }else if("exhaustion_or_burnout".equals(id)){
            core="지금은 해석을 더 분석하기보다 무리와 회복 부족이 감정조절 여력을 떨어뜨린 흐름을 먼저 보는 게 맞다.";
        }else if("avoidance_negative_reinforcement".equals(id)){
            core="피하면 당장은 편해지지만 그 짧은 안도가 다음 회피를 더 강하게 만드는 순환이 핵심일 수 있다.";
        }else{
            core="현재 정보에서 가장 일관되게 보이는 유지 구조를 중심으로 잠정적으로 이해하는 게 좋다.";
        }

        if(evidence!=null&&!evidence.isEmpty())
            core+=" 특히 "+compact(evidence,100)+"라는 정보가 이 이해를 뒷받침한다.";

        return core+" "+uncertainty;
    }

    private static String mechanismFor(String id){
        if("rejection_interpretation_amplification".equals(id))return "AMBIGUITY_TO_REJECTION";
        if("relationship_distance_change".equals(id))return "ACTUAL_RELATIONSHIP_CHANGE";
        if("actual_rejection_or_conflict".equals(id))return "REAL_CONFLICT_OR_REJECTION";
        if("normal_response_variation".equals(id))return "NORMAL_VARIATION";
        if("evaluation_threat".equals(id))return "EVALUATION_THREAT";
        if("workload_stress".equals(id))return "LOAD_EXCEEDS_CAPACITY";
        if("interpersonal_work_stress".equals(id))return "INTERPERSONAL_THREAT";
        if("exhaustion_or_burnout".equals(id))return "RECOVERY_DEFICIT";
        if("avoidance_negative_reinforcement".equals(id))return "SHORT_TERM_RELIEF_MAINTAINS_AVOIDANCE";
        return "";
    }

    private static String bestEvidence(JSONObject h){
        JSONArray a=h.optJSONArray("evidence_for");
        if(a==null||a.length()==0)return "";

        // Prefer most recent / last item to match current formulation.
        for(int i=a.length()-1;i>=0;i--){
            Object raw=a.opt(i);
            if(raw instanceof JSONObject){
                JSONObject o=(JSONObject)raw;
                String t=o.optString("text",o.optString("note",""));
                if(!t.isEmpty())return t;
            }else{
                String t=String.valueOf(raw);
                if(!t.isEmpty())return t;
            }
        }
        return "";
    }

    private static boolean contextBlocked(Context c,String hypothesisId){
        JSONObject p=CentralTherapyProfile.loadProfile(c);
        JSONArray stable=p.optJSONArray("stable_profile");
        if(stable==null)return false;

        String fp=fingerprintFor(hypothesisId);
        if(fp.isEmpty())return false;

        for(int i=0;i<stable.length();i++){
            JSONObject s=stable.optJSONObject(i);
            if(s==null||!"ACTIVE".equals(s.optString("status","ACTIVE")))continue;
            String text=s.optString("text","");
            if(fingerprint(text).equals(fp) && !s.optBoolean("usable_in_current_context",true))
                return true;
        }
        return false;
    }

    private static String fingerprintFor(String id){
        if(id.contains("rejection")||id.contains("relationship"))return "REJECTION_THREAT";
        if(id.contains("evaluation"))return "EVALUATION_THREAT";
        if(id.contains("avoidance"))return "AVOIDANCE";
        return "";
    }

    private static String fingerprint(String text){
        if(has(text,"거절","미워","버려","답장","연락","무시"))return "REJECTION_THREAT";
        if(has(text,"평가","무능","실수","눈치"))return "EVALUATION_THREAT";
        if(has(text,"회피","피해","도망","미뤄"))return "AVOIDANCE";
        return "";
    }

    private static boolean has(String s,String... xs){
        if(s==null)return false;
        for(String x:xs)if(s.contains(x))return true;
        return false;
    }

    private static String compact(String s,int max){
        s=s==null?"":s.trim();
        return s.length()<=max?s:s.substring(0,max);
    }
}
