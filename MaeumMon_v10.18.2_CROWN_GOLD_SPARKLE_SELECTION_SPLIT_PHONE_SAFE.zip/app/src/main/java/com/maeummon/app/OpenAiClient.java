package com.maeummon.app;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

public class OpenAiClient {

    public static final class CounselingResult {
        public final String reply;
        public final String sessionSummary;
        public final String focus;
        public final String pattern;
        public final String reframe;
        public final String experiment;
        public final String followUp;
        public final String strength;
        public final String phase;
        public final String riskLevel;
        public final String approach;
        public final String approachReason;
        public final String rootHypothesis;
        public final String coreBelief;
        public final String unmetNeed;
        public final String protectiveStrategy;
        public final String correctiveExperience;
        public final String trigger;
        public final String coreEmotion;
        public final String automaticThought;
        public final String coreFear;
        public final String relationshipPattern;
        public final String effectiveIntervention;
        public final String recentChange;
        public final int emotionIntensity;
        public final String currentNeed;
        public final String userGoal;
        public final String personalizationBasis;
        public final String interventionRationale;
        public final String nextSessionLink;
        public final String confirmedFacts;
        public final String openQuestion;
        public final String workingHypothesis;
        public final String hypothesisStatus;
        public final int hypothesisEvidenceCount;
        public final int deltaSelfTrust;
        public final int deltaBoundary;
        public final int deltaAmbiguity;
        public final int deltaRecovery;
        public final int deltaSelfCompassion;
        public final int deltaValues;

        CounselingResult(JSONObject o) {
            reply = o.optString("reply", "").trim();
            sessionSummary = o.optString("session_summary", "").trim();
            focus = o.optString("focus", "").trim();
            pattern = o.optString("pattern", "").trim();
            reframe = o.optString("reframe", "").trim();
            experiment = o.optString("experiment", "").trim();
            followUp = o.optString("follow_up", "").trim();
            strength = o.optString("strength", "").trim();
            phase = o.optString("phase", "explore").trim();
            riskLevel = o.optString("risk_level", "none").trim();
            approach = o.optString("approach", "").trim();
            approachReason = o.optString("approach_reason", "").trim();
            rootHypothesis = o.optString("root_hypothesis", "").trim();
            coreBelief = o.optString("core_belief", "").trim();
            unmetNeed = o.optString("unmet_need", "").trim();
            protectiveStrategy = o.optString("protective_strategy", "").trim();
            correctiveExperience = o.optString("corrective_experience", "").trim();
            trigger = o.optString("trigger", "").trim();
            coreEmotion = o.optString("core_emotion", "").trim();
            automaticThought = o.optString("automatic_thought", "").trim();
            coreFear = o.optString("core_fear", "").trim();
            relationshipPattern = o.optString("relationship_pattern", "").trim();
            effectiveIntervention = o.optString("effective_intervention", "").trim();
            recentChange = o.optString("recent_change", "").trim();
            emotionIntensity = Math.max(0, Math.min(100, o.optInt("emotion_intensity", 0)));
            currentNeed = o.optString("current_need", "").trim();
            userGoal = o.optString("user_goal", "").trim();
            personalizationBasis = o.optString("personalization_basis", "").trim();
            interventionRationale = o.optString("intervention_rationale", "").trim();
            nextSessionLink = o.optString("next_session_link", "").trim();
            confirmedFacts = o.optString("confirmed_facts", "").trim();
            openQuestion = o.optString("open_question", "").trim();
            workingHypothesis = o.optString("working_hypothesis", "").trim();
            hypothesisStatus = o.optString("hypothesis_status", "none").trim();
            hypothesisEvidenceCount = Math.max(0, Math.min(3, o.optInt("hypothesis_evidence_count", 0)));
            deltaSelfTrust = o.optInt("delta_self_trust", 0);
            deltaBoundary = o.optInt("delta_boundary", 0);
            deltaAmbiguity = o.optInt("delta_ambiguity", 0);
            deltaRecovery = o.optInt("delta_recovery", 0);
            deltaSelfCompassion = o.optInt("delta_self_compassion", 0);
            deltaValues = o.optInt("delta_values", 0);
        }
    }


    /**
     * v3.7.0 State Counselor / Meta Counselor.
     * 상담문장을 쓰기 전에 ASSESS를 수행하고 이번 턴의 상태를 정확히 하나만 고른다.
     * ASK / FORMULATE / INTERVENE / STABILIZE / REVIEW를 한 턴에 섞지 않는다.
     */
    public static final class MetaCounselDecision {
        public final String action;
        public final String question;
        public final String formulation;
        public final String interventionFocus;
        public final String stabilizeMessage;
        public final String reviewPrompt;
        public final String reason;
        public final String facts;
        public final String hypotheses;
        public final String unknowns;
        public final String highImpactMissingInformation;
        public final String coreFear;
        public final String coreNeed;
        public final String protectiveBehavior;
        public final String longTermCost;
        public final String therapistNextFocus;
        public final String therapistLeadMode;
        public final String userDidWell;
        public final String userActualPart;
        public final String otherPersonPart;
        public final String notUserPart;
        public final String formulationAudit;
        public final boolean unsupportedProblemInvented;
        public final boolean highImpactUnknownExists;
        public final boolean evidenceSufficient;
        public final boolean stabilizationNeeded;
        public final boolean formulationConfirmed;
        public final int directionChangeScore;
        public final int uncertaintyScore;
        public final int noveltyScore;
        public final int burdenScore;
        public final int questionValue;
        public final int confidence;
        public final String responseNeed;
        public final String formulationType;
        public final String coreSentence;
        public final String patternLoop;
        public final int empathyLevel;
        public final int confrontLevel;
        public final int directiveness;
        public final boolean changesFormulation;
        public final boolean changesIntervention;
        public final boolean safetyRelevance;
        public final boolean distinguishesHypotheses;
        public final boolean distinguishesEmotion;
        public final boolean alreadyAnswered;
        public final boolean mereCuriosity;
        public final boolean sameIntervention;
        public final boolean userWantsActionNow;

        // OH_BIGDATA_V2 operators (O19~O27)
        public final String surfaceEmotion;
        public final String coreEmotion;
        public final String emotionTranslationConfidence;
        public final String conversationFunction;
        public final String turningPoint;
        public final boolean turningPointDetected;
        public final String emotionDelivery;
        public final boolean interactionBreakdown;
        public final String endingType;
        public final String endingReason;
        public final boolean practiceNeeded;
        public final String confidenceTarget;
        public final String confidenceLanguage;

        MetaCounselDecision(JSONObject o) {
            action = o.optString("action", "FORMULATE").trim();
            question = o.optString("question", "").trim();
            formulation = o.optString("formulation", "").trim();
            interventionFocus = o.optString("intervention_focus", "").trim();
            stabilizeMessage = o.optString("stabilize_message", "").trim();
            reviewPrompt = o.optString("review_prompt", "").trim();
            reason = o.optString("reason", "").trim();
            facts = joinArray(o.optJSONArray("facts"));
            hypotheses = joinArray(o.optJSONArray("hypotheses"));
            unknowns = joinArray(o.optJSONArray("unknowns"));
            highImpactMissingInformation = o.optString("high_impact_missing_information", "").trim();
            coreFear = o.optString("core_fear", "").trim();
            coreNeed = o.optString("core_need", "").trim();
            protectiveBehavior = o.optString("protective_behavior", "").trim();
            longTermCost = o.optString("long_term_cost", "").trim();
            therapistNextFocus = o.optString("therapist_next_focus", "").trim();
            therapistLeadMode = o.optString("therapist_lead_mode", "LEAD_FORWARD").trim();
            userDidWell = o.optString("user_did_well", "").trim();
            userActualPart = o.optString("user_actual_part", "").trim();
            otherPersonPart = o.optString("other_person_part", "").trim();
            notUserPart = o.optString("not_user_part", "").trim();
            formulationAudit = o.optString("formulation_audit", "").trim();
            unsupportedProblemInvented = o.optBoolean("unsupported_problem_invented", false);
            highImpactUnknownExists = o.optBoolean("high_impact_unknown_exists", false);
            evidenceSufficient = o.optBoolean("evidence_sufficient", false);
            stabilizationNeeded = o.optBoolean("stabilization_needed", false);
            formulationConfirmed = o.optBoolean("formulation_confirmed", false);
            directionChangeScore = clamp(o.optInt("direction_change_score", 0));
            uncertaintyScore = clamp(o.optInt("uncertainty_score", 0));
            noveltyScore = clamp(o.optInt("novelty_score", 0));
            burdenScore = clamp(o.optInt("burden_score", 0));
            questionValue = o.optInt("question_value", 0);
            confidence = clamp(o.optInt("confidence", 0));
            responseNeed = o.optString("response_need", "UNDERSTANDING").trim();
            formulationType = o.optString("formulation_type", "F0_NO_REFRAME").trim();
            coreSentence = o.optString("core_sentence", "").trim();
            patternLoop = joinArray(o.optJSONArray("pattern_loop"));
            empathyLevel = Math.max(0, Math.min(3, o.optInt("empathy_level", 1)));
            confrontLevel = Math.max(0, Math.min(3, o.optInt("confront_level", 0)));
            directiveness = Math.max(0, Math.min(3, o.optInt("directiveness", 1)));
            changesFormulation = o.optBoolean("changes_formulation", false);
            changesIntervention = o.optBoolean("changes_intervention", false);
            safetyRelevance = o.optBoolean("safety_relevance", false);
            distinguishesHypotheses = o.optBoolean("distinguishes_hypotheses", false);
            distinguishesEmotion = o.optBoolean("distinguishes_emotion", false);
            alreadyAnswered = o.optBoolean("already_answered", false);
            mereCuriosity = o.optBoolean("mere_curiosity", false);
            sameIntervention = o.optBoolean("same_intervention", false);
            userWantsActionNow = o.optBoolean("user_wants_action_now", false);
            surfaceEmotion = o.optString("surface_emotion", "").trim();
            coreEmotion = o.optString("core_emotion", "").trim();
            emotionTranslationConfidence = o.optString("emotion_translation_confidence", "LOW").trim();
            conversationFunction = o.optString("conversation_function", "NONE").trim();
            turningPoint = o.optString("turning_point", "").trim();
            turningPointDetected = o.optBoolean("turning_point_detected", false);
            emotionDelivery = o.optString("emotion_delivery", "NONE").trim();
            interactionBreakdown = o.optBoolean("interaction_breakdown", false);
            endingType = o.optString("ending_type", "INSIGHT_ENDING").trim();
            endingReason = o.optString("ending_reason", "").trim();
            practiceNeeded = o.optBoolean("practice_needed", false);
            confidenceTarget = o.optString("confidence_target", "PATTERN").trim();
            confidenceLanguage = o.optString("confidence_language", "MEDIUM").trim();
        }

        private static int clamp(int v) { return Math.max(0, Math.min(100, v)); }

        private static String joinArray(JSONArray a) {
            if (a == null || a.length() == 0) return "";
            StringBuilder b = new StringBuilder();
            for (int i = 0; i < a.length(); i++) {
                String v = a.optString(i, "").trim();
                if (v.isEmpty()) continue;
                if (b.length() > 0) b.append(" | ");
                b.append(v);
            }
            return b.toString();
        }

        public boolean isAsk() { return "ASK".equals(action); }
        public boolean isFormulate() { return "FORMULATE".equals(action); }
        public boolean isIntervene() { return "INTERVENE".equals(action); }
        public boolean isStabilize() { return "STABILIZE".equals(action); }
        public boolean isReview() { return "REVIEW".equals(action); }

        public String directReply() {
            if (isAsk()) return question;
            if (isFormulate()) {
                String text = unsupportedProblemInvented ? safeFallbackFormulation() : formulation;
                if (text.isEmpty()) return "지금까지 들은 걸 내가 제대로 이해했는지 한번 묶어볼게.";
                if (text.endsWith("?") || text.contains("내가 이해한 게 맞")) return text;

                // v5.2: 한 답변의 마침표와 상담주제 종료를 분리한다.
                // 새로운 핵심정보/전환점이 있고 답에 따라 다음 개입이 달라지면,
                // FORMULATE 뒤에도 이미 만든 고가치 질문 1개로 같은 주제를 자연스럽게 이어간다.
                boolean therapistLeadForward = "LEAD_FORWARD".equals(therapistLeadMode)
                        && "CONTINUATION_ENDING".equals(endingType);
                boolean canContinueTopic = highImpactUnknownExists
                        && questionValue >= 3
                        && !alreadyAnswered
                        && !userWantsActionNow
                        && !"ACTION".equals(responseNeed)
                        && !"DECISION".equals(responseNeed)
                        && !"COMMUNICATION".equals(responseNeed)
                        && !question.isEmpty()
                        && (therapistLeadForward || turningPointDetected || !formulationConfirmed || confidence < 75);
                if (canContinueTopic) return text + "\n\n" + question;

                // 질문이 필요하지만 판별 질문이 생성되지 않은 경우에만 최소 확인을 허용한다.
                boolean needsConfirmation = !formulationConfirmed
                        && highImpactUnknownExists
                        && confidence < 60
                        && !alreadyAnswered
                        && !userWantsActionNow;
                return needsConfirmation ? text + "\n\n내가 여기까지 이해한 방향은 맞아?" : text;
            }
            if (isStabilize()) return stabilizeMessage;
            if (isReview()) return reviewPrompt;
            return "";
        }


        private String safeFallbackFormulation() {
            StringBuilder b = new StringBuilder();
            b.append("내가 지금 확실히 확인된 것만 가지고 묶어볼게. ");
            if (!facts.isEmpty()) b.append(facts.replace(" | ", ". ")).append(". ");
            if (!userDidWell.isEmpty()) b.append("그리고 네가 이미 한 부분 중에는 ").append(userDidWell).append(". ");
            if (!userActualPart.isEmpty()) b.append("네가 조절할 수 있는 부분은 ").append(userActualPart).append(". ");
            if (!otherPersonPart.isEmpty()) b.append("반대로 상대가 책임질 부분은 ").append(otherPersonPart).append(". ");
            if (!notUserPart.isEmpty()) b.append("그래서 ").append(notUserPart).append("까지 네 책임으로 가져갈 필요는 없어. ");
            b.append("지금 정보 밖의 목표나 문제는 내가 새로 만들지 않을게.");
            return b.toString().replace("..", ".").trim();
        }

        public String asDirective() {
            StringBuilder sb = new StringBuilder();
            sb.append("[MaeumMon Cognitive Engine v4 결정]\n");
            sb.append("state=").append(action).append("\n");
            sb.append("evidence_sufficient=").append(evidenceSufficient).append("\n");
            sb.append("formulation_confirmed=").append(formulationConfirmed).append("\n");
            sb.append("confidence=").append(confidence).append("\n");
            sb.append("response_need=").append(responseNeed).append("\n");
            sb.append("formulation_type=").append(formulationType).append("\n");
            if (!coreSentence.isEmpty()) sb.append("CORE_SENTENCE=").append(coreSentence).append("\n");
            if (!patternLoop.isEmpty()) sb.append("PATTERN_LOOP=").append(patternLoop).append("\n");
            sb.append("empathy_level=").append(empathyLevel).append(" confront_level=").append(confrontLevel).append(" directiveness=").append(directiveness).append("\n");
            if (!surfaceEmotion.isEmpty()) sb.append("SURFACE_EMOTION=").append(surfaceEmotion).append("\n");
            if (!coreEmotion.isEmpty()) sb.append("CORE_EMOTION=").append(coreEmotion).append(" translation_confidence=").append(emotionTranslationConfidence).append("\n");
            if (!"NONE".equals(conversationFunction)) sb.append("CONVERSATION_FUNCTION=").append(conversationFunction).append("\n");
            if (turningPointDetected) sb.append("TURNING_POINT=").append(turningPoint).append("\n");
            if (!"NONE".equals(emotionDelivery)) sb.append("EMOTION_DELIVERY=").append(emotionDelivery).append("\n");
            sb.append("interaction_breakdown=").append(interactionBreakdown).append("\n");
            sb.append("ENDING_TYPE=").append(endingType).append(" ending_reason=").append(endingReason).append(" practice_needed=").append(practiceNeeded).append("\n");
            sb.append("CONFIDENCE_TARGET=").append(confidenceTarget).append(" CONFIDENCE_LANGUAGE=").append(confidenceLanguage).append("\n");
            if (!facts.isEmpty()) sb.append("FACTS=").append(facts).append("\n");
            if (!hypotheses.isEmpty()) sb.append("HYPOTHESES=").append(hypotheses).append("\n");
            if (!unknowns.isEmpty()) sb.append("UNKNOWN=").append(unknowns).append("\n");
            if (!coreFear.isEmpty()) sb.append("CORE_FEAR=").append(coreFear).append("\n");
            if (!coreNeed.isEmpty()) sb.append("CORE_NEED=").append(coreNeed).append("\n");
            if (!protectiveBehavior.isEmpty()) sb.append("PROTECTIVE_BEHAVIOR=").append(protectiveBehavior).append("\n");
            if (!longTermCost.isEmpty()) sb.append("LONG_TERM_COST=").append(longTermCost).append("\n");
            if (!therapistNextFocus.isEmpty()) sb.append("THERAPIST_NEXT_FOCUS=").append(therapistNextFocus).append("\n");
            sb.append("THERAPIST_LEAD_MODE=").append(therapistLeadMode).append("\n");
            if (!userDidWell.isEmpty()) sb.append("USER_DID_WELL=").append(userDidWell).append("\n");
            if (!userActualPart.isEmpty()) sb.append("USER_ACTUAL_PART=").append(userActualPart).append("\n");
            if (!otherPersonPart.isEmpty()) sb.append("OTHER_PERSON_PART=").append(otherPersonPart).append("\n");
            if (!notUserPart.isEmpty()) sb.append("NOT_USER_PART=").append(notUserPart).append("\n");
            if (!reason.isEmpty()) sb.append("reason=").append(reason).append("\n");
            if (!interventionFocus.isEmpty()) sb.append("intervention_focus=").append(interventionFocus).append("\n");
            sb.append("이번 턴은 INTERVENE 상태다. 핵심 개입 하나만 수행한다. 추가 질문, 장문의 재서술, 여러 치료기법 나열, 새로운 사례개념화는 금지한다.");
            return sb.toString();
        }
    }

    public static MetaCounselDecision getMetaCounselDecision(String apiKey,
                                                               JSONArray history,
                                                               String userMessage,
                                                               String understoodContext,
                                                               String ruleContext,
                                                               String therapyMemory,
                                                               String stateMemory,
                                                               String model) throws Exception {
        URL url = new URL("https://api.openai.com/v1/responses");
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("POST");
        conn.setRequestProperty("Authorization", "Bearer " + apiKey.trim());
        conn.setRequestProperty("Content-Type", "application/json");
        conn.setDoOutput(true);
        conn.setConnectTimeout(30000);
        conn.setReadTimeout(70000);

        JSONObject body = new JSONObject();
        body.put("model", safeModel(model, "gpt-4.1-mini"));
        body.put("max_output_tokens", 1400);

        JSONArray input = new JSONArray();
        JSONObject system = new JSONObject();
        system.put("role", "system");
        system.put("content",
                "너는 마음몬 OH80 Cognitive Engine v4.3.4 + OH_BIGDATA_V2 PLAIN-KOREAN의 상담 판단기다. 사용자에게 바로 상담문장을 길게 쓰는 역할이 아니라, 먼저 정확히 판단하고 이번 턴에 필요한 상태를 하나 고른다. "
                + "최상위 원칙: 사용자가 붙인 문제명을 곧바로 해결하지 말고, 그것이 실제로 변화시킬 핵심인지 확인한다. 사실과 해석, 감정, 행동, 욕구, 두려움, 반복패턴을 분리한다. "
                + "response_need는 UNDERSTANDING, REALITY_CHECK, DECISION, ACTION, COMMUNICATION, REGULATION, VENTING 중 하나로 고른다. 사용자가 지금 원하는 것에 맞지 않는 장황한 분석을 금지한다. "
                + "v4.3.4 라우팅 우선순위: DECISION/ACTION/COMMUNICATION 요청에서 안전 문제가 없고 필요한 사실이 충분하면 FORMULATE를 한 턴 더 끌지 말고 INTERVENE를 우선한다. COMMUNICATION이면 실제 보낼/말할 문장 하나, ACTION이면 관찰 가능한 행동 하나, DECISION이면 지금 선택 기준 또는 권고 하나로 바로 내린다. "
                + "VENTING은 해결책을 강요하지 말고 짧은 수용 또는 핵심 반영을 우선한다. REGULATION은 깊은 분석보다 현재 감정 강도를 낮추는 개입을 먼저 한다. "
                + "즉각적인 위험·공격·충동적 관계행동이 있으면 탐색보다 STABILIZE를 우선한다. 감정은 인정할 수 있지만 해로운 행동은 허용하지 않는다. "
                + "설명이 불명확하면 H1~H3의 대안 가설을 만든다. 애착, ADHD, 트라우마, 성격장애, 가스라이팅 등 라벨을 근거 없이 단정하지 않는다. 가설은 행동·의미·기능 중심으로 쓴다. "
                + "ASK는 단계가 아니라 게이트다. 질문 후보는 사례개념화나 개입을 실제로 바꾸는 판별 질문 하나만 만든다. 단순 호기심, 이미 답한 내용, 답을 알아도 같은 조언이면 질문하지 않는다. "
                + "ASK_VALUE 구성요소를 boolean으로 판단한다: changes_formulation, changes_intervention, safety_relevance, distinguishes_hypotheses, distinguishes_emotion, already_answered, mere_curiosity, same_intervention, user_wants_action_now. "
                + "한 턴의 답변이 끝나는 것과 상담 주제가 끝나는 것은 다르다. 사용자가 직전 답 뒤 새로운 핵심 두려움·의미·상대반응을 말했고 그것이 formulation/개입을 바꿀 수 있으면 같은 ACTIVE_THREAD를 TOPIC_OPEN으로 유지한다. FORMULATE로 이해를 짧게 업데이트한 뒤에도 high-impact 질문 하나를 이어 붙일 수 있다. 단, 단순히 상담을 계속하기 위한 질문은 금지한다. 구조가 충분하거나 사용자가 행동/결정/마무리를 원하면 TOPIC_CLOSE로 질문 없이 넘어간다. 질문 후 다음 턴에는 특별한 이유가 없으면 다시 질문하기보다 FORMULATE를 선호한다. 상태머신 메모리의 questions_since_last_formulation>=1 또는 prefer_formulation=true이면, 안전 판단 또는 사례개념화가 실제로 크게 달라지는 경우가 아니면 추가 ASK를 선택하지 않는다. 질문은 한 턴 최대 하나다. [THERAPIST LEAD v5.4] 상담을 이어가는 주도권은 사용자에게 떠넘기지 않는다. 사용자가 “아하/비슷한 결이구나/그렇구나”처럼 방금 이해를 받아들였다고 해서 자동으로 TOPIC_CLOSE하지 않는다. ACTIVE_THREAD의 장면→의미→핵심두려움→핵심욕구→보호행동→장기비용→변화목표 중 아직 비어 있고 다음 개입을 바꿀 가장 중요한 한 칸을 therapist_next_focus로 정한다. 그 칸을 확인할 필요가 있으면 therapist_lead_mode=LEAD_FORWARD, CONTINUATION_ENDING, 고가치 질문 하나를 만들고, 이미 충분히 확인됐으면 STAY_WITH_IT 또는 CLOSE_OR_ACT를 고른다. 상담을 계속하기 위한 잡담성 질문은 금지하지만, 세션을 앞으로 움직이는 판별 질문은 상담사가 능동적으로 제시한다. LEAD_FORWARD에서는 이미 의미 있는 통찰/가설이 한 문장 이상 잡혔다면 action=FORMULATE를 우선하고, formulation 뒤에 question을 이어 붙일 수 있게 한다. 즉 ASK 단독 질문보다 \"이해를 연결해주고 → 다음 핵심 질문\"의 상담 리듬을 선호한다. "
                + "FORMULATE는 요약이 아니라 가장 설명력 높은 구조를 재정의하는 것이다. formulation_type은 F0_NO_REFRAME, F1_SURFACE_TO_CORE, F2_SYMPTOM_TO_FUNCTION, F3_EVENT_TO_PATTERN, F4_INTENT_TO_IMPACT, F5_PERSON_TO_INTERACTION, F6_TRAIT_TO_COST, F7_FEELING_TO_MEANING 중 하나다. 억지 반전 금지: 사용자 정의가 이미 정확하면 F0를 쓴다. "
                + "FORMULATE는 기본 2문장, 복잡해도 3문장을 넘기지 않는다. 첫 문장에 CORE_SENTENCE를 최대한 선명하게 둔다. [MICRO COMPRESSION] 첫 문장이 이미 사건의 의미를 충분히 설명하면 사건 배경을 다시 요약하지 않는다. [EVENT RETELLING CAP] 사용자가 이미 설명했고 사진에서도 확인된 사건은 답변에서 핵심 근거 1개만 남기고, 동일 사건의 순서·문구를 길게 재현하지 않는다. 사건 설명이 핵심 판단보다 길어지면 삭제한다. 사진 근거는 핵심 판단에 필요한 1개만 우선 사용하고 같은 장면을 다른 표현으로 반복하지 않는다. 그 다음에는 필요할 때만 [HUMAN BRIDGE]를 한 문장 넣는다: 사용자가 직접 말했거나 대화에서 충분히 지지되는 두려움/욕구/딜레마를 바탕으로 '왜 그 순간 그 선택이 그 사람에게는 더 안전하거나 덜 불편하게 느껴졌는지'를 비난 없이 설명한다. 예: 거절 후 어색함이 두려웠다고 사용자가 말한 경우 '그 순간엔 바로 거절해서 관계가 어색해지는 것보다 가능성을 조금 남기는 쪽이 덜 불편했던 거지.'처럼 쓴다. 이 HUMAN BRIDGE는 새로운 과거·진단·숨은 의도를 발명하는 칸이 아니며, 근거가 약하면 생략한다. 마지막 문장은 필요할 때만 그 선택의 비용/모순 또는 FACT와 INTERPRETATION의 구분을 짧게 보여준다. 사용자가 이미 말한 설명을 다시 풀어쓰지 않는다. 사용자가 말하지 않은 목표·의도·과거패턴을 만들지 않는다. user_did_well, user_actual_part, other_person_part, not_user_part를 근거 있을 때 구분한다. [BALANCED RESPONSIBILITY] 사용자를 편들기 위해 user_actual_part를 0으로 만들지 않는다. 상대의 표현/행동이 불편했더라도 사용자의 말이 실제로 모호했거나 오해 여지를 만들었다면 그 조절 가능한 부분은 짧고 비난 없이 남긴다. 반대로 상대의 선택과 평가성 표현까지 사용자 책임으로 돌리지 않는다. '네가 잘못했다/네 잘못이 아니다'의 0/100 판정 대신 '네가 조절할 수 있는 부분 / 상대가 책임질 부분'을 나눠 말한다. 상대 의도를 단정하지 않는다. "
                + "VALIDATE는 감정과 이해 가능한 욕구에만 한다. 확인되지 않은 비난/상대 의도/해로운 행동까지 승인하지 않는다. FACT와 INTERPRETATION을 엄격히 분리한다. [INTENT FIREWALL] '비꼰다, 무시한다, 망신준다, 일부러 피한다, 깎아내린다, 조종한다'처럼 타인의 의도나 목적을 포함하는 표현은 사용자가 그 의도를 직접 확인했다고 말했거나 명백한 발언 근거가 있을 때만 사실형으로 쓴다. 그 외에는 '그렇게 받아들여질 수 있다', '네 입장에서는 그렇게 느껴질 만하다', '그 표현의 영향은 ~였다'처럼 영향 중심으로 바꾼다. 명쾌함을 위해 불확실성을 지우지 않는다. "
                + "직면은 선택적으로 쓴다. 자기합리화·타인 피해·명백한 경계침범이면 높이고, 자기비난·수치심·이미 책임을 이해한 상태면 낮춘다. 단호함은 흥분이 아니라 명확함이다. "
                + "empathy_level은 고정 기본값이 아니라 현재 정서강도와 세션 단계에 따라 0~3으로 조절한다. 상실·충격·강한 수치심·자기공격·정서 폭주에서는 2~3을 적극 사용하고, 관계상처/불안에서는 1~2, 이미 안정되어 행동을 묻는 단계에서는 0~1을 우선한다. 이미 책임을 인정하며 자신 전체를 공격하면 PERSON/BEHAVIOR를 분리하고 confront를 낮춘다. 반대로 '상대가 먼저 그랬으니 내 공격도 정당하다'처럼 합리화하면 FEELING/ACTION을 분리하고 confront를 2 이상으로 올릴 수 있다. "
                + "과거 탐색은 기본 OFF다. 현재 반응이 반복되고 현재 사건만으로 강도가 설명되지 않으며 과거 정보가 가설을 가를 때만 고려한다. "
                + "INTERVENE는 현재 response_need에 맞는 핵심 개입 하나만 고른다. 행동을 요구하면 관찰 가능한 행동으로, COMMUNICATION이면 실제 말할 문장으로 내린다. 여러 치료기법 나열 금지. "
                + "한 응답의 PRIMARY INSIGHT는 최대 하나다. 핵심을 여러 원인으로 분산시키지 않는다. [EMOTIONAL MEANING BRIDGE] 사용자의 핵심 불편함이 단순 사건 자체보다 '내 의도/수고/경계가 다른 의미로 전달된 느낌', '내가 이상한 사람처럼 규정된 느낌', '거절이 존중받지 못한 느낌'처럼 사용자 발언과 근거에서 직접 지지될 때만 그 의미를 생활어 한 문장으로 되돌려준다. 상담용어로 이름 붙이거나 새로운 숨은 감정을 발명하지 않는다. [COMPRESSION RULE] 사용자 답변에 같은 뜻을 두 번 설명하지 않는다. CORE_SENTENCE와 HUMAN BRIDGE가 같은 뜻이면 둘 중 하나만 남긴다. [BALANCE CHECK] 행동/표현 갈등에서는 가능하면 한 문장 안에 사용자에게 이해되는 부분과 사용자가 조절할 수 있는 부분을 함께 담되, 억지로 양비론을 만들지는 않는다. 예: '그 표현이 불편했던 건 이해돼. 다만 \"시간 나면\"은 상대에겐 가능성을 남긴 말로 들릴 수 있어서 다음엔 결론을 먼저 말하는 게 더 깔끔해.'처럼 쓴다. 핵심 문장을 말한 뒤 이미 사용자가 아는 배경설명을 반복하지 말고 바로 현실검증/경계/행동으로 이동한다. 초안에서 없어도 의미가 유지되는 문장은 삭제한다고 생각한다. 이미 분석을 전달한 뒤 사용자가 '그래서 어떻게 해?', '연락해 말아?', '뭐라고 말해?'라고 하면 새 원인 분석을 반복하지 말고 바로 ACTION/DECISION/SCRIPT로 전환한다. "
                + "새 사실은 오래된 사례개념화보다 우선한다. NEW FACTS OVERRIDE OLD FORMULATION. 이전 가설과 모순되면 confidence를 낮추고 formulation을 수정한다. "
                + "confidence는 근거가 적으면 낮게, 반복 근거와 사용자 확인이 쌓이면 높게. 확신이 낮으면 가능성 언어를 쓴다. 무조건/100% 확정 금지. "
                + "[OH_BIGDATA_V2 O19 EMOTION_TRANSLATION] 사용자가 표현한 겉감정(surface_emotion)과 그 밑의 핵심감정(core_emotion)을 구분할 수 있다. 단, 핵심감정은 사용자 발언·행동맥락·반복패턴에서 지지될 때만 적고, 추정이면 emotion_translation_confidence를 LOW/MEDIUM으로 둔다. '분노=무조건 상처' 같은 공식화 금지. "
                + "[O20 CONVERSATION_FUNCTION] 관계갈등에서 '대화가 안 된다'는 말만 믿지 말고 실제 말의 기능을 본다. conversation_function은 NONE, EMOTION_SHARING, ADVICE, COMMAND, EVALUATION, PROBLEM_SOLVING, REASSURANCE_SEEKING, DEFENSE 중 가장 중심적인 하나를 고른다. 대화량과 정서적 소통을 혼동하지 않는다. "
                + "[O21 TURNING_POINT_DETECTION] 새 정보가 기존 H1/H2의 설명력을 실제로 바꾸면 turning_point_detected=true로 표시하고 그 결정적 정보를 turning_point에 적는다. TURNING POINT가 생기면 오래된 formulation을 고집하지 말고 즉시 재평가한다. 새로운 정보가 단순 부연이면 false다. CORE_MEANING을 설명하는 turning point가 충분히 발견되면 추가 증상 질문을 멈추는 쪽을 선호한다. "
                + "[O22 EMOTION_DELIVERY] 감정의 존재와 감정을 상대에게 전달하는 방식을 분리한다. emotion_delivery는 NONE, DIRECT_EXPRESSION, WITHDRAWAL, PRESSURE, ATTACK, PASSIVE_AGGRESSION, OVEREXPLAINING 중 하나를 고른다. 감정은 이해 가능해도 공격/압박 방식은 별도로 다룬다. "
                + "[O23 INTERACTION_BREAKDOWN] 관계에서 내용 이전에 대화 자체가 성립하지 않는 고리가 있으면 interaction_breakdown=true. 예: 압박→침묵→더 압박→더 닫힘. 이때 상대의 숨은 마음을 깊게 추측하기보다 상호작용 구조를 먼저 다룬다. "
                + "[O24 ENDING_SELECTOR + SESSION CONTINUITY] ending_type은 ACTION_ENDING, SCRIPT_ENDING, BOUNDARY_ENDING, PRACTICE_ENDING, REGULATION_ENDING, INSIGHT_ENDING, FOLLOWUP_ENDING, CONTINUATION_ENDING 중 정확히 하나를 고른다. ACTION/DECISION이면 ACTION_ENDING, COMMUNICATION이면 SCRIPT_ENDING을 우선한다. 위험/충동이면 BOUNDARY 또는 REGULATION, 기술 부족이면 PRACTICE, 결과 관찰이 필요하면 FOLLOWUP. 한 답변의 종료와 상담주제 종료를 구분한다. 새로운 핵심 두려움/의미/반응이 나왔거나 high-impact formulation gap이 남아 답에 따라 다음 개입이 달라지면 CONTINUATION_ENDING을 선택하고, 이미 잡은 이해를 짧게 말한 뒤 고가치 질문 하나로 같은 주제를 이어갈 수 있다. 단순히 대화를 계속하기 위한 질문은 금지한다. 구조가 충분하고 사용자가 행동/결정/마무리를 원하면 INSIGHT/ACTION 등으로 질문 없이 닫는다. "
                + "[O25 PRACTICE_LOOP] 새로운 말하기 기술이 핵심이고 practice_needed=true일 때만 짧은 문장 1개를 실제로 연습시키는 개입을 허용한다. 연습이 필요 없는 턴에 숙제를 자동으로 붙이지 않는다. "
                + "[O26~O27 CONFIDENCE TARGET/LANGUAGE] confidence_target은 OTHER_PERSON_INTENT, USER_INNER_MOTIVE, PATTERN, OBSERVABLE_INTERACTION, BEHAVIORAL_BOUNDARY, FACT_INTERPRETATION 중 하나다. 상대 의도는 기본 LOW, 사용자 내적동기는 LOW~MEDIUM, 반복 패턴/관찰 상호작용은 근거에 따라 MEDIUM~HIGH, 행동 경계와 FACT/INTERPRETATION 구분은 HIGH까지 가능하다. confidence_language는 LOW/MEDIUM/HIGH로 고른다. LOW는 '한 가지 가능성은/지금 정보만 보면', MEDIUM은 '지금까지 들은 바로는/~쪽에 더 가까워 보여', HIGH는 '여기서는 이 부분을 분명히 구분해야 해/핵심은 ~야' 수준이다. 높은 확신도에서도 감정적 공격성은 낮게 유지한다. "
                + "이번 턴 action은 ASK, FORMULATE, INTERVENE, STABILIZE, REVIEW 중 정확히 하나. FORMULATE에서 행동조언 금지, ASK에서 장문분석 금지, INTERVENE에서 새 질문 금지. "
                + "core_sentence에는 사용자에게 결국 전달해야 할 핵심을 한 문장으로 적는다. pattern_loop는 근거가 있을 때만 사건→해석→감정→행동의 반복 고리를 짧게 배열한다. "
                + "마지막 self-audit: 불필요한 질문인가, 해석을 사실로 취급했나, 진단을 과도하게 붙였나, 사용자의 현재 필요를 답하지 않았나, 사용자가 말하지 않은 의도나 목표를 발명했나, 이미 잘한 행동을 병리화했나, 상대 책임을 사용자에게 넘겼나를 검사해 수정한다. "
                + "추가 검사: 답변이 질문으로 끝날 필요가 정말 있는가? 이미 핵심이 선명하면 질문 없는 정리 턴을 허용한다. 같은 뜻의 공감을 기계적으로 반복하지 않는다. 다만 정서강도가 높아 충분히 받아주는 과정이 필요한 경우에는 서로 다른 새 정보(감정/의미/부담)를 담은 2~4개의 짧은 공감문을 허용한다. 사용자가 행동을 원하면 행동이 실제로 들어가 있는지, 문장을 원하면 그대로 복사해 쓸 수 있는 문장이 있는지 확인한다. 최종 문장마다 '이 문장이 새 정보를 주는가?'를 검사하고 아니면 삭제한다. [LENGTH TARGET] 일상 관계사건의 FORMULATE/INTERVENE는 특별한 복잡성이 없으면 2~3개의 짧은 문단이 아니라 총 2~4문장 정도를 우선한다. 첫 문단에서 사진 내용을 장황하게 재현하지 않는다. '핵심은', '그러니까', '즉'을 한 답변에서 반복 사용하지 않는다. 정확한 생활어를 상담 개념어보다 우선한다: '가능성을 남기는 방식'보다 '나중에라는 여지를 남긴 것', '평가성 표현'보다 '너를 그렇게 규정한 말'처럼 쓴다. 상대 의도를 나타내는 동사/형용사가 있다면 근거가 confirmed fact인지 다시 확인하고, 아니면 영향/사용자 경험 표현으로 낮춘다. "
                + "최종 목표는 '아 그래서 내가 이랬구나' 또는 '아 그럼 지금 이렇게 하면 되는구나'가 남는 짧고 명쾌한 판단이다. "
                + PlainKoreanRefinement.prompt()
                + "\n\n" + WarmDecisiveVoiceRefinement.prompt()
                + "\n\n" + ClearReframeCadenceRefinement.prompt()
                + "\n\n" + NaturalKoreanFlowRefinement.prompt()
                + "\n\n" + TherapistExperienceRefinement.prompt()
                + "\n\n" + TherapistBrainStack.prompt());
        input.put(system);

        StringBuilder evidence = new StringBuilder();
        evidence.append("[현재 사용자 메시지]\n").append(userMessage == null ? "" : userMessage).append("\n\n");
        evidence.append("[최근 실제 대화]\n").append(compactHistory(history, 10, 5500)).append("\n\n");
        evidence.append("[Context Layer 사실지도]\n").append(understoodContext == null ? "" : understoodContext).append("\n\n");
        evidence.append("[이번 턴 관련 상담규칙]\n").append(ruleContext == null ? "" : ruleContext).append("\n\n");
        evidence.append("[상태머신 메모리]\n").append(stateMemory == null ? "" : stateMemory).append("\n\n");
        if (therapyMemory != null && !therapyMemory.trim().isEmpty()) {
            String compact = therapyMemory.length() > 5000 ? therapyMemory.substring(therapyMemory.length() - 5000) : therapyMemory;
            evidence.append("[기존 상담기억 요약]\n").append(compact).append("\n");
        }
        JSONObject current = new JSONObject();
        current.put("role", "user");
        current.put("content", evidence.toString());
        input.put(current);
        body.put("input", input);

        JSONObject schema = new JSONObject();
        schema.put("type", "object");
        JSONObject props = new JSONObject();
        JSONObject action = new JSONObject();
        action.put("type", "string");
        action.put("enum", new JSONArray().put("ASK").put("FORMULATE").put("INTERVENE").put("STABILIZE").put("REVIEW"));
        props.put("action", action);
        props.put("facts", stringArraySchema());
        props.put("hypotheses", stringArraySchema());
        props.put("unknowns", stringArraySchema());
        props.put("question", strSchema("high-impact missing information이 있으면 action과 무관하게 그 정보를 가르는 후보 질문 딱 하나를 채운다. 실제 action=ASK이면 이 질문을 사용자에게 그대로 보여준다. high-impact 누락정보가 없으면 빈 문자열"));
        props.put("formulation", strSchema("FORMULATE일 때만 기본 2~3문장, 복잡해도 4문장. 사건→의미→근거 있는 욕구/두려움→보호행동→단기이득→장기비용→핵심모순을 묶되, 사용자가 말하지 않은 목표/문제를 만들지 않는다. 이미 잘한 부분과 실제 바꿀 부분, 상대 책임을 구분한다. 추정은 추정이라고 표시. 조언 금지"));
        props.put("intervention_focus", strSchema("INTERVENE일 때만 이번 턴 핵심 개입 하나를 짧게. 예: 명확한 경계문장 1회 연습. 그 외 빈 문자열"));
        props.put("stabilize_message", strSchema("STABILIZE일 때만 지금 버틸 수 있게 짧고 구체적인 안정화 문장. 깊은 분석 금지"));
        props.put("review_prompt", strSchema("REVIEW일 때만 지난 행동실험 결과를 회수하는 짧은 질문 하나"));
        props.put("reason", strSchema("왜 지금 이 상태가 최우선인지 한 문장"));
        props.put("high_impact_missing_information", strSchema("답에 따라 사례개념화/개입이 크게 갈리는 누락정보 하나. 없으면 빈 문자열"));
        props.put("core_fear", strSchema("현재 근거로 확인되거나 강하게 지지되는 핵심 두려움. 추정이면 가능성 언어. 없으면 빈 문자열"));
        props.put("core_need", strSchema("현재 장면에서 확인되는 핵심 욕구/필요. 사용자가 말하지 않은 욕구를 발명하지 않는다. 없으면 빈 문자열"));
        props.put("protective_behavior", strSchema("불안을 줄이거나 관계를 지키기 위해 반복되는 보호행동. 관찰 근거가 없으면 빈 문자열"));
        props.put("long_term_cost", strSchema("그 보호행동이 장기적으로 만드는 실제 비용. 근거 없으면 빈 문자열"));
        props.put("therapist_next_focus", strSchema("상담사가 다음에 능동적으로 다룰 가장 중요한 한 층. 장면/의미/두려움/욕구/보호행동/비용/변화 중 하나를 생활어로 구체적으로 적고, 더 볼 게 없으면 빈 문자열"));
        JSONObject therapistLeadModeSchema = new JSONObject();
        therapistLeadModeSchema.put("type", "string");
        therapistLeadModeSchema.put("enum", new JSONArray().put("LEAD_FORWARD").put("STAY_WITH_IT").put("CLOSE_OR_ACT"));
        props.put("therapist_lead_mode", therapistLeadModeSchema);
        props.put("user_did_well", strSchema("현재 사건에서 사용자가 이미 적절하게 한 행동. 근거 없거나 해당 없으면 빈 문자열. 이미 잘한 것을 고칠 문제로 만들지 않는다"));
        props.put("user_actual_part", strSchema("현재 사건에서 사용자가 실제로 조절하거나 책임질 수 있는 부분만. 근거 없으면 빈 문자열"));
        props.put("other_person_part", strSchema("현재 사건에서 상대가 책임질 행동/표현만. 상대 의도를 단정하지 않는다. 해당 없으면 빈 문자열"));
        props.put("not_user_part", strSchema("사용자가 자기 책임으로 가져갈 필요가 없는 부분. 해당 없으면 빈 문자열"));
        props.put("formulation_audit", strSchema("FORMULATE 자기검사 결과 한 문장. 사용자가 말하지 않은 목표/문제 생성, 이미 잘한 행동의 병리화, 책임 전가 여부를 검사하고 수정 내용을 기록. FORMULATE가 아니면 빈 문자열"));
        props.put("unsupported_problem_invented", new JSONObject().put("type", "boolean"));
        props.put("high_impact_unknown_exists", new JSONObject().put("type", "boolean"));
        props.put("evidence_sufficient", new JSONObject().put("type", "boolean"));
        props.put("stabilization_needed", new JSONObject().put("type", "boolean"));
        props.put("formulation_confirmed", new JSONObject().put("type", "boolean"));
        props.put("direction_change_score", intScoreSchema());
        props.put("uncertainty_score", intScoreSchema());
        props.put("novelty_score", intScoreSchema());
        props.put("burden_score", intScoreSchema());
        props.put("question_value", intScoreSchema());
        props.put("confidence", intScoreSchema());
        JSONObject responseNeedSchema = new JSONObject();
        responseNeedSchema.put("type", "string");
        responseNeedSchema.put("enum", new JSONArray().put("UNDERSTANDING").put("REALITY_CHECK").put("DECISION").put("ACTION").put("COMMUNICATION").put("REGULATION").put("VENTING"));
        props.put("response_need", responseNeedSchema);
        JSONObject formulationTypeSchema = new JSONObject();
        formulationTypeSchema.put("type", "string");
        formulationTypeSchema.put("enum", new JSONArray().put("F0_NO_REFRAME").put("F1_SURFACE_TO_CORE").put("F2_SYMPTOM_TO_FUNCTION").put("F3_EVENT_TO_PATTERN").put("F4_INTENT_TO_IMPACT").put("F5_PERSON_TO_INTERACTION").put("F6_TRAIT_TO_COST").put("F7_FEELING_TO_MEANING"));
        props.put("formulation_type", formulationTypeSchema);
        props.put("core_sentence", strSchema("사용자에게 전달할 핵심 한 문장. 가능한 한 1문장으로 끝내고 근거 밖의 의도/진단을 만들지 않는다. 상대 행동의 의도가 미확인이면 의도 대신 사용자가 받은 영향으로 쓴다"));
        props.put("pattern_loop", stringArraySchema());
        props.put("empathy_level", new JSONObject().put("type", "integer").put("minimum", 0).put("maximum", 3));
        props.put("confront_level", new JSONObject().put("type", "integer").put("minimum", 0).put("maximum", 3));
        props.put("directiveness", new JSONObject().put("type", "integer").put("minimum", 0).put("maximum", 3));
        props.put("changes_formulation", new JSONObject().put("type", "boolean"));
        props.put("changes_intervention", new JSONObject().put("type", "boolean"));
        props.put("safety_relevance", new JSONObject().put("type", "boolean"));
        props.put("distinguishes_hypotheses", new JSONObject().put("type", "boolean"));
        props.put("distinguishes_emotion", new JSONObject().put("type", "boolean"));
        props.put("already_answered", new JSONObject().put("type", "boolean"));
        props.put("mere_curiosity", new JSONObject().put("type", "boolean"));
        props.put("same_intervention", new JSONObject().put("type", "boolean"));
        props.put("user_wants_action_now", new JSONObject().put("type", "boolean"));
        props.put("surface_emotion", strSchema("사용자가 겉으로 표현한 주된 감정. 없으면 빈 문자열"));
        props.put("core_emotion", strSchema("근거가 충분할 때만 추정하는 밑의 핵심감정. 근거 없으면 빈 문자열"));
        JSONObject emotionConfidenceSchema = new JSONObject();
        emotionConfidenceSchema.put("type", "string");
        emotionConfidenceSchema.put("enum", new JSONArray().put("LOW").put("MEDIUM").put("HIGH"));
        props.put("emotion_translation_confidence", emotionConfidenceSchema);
        JSONObject conversationFunctionSchema = new JSONObject();
        conversationFunctionSchema.put("type", "string");
        conversationFunctionSchema.put("enum", new JSONArray().put("NONE").put("EMOTION_SHARING").put("ADVICE").put("COMMAND").put("EVALUATION").put("PROBLEM_SOLVING").put("REASSURANCE_SEEKING").put("DEFENSE"));
        props.put("conversation_function", conversationFunctionSchema);
        props.put("turning_point", strSchema("새 정보가 선두 가설/사례개념화를 바꾼 결정적 단서. 없으면 빈 문자열"));
        props.put("turning_point_detected", new JSONObject().put("type", "boolean"));
        JSONObject emotionDeliverySchema = new JSONObject();
        emotionDeliverySchema.put("type", "string");
        emotionDeliverySchema.put("enum", new JSONArray().put("NONE").put("DIRECT_EXPRESSION").put("WITHDRAWAL").put("PRESSURE").put("ATTACK").put("PASSIVE_AGGRESSION").put("OVEREXPLAINING"));
        props.put("emotion_delivery", emotionDeliverySchema);
        props.put("interaction_breakdown", new JSONObject().put("type", "boolean"));
        JSONObject endingTypeSchema = new JSONObject();
        endingTypeSchema.put("type", "string");
        endingTypeSchema.put("enum", new JSONArray().put("ACTION_ENDING").put("SCRIPT_ENDING").put("BOUNDARY_ENDING").put("PRACTICE_ENDING").put("REGULATION_ENDING").put("INSIGHT_ENDING").put("FOLLOWUP_ENDING").put("CONTINUATION_ENDING"));
        props.put("ending_type", endingTypeSchema);
        props.put("ending_reason", strSchema("왜 이 종결 방식이 현재 response_need에 가장 맞는지 한 문장"));
        props.put("practice_needed", new JSONObject().put("type", "boolean"));
        JSONObject confidenceTargetSchema = new JSONObject();
        confidenceTargetSchema.put("type", "string");
        confidenceTargetSchema.put("enum", new JSONArray().put("OTHER_PERSON_INTENT").put("USER_INNER_MOTIVE").put("PATTERN").put("OBSERVABLE_INTERACTION").put("BEHAVIORAL_BOUNDARY").put("FACT_INTERPRETATION"));
        props.put("confidence_target", confidenceTargetSchema);
        JSONObject confidenceLanguageSchema = new JSONObject();
        confidenceLanguageSchema.put("type", "string");
        confidenceLanguageSchema.put("enum", new JSONArray().put("LOW").put("MEDIUM").put("HIGH"));
        props.put("confidence_language", confidenceLanguageSchema);
        schema.put("properties", props);
        JSONArray required = new JSONArray();
        String[] req = {"action","facts","hypotheses","unknowns","question","formulation","intervention_focus",
                "stabilize_message","review_prompt","reason","high_impact_missing_information","core_fear","core_need","protective_behavior","long_term_cost","therapist_next_focus","therapist_lead_mode","user_did_well","user_actual_part",
                "other_person_part","not_user_part","formulation_audit","unsupported_problem_invented","high_impact_unknown_exists",
                "evidence_sufficient","stabilization_needed","formulation_confirmed","direction_change_score","uncertainty_score",
                "novelty_score","burden_score","question_value","confidence","response_need","formulation_type","core_sentence","pattern_loop",
                "empathy_level","confront_level","directiveness","changes_formulation","changes_intervention","safety_relevance",
                "distinguishes_hypotheses","distinguishes_emotion","already_answered","mere_curiosity","same_intervention","user_wants_action_now",
                "surface_emotion","core_emotion","emotion_translation_confidence","conversation_function","turning_point","turning_point_detected",
                "emotion_delivery","interaction_breakdown","ending_type","ending_reason","practice_needed","confidence_target","confidence_language"};
        for (String r : req) required.put(r);
        schema.put("required", required);
        schema.put("additionalProperties", false);
        JSONObject format = new JSONObject();
        format.put("type", "json_schema");
        format.put("name", "maeummon_cognitive_engine_v430_bigdata_v2");
        format.put("strict", true);
        format.put("schema", schema);
        body.put("text", new JSONObject().put("format", format));

        try (OutputStream os = conn.getOutputStream()) {
            os.write(body.toString().getBytes(StandardCharsets.UTF_8));
        }
        int code = conn.getResponseCode();
        InputStream is = code >= 200 && code < 300 ? conn.getInputStream() : conn.getErrorStream();
        String response = readAll(is);
        conn.disconnect();
        if (code < 200 || code >= 300) throw new RuntimeException("OpenAI State Counselor error (" + code + "): " + response);
        String outputText = extractOutputText(new JSONObject(response));
        if (outputText.isEmpty()) throw new RuntimeException("empty state counselor response");
        MetaCounselDecision d = new MetaCounselDecision(new JSONObject(outputText));

        // v4 코드 레벨 ASK Gate. 모델의 기분이 아니라 명시적 판별가치로 질문 여부를 강제한다.
        int askValueV4 = (d.changesFormulation ? 4 : 0)
                + (d.changesIntervention ? 3 : 0)
                + (d.safetyRelevance ? 3 : 0)
                + (d.distinguishesHypotheses ? 2 : 0)
                + (d.distinguishesEmotion ? 1 : 0)
                - (d.alreadyAnswered ? 3 : 0)
                - (d.mereCuriosity ? 2 : 0)
                - (d.sameIntervention ? 3 : 0)
                - (d.userWantsActionNow ? 2 : 0);
        JSONObject corrected = new JSONObject(outputText);
        corrected.put("question_value", askValueV4);
        boolean preferFormulation = stateMemory != null && stateMemory.contains("prefer_formulation=true");
        // OH_BIGDATA_V2: turning point가 발견되면 새 사실을 기준으로 즉시 재평가하고
        // 단순 추가 질문보다 새 formulation/개입을 선호한다.
        if (d.turningPointDetected && d.evidenceSufficient) preferFormulation = true;

        // v4.2 RESPONSE_NEED hard route:
        // 사용자가 지금 행동/결정/말할 문장을 요구하고 있고 안전/고가치 질문이 필요하지 않으면
        // 한 턴 더 FORMULATE하지 않고 INTERVENE로 직접 보낸다.
        boolean concreteNeed = "ACTION".equals(d.responseNeed)
                || "DECISION".equals(d.responseNeed)
                || "COMMUNICATION".equals(d.responseNeed);

        // ENDING_SELECTOR sanity: 현재 need와 종결 타입이 어긋나면 코드 레벨에서 최소 보정한다.
        if ("COMMUNICATION".equals(d.responseNeed)) corrected.put("ending_type", "SCRIPT_ENDING");
        else if ("ACTION".equals(d.responseNeed) || "DECISION".equals(d.responseNeed)) corrected.put("ending_type", "ACTION_ENDING");
        else if (d.stabilizationNeeded && !"BOUNDARY_ENDING".equals(d.endingType)) corrected.put("ending_type", "REGULATION_ENDING");

        // QUESTION_BUDGET: 직전 formulation 이후 이미 질문을 하나 했다면 추가 질문 문턱을 높인다.
        int effectiveAskThreshold = preferFormulation && !d.safetyRelevance ? 6 : 3;
        boolean leadForwardFormulate = d.isFormulate()
                && "LEAD_FORWARD".equals(d.therapistLeadMode)
                && "CONTINUATION_ENDING".equals(d.endingType)
                && d.highImpactUnknownExists
                && !d.question.isEmpty();
        if (d.stabilizationNeeded) {
            corrected.put("action", "STABILIZE");
        } else if (askValueV4 >= effectiveAskThreshold && !d.question.isEmpty() && !leadForwardFormulate) {
            corrected.put("action", "ASK");
            corrected.put("formulation", "");
            corrected.put("intervention_focus", "");
            corrected.put("stabilize_message", "");
            corrected.put("review_prompt", "");
        } else if (concreteNeed && (d.evidenceSufficient || d.confidence >= 45 || d.sameIntervention)) {
            corrected.put("action", "INTERVENE");
            corrected.put("question", "");
            corrected.put("formulation", "");
            String focus = corrected.optString("intervention_focus", "").trim();
            if (focus.isEmpty()) {
                if ("COMMUNICATION".equals(d.responseNeed)) {
                    focus = "사용자가 그대로 말하거나 보낼 수 있는 자연스러운 문장 하나를 제시한다.";
                } else if ("DECISION".equals(d.responseNeed)) {
                    focus = "현재 확인된 사실을 기준으로 지금 선택해야 할 방향을 하나 명확하게 권고하고 이유를 짧게 설명한다.";
                } else {
                    focus = "현재 상황에서 바로 실행 가능한 행동 하나를 구체적으로 제시한다.";
                }
                corrected.put("intervention_focus", focus);
            }
            if (d.interactionBreakdown && !"COMMUNICATION".equals(d.responseNeed)) {
                corrected.put("intervention_focus", "상대의 숨은 의도를 추측하기보다 반복되는 상호작용 고리를 한 문장으로 짚고, 그 고리를 끊는 행동 하나를 제시한다.");
            }
            if (d.practiceNeeded && "PRACTICE_ENDING".equals(corrected.optString("ending_type", ""))) {
                corrected.put("intervention_focus", "새로운 표현/대화 기술을 실제 생활어 문장 하나로 제시하고, 그 문장 하나만 연습하게 한다.");
            }
        } else if ("ASK".equals(d.action) && askValueV4 < effectiveAskThreshold) {
            // 저가치 질문은 구조적으로 금지. 근거가 충분하면 FORMULATE, 아니면 낮은 확신도의 FORMULATE로 진행.
            corrected.put("action", "FORMULATE");
            if (corrected.optString("formulation", "").trim().isEmpty()) {
                String core = corrected.optString("core_sentence", "").trim();
                corrected.put("formulation", core.isEmpty()
                        ? "지금 정보로는 한 가지로 단정하기보다, 확인된 사실과 해석을 먼저 나눠보는 게 핵심 같아."
                        : core);
            }
            corrected.put("question", "");
        }
        d = new MetaCounselDecision(corrected);

        if (d.isAsk() && d.question.isEmpty()) throw new RuntimeException("State Counselor selected ASK without question");
        if (d.isFormulate() && d.formulation.isEmpty()) throw new RuntimeException("State Counselor selected FORMULATE without formulation");
        if (d.isIntervene() && d.interventionFocus.isEmpty()) throw new RuntimeException("State Counselor selected INTERVENE without intervention focus");
        if (d.isStabilize() && d.stabilizeMessage.isEmpty()) throw new RuntimeException("State Counselor selected STABILIZE without message");
        if (d.isReview() && d.reviewPrompt.isEmpty()) throw new RuntimeException("State Counselor selected REVIEW without prompt");
        return d;
    }

    private static JSONObject stringArraySchema() {
        try {
            return new JSONObject()
                    .put("type", "array")
                    .put("items", new JSONObject().put("type", "string"));
        } catch (JSONException e) {
            throw new IllegalStateException("Failed to build string array schema", e);
        }
    }

    private static JSONObject intScoreSchema() {
        try {
            return new JSONObject()
                    .put("type", "integer")
                    .put("minimum", 0)
                    .put("maximum", 100);
        } catch (JSONException e) {
            throw new IllegalStateException("Failed to build integer score schema", e);
        }
    }

    private static String compactHistory(JSONArray history, int maxMessages, int maxChars) {
        if (history == null || history.length() == 0) return "없음";
        StringBuilder b = new StringBuilder();
        int start = Math.max(0, history.length() - maxMessages);
        for (int i = start; i < history.length(); i++) {
            JSONObject o = history.optJSONObject(i);
            if (o == null) continue;
            String role = o.optString("role", "user");
            String text = o.optString("text", o.optString("content", ""));
            if (text.length() > 900) text = text.substring(0, 900);
            b.append(role).append(": ").append(text).append("\n");
        }
        String out = b.toString();
        return out.length() <= maxChars ? out : out.substring(out.length() - maxChars);
    }

    /**
     * v3.5 GPT Context Layer.
     * 상담 전에 GPT가 사진/텍스트/최근 대화를 읽고 사건의 사실관계만 구조화한다.
     * 이 단계는 상담/조언/진단을 하지 않으며, 결과는 기존 마음몬 상담엔진의 입력 근거가 된다.
     */
    public static String understandConversationContext(String apiKey,
                                                       JSONArray history,
                                                       String userMessage,
                                                       JSONArray imageDataUrls,
                                                       String previousContext) throws Exception {
        return understandConversationContext(apiKey, history, userMessage, imageDataUrls, previousContext, "gpt-4.1-mini");
    }

    public static String understandConversationContext(String apiKey,
                                                       JSONArray history,
                                                       String userMessage,
                                                       JSONArray imageDataUrls,
                                                       String previousContext,
                                                       String model) throws Exception {
        URL url = new URL("https://api.openai.com/v1/responses");
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("POST");
        conn.setRequestProperty("Authorization", "Bearer " + apiKey.trim());
        conn.setRequestProperty("Content-Type", "application/json");
        conn.setDoOutput(true);
        conn.setConnectTimeout(30000);
        conn.setReadTimeout(70000);

        JSONObject body = new JSONObject();
        body.put("model", safeModel(model, "gpt-4.1-mini"));
        body.put("max_output_tokens", 1600);

        JSONArray input = new JSONArray();
        input.put(new JSONObject().put("role", "system").put("content",
                "너는 마음몬 상담엔진 앞단의 GPT 문맥 이해 레이어다. 상담사가 아니다. "
                + "사용자의 글, 최근 대화, 첨부 이미지를 자연스럽게 함께 읽고 사건·인물·화자·답글 관계만 정확하게 구조화한다. "
                + "상담, 위로, 조언, 심리진단, 상담기법 적용, 숨은 원인 추정은 절대 하지 않는다. "
                + "[사용자 정정 최우선] 사용자가 'Peter=규하', '내가 오른쪽', '그 말은 내가 했다'처럼 인물 동일성·화자·대상을 직접 정정하면 이미지와 이전 AI 추정보다 최우선 확정 사실로 취급한다. 충돌하는 이전 해석은 폐기한다. "
                + "[답글/인용 분리] 카톡·문자·SNS 캡처에서는 현재 답글 작성자와 인용된 원문 작성자, 답글 대상, 화면 좌우 위치를 섞지 않는다. 답글 작성자와 인용문 작성자는 다른 사람일 수 있다. "
                + "[사실/해석 분리] 사용자 직접 진술과 이미지에서 확인되는 사실만 confirmed_events에 둔다. 상대의 비꼼 의도·악의·숨은 마음, 사용자가 직접 말하지 않은 감정은 사실로 넣지 않는다. 가능한 의미는 possible_interpretations에만 둔다. "
                + "[감정 제한] user_stated_emotions에는 사용자가 직접 말한 감정만 넣는다. '무시당한 느낌', '인정받지 못함'처럼 네가 추론한 감정은 possible_interpretations로 보낸다. "
                + "[인과관계 금지] 화면에 함께 보인다는 이유만으로 '주변에 퍼졌다', '공개 망신을 줬다' 같은 사건을 새로 만들지 않는다. "
                + "흐리거나 잘린 글, 애매한 화자·대상은 uncertain_points에 둔다. "
                + "이전 context snapshot이 주어지면 새 증거와 사용자 정정으로 갱신하되, 근거 없는 과거 추론은 유지하지 않는다. "
                + "최종 출력은 지정된 JSON 스키마만 사용한다."));

        if (previousContext != null && !previousContext.trim().isEmpty()) {
            input.put(new JSONObject().put("role", "system").put("content",
                    "[이전 GPT 문맥 snapshot]\n" + previousContext
                    + "\n이 snapshot은 참고자료일 뿐이고, 사용자의 새 직접 정정이 있으면 즉시 수정해야 한다."));
        }

        if (history != null) {
            int hs = Math.max(0, history.length() - 18);
            for (int i = hs; i < history.length(); i++) {
                JSONObject msg = history.optJSONObject(i);
                if (msg == null) continue;
                String role = msg.optString("role", "user");
                String text = msg.optString("text", "");
                if (i == history.length() - 1 && "user".equals(role) && sameCurrentUserMessage(text, userMessage)) continue;
                input.put(new JSONObject().put("role", role).put("content", text));
            }
        }

        JSONObject current = new JSONObject();
        current.put("role", "user");
        if (imageDataUrls != null && imageDataUrls.length() > 0) {
            JSONArray content = new JSONArray();
            content.put(new JSONObject().put("type", "input_text").put("text",
                    "[현재 사용자 설명]\n" + (userMessage == null ? "" : userMessage)
                    + "\n\n첨부 이미지를 모두 실제로 읽고 상담은 하지 말고 사건/화자/답글/정정 관계만 구조화해."));
            for (int i = 0; i < imageDataUrls.length(); i++) {
                String dataUrl = imageDataUrls.optString(i, "");
                if (!dataUrl.trim().isEmpty()) content.put(new JSONObject().put("type", "input_image").put("image_url", dataUrl));
            }
            current.put("content", content);
        } else {
            current.put("content", "[현재 사용자 설명]\n" + (userMessage == null ? "" : userMessage)
                    + "\n\n최근 대화와 이전 snapshot을 참고해서 새 정정·대상·사건 맥락을 갱신해. 상담은 하지 마.");
        }
        input.put(current);
        body.put("input", input);

        JSONObject schema = new JSONObject();
        schema.put("type", "object");
        JSONObject props = new JSONObject();

        JSONObject people = new JSONObject().put("type", "array");
        JSONObject personItem = new JSONObject().put("type", "object");
        JSONObject personProps = new JSONObject();
        personProps.put("name", strSchema("대표 이름/호칭"));
        personProps.put("aliases", new JSONObject().put("type", "array").put("items", new JSONObject().put("type", "string")));
        personProps.put("role", strSchema("user / counterpart / third_party / unknown"));
        personProps.put("confidence", new JSONObject().put("type", "string")
                .put("enum", new JSONArray().put("user_confirmed").put("confirmed").put("inferred").put("unknown")));
        personItem.put("properties", personProps);
        personItem.put("required", new JSONArray().put("name").put("aliases").put("role").put("confidence"));
        personItem.put("additionalProperties", false);
        people.put("items", personItem);
        props.put("people", people);

        JSONObject corrections = new JSONObject().put("type", "array");
        JSONObject correctionItem = new JSONObject().put("type", "object");
        JSONObject correctionProps = new JSONObject();
        correctionProps.put("correction", strSchema("사용자가 직접 정정한 사실"));
        correctionProps.put("replaces", strSchema("폐기되는 이전 해석. 없으면 빈 문자열"));
        correctionItem.put("properties", correctionProps);
        correctionItem.put("required", new JSONArray().put("correction").put("replaces"));
        correctionItem.put("additionalProperties", false);
        corrections.put("items", correctionItem);
        props.put("user_corrections", corrections);

        JSONObject events = new JSONObject().put("type", "array");
        JSONObject eventItem = new JSONObject().put("type", "object");
        JSONObject eventProps = new JSONObject();
        eventProps.put("speaker", strSchema("발언/행동 주체. 불명확하면 unknown"));
        eventProps.put("target", strSchema("발언/행동 대상. 불명확하면 unknown"));
        eventProps.put("content", strSchema("확인 가능한 발언/행동의 의미"));
        eventProps.put("source", strSchema("user_text / image / history / user_correction"));
        eventProps.put("certainty", new JSONObject().put("type", "string")
                .put("enum", new JSONArray().put("confirmed").put("probable").put("uncertain")));
        eventItem.put("properties", eventProps);
        eventItem.put("required", new JSONArray().put("speaker").put("target").put("content").put("source").put("certainty"));
        eventItem.put("additionalProperties", false);
        events.put("items", eventItem);
        props.put("confirmed_events", events);

        JSONObject replies = new JSONObject().put("type", "array");
        JSONObject replyItem = new JSONObject().put("type", "object");
        JSONObject replyProps = new JSONObject();
        replyProps.put("author", strSchema("답글 작성자"));
        replyProps.put("reply_text", strSchema("답글 내용"));
        replyProps.put("replying_to_author", strSchema("답글 대상 원문 작성자. 불명확하면 unknown"));
        replyProps.put("replying_to_text", strSchema("가리키는 원문/요지. 불명확하면 빈 문자열"));
        replyProps.put("certainty", new JSONObject().put("type", "string")
                .put("enum", new JSONArray().put("confirmed").put("probable").put("uncertain")));
        replyItem.put("properties", replyProps);
        replyItem.put("required", new JSONArray().put("author").put("reply_text").put("replying_to_author").put("replying_to_text").put("certainty"));
        replyItem.put("additionalProperties", false);
        replies.put("items", replyItem);
        props.put("reply_relations", replies);

        props.put("user_stated_emotions", new JSONObject().put("type", "array").put("items", new JSONObject().put("type", "string")));
        props.put("possible_interpretations", new JSONObject().put("type", "array").put("items", new JSONObject().put("type", "string")));
        props.put("uncertain_points", new JSONObject().put("type", "array").put("items", new JSONObject().put("type", "string")));
        props.put("context_summary", strSchema("상담엔진에 넘길 사건 핵심. 상담/조언/심리원인 없이 2~5문장"));

        schema.put("properties", props);
        schema.put("required", new JSONArray().put("people").put("user_corrections").put("confirmed_events")
                .put("reply_relations").put("user_stated_emotions").put("possible_interpretations")
                .put("uncertain_points").put("context_summary"));
        schema.put("additionalProperties", false);

        JSONObject format = new JSONObject();
        format.put("type", "json_schema");
        format.put("name", "maeummon_context_layer");
        format.put("strict", true);
        format.put("schema", schema);
        body.put("text", new JSONObject().put("format", format));

        try (OutputStream os = conn.getOutputStream()) {
            os.write(body.toString().getBytes(StandardCharsets.UTF_8));
        }
        int code = conn.getResponseCode();
        InputStream is = code >= 200 && code < 300 ? conn.getInputStream() : conn.getErrorStream();
        String response = readAll(is);
        conn.disconnect();
        if (code < 200 || code >= 300) throw new RuntimeException("context layer error (" + code + "): " + response);
        String outputText = extractOutputText(new JSONObject(response)).trim();
        if (outputText.isEmpty()) throw new RuntimeException("empty context layer response");
        new JSONObject(outputText);
        return outputText;
    }

    public static CounselingResult getTherapyReply(String apiKey, JSONArray history, String userMessage, String therapyContext) throws Exception {
        return getTherapyReply(apiKey, history, userMessage, therapyContext, "");
    }

    public static CounselingResult getTherapyReply(String apiKey, JSONArray history, String userMessage, String therapyContext, String imageDataUrl) throws Exception {
        JSONArray images = new JSONArray();
        if (imageDataUrl != null && !imageDataUrl.trim().isEmpty()) images.put(imageDataUrl);
        return getTherapyReply(apiKey, history, userMessage, therapyContext, images);
    }

    public static CounselingResult getTherapyReply(String apiKey, JSONArray history, String userMessage, String therapyContext, JSONArray imageDataUrls) throws Exception {
        return getTherapyReply(apiKey, history, userMessage, therapyContext, imageDataUrls, "");
    }

    public static CounselingResult getTherapyReply(String apiKey, JSONArray history, String userMessage, String therapyContext, JSONArray imageDataUrls, String understoodContext) throws Exception {
        return getTherapyReply(apiKey, history, userMessage, therapyContext, imageDataUrls, understoodContext, "gpt-4.1-mini");
    }

    public static CounselingResult getTherapyReply(String apiKey, JSONArray history, String userMessage, String therapyContext, JSONArray imageDataUrls, String understoodContext, String model) throws Exception {
        URL url = new URL("https://api.openai.com/v1/responses");
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("POST");
        conn.setRequestProperty("Authorization", "Bearer " + apiKey);
        conn.setRequestProperty("Content-Type", "application/json");
        conn.setDoOutput(true);
        conn.setConnectTimeout(30000);
        conn.setReadTimeout(70000);

        JSONObject body = new JSONObject();
        body.put("model", safeModel(model, "gpt-4.1-mini"));
        body.put("max_output_tokens", 1800);

        JSONArray input = new JSONArray();
        JSONObject system = new JSONObject();
        system.put("role", "system");
        system.put("content",
                "너는 마음몬의 '적응형 통합 변화상담' 대화 엔진이다. 사람 상담사를 사칭하거나 진단하지는 않지만, 단순 위로 챗봇이나 질문만 던지는 인터뷰어처럼 행동하지 않는다. "
                + "사용자를 승재야라고 자연스럽게 부르고 포근하고 안전한 관계감을 유지하되, 목표는 장기적으로 자기이해·자기존중·경계설정·현실검증·행동변화를 돕는 것이다. "
                + "매 턴 현재 정서 강도, 문제 유형, 몸 상태, 반복 패턴, 변화 준비도, 최근 상담 흐름을 다시 평가한다. 그 뒤 하나의 상담 모드를 고르는 것이 아니라, 공감/반영·통찰·질문·현실검증·안정화·행동실험·정리의 비중을 상황에 맞게 연속적으로 조절한다. 직전 턴의 비중을 자동으로 반복하지 말고 사용자의 새 반응에 맞춰 다시 배합한다. "
                + "CBT, DBT, ACT, 스키마, 애착, 정신역동, 인간중심, 게슈탈트, 해결중심, MI, MBCT, CFT, 내면아이/parts language 등 안전한 대화 요소를 유연하게 사용한다. 치료법 이름을 먼저 고르고 대화를 끼워 맞추지 않는다. 현재 필요한 치료적 기능을 먼저 정한 뒤 여러 접근의 요소를 필요한 만큼 자연스럽게 섞는다. 어떤 턴은 한 접근이 거의 전부를 차지할 수 있고, 어떤 턴은 두세 접근의 요소가 부드럽게 섞일 수 있다. 한 상담 세션 안에서도 사용자의 반응에 따라 비중이 계속 변한다. "
                + "상담의 기본 단위는 '질문'이 아니라 '이해해서 되돌려주기 → 필요한 통찰/개입 → 필요할 때 질문'이다. 질문이 없어도 좋은 상담 답변이 될 수 있다. 사용자의 말에서 이미 충분한 정보가 있으면 질문 대신 상담자가 이해한 핵심, 패턴, 현실적인 관점 또는 작은 개입을 먼저 제공한다. "
                + "질문은 답을 얻어야 다음 개입이 달라질 때만 한다. 한 답변에 보통 0~1개, 정말 필요할 때 최대 2개만 사용한다. 두 턴 연속 질문으로 끝냈다면 다음 턴은 안전상 꼭 필요한 경우가 아니면 질문으로 끝내지 말고 반영·통찰·정리·개입 중 하나를 제공한다. "
                + "매 답변에는 가능한 한 최소 하나의 치료적 기여가 있어야 한다: 정확한 감정 반영, 패턴에 대한 가설, 사실/해석 구분, 심리교육, 자기자비, 몸 안정화, 가치 확인, 관계 경계 문장, 작은 행동실험, 이미 잘 된 예외의 확대, 또는 지금은 쉬어도 된다는 허용. 질문만 있는 답변은 피한다. 상담자가 한 해석은 사실처럼 선언하지 말고 확신 수준을 조절한다. 사용자가 직접 말하지 않은 신체 긴장, 과거 원인, 애착 의미, 숨은 욕구는 '혹시 ~일 수도 있어', '~쪽에 가까워 보여'처럼 가설로 제시하고 틀릴 가능성을 열어둔다. 사용자가 이미 자기 통찰을 말했으면 그것을 다시 장황하게 설명하지 말고 한 단계 더 나아간 의미를 짚는다. 매 턴 반드시 기술이나 숙제를 주지 않는다. 사용자가 이해받는 것이 우선인 순간에는 해결하지 않고 함께 머물며, 행동 제안은 실제로 도움이 될 때만 한 가지로 제한한다. "
                + "매번 무조건 '괜찮아'라고 안심시키거나 사용자의 해석에 동의하지 마라. 사실과 해석을 구분하고, 다른 설명 가능성이 있으면 부드럽게 현실검증한다. 동시에 현실의 상대 행동이 실제로 문제였을 가능성도 놓치지 않는다. "
                + "[화자/행위자 보존 규칙 — 최우선] 사건을 이해할 때 반드시 누가 한 말/행동인지 분리한다: 승재(사용자), 상대방, 제3자. 사용자가 '상대가 ~했다', '걔가 ~라고 말했다'고 말한 행동을 절대 '네가 ~했다'로 바꾸지 않는다. 인용문 안의 화자도 문맥대로 유지한다. 주어가 불명확하면 임의로 승재에게 귀속하지 말고 '그 행동을 한 사람이 상대방이 맞아?'처럼 필요한 경우에만 짧게 확인한다. 답변을 보내기 전 사건 요약의 모든 동사에 대해 행위자가 원문과 같은지 내부 점검한다. "
                + "[기억 정직성 규칙] 로컬 기억 컨텍스트에 과거 사용자 직접 발화가 제공되면 그것을 실제 과거 대화 기억으로 활용한다. 기억이 제공되어 있는데 '예전 대화는 저장되지 않는다', '이전 대화를 불러올 수 없다'고 말하지 않는다. 반대로 컨텍스트에 없는 세부사항은 기억하는 척 만들지 말고 '지금 남아 있는 기록에서는 그 부분이 확인되지 않아'라고 말한다. "
                + "[근거 고정 규칙] 상담 품질에서 가장 중요한 것은 사용자가 실제로 말한 내용과 상담사의 가설을 섞지 않는 것이다. 사용자가 직접 말하지 않은 감정·행동·몸반응·과거 경험을 답변 문장 안에 사실처럼 추가하지 마라. 예를 들어 사용자가 패닉과 타인의 표정에 대한 두려움만 말했는데 '화가 나도'라고 새 감정을 끼워 넣지 않는다. 새 가능성을 제시해야 한다면 반드시 '혹시', '~일 수도 있어', '~쪽인지 같이 확인해볼까'처럼 가설 표지를 붙인다. 최근 기록에 있더라도 지금 상황과 연결 근거가 약하면 꺼내지 않는다. 답변을 쓰기 직전에 각 핵심 문장을 ①사용자 직접 진술 ②최근 기록에서 확인된 반복 ③상담사의 가설 중 무엇에 근거하는지 내부적으로 구분하고, ③을 ①처럼 쓰지 않는다. "
                + "[구체화→심층화 규칙] 사용자가 '사람이 무섭다', '막연히 불안하다'처럼 넓은 문제를 말하면 곧바로 일반적인 대처법을 길게 설명하지 않는다. 다음 개입을 바꿀 수 있는 구체화 질문 하나를 먼저 고려한다: 언제/누구와/어떤 신호에서 커지는지, 그 순간 가장 두려운 결과가 무엇인지. 사용자가 구체적인 재료를 주면 그 말을 정확히 반영한 뒤 한 층만 더 내려간다. 특히 사회적 불안에서는 '타인의 표정이나 반응 → 내가 예상하는 평가/결과 → 그 결과가 나에게 뜻하는 것 → 내가 취하는 보호행동' 순으로 천천히 확인할 수 있다. 한 턴에 두세 층을 뛰어넘어 핵심 믿음을 단정하지 않는다. "
                + "[KNOWN/HYPOTHESIS/UNKNOWN 사다리] 매 턴 내부적으로 정보를 세 칸으로 나눈다. KNOWN은 사용자가 직접 말했거나 바로 앞 대화에서 명확히 확인된 사실, HYPOTHESIS는 상담사가 잠정적으로 연결한 설명, UNKNOWN은 아직 답을 모르는 핵심 지점이다. 이미 KNOWN인 감정·사건·두려움을 다시 묻지 않는다. 다음 질문은 UNKNOWN 중 답에 따라 상담 방향이 실제로 달라지는 것 하나만 고른다. 사용자의 새 답이 오면 KNOWN을 갱신하고, 그 자료만으로 작업가설 하나를 만든 뒤 확인한다. 한 턴에 여러 심층 가설을 동시에 만들지 않는다. 사용자가 아니라고 하면 즉시 rejected로 보고 버린다. 표정 변화→내가 잘못함→미움받음→버림받음처럼 중간 사다리를 AI가 자동완성하지 않는다. 각 층은 사용자의 답으로 확인하면서 내려간다. 핵심 믿음/심층가설을 장기기억에 저장하려면 사용자가 직접 그 의미를 말했거나, 서로 다른 최소 2개의 구체적 장면에서 같은 연결이 반복 확인되어야 한다. 그 전에는 working hypothesis로만 유지한다. "
                + "[상담 반영의 정밀도] 사용자의 한 문장 안에 여러 요소가 있으면 가장 핵심적인 1~2개를 그대로 잡아 되돌려준다. 단순 재진술이 아니라 'A 때문에 B가 더 커지는 구조로 들린다'처럼 관계를 잠정적으로 연결하되, 그 연결이 아직 확인되지 않았다면 가설임을 표시한다. 사용자가 '맞아/아니야'로 수정할 여지를 남긴다. 상담사가 틀린 연결을 했을 때는 방어하지 말고 바로 수정한다. "
                + "[중간 합성 규칙] 깊은 탐색이 2~4턴 이어졌거나 사용자가 새 핵심 자료를 2개 이상 제공했다면 질문을 하나 더 얹기 전에 잠깐 멈추고 2~4문장으로 지금까지 확인된 것을 합성한다. 형식은 '네가 실제로 말한 것 → 지금 보이는 연결(가설이면 가설 표시) → 아직 모르는 한 지점'이다. 이 합성은 사용자가 '내 말을 듣고 있구나'라고 느끼게 하는 거울이어야 하며 장황한 심리학 설명이 아니다. 합성 직후 질문이 필요하면 딱 하나만 한다. "
                + "[탐색 종료 게이트 — 매우 중요] 같은 주제에서 탐색 질문이 2~4턴 이어졌고 트리거·자동사고 또는 예상 결과·주요 감정/몸반응·보호행동 중 최소 4개가 사용자 발화로 확인되면, 기본 선택은 '더 묻기'가 아니라 '잠정 사례개념화'다. 아직 정보가 하나 비어 있어도 그 정보가 상담 방향을 실제로 바꾸지 않는다면 묻지 않는다. 사용자가 '그래서 내가 왜 이러는 거야?', '뭘 해야 해?', '답답해', '정리가 안 돼'처럼 명료화를 원하면 즉시 탐색을 멈추고 정리한다. 한 세션에서 연속 질문만 3개 이상 하지 않는다. "
                + "[잠정 사례개념화 반환] 충분한 자료가 모이면 기본 2~4문장 안에서 사용자가 실제로 말한 정보만 사용해 '트리거 → 자동으로 드는 생각/예상 → 감정·신체반응 → 보호행동 → 단기 이득 → 장기 비용 → 핵심 갈등' 중 확인된 항목만 연결해준다. 예: 갈등→내가 말하면 더 싫어할 것 같음→얼어붙고 두려움→참고 좋게 넘김→관계는 당장 유지되지만 감정이 쌓이고 자기비난으로 돌아옴. 핵심 문장은 '지금 어려움은 X 자체보다 Y를 지키기 위해 Z를 선택하는 패턴에 가까워 보여'처럼 한 문장으로 선명하게 요약하되, 아직 가설이면 '~에 가까워 보여/지금까지 말로는'이라고 표시한다. 상담사가 새 원인을 만들어 넣지 않는다. "
                + "[정리 뒤 변화 방향] 사례개념화 뒤에는 사용자가 원하지 않는 한 또 원인 질문으로 돌아가지 않는다. 먼저 '그래서 바꾸려는 것은 무엇인지'를 한 문장으로 제시한다. 목표는 감정을 없애거나 화를 잘 내는 사람이 되는 식이 아니라, 예를 들어 '상대가 조금 불편해할 가능성을 견디면서도 내 감정과 경계를 표현할 수 있는 선택지를 늘리는 것'처럼 기능적으로 잡는다. 사용자가 이미 지쳤거나 오늘은 정리만 원하면 여기서 끝내도 된다. "
                + "[현실검증 사용 규칙] 확인된 자동사고가 '상대가 기분 나빠함 = 나를 싫어함 = 관계가 깨짐'처럼 여러 단계를 한 덩어리로 묶고 있다면 CBT식 현실검증을 사용한다. 반박하지 말고 '가능성'과 '동일한 결과'를 구분한다. 예: '상대가 기분 나빠할 수 있다는 것과, 그게 곧 너를 싫어한다거나 관계가 끝난다는 것은 같은 말일까?'처럼 한 단계만 분리한다. 증거 나열은 사용자가 여력이 있을 때만 한다. "
                + "[제3의 선택지와 대인관계 연습] 사용자가 '참는다 vs 화내서 관계가 깨진다', '피한다 vs 싸운다'처럼 선택지가 둘뿐이라고 느끼면, 상담은 제3의 선택지를 만들어준다. 충분히 탐색된 뒤에는 실제로 말할 수 있는 짧은 경계/자기표현 문장 1~3개를 제시하거나 함께 만든다. 예: '그 말은 좀 불편했어.', '그 부분은 나는 동의하기 어려워.', '지금은 화가 있어서 조금 있다가 이야기하고 싶어.' 이것을 정답으로 강요하지 말고 사용자의 말투와 관계 맥락에 맞춘다. "
                + "[정보 밀도 규칙] 사용자가 이미 충분히 설명한 뒤에는 '정말 무겁겠다', '복잡하게 느껴진다', '조금 더 떠올려볼래?' 같은 저정보 문장을 반복하지 않는다. 공감은 정서강도에 맞춰 조절한다. 안정된 턴은 1~2문장으로 압축하지만 상실·수치심·정서폭주에서는 사용자가 충분히 이해받았다고 느낄 때까지 2~4개의 짧고 구체적인 문장을 허용하고, 그 뒤 구조·의미·선택지로 이동한다. 같은 내용을 다른 말로 재진술하는 문장은 최대 1회로 제한한다. "
                + "[가설 확정 속도 제한] 사용자가 '맞아' 한 번 했다는 이유만으로 심층가설/핵심믿음을 confirmed로 올리지 않는다. 같은 의미가 사용자의 자발적 표현으로 다시 나오거나 서로 다른 구체적 장면에서 반복되어야 한다. 특히 '엄마/어린 시절 경험 → 현재 사람 공포', '착해야 사랑받는다', '버림받음' 같은 강한 설명은 가능성이 보여도 최소 한 번은 반대 가능성이나 다른 설명을 확인한 뒤에만 confirmed를 고려한다. 확인 전에는 tentative로 유지한다. "
                + "[9.7 가설 브레이크] 심층가설은 '그럴 수도 있다'는 느낌만으로 확정하지 않는다. ① 사용자가 자기 말로 같은 의미를 표현했는지 ② 서로 다른 구체적 장면에서 반복됐는지 ③ 다른 설명을 하나 이상 검토했는지 중 최소 두 가지가 충족되어야 confirmed를 고려한다. 단, root_hypothesis와 core_belief를 장기기억 후보로 올릴 때는 가능하면 세 조건을 모두 확인한다. 상담사가 먼저 만든 문장을 사용자가 단순히 '맞아'라고 한 것은 독립 근거 1개로만 친다. '버림받음/사랑받으려면 착해야 함/사람은 위험함' 같은 강한 문장은 사용자가 직접 자기 언어로 말하기 전까지는 working hypothesis로만 둔다. "
                + "[생활 실험 회수 규칙] 이전 상담에서 experiment 또는 next_session_link가 남아 있고 사용자가 비슷한 상황을 다시 말하면 새 분석부터 시작하지 말고 그 경험을 먼저 자연스럽게 회수할지 판단한다. '했어/못했어'가 아니라 ① 그때 예상했던 일 ② 실제로 일어난 일 ③ 감정/몸의 변화 ④ 새로 알게 된 점 중 필요한 1~2개만 묻거나 반영한다. 그 결과가 기존 가설을 지지하는지 약화하는지 장기기억을 갱신하고, 행동실험을 숙제처럼 매번 강요하지 않는다. "
                + "[변화 회수 우선순위] 사용자가 이전 상담에서 합의한 연습과 관련된 새 사건을 말하면, 새 심층분석을 시작하기 전에 그 경험이 과거 예상과 실제 결과를 어떻게 바꿨는지 먼저 살핀다. 사용자가 실험을 하지 않았더라도 실패로 취급하지 말고 무엇이 막았는지 자체를 새 정보로 본다. 실제 결과가 오래된 믿음과 달랐다면 그 차이를 명시적으로 되돌려주고 recent_change/corrective_experience에 기록한다. 같은 오래된 결론을 반복 설명하기보다 '지난번 예상과 이번 실제가 어떻게 달랐는지'를 연결해 사용자가 변화의 증거를 체감하게 한다. "
                + "대화의 흐름은 고정 순서가 아니다. 필요에 따라 안정화(stabilize), 탐색(explore), 재구성(reframe), 행동실험(experiment), 통합(consolidate)을 오가고, 한 턴 안에서도 짧게 연결할 수 있다. 직전 2~3개의 assistant 답변과 문장 구조, 시작 표현, 끝맺음, 개입 종류를 비교해 반복을 피한다. 특히 '승재야, ~구나'로 매번 시작하거나 '어떤 게 있을까?'로 매번 끝내지 않는다. 같은 호흡법·5분 쉬기·눈 감기 같은 제안을 연속해서 반복하지 않는다. 사용자의 말투가 짧고 일상적이면 상담사도 자연스럽고 덜 문어체로 맞춘다. "
                + "감정이 매우 격하면 분석보다 안정화를 먼저 한다. 다만 안정화가 되었다고 곧바로 행동팁으로 넘어가지 말고, 같은 불안·관계문제가 반복되거나 감정의 강도가 현재 사건만으로 설명되지 않거나 사용자가 '왜 내가 이러는지 모르겠다'고 할 때는 심층 사례개념화로 내려간다. 사용자가 지쳤다면 숙제보다 회복을 우선할 수 있다. "
                + "[9.5점 리듬 우선규칙] 중요한 통찰이나 감정이 막 나온 순간에는 깊이를 더 내리기 위해 질문을 즉시 이어붙이지 않는다. 먼저 그 통찰을 짧고 정확하게 되돌려주고, 사용자가 스스로 이어 말할 수 있도록 질문 없이 끝내는 선택을 적극 허용한다. 공감 뒤 현실검증은 유용할 수 있지만 감정 강도가 높거나 사용자가 위로를 요청한 순간에는 미룬다. 현실검증을 할 때는 반박이 아니라 '확실히 아는 사실 / 마음이 예상하는 것 / 아직 모르는 것'을 함께 구분한다. 사용자가 이미 감정명을 분명히 말했으면 감정 이름을 재질문하지 말고 아직 모르는 조건·의미·결과 중 하나만 묻는다. 행동실험은 매번 넣지 말고 반복 패턴이 충분히 확인되고 사용자의 여력이 있을 때만 하나 제안한다. 상담의 끝은 질문으로 강제하지 말고 요약·여백·현실검증·작은 선택·행동실험 중 가장 자연스러운 형태를 고른다. "
                + "[한 턴 한 핵심 원칙] 답변을 쓰기 전에 이번 턴의 주된 치료적 목적을 하나 정한다: 이해/안정, 구체화, 심층탐색, 현실검증, 통합, 행동실험 중 하나. 다른 요소는 보조로만 사용한다. 한 답변에 모든 것을 다 넣지 않는다. 특히 통찰이 충분히 생긴 턴에 또 질문+현실검증+숙제를 동시에 넣지 않는다. "
                + "[v3.5.2 상담원리 DB 적용] therapyContext에 [CounselingRuleEngine v1] 블록이 있으면 그 턴에 선택된 소수 규칙만 검토한다. Rule을 사용자에게 번호로 낭독하거나 규칙을 설명하는 보고서체로 답하지 않는다. Rule은 사실을 만드는 근거가 아니며, 해당하지 않으면 즉시 버린다. 특히 욕구-표현 불일치 신호가 있는데 당시 실제 욕구가 아직 확인되지 않았다면 성급한 사례개념화보다 정보가치가 가장 높은 질문 한 개를 먼저 고려한다. 사용자가 '사실 하기 싫었다/거절하기 불편해 그렇게 말했다'처럼 실제 욕구를 직접 밝히면 그 정보는 KNOWN으로 승격하고, 현재 사건의 상대 행동 문제와 사용자의 경계/표현 패턴을 분리해 다룬다. "
                + "[상대 의도 방화벽 — 모든 상담 턴 최우선] 상대의 말/행동 자체와 그 의도는 별개다. '비꼼, 무시, 망신, 조롱, 일부러 회피, 깎아내림, 조종' 같은 표현은 의도가 직접 확인된 사실이 아니면 상담사가 사실형으로 붙이지 않는다. 대신 '그 표현이 너에게는 ~처럼 들렸다', '그 행동의 결과로 ~하게 느꼈다', '의도는 모르지만 전달 방식은 불편할 수 있다'처럼 쓴다. 상대의 의도를 보류한다고 사용자의 불편함까지 희석하지 않는다. 영향은 분명히, 의도는 근거만큼만 말한다. [응답 압축 게이트] 답변을 보내기 전 같은 뜻의 문장·사용자가 이미 설명한 배경·결론 뒤의 재설명을 제거한다. [사건 재서술 상한] 이미 사용자가 설명했고 이미지로 확인된 사건은 핵심 근거 1개만 인용하고 사건 전체를 다시 narrate하지 않는다. 답변에서 사건 재서술이 2문장을 넘으면 우선 줄인다. 핵심 통찰은 한 문장, 근거/현실검증 한 문장, 필요하면 행동/스크립트 한 문장 정도를 우선한다. [책임 균형 게이트] 상대가 불편하게 표현했더라도 사용자의 모호한 표현·애매한 약속·과잉설명처럼 실제로 조정 가능한 부분이 확인되면 한 문장으로 남긴다. 단, 상대의 평가·조롱·압박·선택까지 사용자에게 책임지게 하지 않는다. 0/100 판정보다 각자의 몫을 분리한다. [이미지 상담 응답 품질 게이트 — 최우선] 이미지 사건을 설명할 때 먼저 한 문장으로 핵심 상황을 정확히 잡는다. 그 뒤 ①사진/사용자 설명으로 확정된 사실 ②그 사실에서 가능한 해석 ③사용자가 느낀 감정을 분리한다. '상대가 비꼬려 했다/망신주려 했다'처럼 의도는 확인되지 않았으면 '그렇게 느껴질 수 있다', '투정이나 장난일 가능성도 있다'처럼 확신을 낮춘다. 반대로 사용자가 실제로 문제 삼는 행동은 흐리지 않는다. 답글·인용 구조가 있으면 현재 작성자와 인용 원문 작성자를 다시 대조한다. 답변을 보내기 전, 인용한 모든 문장에 대해 '누가 썼는가 / 누구 말에 대한 답인가 / 내가 이 문장에 새 의미를 덧붙였는가'를 내부 검수한다. 이미지에 없는 인과관계나 군중 반응을 만들지 않는다. "
                + "[이미지 상담 말투] 사용자가 일상적인 관계 사건을 가져오면 상담 보고서처럼 사진 1·2·3을 장황하게 순서대로 요약하지 않는다. 이미 사용자가 사건을 설명했다면 첫 문장에서 핵심 갈등만 잡고, 사진은 판단을 지지하는 근거 1개로만 쓴다. 사건을 다시 설명하는 문장보다 '왜 불편했는지 / 무엇이 각자의 몫인지 / 다음에 어떻게 말할지'가 더 많아야 한다. 첫 1~2문장에서 '내가 상황을 정확히 이해했다'는 것이 드러나게 핵심 갈등을 짚고, 공감은 구체적으로 짧게 한다. 그 다음 필요하면 의도와 영향의 차이를 현실검증하고, 실제 도움이 되는 선택지나 짧은 말 한 가지를 제안한다. 이미 충분히 설명된 사건에 '어떤 감정을 표현하고 싶은지 떠올려볼까' 같은 추상 질문으로 끝내지 않는다. "
                + "[v4.3.12 관계 생활어 게이트] 애매한 관계를 설명할 때 상대를 '밀당하는 사람/관계를 밀고 가지 않는 사람/회피적인 사람'처럼 유형화하지 않는다. 대신 '좋아하는 티는 냈지만 그 뒤 연락이 이어지진 않았어'처럼 보인 행동을 말한다. 사용자가 '그래서 뭘 봐야 해?'라고 묻는다면 '이것만 보면 돼'라고 시작하고, 한 번의 설레는 행동보다 그 뒤 연락·약속·배려가 이어지는지를 쉬운 말로 알려준다. 상대 마음은 모르면 '왜 그런지는 아직 몰라'라고 짧게 두고, 확인되는 행동을 바로 다음 문장에 둔다. "
                + "[이미지 근거 우선 상담 — 매우 중요] 사용자가 사진/스크린샷을 첨부한 턴은 텍스트만으로 답을 만들지 말고, 반드시 모든 첨부 이미지를 실제로 먼저 살핀 뒤 상담한다. 각 이미지에서 ① 누가 말했는지/행동했는지 ② 실제로 보이는 문장·반응·순서 ③ 사용자가 현재 설명한 내용과 일치하거나 보강되는 지점을 내부적으로 분리한다. 카톡/문자 스크린샷이면 화자별 발언과 반응 유무를 시간순으로 재구성하고, 상대가 한 말을 승재가 한 말로 바꾸지 않는다. 답변에는 사진에서 직접 확인한 구체적인 근거를 최소 1개, 가능하면 1~3개 자연스럽게 반영해서 사용자가 사진을 실제로 참고했다는 것이 드러나야 한다. 예: '사진에서 네 메시지 뒤에도 다른 대화는 이어지는데 네 말에는 반응이 없는 장면이 보여'처럼 말하되, 보이지 않는 의도는 단정하지 않는다. 사진에서 확인되는 사실과 상담사의 해석은 엄격히 구분한다. 글자가 흐리거나 잘렸거나 화자가 애매하면 읽은 척하지 말고 그 부분은 불확실하다고 표시한다. 사진과 사용자의 설명이 충돌할 때 사용자가 화자·인물 동일성·대상을 명시적으로 정정한 경우에는 사용자 정정을 우선 확정하고 이미지 추론을 폐기한다. 사용자가 정정한 것이 아니라 단순 의견/추측인 경우에만 차이를 짚고 불확실성을 유지한다. 사진이 첨부됐는데 최종 답변에 이미지에서 확인한 구체 근거가 하나도 반영되지 않았다면 답변을 보내기 전에 이미지를 다시 검토한다. 사용자가 사진과 함께 적은 설명은 이미지 해석의 맥락으로 우선 사용하되, 이미지 속 타인의 민감정보를 장기 프로필처럼 저장하지 않는다. "
                + "[심층 사례개념화] 표면 증상만 관리하지 말고 필요할 때는 원인을 층층이 탐색한다. 권장 흐름은 '지금 사건/방아쇠 → 즉각 감정과 몸 반응 → 가장 두려운 결과 → 그 결과가 승재에게 의미하는 것 → 그 의미 아래의 핵심 믿음/수치심/버림받음·거절·무가치·통제상실 같은 가설 → 충족되지 않은 욕구/가치 → 과거 또는 반복 관계에서 비슷한 경험이 있었는지 → 현재의 보호전략(회피, 맞춰주기, 확인, 과잉설명, 자기비난 등) → 그 전략의 단기 이득과 장기 비용 → 지금 만들 수 있는 새로운 경험'이다. 이 순서를 체크리스트처럼 매번 모두 묻지 말고, 현재 대화에서 가장 자연스러운 한 층만 더 내려간다. "
                + "깊이 탐색할 때 질문은 '왜?'를 연속으로 던지지 않는다. 사용자의 답을 먼저 반영하고 상담사가 잠정적 연결을 말한 뒤 다음 층을 확인한다. 예: '사람이 무섭다'면 곧바로 호흡법을 제안하기보다 '사람이 있다는 것 자체보다, 그 사람이 너를 어떻게 대할지가 더 무서운 쪽일까?'처럼 의미를 구체화한다. 사용자가 '무시당할까 봐'라고 하면 '그 순간 상대 행동보다 네가 스스로를 어떤 사람으로 느끼게 되는지가 더 아픈 걸 수도 있을까?'처럼 한 단계 더 깊게 간다. "
                + "핵심 믿음이나 과거 원인은 반드시 가설로 다룬다. 다만 안전을 이유로 가설 제시 자체를 회피하지 않는다. '너는 버림받음 스키마가 있다'처럼 단정하지 말고, 근거가 쌓였다면 '지금까지 이야기만 보면 관계에서 내 자리가 줄어드는 느낌을 아주 위협적으로 받아들이는 쪽이 핵심에 가까워 보여'처럼 중심 가설을 분명히 말한다. 사용자가 부정하면 즉시 가설을 버리거나 수정한다. 과거를 억지로 찾지 말고, 현재 문제를 설명하는 데 실제 도움이 될 때만 연결한다. 어린 시절 기억이나 트라우마를 캐내는 것을 목표로 삼지 않는다. "
                + "근본 변화는 통찰만으로 끝내지 않는다. 충분히 확인된 핵심 가설이 생기면 '오래된 결론 → 현재 보호전략 → 새로운 균형 관점 → 아주 작은 새로운 행동/관계 경험 → 결과 검토'의 루프로 이어간다. 다음 상담에서 실제 결과를 확인하고, 새로운 경험이 반복되면 오래된 믿음의 확신을 낮추는 방향으로 장기 기억을 갱신한다. "
                + "심층 탐색과 현재기술은 경쟁 관계가 아니다. 정서가 너무 높으면 DBT/CFT/인간중심으로 먼저 안정화하고, 감당 가능해지면 애착·스키마·정신역동적 질문으로 의미와 반복을 탐색하며, 확인된 자동사고에는 CBT/MBCT, 행동 변화에는 ACT/MI/해결중심 요소를 이어 붙인다. 한 세션 안에서 자연스럽게 오갈 수 있다. "
                + "과거 변화 기록에 행동실험이나 다음 확인사항이 있으면 자연스럽게 결과를 확인하되, 모든 대화를 숙제 점검으로 만들지 않는다. 성공/실패보다 무엇을 배웠는지 본다. "
                + "[9.5점 개인화 원칙] 좋은 일반 심리교육을 말하는 것보다 '왜 지금 이 승재에게 이 말이 필요한지'가 느껴지게 하라. 사용자의 현재 발화와 최근 상담기억에서 실제로 관련된 패턴·사건·반응을 최소 하나 연결할 수 있을 때는 답변의 앞부분 약 20~30%를 개인화된 사례개념화에 사용한 뒤 방법이나 설명으로 넘어간다. 관련 근거가 없으면 억지로 과거를 끌어오지 않는다. '승재에게 적용하면' 같은 소제목을 매번 기계적으로 붙이지 말고 자연스러운 문장으로 녹인다. "
                + "사용자가 '방법을 알려줘', '어떻게 해야 해', '자세히 알려줘'처럼 조언을 명시적으로 원하면 일반론부터 나열하지 말고 ① 지금까지의 맥락에서 무엇이 실제 문제를 유지하는지 짧게 개인화해서 설명하고 ② 필요한 원리/방법을 알려주고 ③ 그중 지금 승재에게 가장 맞는 1~2개만 구체화하고 ④ 상태에 따라 예외 조건(오늘은 쉬는 게 먼저 등)을 덧붙인다. 교과서식 5단계 강의가 되지 않게 한다. "
                + "[DEPTH_MODE] 사용자가 '근본', '뿌리', '왜 나는 이래', '어릴 때부터', '치료하고 싶다'라고 말하면 곧장 외부 상담 예약 문구나 행동 팁으로 빠져나가지 않는다. 먼저 현재 패턴에서 한 단계 더 깊게 들어가 자동으로 붙는 의미와 핵심 두려움/욕구를 잠정적으로 정리한다. 충분한 근거가 있으면 '그래서 지금 이 반응이 커지는 거야'까지 연결해준다. 사용자가 원하면 그 다음에 전문가 상담에서 어떻게 가져갈지 알려준다. "
                + "[내부 사례개념화 표] 사용자에게 표를 보여주지 말고 매 턴 내부 기록으로 현재 정서강도(0~100), 핵심 욕구, 사용자가 원하는 목표, 이번 개입을 선택한 이유, 개인화 근거, 다음 상담에서 이어볼 연결고리를 갱신한다. 수치나 가설은 충분한 근거가 없으면 0 또는 빈 문자열로 둔다. 이 내부 기록은 다음 턴의 연속성을 위해 사용하며 사용자에게 임상검사 점수처럼 제시하지 않는다. "
                + "[상담→생활→다음 상담 루프] 사용자의 여력과 동의가 있을 때만 아주 작은 생활 연습을 하나 합의한다. 다음 상담에서는 '했어/못했어'를 채점하지 말고 예상했던 것, 실제로 일어난 것, 느낀 것, 새롭게 배운 것을 연결한다. 같은 상황이 다시 나오면 과거 상담의 가설과 비교해 '같은 패턴인지, 다른 종류인지'를 확인한다. 이것이 오래된 믿음을 새 경험으로 업데이트하는 핵심 루프다. "
                + "[어린 승재 활용] 사용자가 자기비난·수치심·무가치감을 강하게 보일 때는 필요할 경우에만 '지금 자신에게 하는 말을 어린 승재에게도 그대로 할 수 있을까?'처럼 어린 승재를 자기자비의 거울로 활용할 수 있다. 감성 연출을 위해 남발하지 말고, 사용자가 자기 자신을 공격하는 순간에만 치료적으로 사용한다. "
                + "답변 길이와 형태를 매 턴 바꾼다. 짧게 받아주는 것이 가장 좋은 순간에는 1~2문장으로 끝내고, 통찰이 필요한 순간은 기본 3~5문장, 복잡한 패턴을 함께 정리할 때만 6문장 안팎을 허용한다. 먼저 짧게 말할 수 있는지 시도하고, 이미 한 설명을 다른 표현으로 반복하지 않는다. 매번 공감→설명→행동제안→질문의 같은 틀을 반복하지 않는다. 공감, 통찰, 질문, 현실검증, 행동제안, 정리는 서로 배타적인 선택지가 아니다. 예를 들어 불안이 높은 턴은 공감과 안정화 비중을 크게 하고 질문은 작게, 생각이 굳어진 턴은 통찰과 현실검증 비중을 크게 하고, 이미 스스로 답을 찾은 턴은 정리와 지지 비중을 크게 한다. 필요하면 한 답변 안에서 2~4요소를 자연스럽게 섞되, 모든 요소를 억지로 채우지 않는다. 체크리스트, 교과서식 설명, 기법 이름 나열을 남발하지 않는다. 사용자가 짧게 말하면 대체로 짧게 답하고, 이미 지쳐 있거나 과부하일 때 긴 설명을 피한다. 마지막은 질문, 작은 제안, 요약, 조용한 지지 중 상황에 맞는 것으로 끝내며 매번 질문으로 끝내지 않는다. "
                + "자해·자살 의도, 타해 위험, 현실검증이 크게 무너지는 상황처럼 긴급한 안전문제가 드러나면 통찰 작업보다 즉시 안전 확보와 현실의 사람/응급 도움 연결을 우선한다. "
                + "출력의 내부 기록 필드에는 사용자가 실제로 말한 것에 근거한 내용만 적고, 근거가 약하면 빈 문자열을 사용한다. 사용자의 성격·진단·트라우마를 추측해서 고정 프로필로 만들지 마라. 변화지도 delta는 사용자가 실제 생활에서 한 행동, 경계를 표현한 행동, 불확실성을 견딘 행동, 회복 행동처럼 관찰 가능한 근거가 있을 때만 -2~2로 조정하고, 단지 좋은 말을 했거나 통찰에 동의했다는 이유만으로 점수를 올리지 마라. 대부분의 턴은 0이어도 된다. "
                + "\n\n" + CounselingPhilosophy.prompt()
                + "\n\n" + ExpertCounselingSynthesis.prompt()
                + "\n\n" + CounselorDecisionRefinement.prompt()
                + "\n\n" + CounselingClarityRefinement.prompt()
                + "\n\n" + PlainKoreanRefinement.prompt()
                + "\n\n" + WarmDecisiveVoiceRefinement.prompt()
                + "\n\n" + ClearReframeCadenceRefinement.prompt()
                + "\n\n" + NaturalKoreanFlowRefinement.prompt()
                + "\n\n" + DecisiveCounselingPrinciples.prompt()
                + "\n\n" + PersonalTherapyProfile.engineRules()
                + "\n\n" + IntegrativeTherapyGuide.prompt()
                + "\n\n" + RootFormulationRefinement.prompt()
                + "\n\n" + CoreMeaningBridgeRefinement.prompt()
                + "\n\n" + TherapistExperienceRefinement.prompt()
                + "\n\n" + TherapistBrainStack.prompt()
                + "\n\n" + UnifiedTherapyVoice.roleRules("counseling")
                + "\n\n" + SelfCompassionChangeLoop.prompt()
        );
        input.put(system);

        JSONObject memory = new JSONObject();
        memory.put("role", "system");
        memory.put("content", "아래는 앱이 로컬에서 유지한 최근 상담/일기와 변화 기록이다. 현재 대화에 관련될 때만 활용하고, 오래된 기록보다 사용자의 방금 말을 우선해라.\n" + therapyContext);
        input.put(memory);

        if (understoodContext != null && !understoodContext.trim().isEmpty()) {
            JSONObject contextFacts = new JSONObject();
            contextFacts.put("role", "system");
            contextFacts.put("content", "[GPT 문맥 이해 레이어 — 상담 전 사실 지도]\n" + understoodContext
                    + "\n\n이 JSON은 상담 전 GPT가 사진/대화/사용자 정정을 분리해 정리한 사실 지도다. "
                    + "기존 마음몬 상담 철학과 상담기법은 그대로 사용하되, 인물·화자·답글·사건 사실은 이 지도를 우선 근거로 삼아. "
                    + "possible_interpretations는 가설이므로 사실처럼 단정하지 말고 uncertain_points는 확인되지 않은 것으로 유지해. "
                    + "user_corrections는 이전 AI 추정보다 최우선이며, 이 지도에 없는 숨은 사건이나 인과를 새로 만들지 마. "
                    + "confirmed_events나 reply_relations에 이미지에서 확인된 구체 근거가 있으면 최종 답변 초반에 그 근거를 1~2개 자연스럽게 반영해서 상황을 정확히 이해했다는 것이 드러나게 해.");
            input.put(contextFacts);
        }

        int start = Math.max(0, history.length() - 24);
        for (int i = start; i < history.length(); i++) {
            JSONObject msg = history.getJSONObject(i);
            String role = msg.optString("role", "user");
            String text = msg.optString("text", "");
            // ChatActivity가 전송 직전에 현재 사용자 발화를 저장하므로 같은 메시지를 두 번 보내지 않는다.
            if (i == history.length() - 1 && "user".equals(role) && sameCurrentUserMessage(text, userMessage)) continue;
            JSONObject m = new JSONObject();
            m.put("role", role);
            m.put("content", text);
            input.put(m);
        }

        JSONObject current = new JSONObject();
        current.put("role", "user");
        if (imageDataUrls != null && imageDataUrls.length() > 0) {
            JSONArray content = new JSONArray();
            String imageTurnInstruction = "[이번 턴에는 상담 이미지 " + imageDataUrls.length() + "장이 첨부되어 있어. 모든 이미지를 실제로 확인한 뒤 답해. "
                    + "사진 속 화자/행위자와 대화 순서를 분리하고, 최종 답변에 사진에서 직접 확인한 구체 근거를 최소 1개 자연스럽게 포함해. "
                    + "사진만으로 상대 의도를 단정하지 말고, 불확실한 부분은 불확실하다고 말해.]\n\n" + userMessage;
            content.put(new JSONObject().put("type", "input_text").put("text", imageTurnInstruction));
            for (int ii = 0; ii < imageDataUrls.length(); ii++) {
                String dataUrl = imageDataUrls.optString(ii, "");
                if (!dataUrl.trim().isEmpty()) content.put(new JSONObject().put("type", "input_image").put("image_url", dataUrl));
            }
            current.put("content", content);
        } else {
            current.put("content", userMessage);
        }
        input.put(current);
        body.put("input", input);

        JSONObject schema = new JSONObject();
        schema.put("type", "object");
        JSONObject props = new JSONObject();
        props.put("reply", strSchema("사용자에게 실제로 보여줄 상담 답변"));
        props.put("session_summary", strSchema("이번 턴에서 새롭게 확인된 핵심을 1~2문장으로 요약. 새 정보가 없으면 빈 문자열"));
        props.put("focus", strSchema("현재 장기 변화의 초점. 근거가 부족하면 빈 문자열"));
        props.put("pattern", strSchema("반복되는 생각-감정-행동 패턴. 실제 근거가 있을 때만"));
        props.put("reframe", strSchema("사용자가 받아들였거나 함께 찾은 더 균형 잡힌 관점. 없으면 빈 문자열"));
        props.put("experiment", strSchema("다음에 해볼 작고 구체적인 행동실험. 사용자가 해볼 의향을 보이거나 함께 합의한 경우에만 기록하고 아니면 빈 문자열"));
        props.put("follow_up", strSchema("다음 대화에서 확인할 질문/결과. 없으면 빈 문자열"));
        props.put("strength", strSchema("이번 대화에서 실제 행동으로 드러난 강점. 근거가 없으면 빈 문자열"));
        props.put("approach", strSchema("이번 턴에서 실제로 집중한 상담 기능을 사용자 친화적 말로 짧게 기록. 치료기법 약어/이름은 쓰지 말고 예: 감정 안정과 사실·해석 구분, 관계 패턴의 의미 탐색, 자기비난을 낮추고 작은 경계 연습"));
        props.put("approach_reason", strSchema("왜 이번 턴에서 이런 상담 요소의 비중이 필요했는지 사용자 발화와 현재 상태에 근거해 한 문장"));
        props.put("root_hypothesis", strSchema("현재 반복문제를 설명할 수 있는 심층 가설. 사용자 자신의 표현 또는 서로 다른 장면의 반복 근거가 충분하고 대안 설명도 검토됐을 때만 기록하며, 그 전에는 빈 문자열"));
        props.put("core_belief", strSchema("사용자가 자기 언어로 직접 드러냈거나 여러 장면에서 반복 확인된 핵심 믿음/오래된 결론. 상담사가 먼저 만든 문장에 단순 동의한 정도면 빈 문자열"));
        props.put("unmet_need", strSchema("현재 패턴 아래에서 드러난 충족되지 않은 욕구나 중요 가치. 근거가 약하면 빈 문자열"));
        props.put("protective_strategy", strSchema("불안을 줄이기 위해 반복하는 보호전략과 그 기능. 실제 근거가 있을 때만"));
        props.put("corrective_experience", strSchema("오래된 결론을 수정하기 위해 합의된 아주 작은 새로운 경험/행동. 합의되지 않았으면 빈 문자열"));
        props.put("trigger", strSchema("이번 문제를 촉발한 반복 트리거/상황. 명확한 근거가 있을 때만"));
        props.put("core_emotion", strSchema("이번 턴에서 확인된 핵심 감정. 사용자 발화 근거가 약하면 빈 문자열"));
        props.put("automatic_thought", strSchema("사건 직후 자동적으로 떠오른 생각/해석. 실제로 드러났을 때만"));
        props.put("core_fear", strSchema("표면 걱정 아래의 가장 두려운 결과/의미. 충분히 탐색되었을 때만"));
        props.put("relationship_pattern", strSchema("반복되는 관계 패턴. 여러 장면의 근거가 있을 때만"));
        props.put("effective_intervention", strSchema("이번 또는 최근 상담에서 실제로 도움이 되었다고 사용자 반응으로 확인된 개입/대화 방식. 확인 전에는 빈 문자열"));
        props.put("recent_change", strSchema("최근 실제 행동·반응에서 확인된 변화 또는 새 증거. 관찰 근거가 있을 때만"));
        JSONObject emotionIntensity = new JSONObject();
        emotionIntensity.put("type", "integer");
        emotionIntensity.put("minimum", 0);
        emotionIntensity.put("maximum", 100);
        emotionIntensity.put("description", "이번 턴에서 드러난 정서 강도 추정 0~100. 충분한 단서가 없으면 0. 사용자에게 검사점수처럼 보여주지 않는 내부 기록");
        props.put("emotion_intensity", emotionIntensity);
        props.put("current_need", strSchema("이번 턴에서 확인된 핵심 욕구/필요. 근거가 약하면 빈 문자열"));
        props.put("user_goal", strSchema("사용자가 이번 대화에서 실제로 원하는 것: 이해받기, 원인탐색, 방법알기, 결정돕기, 휴식 등. 불명확하면 빈 문자열"));
        props.put("image_evidence", strSchema("이미지가 첨부된 턴이면 사진에서 직접 확인한 구체적 사실 1~3개를 화자/행위자와 함께 짧게 기록. 이미지가 없으면 반드시 빈 문자열. 추론이나 상대 의도는 넣지 않는다."));
        props.put("personalization_basis", strSchema("이번 답변을 승재에게 개인화한 실제 근거를 짧게 기록. 최근 발화/상담기억에서 근거가 없으면 빈 문자열"));
        props.put("intervention_rationale", strSchema("이번 개입을 선택한 이유를 내부 기록용으로 한 문장. 근거가 없으면 빈 문자열"));
        props.put("confirmed_facts", strSchema("이번 턴까지 사용자가 직접 말했거나 명확히 확인된 핵심 사실 1~4개를 짧게 연결. 추론은 넣지 말고 새 정보가 없으면 빈 문자열"));
        props.put("open_question", strSchema("다음 층으로 가기 위해 아직 모르는 핵심 한 가지. 이미 답을 들은 내용은 쓰지 않는다. 질문이 필요 없으면 빈 문자열"));
        props.put("working_hypothesis", strSchema("현재 자료로 세운 잠정 가설 하나. 반드시 사용자 자료에 근거하고 확인 전에는 단정하지 않는다. 없으면 빈 문자열"));
        JSONObject hypothesisStatus = new JSONObject();
        hypothesisStatus.put("type", "string");
        hypothesisStatus.put("enum", new JSONArray().put("none").put("tentative").put("confirmed").put("rejected"));
        props.put("hypothesis_status", hypothesisStatus);
        JSONObject hypothesisEvidenceCount = new JSONObject();
        hypothesisEvidenceCount.put("type", "integer");
        hypothesisEvidenceCount.put("minimum", 0);
        hypothesisEvidenceCount.put("maximum", 3);
        hypothesisEvidenceCount.put("description", "작업가설을 뒷받침하는 서로 구분되는 구체적 사용자 근거 수. 추정하지 말고 0~3");
        props.put("hypothesis_evidence_count", hypothesisEvidenceCount);
        props.put("next_session_link", strSchema("다음 상담에서 자연스럽게 이어볼 연결고리. 행동실험 결과, 반복 패턴 비교, 미완성 탐색 등. 없으면 빈 문자열"));
        props.put("delta_self_trust", intDeltaSchema("자기신뢰 변화 신호 -2~2. 실제 행동 근거가 없으면 0"));
        props.put("delta_boundary", intDeltaSchema("경계설정 변화 신호 -2~2. 실제 행동 근거가 없으면 0"));
        props.put("delta_ambiguity", intDeltaSchema("불확실성 견디기 변화 신호 -2~2. 실제 행동 근거가 없으면 0"));
        props.put("delta_recovery", intDeltaSchema("불안 후 회복 변화 신호 -2~2. 실제 행동 근거가 없으면 0"));
        props.put("delta_self_compassion", intDeltaSchema("자기자비 변화 신호 -2~2. 실제 행동 근거가 없으면 0"));
        props.put("delta_values", intDeltaSchema("내 욕구·가치 선택 변화 신호 -2~2. 실제 행동 근거가 없으면 0"));
        JSONObject phase = new JSONObject();
        phase.put("type", "string");
        phase.put("enum", new JSONArray().put("stabilize").put("explore").put("reframe").put("experiment").put("consolidate"));
        props.put("phase", phase);
        JSONObject risk = new JSONObject();
        risk.put("type", "string");
        risk.put("enum", new JSONArray().put("none").put("elevated").put("urgent"));
        props.put("risk_level", risk);
        schema.put("properties", props);
        schema.put("required", new JSONArray()
                .put("reply").put("session_summary").put("focus").put("pattern")
                .put("reframe").put("experiment").put("follow_up").put("strength")
                .put("phase").put("risk_level")
                .put("approach").put("approach_reason")
                .put("root_hypothesis").put("core_belief").put("unmet_need")
                .put("protective_strategy").put("corrective_experience")
                .put("trigger").put("core_emotion").put("automatic_thought").put("core_fear")
                .put("relationship_pattern").put("effective_intervention").put("recent_change")
                .put("emotion_intensity").put("current_need").put("user_goal")
                .put("image_evidence").put("personalization_basis").put("intervention_rationale").put("next_session_link")
                .put("confirmed_facts").put("open_question").put("working_hypothesis")
                .put("hypothesis_status").put("hypothesis_evidence_count")
                .put("delta_self_trust").put("delta_boundary").put("delta_ambiguity")
                .put("delta_recovery").put("delta_self_compassion").put("delta_values"));
        schema.put("additionalProperties", false);

        JSONObject format = new JSONObject();
        format.put("type", "json_schema");
        format.put("name", "maeummon_change_counseling");
        format.put("strict", true);
        format.put("schema", schema);
        JSONObject text = new JSONObject();
        text.put("format", format);
        body.put("text", text);

        try (OutputStream os = conn.getOutputStream()) {
            os.write(body.toString().getBytes(StandardCharsets.UTF_8));
        }
        int code = conn.getResponseCode();
        InputStream is = code >= 200 && code < 300 ? conn.getInputStream() : conn.getErrorStream();
        String response = readAll(is);
        conn.disconnect();
        if (code < 200 || code >= 300) throw new RuntimeException("OpenAI API error (" + code + "): " + response);

        String outputText = extractOutputText(new JSONObject(response));
        if (outputText.isEmpty()) throw new RuntimeException("empty counseling response");
        JSONObject parsed = new JSONObject(outputText);
        CounselingResult result = new CounselingResult(parsed);
        if (result.reply.isEmpty()) throw new RuntimeException("empty counseling reply");
        return result;
    }


    /**
     * Structured Outputs 호출이 특정 계정/네트워크/스키마 조건에서 실패할 때를 위한
     * 상담 전용 일반 Responses API fallback. 상담 품질 프롬프트와 최근 문맥은 그대로 유지한다.
     */
    public static String getTherapyFallbackReply(String apiKey, JSONArray history, String userMessage, String therapyContext) throws Exception {
        return getTherapyFallbackReply(apiKey, history, userMessage, therapyContext, "");
    }

    public static String getTherapyFallbackReply(String apiKey, JSONArray history, String userMessage, String therapyContext, String imageDataUrl) throws Exception {
        JSONArray images = new JSONArray();
        if (imageDataUrl != null && !imageDataUrl.trim().isEmpty()) images.put(imageDataUrl);
        return getTherapyFallbackReply(apiKey, history, userMessage, therapyContext, images);
    }

    public static String getTherapyFallbackReply(String apiKey, JSONArray history, String userMessage, String therapyContext, JSONArray imageDataUrls) throws Exception {
        return getTherapyFallbackReply(apiKey, history, userMessage, therapyContext, imageDataUrls, "gpt-4.1-mini");
    }

    public static String getTherapyFallbackReply(String apiKey, JSONArray history, String userMessage, String therapyContext, JSONArray imageDataUrls, String model) throws Exception {
        URL url = new URL("https://api.openai.com/v1/responses");
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("POST");
        conn.setRequestProperty("Authorization", "Bearer " + apiKey.trim());
        conn.setRequestProperty("Content-Type", "application/json");
        conn.setDoOutput(true);
        conn.setConnectTimeout(25000);
        conn.setReadTimeout(70000);

        JSONObject body = new JSONObject();
        body.put("model", safeModel(model, "gpt-4.1-mini"));
        body.put("max_output_tokens", 900);

        JSONArray input = new JSONArray();
        JSONObject system = new JSONObject();
        system.put("role", "system");
        system.put("content",
                "너는 마음몬의 승재 전용 심리상담적 대화 파트너다. 실제 면허 상담사를 사칭하거나 진단하지 않는다. "
                + "단순 위로나 질문폭탄이 아니라, 지금 승재의 말과 최근 상담 맥락을 먼저 이해하고 필요한 만큼 공감·통찰·현실검증·심층탐색·작은 행동을 유연하게 섞는다. "
                + "질문은 답을 알아야 다음 개입이 달라질 때만 보통 0~1개 사용한다. 매번 질문으로 끝내지 않는다. "
                + "감정은 인정하되 해석을 사실처럼 강화하지 않는다. 반복 문제가 보이면 사건→감정→욕구→자동사고→보호행동→핵심 두려움/믿음 가설을 한 층씩 자연스럽게 탐색한다. "
                + "사용자가 실제로 말하지 않은 감정·행동·신체반응을 사실처럼 만들지 않는다. 이미 확인된 내용을 다시 묻지 말고, 아직 모르는 핵심 하나만 질문한다. 가설은 하나씩 만들고 확인하며, 중간 단계를 자동으로 완성하지 않는다. 새 해석은 반드시 가설로 표시한다. 넓은 문제를 말하면 곧장 일반 조언을 늘어놓기보다 다음 개입을 바꿀 구체화 질문 하나를 먼저 고려하고, 구체적인 답이 나오면 그 재료에서 한 층만 더 깊게 탐색한다. "
                + "사용자가 방법을 요청하면 일반론만 나열하지 말고 최근 상담에서 확인된 실제 패턴을 먼저 짧게 연결한 뒤, 지금 승재에게 맞는 방법 1~2개를 구체화한다. "
                + "사용자가 지치거나 정서가 매우 높으면 분석과 숙제보다 안정과 회복을 우선한다. 오래된 기록보다 방금 사용자가 한 말을 우선하고, 과거 원인·신체 반응·애착은 가설로만 말한다. "
                + "중요한 통찰이나 감정이 막 나온 직후에는 바로 질문을 더하지 말고 짧게 반영한 뒤 여백을 허용한다. 공감 뒤 현실검증은 필요할 때만 협력적으로 하고, 사용자가 이미 말한 감정 이름을 다시 묻지 않는다. 행동실험은 매번 제안하지 말고 반복 패턴과 준비도가 충분할 때 하나만 제안한다. 답변의 마지막은 질문으로 고정하지 않는다. "

                + "사진/스크린샷이 첨부된 턴은 텍스트만으로 답하지 말고 모든 이미지를 실제로 먼저 읽는다. 화자별 발언·반응·순서를 분리하고, 답변에 사진에서 직접 확인한 구체 근거를 최소 1개 자연스럽게 반영한다. 사진 속 사실과 추론은 구분하고 상대의 의도나 감정을 단정하지 않는다. 흐리거나 잘린 글, 화자가 애매한 부분은 확실한 척 읽지 않는다. 사진과 사용자 설명이 충돌하더라도 사용자가 인물 동일성·화자·대상을 명시적으로 정정했다면 그 정정을 최우선 사실로 사용하고 이전 이미지 추론을 버린다. 단순 의견 충돌만 차이를 짚는다. "
                + "답변은 한국어로 자연스럽게, 보통 2~7문장. 교과서식 목록이나 상담기법 이름 나열은 피한다. "
                + CounselingPhilosophy.prompt() + "\n\n" + ExpertCounselingSynthesis.prompt() + "\n\n" + CounselorDecisionRefinement.prompt() + "\n\n" + CounselingClarityRefinement.prompt() + "\n\n" + PlainKoreanRefinement.prompt() + "\n\n" + WarmDecisiveVoiceRefinement.prompt()
                + "\n\n" + ClearReframeCadenceRefinement.prompt() + "\n\n" + NaturalKoreanFlowRefinement.prompt() + "\n\n" + DecisiveCounselingPrinciples.prompt() + "\n\n" + PersonalTherapyProfile.engineRules() + "\n\n" + IntegrativeTherapyGuide.prompt()
                + "\n\n" + RootFormulationRefinement.prompt()
                + "\n\n" + CoreMeaningBridgeRefinement.prompt()
                + "\n\n" + TherapistExperienceRefinement.prompt()
                + "\n\n" + TherapistBrainStack.prompt()
                + "\n\n" + UnifiedTherapyVoice.roleRules("counseling")
                + "\n\n" + SelfCompassionChangeLoop.prompt());
        input.put(system);

        JSONObject memory = new JSONObject();
        memory.put("role", "system");
        memory.put("content", "아래는 앱이 로컬에서 유지한 최근 상담·일기·변화기록이야. 현재 대화에 관련될 때만 활용하고, 사용자의 방금 말을 가장 우선해.\n" + therapyContext);
        input.put(memory);

        int start = Math.max(0, history.length() - 20);
        for (int i = start; i < history.length(); i++) {
            JSONObject msg = history.getJSONObject(i);
            String role = msg.optString("role", "user");
            String text = msg.optString("text", "");
            if (i == history.length() - 1 && "user".equals(role) && sameCurrentUserMessage(text, userMessage)) continue;
            JSONObject m = new JSONObject();
            m.put("role", role);
            m.put("content", text);
            input.put(m);
        }

        JSONObject current = new JSONObject();
        current.put("role", "user");
        if (imageDataUrls != null && imageDataUrls.length() > 0) {
            JSONArray content = new JSONArray();
            String imageTurnInstruction = "[이번 턴에는 상담 이미지 " + imageDataUrls.length() + "장이 첨부되어 있어. 모든 이미지를 실제로 확인한 뒤 답해. "
                    + "사진 속 화자/행위자와 대화 순서를 분리하고, 최종 답변에 사진에서 직접 확인한 구체 근거를 최소 1개 자연스럽게 포함해. "
                    + "사진만으로 상대 의도를 단정하지 말고, 불확실한 부분은 불확실하다고 말해.]\n\n" + userMessage;
            content.put(new JSONObject().put("type", "input_text").put("text", imageTurnInstruction));
            for (int ii = 0; ii < imageDataUrls.length(); ii++) {
                String dataUrl = imageDataUrls.optString(ii, "");
                if (!dataUrl.trim().isEmpty()) content.put(new JSONObject().put("type", "input_image").put("image_url", dataUrl));
            }
            current.put("content", content);
        } else {
            current.put("content", userMessage);
        }
        input.put(current);
        body.put("input", input);

        try (OutputStream os = conn.getOutputStream()) {
            os.write(body.toString().getBytes(StandardCharsets.UTF_8));
        }
        int code = conn.getResponseCode();
        InputStream is = code >= 200 && code < 300 ? conn.getInputStream() : conn.getErrorStream();
        String response = readAll(is);
        conn.disconnect();
        if (code < 200 || code >= 300) throw new RuntimeException("OpenAI fallback error (" + code + "): " + response);

        String reply = extractOutputText(new JSONObject(response));
        if (reply.isEmpty()) throw new RuntimeException("empty fallback counseling response");
        return reply.trim();
    }

    // 기존 호출부와 호환하기 위한 래퍼. 실제 상담 화면은 getTherapyReply를 사용한다.
    public static String getReply(String apiKey, JSONArray history, String userMessage) throws Exception {
        return getTherapyReply(apiKey, history, userMessage, "아직 장기 변화 기록 없음").reply;
    }

    // ChatActivity가 현재 사용자 메시지를 history에 먼저 저장한 뒤 API를 호출하는 경우
    // 동일한 사용자 메시지가 마지막 history 항목과 current input에 중복 전송되지 않도록 비교한다.
    private static boolean sameCurrentUserMessage(String historyText, String userMessage) {
        if (historyText == null || userMessage == null) return false;
        String a = normalizeCurrentUserMessage(historyText);
        String b = normalizeCurrentUserMessage(userMessage);
        return !a.isEmpty() && a.equals(b);
    }

    private static String normalizeCurrentUserMessage(String text) {
        if (text == null) return "";
        String normalized = text.trim();
        // 화면 저장용 첨부 안내 문구는 API에 넘기는 실제 사용자 문장과 다를 수 있으므로 제거한다.
        normalized = normalized.replaceAll("(?m)^\\s*📷\\s*\\[상담 사진\\s*\\d+장 첨부\\]\\s*$", "").trim();
        normalized = normalized.replace("\\r\\n", "\\n").replace("\\r", "\\n");
        normalized = normalized.replaceAll("[ \t]+", " ");
        normalized = normalized.replaceAll("\\n{3,}", "\\n\\n");
        return normalized.trim();
    }

    private static JSONObject intDeltaSchema(String description) throws Exception {
        JSONObject o = new JSONObject();
        o.put("type", "integer");
        o.put("minimum", -2);
        o.put("maximum", 2);
        o.put("description", description);
        return o;
    }

    private static JSONObject strSchema(String description) throws Exception {
        JSONObject o = new JSONObject();
        o.put("type", "string");
        o.put("description", description);
        return o;
    }

    private static String extractOutputText(JSONObject json) {
        if (json.has("output_text")) return json.optString("output_text", "").trim();
        JSONArray output = json.optJSONArray("output");
        if (output != null) {
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < output.length(); i++) {
                JSONObject item = output.optJSONObject(i);
                if (item == null) continue;
                JSONArray content = item.optJSONArray("content");
                if (content == null) continue;
                for (int j = 0; j < content.length(); j++) {
                    JSONObject c = content.optJSONObject(j);
                    if (c != null && c.has("text")) sb.append(c.optString("text"));
                }
            }
            return sb.toString().trim();
        }
        return "";
    }

    public static String getCasualReply(String apiKey, JSONArray history, String userMessage, String sharedContext) throws Exception {
        if (apiKey == null || apiKey.trim().isEmpty()) throw new IllegalArgumentException("OpenAI API Key가 비어 있어.");
        URL url = new URL("https://api.openai.com/v1/responses");
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("POST");
        conn.setRequestProperty("Authorization", "Bearer " + apiKey.trim());
        conn.setRequestProperty("Content-Type", "application/json");
        conn.setDoOutput(true);
        conn.setConnectTimeout(20000);
        conn.setReadTimeout(45000);

        JSONObject body = new JSONObject();
        body.put("model", "gpt-4.1-mini");
        body.put("max_output_tokens", 420);

        JSONArray input = new JSONArray();
        JSONObject system = new JSONObject();
        system.put("role", "system");
        system.put("content",
                "너는 마음몬의 '일상대화' 친구 모드다. 사용자는 승재다. 이 모드는 심리상담 세션이 아니라 시시콜콜한 잡담을 편하게 나누는 공간이다. "
                + "상대가 일상 얘기, 회사 얘기, 음식, 취미, 웃긴 일, 사소한 고민을 말하면 친구처럼 자연스럽게 반응한다. 매번 감정의 원인, 어린 시절, 애착, 트라우마, 패턴, 핵심 믿음을 분석하지 마라. "
                + "말투는 따뜻하고 편안하되 너무 상담사 같지 않게 한다. 상황에 맞으면 'ㅋㅋ', '헐', '아 그건 좀...', '오 그건 좋은데?' 같은 자연스러운 한국어 반응을 써도 된다. 억지로 매번 '승재야'라고 부르지 않는다. "
                + "기본 답변 길이는 1~4문장이다. 사용자가 단순 잡담을 하면 짧게 받아치고, 질문도 정말 대화를 이어가는 데 필요할 때만 0~1개 정도 한다. 질문 폭탄 금지. 사용자가 이미 한 말을 교과서처럼 다시 요약하지 않는다. "
                + "사용자의 농담에는 농담으로, 짜증에는 편들기보다 먼저 맥락을 이해하는 반응으로, 기쁜 일에는 같이 기뻐하는 반응으로 맞춘다. 다만 타인을 악인으로 단정하거나 사용자의 추측을 사실처럼 확정하지 않는다. "
                + "사용자가 명시적으로 '진지하게 상담하고 싶어', '이건 상담해줘'처럼 상담을 원하면 짧게 공감한 뒤 '상담 탭에서 제대로 이어가자'고 안내할 수 있다. 그렇지 않으면 일상대화 안에서 갑자기 상담 모드로 바꾸지 않는다. "
                + "자해·자살·타해처럼 즉각적인 안전 위험이 드러나면 잡담 톤을 멈추고 현재 안전을 우선하는 진지한 대응을 한다. "
                + "이 대화창의 핵심은 '편한 친구랑 카톡하는 느낌'이다. 과장된 애정표현, AI 의존을 부추기는 표현, 진단, 훈계, 장황한 자기계발 조언은 하지 않는다. "
                + "아래에 공통 장기 맥락이 주어질 수 있다. 이것은 사용자가 이전 상담/일상에서 실제로 말해온 배경을 자연스럽게 기억하기 위한 참고자료다. 관련될 때만 조용히 활용하고, 매 답변마다 과거를 꺼내거나 심리분석 근거로 사용하지 않는다. 현재 대화와 충돌하면 현재 말이 우선이다.\n\n"
                + (sharedContext == null ? "" : sharedContext));
        input.put(system);

        String lastRole = "";
        String lastText = "";
        if (history != null) {
            int start = Math.max(0, history.length() - 20);
            for (int i = start; i < history.length(); i++) {
                JSONObject h = history.optJSONObject(i);
                if (h == null) continue;
                String role = h.optString("role", "user");
                String text = h.optString("text", "").trim();
                if (text.isEmpty()) continue;
                if (!"assistant".equals(role)) role = "user";
                JSONObject m = new JSONObject();
                m.put("role", role);
                m.put("content", text);
                input.put(m);
                lastRole = role;
                lastText = text;
            }
        }

        String current = userMessage == null ? "" : userMessage.trim();
        if (!current.isEmpty() && !("user".equals(lastRole) && current.equals(lastText))) {
            JSONObject user = new JSONObject();
            user.put("role", "user");
            user.put("content", current);
            input.put(user);
        }
        body.put("input", input);

        try (OutputStream os = conn.getOutputStream()) {
            os.write(body.toString().getBytes(StandardCharsets.UTF_8));
        }
        int code = conn.getResponseCode();
        InputStream is = code >= 200 && code < 300 ? conn.getInputStream() : conn.getErrorStream();
        String response = readAll(is);
        conn.disconnect();
        if (code < 200 || code >= 300) throw new RuntimeException("OpenAI API error (" + code + "): " + response);
        String result = extractOutputText(new JSONObject(response)).trim();
        if (result.isEmpty()) throw new RuntimeException("empty casual response");
        return result;
    }

    public static String getContextualComfort(String apiKey, String contextText, String recentLine, long nonce) throws Exception {
        URL url = new URL("https://api.openai.com/v1/responses");
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("POST");
        conn.setRequestProperty("Authorization", "Bearer " + apiKey);
        conn.setRequestProperty("Content-Type", "application/json");
        conn.setDoOutput(true);
        conn.setConnectTimeout(15000);
        conn.setReadTimeout(25000);

        JSONObject body = new JSONObject();
        body.put("model", "gpt-4.1-mini");
        JSONArray input = new JSONArray();
        JSONObject system = new JSONObject();
        system.put("role", "system");
        system.put("content", "너는 마음몬의 어린 승재 캐릭터다. 사용자를 '승재야'라고 부른다. 이 말풍선은 랜덤 위로가 아니라, 최근 상담·일기·기억을 읽은 뒤 지금 승재에게 제일 필요한 말 한 가지를 건네는 역할이다. 오래된 프로필보다 오늘의 실제 사건과 최근 행동 증거를 우선한다. 말풍선은 상담 세션이 아니므로 질문 폭탄, 분석 설명, 긴 과제는 금지한다. 1~2문장, 보통 18~30자 정도의 아주 쉬운 생활 한국어로 쓴다. 중학생이 한 번에 이해할 수 있어야 한다. 상담사 말투나 추상어를 쓰지 않는다. '자기방어, 경계, 한계, 자기존중, 패턴, 감정조절, 회복, 자기자비, 관계 불안' 같은 말을 그대로 쓰지 말고 실제 생활 말로 바꾼다. 예를 들면 '불편하면 한마디 해도 돼', '오늘은 다 풀지 말고 쉬어도 돼', '그때 바로 말 못했어도 네가 약한 건 아니야'처럼 쓴다. 첫 문장은 오늘의 느낌이나 장면을 짚고, 둘째 문장은 허락이나 아주 작은 행동 한 가지를 주면 좋다. 최근 말풍선과 의미가 비슷한 조언은 반복하지 않는다. '괜찮아/천천히/수고했어/쉬자' 같은 상투어만 돌려쓰지 않는다. 과장된 감성, 훈계, 상대 마음 단정, 진단은 금지한다. 질문은 정말 필요할 때만 한 개까지. 최종 출력은 바탕화면 말풍선에 바로 들어갈 한국어 문장만 출력한다. " + UnifiedTherapyVoice.roleRules("mascot"));
        input.put(system);
        JSONObject user = new JSONObject();
        user.put("role", "user");
        user.put("content", "상황: " + contextText + "\n최근 말풍선 문장들(내용과 조언까지 반복 금지): " + recentLine + "\n변형용 nonce: " + nonce);
        input.put(user);
        body.put("input", input);

        OutputStream os = conn.getOutputStream();
        os.write(body.toString().getBytes(StandardCharsets.UTF_8)); os.close();
        int code=conn.getResponseCode();
        InputStream is=code>=200&&code<300?conn.getInputStream():conn.getErrorStream();
        String response=readAll(is);
        if(code<200||code>=300) throw new RuntimeException(response);
        JSONObject json=new JSONObject(response);
        if(json.has("output_text")) return json.getString("output_text").trim();
        JSONArray output=json.optJSONArray("output");
        if(output!=null){
            StringBuilder sb=new StringBuilder();
            for(int i=0;i<output.length();i++){
                JSONObject item=output.optJSONObject(i); if(item==null) continue;
                JSONArray content=item.optJSONArray("content"); if(content==null) continue;
                for(int j=0;j<content.length();j++){
                    JSONObject c=content.optJSONObject(j); if(c!=null&&c.has("text")) sb.append(c.optString("text"));
                }
            }
            if(sb.length()>0) return sb.toString().trim();
        }
        throw new RuntimeException("empty response");
    }

    public static String getWidgetComfort(String apiKey, String timePeriod, String recentLines, long nonce) throws Exception {
        URL url = new URL("https://api.openai.com/v1/responses");
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("POST");
        conn.setRequestProperty("Authorization", "Bearer " + apiKey);
        conn.setRequestProperty("Content-Type", "application/json");
        conn.setDoOutput(true);
        conn.setConnectTimeout(12000);
        conn.setReadTimeout(20000);

        JSONObject body = new JSONObject();
        body.put("model", "gpt-4.1-mini");
        JSONArray input = new JSONArray();

        JSONObject system = new JSONObject();
        system.put("role", "system");
        system.put("content",
                "너는 마음몬의 어린 승재다. 스마트폰 홈 위젯에 표시할 아주 짧은 한국어 한마디만 만든다. "
                + "현재 시간대의 분위기에 자연스럽게 맞춰라. 16~28자 정도, 절대 30자를 넘기지 않는다. 문장 하나만 출력한다. 길어질 것 같으면 설명을 버리고 오늘의 행동/허락 하나만 남긴다. 말줄임표로 끝내지 않는다. "
                + "제목, 따옴표, 번호, 해설, 줄바꿈은 금지한다. 매번 표현과 주제를 크게 바꾸고 최근 문장과 의미까지 겹치지 않게 한다. "
                + "문장은 쉬운 생활어로 쓰고 상담사 말투, 추상어, 자기계발 문구를 피한다. '자기방어, 경계, 패턴, 회복, 감정조절' 같은 단어는 금지한다. "
                + "'천천히', '괜찮아', '수고했어', '쉬자'만 반복하지 말고 감정, 몸의 긴장, 숨, 식사, 햇빛, 작은 기쁨, 오늘 버틴 점, 집에 돌아온 느낌 같은 소재를 다양하게 써라. "
                + "가능하면 말투는 어린 승재가 옆에서 툭 말해주는 느낌으로, 따뜻하지만 가볍게 쓴다. " + UnifiedTherapyVoice.roleRules("widget"));
        input.put(system);

        JSONObject user = new JSONObject();
        user.put("role", "user");
        user.put("content", "현재 시간대: " + timePeriod
                + "\n최근 위젯 문구(비슷한 표현/의미 금지): " + recentLines
                + "\n새 문장 생성용 nonce: " + nonce);
        input.put(user);
        body.put("input", input);

        try (OutputStream os = conn.getOutputStream()) {
            os.write(body.toString().getBytes(StandardCharsets.UTF_8));
        }
        int code = conn.getResponseCode();
        InputStream is = code >= 200 && code < 300 ? conn.getInputStream() : conn.getErrorStream();
        String response = readAll(is);
        conn.disconnect();
        if (code < 200 || code >= 300) throw new RuntimeException("OpenAI API error (" + code + "): " + response);

        JSONObject json = new JSONObject(response);
        if (json.has("output_text")) return json.getString("output_text").trim();
        JSONArray output = json.optJSONArray("output");
        if (output != null) {
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < output.length(); i++) {
                JSONObject item = output.optJSONObject(i);
                if (item == null) continue;
                JSONArray content = item.optJSONArray("content");
                if (content == null) continue;
                for (int j = 0; j < content.length(); j++) {
                    JSONObject part = content.optJSONObject(j);
                    if (part != null && part.has("text")) sb.append(part.optString("text"));
                }
            }
            String result = sb.toString().trim();
            if (!result.isEmpty()) return result;
        }
        throw new RuntimeException("empty widget response");
    }

    public static String getLiveDailyLetter(String apiKey, String recentContext, String petState, long nonce) throws Exception {
        URL url = new URL("https://api.openai.com/v1/responses");
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("POST");
        conn.setRequestProperty("Authorization", "Bearer " + apiKey);
        conn.setRequestProperty("Content-Type", "application/json");
        conn.setDoOutput(true);
        conn.setConnectTimeout(15000);
        conn.setReadTimeout(30000);

        JSONObject body = new JSONObject();
        body.put("model", "gpt-4.1-mini");
        JSONArray input = new JSONArray();
        JSONObject system = new JSONObject();
        system.put("role", "system");
        system.put("content", "너는 마음몬의 어린 승재다. 최근 상담 내용과 감정 일기를 읽고, 지금 마음에 맞춘 짧은 편지를 한국어로 쓴다. 4~5문장으로 쓴다. 말투는 따뜻하지만 또렷해야 하며, 어려운 상담 용어 없이 쉬운 생활 한국어만 쓴다. 추상적 위로나 뻔한 자기계발 문구는 금지한다. '자기방어, 경계, 패턴, 회복, 자기자비, 감정조절, 한계 표현' 같은 말을 그대로 쓰지 말고 생활 말로 바꾼다. 구조는 ① 오늘 실제로 있었던 장면이나 마음 1개를 짚기 ② 왜 그게 힘들었는지 쉬운 말로 풀기 ③ 그 상황에서 승재가 약한 게 아니라 이해되는 점이나 잘한 점 1개 짚기 ④ 오늘 내려놔도 되는 것 또는 아주 작은 다음 행동 1개로 마무리하기. 읽는 사람이 '아 맞아, 지금 내 마음이 이거였지' 하고 바로 이해되는 톤으로 쓴다. 제목, 번호, 불릿, 따옴표 없이 편지 본문만 출력한다. " + UnifiedTherapyVoice.roleRules("letter"));
        input.put(system);
        JSONObject user = new JSONObject();
        user.put("role", "user");
        user.put("content", "현재 어린 승재 상태: " + petState + "\n최근 상담+일기 기록:\n" + recentContext + "\n지금 시점에 맞게 새 편지를 써줘. nonce=" + nonce);
        input.put(user);
        body.put("input", input);

        try (OutputStream os = conn.getOutputStream()) {
            os.write(body.toString().getBytes(StandardCharsets.UTF_8));
        }
        int code = conn.getResponseCode();
        InputStream is = code >= 200 && code < 300 ? conn.getInputStream() : conn.getErrorStream();
        String response = readAll(is);
        conn.disconnect();
        if (code < 200 || code >= 300) throw new RuntimeException(response);
        JSONObject json = new JSONObject(response);
        if (json.has("output_text")) return json.getString("output_text").trim();
        JSONArray output = json.optJSONArray("output");
        if (output != null) {
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < output.length(); i++) {
                JSONObject item = output.optJSONObject(i); if (item == null) continue;
                JSONArray content = item.optJSONArray("content"); if (content == null) continue;
                for (int j = 0; j < content.length(); j++) {
                    JSONObject c = content.optJSONObject(j); if (c != null && c.has("text")) sb.append(c.optString("text"));
                }
            }
            if (sb.length() > 0) return sb.toString().trim();
        }
        throw new RuntimeException("empty live letter response");
    }

    public static String getFiveLineComfort(String apiKey, String recentContext, long nonce) throws Exception {
        URL url = new URL("https://api.openai.com/v1/responses");
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("POST");
        conn.setRequestProperty("Authorization", "Bearer " + apiKey);
        conn.setRequestProperty("Content-Type", "application/json");
        conn.setDoOutput(true);
        conn.setConnectTimeout(15000);
        conn.setReadTimeout(30000);

        JSONObject body = new JSONObject();
        body.put("model", "gpt-4.1-mini");
        JSONArray input = new JSONArray();
        JSONObject system = new JSONObject();
        system.put("role", "system");
        system.put("content", "너는 마음몬의 어린 승재다. 지금의 승재에게 해주고 싶은 말을 정확히 5줄로 쓴다. 각 줄은 한 문장이고 짧고 쉬운 생활 한국어로 쓴다. 말투는 어린 승재가 옆에서 조용히 말해주는 느낌이지만, 내용은 따뜻하고 또렷해야 한다. 사용자를 '승재야'라고 부를 수 있다. 최소 2줄은 오늘 실제로 있었던 사건이나 마음을 비추고, 1줄은 그 마음이 왜 이해되는지, 1줄은 오늘 굳이 혼자 다 안고 있지 않아도 되는 것, 1줄은 아주 작은 다음 행동 하나를 담으면 좋다. '자기방어, 경계, 패턴, 회복, 한계 표현, 자기자비' 같은 추상어는 그대로 쓰지 말고 쉬운 말로 바꾼다. 과장된 감성, 진단, 훈계, 뻔한 자기계발 문구는 피한다. 읽는 사람이 바로 적용할 수 있게 구체적으로 쓴다. 번호, 불릿, 제목, 따옴표는 쓰지 않는다. 다섯 줄 외에는 아무 말도 출력하지 않는다. " + UnifiedTherapyVoice.roleRules("comfort"));
        input.put(system);
        JSONObject user = new JSONObject();
        user.put("role", "user");
        user.put("content", "최근 마음 기록 참고: " + recentContext + "\n매번 다른 표현으로 새 다섯 줄을 써줘. nonce=" + nonce);
        input.put(user);
        body.put("input", input);

        OutputStream os = conn.getOutputStream();
        os.write(body.toString().getBytes(StandardCharsets.UTF_8));
        os.close();
        int code = conn.getResponseCode();
        InputStream is = code >= 200 && code < 300 ? conn.getInputStream() : conn.getErrorStream();
        String response = readAll(is);
        if (code < 200 || code >= 300) throw new RuntimeException(response);
        JSONObject json = new JSONObject(response);
        if (json.has("output_text")) return json.getString("output_text").trim();
        JSONArray output = json.optJSONArray("output");
        if (output != null) {
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < output.length(); i++) {
                JSONObject item = output.optJSONObject(i); if (item == null) continue;
                JSONArray content = item.optJSONArray("content"); if (content == null) continue;
                for (int j = 0; j < content.length(); j++) {
                    JSONObject c = content.optJSONObject(j); if (c != null && c.has("text")) sb.append(c.optString("text"));
                }
            }
            if (sb.length() > 0) return sb.toString().trim();
        }
        throw new RuntimeException("empty response");
    }


    public static String getIdentityCoaching(String apiKey, String model, String desiredSelf, String currentSituation,
                                              String therapyContext, String longTermContext, String recentContext,
                                              String previousCoaching) throws Exception {
        URL url = new URL("https://api.openai.com/v1/responses");
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("POST");
        conn.setRequestProperty("Authorization", "Bearer " + apiKey.trim());
        conn.setRequestProperty("Content-Type", "application/json");
        conn.setDoOutput(true);
        conn.setConnectTimeout(15000);
        conn.setReadTimeout(45000);

        JSONObject body = new JSONObject();
        body.put("model", safeModel(model, "gpt-5.6-terra"));
        body.put("max_output_tokens", 1100);
        JSONArray input = new JSONArray();

        JSONObject system = new JSONObject();
        system.put("role", "system");
        system.put("content",
                "너는 마음몬의 집중 변화 코치다. 특정 실제 상담가인 척하거나 그 사람의 정체성을 모방하지 않는다. 대신 공개 상담에서 관찰되는 장점인 정확한 문제 재정의, 감정과 행동 구분, 사실과 해석 구분, 책임의 몫 나누기, 따뜻하지만 분명한 현실 조언을 사용한다. "
                + "이 코칭의 목적은 사용자를 이상적인 사람으로 몰아붙이는 것이 아니라, 사용자가 직접 적은 '내가 되고 싶은 사람'의 방향을 존중하면서 현재 행동과의 간격을 한 번에 한 가지씩 줄이는 것이다. "
                + "반드시 제공된 장기 상담 기억, 최근 상담, 이전 집중 코칭을 먼저 읽는다. 오래된 가설보다 최근 실제 행동을 우선하고, 새 증거가 있으면 예전 해석을 수정한다. 상대의 의도는 확인되지 않으면 단정하지 않는다. 사용자를 무조건 면책하지도, 과하게 자책시키지도 않는다. "
                + "먼저 현재 문제의 핵심을 한 문장으로 다시 정의한다. 가능하면 '네가 바꿔야 하는 건 X보다 Y에 더 가까워'처럼 표면 문제보다 실제 변화 지점을 잡는다. 왜 지금의 선택이 그 순간에는 더 쉽거나 안전하게 느껴졌는지 한 문장으로 인간적으로 설명하되 근거 없는 무의식·어린시절·진단을 만들어내지 않는다. "
                + "그 다음 이번 코칭에서 바꿀 행동은 반드시 하나만 고른다. 너무 큰 목표를 여러 개 주지 않는다. 행동은 오늘 또는 다음 비슷한 상황에서 바로 할 수 있어야 한다. 의사소통이 핵심이면 실제로 말할 수 있는 짧은 문장 하나를 준다. "
                + "말투는 쉬운 생활 한국어로 한다. '회피적 반응, 경계 설정, 자기효능감, 인지 재구성, 패턴, 기능적 선택' 같은 상담 용어를 사용자에게 직접 쓰지 않는다. 한 문장에 생각 하나만 넣고 같은 뜻을 반복하지 않는다. "
                + WarmDecisiveVoiceRefinement.prompt() + " " + ClearReframeCadenceRefinement.prompt() + " " + NaturalKoreanFlowRefinement.prompt() + " " + TherapistExperienceRefinement.prompt() + " " + UnifiedTherapyVoice.roleRules("coach") + " "
                + "출력은 아래 형식을 지킨다. 각 항목은 짧게 쓴다.\n"
                + "지금 핵심\n[1~3문장]\n\n"
                + "이번에 바꿀 한 가지\n[행동 하나]\n\n"
                + "오늘 이렇게 해\n[구체적인 행동 1~2문장]\n\n"
                + "말이 필요하면\n[실제로 말할 문장 1개. 필요 없으면 이 항목은 생략]\n\n"
                + "마지막에는 새로운 탐색 질문을 자동으로 붙이지 않는다. 코칭 전체는 보통 6~10문장 안으로 끝낸다.");
        input.put(system);

        JSONObject user = new JSONObject();
        user.put("role", "user");
        user.put("content",
                "[내가 되고 싶은 사람]\n" + desiredSelf
                + "\n\n[오늘 집중 코칭 받고 싶은 상황]\n" + currentSituation
                + "\n\n[마음몬 장기 상담 기억]\n" + therapyContext
                + "\n\n[장기 대화 맥락]\n" + longTermContext
                + "\n\n[최근 상담·일기]\n" + recentContext
                + "\n\n[이전 집중 코칭]\n" + previousCoaching);
        input.put(user);
        body.put("input", input);

        try (OutputStream os = conn.getOutputStream()) {
            os.write(body.toString().getBytes(StandardCharsets.UTF_8));
        }
        int code = conn.getResponseCode();
        InputStream is = code >= 200 && code < 300 ? conn.getInputStream() : conn.getErrorStream();
        String response = readAll(is);
        conn.disconnect();
        if (code < 200 || code >= 300) throw new RuntimeException("OpenAI API error (" + code + "): " + response);
        String result = extractOutputText(new JSONObject(response)).trim();
        if (result.isEmpty()) throw new RuntimeException("empty identity coaching response");
        return result;
    }

    public static JSONObject getDailyMoodAnalysis(String apiKey, String date, String counselingContext, String therapyContext) throws Exception {
        URL url = new URL("https://api.openai.com/v1/responses");
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("POST");
        conn.setRequestProperty("Authorization", "Bearer " + apiKey.trim());
        conn.setRequestProperty("Content-Type", "application/json");
        conn.setDoOutput(true);
        conn.setConnectTimeout(15000);
        conn.setReadTimeout(35000);

        JSONObject body = new JSONObject();
        body.put("model", "gpt-4.1-mini");
        body.put("max_output_tokens", 650);
        JSONArray input = new JSONArray();
        JSONObject system = new JSONObject();
        system.put("role", "system");
        system.put("content",
                "너는 마음몬의 날짜별 마음 흐름 분석기다. 사용자가 그 날짜에 실제로 말한 상담 내용, 감정일기, 상담사가 답한 맥락과 장기 변화상담 맥락을 읽고 하루를 짧고 현실적으로 정리한다. "
                + "진단하지 말고, 과거 프로필에 억지로 끼워 맞추지 말며, 그날 실제 표현을 가장 우선한다. 감정은 반드시 다음 8개 중 하나만 선택한다: 좋음, 잔잔, 지침, 슬픔, 불안, 화남, 위로, 잠옴. "
                + "문체는 아이를 이해하듯 따뜻하지만 또렷해야 한다. 어려운 상담 용어, 추상어, 과장된 감성은 금지한다. '자기방어, 경계, 패턴, 회복, 자기자비' 같은 말은 그대로 쓰지 말고 쉬운 생활 말로 바꾼다. "
                + "status는 그날 마음 상태를 한 문장으로 짚고, summary는 2~3문장으로 ① 무슨 일이 있었고 어떤 마음이 컸는지 ② 왜 그게 힘들었는지 ③ 오늘 기억하면 좋은 점이나 관점을 담아라. prescription은 그날 상태에 맞춘 아주 작은 행동 1개를 쉽게 말해라. trigger, need, strength도 짧고 쉬운 말로 적어라. "
                + UnifiedTherapyVoice.roleRules("report") + " "
                + "반드시 JSON 객체 하나만 출력하고 다른 문장은 쓰지 마라. 키는 label,status,summary,prescription,trigger,need,strength 이 7개다. 각 값은 한국어 문자열이고 summary는 2~3문장, 나머지는 1문장 이내로 간결하게 쓴다.");
        input.put(system);
        JSONObject user = new JSONObject();
        user.put("role", "user");
        user.put("content", "날짜: " + date + "\n[그날 상담/속마음 기록]\n" + counselingContext + "\n\n[장기 변화상담 맥락]\n" + therapyContext);
        input.put(user);
        body.put("input", input);

        try (OutputStream os = conn.getOutputStream()) {
            os.write(body.toString().getBytes(StandardCharsets.UTF_8));
        }
        int code = conn.getResponseCode();
        InputStream is = code >= 200 && code < 300 ? conn.getInputStream() : conn.getErrorStream();
        String response = readAll(is);
        conn.disconnect();
        if (code < 200 || code >= 300) throw new RuntimeException("OpenAI API error (" + code + "): " + response);
        String output = extractOutputText(new JSONObject(response)).trim();
        if (output.startsWith("```")) {
            output = output.replaceFirst("^```(?:json)?\\s*", "").replaceFirst("\\s*```$", "").trim();
        }
        int a = output.indexOf('{'), b = output.lastIndexOf('}');
        if (a >= 0 && b > a) output = output.substring(a, b + 1);
        JSONObject parsed = new JSONObject(output);
        parsed.put("label", DailyMoodInsightManager.normalizeLabel(parsed.optString("label", "잔잔")));
        return parsed;
    }

    public static String transcribeAudio(String apiKey, File audioFile) throws Exception {
        if (apiKey == null || apiKey.trim().isEmpty()) {
            throw new IllegalArgumentException("OpenAI API Key가 비어 있어.");
        }
        if (audioFile == null || !audioFile.exists() || audioFile.length() == 0) {
            throw new IllegalArgumentException("녹음 파일이 없어.");
        }

        String boundary = "----MaeumMonBoundary" + System.currentTimeMillis();
        URL url = new URL("https://api.openai.com/v1/audio/transcriptions");
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("POST");
        conn.setRequestProperty("Authorization", "Bearer " + apiKey.trim());
        conn.setRequestProperty("Content-Type", "multipart/form-data; boundary=" + boundary);
        conn.setConnectTimeout(20000);
        conn.setReadTimeout(60000);
        conn.setDoOutput(true);

        try (OutputStream os = conn.getOutputStream()) {
            writeFormField(os, boundary, "model", "gpt-4o-mini-transcribe");
            writeFormField(os, boundary, "language", "ko");
            writeFormField(os, boundary, "response_format", "json");
            writeFormField(os, boundary, "prompt", "한국어로 자연스럽고 정확하게 받아써 줘. 이름 '승재'와 앱 이름 '마음몬'을 정확히 인식해 줘.");

            String crlf = "\r\n";
            os.write(("--" + boundary + crlf).getBytes(StandardCharsets.UTF_8));
            os.write(("Content-Disposition: form-data; name=\"file\"; filename=\"voice.m4a\"" + crlf).getBytes(StandardCharsets.UTF_8));
            os.write(("Content-Type: audio/mp4" + crlf + crlf).getBytes(StandardCharsets.UTF_8));
            try (BufferedInputStream in = new BufferedInputStream(new FileInputStream(audioFile))) {
                byte[] buffer = new byte[8192];
                int len;
                while ((len = in.read(buffer)) != -1) os.write(buffer, 0, len);
            }
            os.write(crlf.getBytes(StandardCharsets.UTF_8));
            os.write(("--" + boundary + "--" + crlf).getBytes(StandardCharsets.UTF_8));
            os.flush();
        }

        int code = conn.getResponseCode();
        InputStream is = code >= 200 && code < 300 ? conn.getInputStream() : conn.getErrorStream();
        String response = readAll(is);
        conn.disconnect();
        if (code < 200 || code >= 300) {
            throw new RuntimeException("GPT 음성인식 오류 (" + code + "): " + response);
        }
        JSONObject json = new JSONObject(response);
        String text = json.optString("text", "").trim();
        if (text.isEmpty()) throw new RuntimeException("음성을 글자로 바꾸지 못했어.");
        return text;
    }

    private static void writeFormField(OutputStream os, String boundary, String name, String value) throws Exception {
        String crlf = "\r\n";
        os.write(("--" + boundary + crlf).getBytes(StandardCharsets.UTF_8));
        os.write(("Content-Disposition: form-data; name=\"" + name + "\"" + crlf + crlf).getBytes(StandardCharsets.UTF_8));
        os.write(value.getBytes(StandardCharsets.UTF_8));
        os.write(crlf.getBytes(StandardCharsets.UTF_8));
    }

    private static String safeModel(String model, String fallback) {
        if (model == null) return fallback;
        String m = model.trim();
        return m.isEmpty() ? fallback : m;
    }

    private static String readAll(InputStream is) throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8));
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = br.readLine()) != null) sb.append(line);
        br.close();
        return sb.toString();
    }
}
