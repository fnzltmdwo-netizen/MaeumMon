package com.maeummon.app;

import java.util.Locale;

/** Creates a therapy-like close only when the user is actually ending the session. */
public final class EndOfSessionSummaryV53 {
    private EndOfSessionSummaryV53() {}

    public static String buildContext(String userMessage) {
        String t = userMessage == null ? "" : userMessage.toLowerCase(Locale.KOREA);
        boolean close = has(t, "오늘은 여기", "마무리", "정리해줘", "그만할", "상담 끝", "이제 됐", "오늘 상담", "자러 갈");
        return "[END OF SESSION SUMMARY v5.3]\n"
                + "explicit_session_close=" + close + ".\n"
                + "- 명시적 마무리이거나 충분한 통합 단계일 때만 4요소로 짧게 닫는다: ①오늘 가장 중요한 발견 ②그 발견이 뜻하는 변화 목표 ③다음에 해볼 작은 행동 ④다음 상담에서 이어볼 한 가지.\n"
                + "- 사용자가 아직 감정/새 정보를 말하고 있으면 요약 카드처럼 닫지 않는다. RESPONSE_END와 SESSION_END를 구분한다.\n"
                + "- 요약은 새 진단/새 원인/새 과제를 추가하는 시간이 아니다. 오늘 확인된 내용만 사용한다.\n"
                + "- '잘했어'만 반복하지 말고 변화 증거가 있으면 무엇이 달라졌는지 구체적으로 이름 붙인다.\n"
                + "- 다음 상담 연결고리는 질문형 숙제가 아니라 기억해둘 관찰점 한 가지면 충분하다.";
    }

    public static String prompt() {
        return "[END OF SESSION SUMMARY v5.3] 실제 세션 종료 신호가 있을 때만 오늘의 발견/변화목표/작은행동/다음 연결고리를 짧게 통합한다. 새 해석을 추가하지 않고, 아직 열린 주제는 억지로 닫지 않는다.";
    }

    private static boolean has(String t, String... xs) {
        for (String x : xs) if (t.contains(x.toLowerCase(Locale.KOREA))) return true;
        return false;
    }
}
