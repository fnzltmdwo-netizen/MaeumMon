package com.maeummon.app.clinical;

import android.content.Context;
import org.json.*;
import java.security.MessageDigest;
import java.util.HashSet;

public final class CooldownCleanConfirmationEvidenceLedgerRC14 {
    private CooldownCleanConfirmationEvidenceLedgerRC14(){}

    public enum State {
        NONE,
        EVIDENCE_COMMITTED,
        DUPLICATE_EVIDENCE_SUPPRESSED,
        INELIGIBLE,
        CONTRADICTION_COMMITTED
    }

    public static final class Result {
        public boolean evaluated=false;
        public boolean committed=false;
        public boolean duplicate=false;
        public boolean eligible=false;
        public boolean contradiction=false;
        public State state=State.NONE;
        public String evidenceId="";
        public String ledgerIdentity="";
        public String transitionKey="";
        public String quarantinedCause="";
        public String currentCause="";
        public String normalizedEvidence="";
        public String reason="";
        public String summary="";
    }

    public static Result commitCurrentTurn(
            Context c,
            ClinicalDecisionRC7 d,
            String userText,
            CooldownEvidenceIndependenceParaphraseGuardRC14.Result independence,
            CooldownEvidenceTemporalIndependenceBurstGuardRC14.Result temporal){

        Result r=new Result();

        if(c==null||d==null){
            r.state=State.INELIGIBLE;
            r.reason="MISSING_INPUT";
            return finish(r);
        }

        r.evaluated=true;

        if(independence==null
                ||!CooldownEvidenceIndependenceParaphraseGuardRC14
                    .mayCount(independence)){
            r.state=State.INELIGIBLE;
            r.reason="EVIDENCE_NOT_INDEPENDENT";
            return finish(r);
        }

        if(temporal==null
                ||!CooldownEvidenceTemporalIndependenceBurstGuardRC14
                    .mayCount(temporal)){
            r.state=State.INELIGIBLE;
            r.reason="EVIDENCE_NOT_TEMPORALLY_INDEPENDENT";
            return finish(r);
        }

        if(!d.transitionExplanationCorrectionApplied){
            r.state=State.INELIGIBLE;
            r.reason="NO_EXPLICIT_CURRENT_CORRECTION";
            return finish(r);
        }

        JSONObject p=CentralTherapyProfile.loadProfile(c);
        JSONObject f=CentralTherapyProfile.loadFormulation(c);

        String context=f.optString("current_context_scope","UNKNOWN");

        r.transitionKey=
                safe(d.decisionTransitionFromState)
                +"->"
                +safe(d.decisionTransitionToState)
                +"::"
                +context;

        JSONArray provenance=
                p.optJSONArray(
                        "transition_correction_commit_provenance_history");

        if(provenance==null){
            r.state=State.INELIGIBLE;
            r.reason="NO_PROVENANCE_HISTORY";
            return finish(r);
        }

        JSONObject newestRequarantined=null;

        for(int i=provenance.length()-1;i>=0;i--){
            JSONObject row=provenance.optJSONObject(i);
            if(row==null)continue;

            if(!r.transitionKey.equals(
                    row.optString("transition_key","")))
                continue;

            if(row.optLong(
                    "correction_provenance_requarantined_at",
                    0L)<=0L)
                continue;

            newestRequarantined=row;
            break;
        }

        if(newestRequarantined==null){
            r.state=State.INELIGIBLE;
            r.reason="NO_MATCHING_REQUARANTINED_ROW";
            return finish(r);
        }

        r.quarantinedCause=
                newestRequarantined.optString(
                        "corrected_cause","");

        r.currentCause=
                safe(d.transitionExplanationCorrectedCause);

        r.normalizedEvidence=normalize(userText);

        if(r.normalizedEvidence.isEmpty()
                ||r.currentCause.isEmpty()){
            r.state=State.INELIGIBLE;
            r.reason="MISSING_USER_EVIDENCE_OR_CAUSE";
            return finish(r);
        }

        r.evidenceId=sha256(r.normalizedEvidence);

        r.ledgerIdentity=sha256(
                r.transitionKey
                +"::"
                +r.currentCause
                +"::"
                +r.evidenceId);

        JSONArray ledger=
                p.optJSONArray(
                        "requarantine_cooldown_evidence_ledger");

        if(ledger==null)
            ledger=new JSONArray();

        for(int i=0;i<ledger.length();i++){
            JSONObject x=ledger.optJSONObject(i);
            if(x==null)continue;

            if(r.ledgerIdentity.equals(
                    x.optString("ledger_identity",""))){
                r.duplicate=true;
                r.state=State.DUPLICATE_EVIDENCE_SUPPRESSED;
                r.reason="SAME_USER_EVIDENCE_ALREADY_COUNTED";
                return finish(r);
            }
        }

        r.eligible=true;
        r.contradiction=
                !r.quarantinedCause.equals(
                        r.currentCause);

        try{
            JSONObject item=new JSONObject();
            item.put("ledger_identity",r.ledgerIdentity);
            item.put("user_evidence_id",r.evidenceId);
            item.put("user_evidence_text",r.normalizedEvidence);
            item.put("transition_key",r.transitionKey);
            item.put("quarantined_cause",r.quarantinedCause);
            item.put("current_cause",r.currentCause);
            item.put("clean_confirmation",!r.contradiction);
            item.put("contradiction",r.contradiction);
            item.put("source_type","EXPLICIT_USER_CORRECTION");
            item.put("schema_version","6.9.5");
            item.put("time",System.currentTimeMillis());

            ledger.put(item);
        }catch(Exception e){
            r.state=State.INELIGIBLE;
            r.reason="LEDGER_ITEM_BUILD_FAILED";
            return finish(r);
        }

        JSONArray trimmed=new JSONArray();
        int start=Math.max(0,ledger.length()-40);

        for(int i=start;i<ledger.length();i++)
            trimmed.put(ledger.opt(i));

        try{
            p.put(
                    "requarantine_cooldown_evidence_ledger",
                    trimmed);
            p.put(
                    "last_requarantine_cooldown_evidence_identity",
                    r.ledgerIdentity);
            p.put(
                    "last_requarantine_cooldown_evidence_at",
                    System.currentTimeMillis());

            CentralTherapyProfile.replaceProfile(c,p);

            r.committed=true;

            if(r.contradiction){
                r.state=State.CONTRADICTION_COMMITTED;
                r.reason="EXPLICIT_CONTRADICTION_EVIDENCE_COMMITTED";
            }else{
                r.state=State.EVIDENCE_COMMITTED;
                r.reason="EXPLICIT_CLEAN_CONFIRMATION_COMMITTED";
            }

        }catch(Exception e){
            r.state=State.INELIGIBLE;
            r.reason="LEDGER_WRITE_FAILED";
        }

        return finish(r);
    }

    public static Result commitCurrentTurn(
            Context c,
            ClinicalDecisionRC7 d,
            String userText){

        CooldownEvidenceIndependenceParaphraseGuardRC14.Result independence =
                CooldownEvidenceIndependenceParaphraseGuardRC14.evaluate(
                        c,d,userText);

        CooldownEvidenceTemporalIndependenceBurstGuardRC14.Result temporal =
                CooldownEvidenceTemporalIndependenceBurstGuardRC14.evaluate(
                        c,d);

        return commitCurrentTurn(
                c,d,userText,independence,temporal);
    }

    public static int countClean(
            Context c,
            String transitionKey,
            String quarantinedCause){

        if(c==null)return 0;

        JSONObject p=CentralTherapyProfile.loadProfile(c);
        JSONArray ledger=
                p.optJSONArray(
                        "requarantine_cooldown_evidence_ledger");

        if(ledger==null)return 0;

        int count=0;
        HashSet<String> seen=new HashSet<>();

        for(int i=0;i<ledger.length();i++){
            JSONObject x=ledger.optJSONObject(i);
            if(x==null)continue;

            if(!CooldownEvidenceLedgerIntegrityAntiSyntheticRC14
                    .rowEligible(x))
                continue;

            if(!safe(transitionKey).equals(
                    x.optString("transition_key","")))
                continue;

            if(!safe(quarantinedCause).equals(
                    x.optString("quarantined_cause","")))
                continue;

            if(!x.optBoolean("clean_confirmation",false))
                continue;

            String evidenceId=
                    x.optString("user_evidence_id","");

            if(evidenceId.isEmpty()||seen.contains(evidenceId))
                continue;

            seen.add(evidenceId);
            count++;
        }

        return count;
    }

    public static int countContradictions(
            Context c,
            String transitionKey,
            String quarantinedCause){

        if(c==null)return 0;

        JSONObject p=CentralTherapyProfile.loadProfile(c);
        JSONArray ledger=
                p.optJSONArray(
                        "requarantine_cooldown_evidence_ledger");

        if(ledger==null)return 0;

        int count=0;
        HashSet<String> seen=new HashSet<>();

        for(int i=0;i<ledger.length();i++){
            JSONObject x=ledger.optJSONObject(i);
            if(x==null)continue;

            if(!CooldownEvidenceLedgerIntegrityAntiSyntheticRC14
                    .rowEligible(x))
                continue;

            if(!safe(transitionKey).equals(
                    x.optString("transition_key","")))
                continue;

            if(!safe(quarantinedCause).equals(
                    x.optString("quarantined_cause","")))
                continue;

            if(!x.optBoolean("contradiction",false))
                continue;

            String evidenceId=
                    x.optString("user_evidence_id","");

            if(evidenceId.isEmpty()||seen.contains(evidenceId))
                continue;

            seen.add(evidenceId);
            count++;
        }

        return count;
    }

    public static String instruction(Result r){
        if(r==null||!r.evaluated)return "";

        if(r.state==State.EVIDENCE_COMMITTED)
            return "COOLDOWN_EVIDENCE_LEDGER=CLEAN_COMMITTED. 이번 clean confirmation은 명시적 사용자 발화 provenance와 함께 1회만 카운트한다.";

        if(r.state==State.CONTRADICTION_COMMITTED)
            return "COOLDOWN_EVIDENCE_LEDGER=CONTRADICTION_COMMITTED. 이번 모순도 명시적 사용자 발화 provenance와 함께 기록한다.";

        if(r.state==State.DUPLICATE_EVIDENCE_SUPPRESSED)
            return "COOLDOWN_EVIDENCE_LEDGER=DUPLICATE_SUPPRESSED. 동일 사용자 근거는 clean confirmation 횟수에 중복 가산하지 않는다.";

        return "";
    }

    private static String normalize(String s){
        if(s==null)return "";
        return s.trim()
                .replaceAll("\\s+"," ")
                .toLowerCase();
    }

    private static String sha256(String s){
        try{
            MessageDigest md=MessageDigest.getInstance("SHA-256");
            byte[] b=md.digest(safe(s).getBytes("UTF-8"));
            StringBuilder out=new StringBuilder();
            for(byte x:b)out.append(String.format("%02x",x));
            return out.toString();
        }catch(Exception e){
            return Integer.toHexString(safe(s).hashCode());
        }
    }

    private static Result finish(Result r){
        r.summary=r.state.name()
                +" | committed="+r.committed
                +" | duplicate="+r.duplicate
                +" | contradiction="+r.contradiction
                +" | transition="+r.transitionKey
                +" | quarantinedCause="+r.quarantinedCause
                +" | currentCause="+r.currentCause
                +" | evidenceId="+r.evidenceId
                +" | reason="+r.reason;
        return r;
    }

    private static String safe(String s){
        return s==null?"":s;
    }
}
