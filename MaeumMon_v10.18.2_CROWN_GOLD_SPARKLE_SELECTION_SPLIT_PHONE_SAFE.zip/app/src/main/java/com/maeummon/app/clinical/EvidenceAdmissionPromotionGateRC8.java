package com.maeummon.app.clinical;

import android.content.Context;
import org.json.*;

public final class EvidenceAdmissionPromotionGateRC8 {
    private EvidenceAdmissionPromotionGateRC8(){}

    public static final String ADMIT="ADMIT";
    public static final String HOLD="HOLD";
    public static final String REJECT="REJECT";
    public static final String PROMOTE="PROMOTE";

    public static final class Result {
        public int admitted=0;
        public int held=0;
        public int rejected=0;
        public int promoted=0;
        public String summary="";
    }

    public static Result evaluate(Context c){
        Result r=new Result();
        if(c==null)return r;

        JSONObject f=CentralTherapyProfile.loadFormulation(c);
        JSONArray ledger=f.optJSONArray("evidence_ledger");
        if(ledger==null)return r;

        JSONArray conflicts=f.optJSONArray("evidence_conflict_matrix");

        for(int i=0;i<ledger.length();i++){
            JSONObject e=ledger.optJSONObject(i);
            if(e==null)continue;

            String source=e.optString("source_type","UNKNOWN");
            String text=e.optString("text","");
            double confidence=e.optDouble("confidence",0.50);
            boolean explicit=e.optBoolean("explicit",false);
            boolean stale=isStale(e);
            boolean conflicted=isConflicted(conflicts,text);

            String decision;
            String reason;

            if("UNKNOWN".equals(source)){
                decision=REJECT;
                reason="unknown provenance";
            }else if(conflicted){
                decision=HOLD;
                reason="unresolved contradiction";
            }else if(stale && !explicit){
                decision=HOLD;
                reason="stale non-explicit evidence";
            }else if("SESSION_INFERENCE".equals(source)){
                decision=HOLD;
                reason="inference remains tentative";
            }else if("USER_CORRECTION".equals(source)){
                decision=ADMIT;
                reason="explicit correction";
            }else if("USER_DIRECT".equals(source) && explicit && confidence>=0.80){
                decision=ADMIT;
                reason="direct explicit user evidence";
            }else if(("CHECKIN".equals(source)||"DIARY".equals(source))
                    && confidence>=0.65){
                decision=ADMIT;
                reason="structured self-report evidence";
            }else if("INTERVENTION_OUTCOME".equals(source)){
                decision=ADMIT;
                reason="review outcome evidence";
            }else if("STABLE_MEMORY".equals(source) && confidence>=0.70){
                decision=ADMIT;
                reason="previously consolidated memory";
            }else{
                decision=HOLD;
                reason="insufficient evidence quality";
            }

            boolean promote=false;

            // Promotion requires more than one direct/structured confirmation signal.
            int repetition=e.optInt("repetition_count",0);
            if((ADMIT.equals(decision))
                    && !stale
                    && !conflicted
                    && (
                        ("USER_CORRECTION".equals(source) && repetition>=1)
                        || ("USER_DIRECT".equals(source) && repetition>=2)
                        || ("CHECKIN".equals(source) && repetition>=3)
                        || ("DIARY".equals(source) && repetition>=3)
                    )){
                promote=true;
                decision=PROMOTE;
                reason="repeated high-quality evidence";
            }

            try{
                e.put("admission_status",decision);
                e.put("admission_reason",reason);
                e.put("eligible_for_formulation",
                        ADMIT.equals(decision)||PROMOTE.equals(decision));
                e.put("eligible_for_stable_promotion",promote);
            }catch(Exception ignored){}

            if(ADMIT.equals(decision))r.admitted++;
            else if(HOLD.equals(decision))r.held++;
            else if(REJECT.equals(decision))r.rejected++;
            else if(PROMOTE.equals(decision))r.promoted++;
        }

        try{
            f.put("evidence_ledger",ledger);
            f.put("evidence_gate_summary",
                    "admit="+r.admitted+", hold="+r.held
                            +", reject="+r.rejected+", promote="+r.promoted);
            f.put("evidence_gate_updated_at",System.currentTimeMillis());
            CentralTherapyProfile.replaceFormulation(c,f);
        }catch(Exception ignored){}

        r.summary="admit="+r.admitted+", hold="+r.held
                +", reject="+r.rejected+", promote="+r.promoted;
        return r;
    }

    public static String instruction(Result r){
        if(r==null)return "";
        return "EVIDENCE_GATE=true. HOLD/REJECT evidence를 formulation의 확정 근거로 사용하지 않는다. "
                +"PROMOTE는 반복 확인된 고품질 evidence에만 허용한다. "
                +"추론 하나만으로 stable pattern을 만들지 않는다. "+r.summary;
    }

    private static boolean isStale(JSONObject e){
        long time=e.optLong("time",0);
        if(time<=0)return false;
        long now=System.currentTimeMillis();
        long days=Math.max(0,(now-time)/(24L*60L*60L*1000L));
        return days>90;
    }

    private static boolean isConflicted(JSONArray conflicts,String text){
        if(conflicts==null||text==null||text.isEmpty())return false;
        for(int i=0;i<conflicts.length();i++){
            JSONObject c=conflicts.optJSONObject(i);
            if(c==null||!c.optBoolean("unresolved",false))continue;
            String key=c.optString("key","");
            if(matchesConflictKey(key,text))return true;
        }
        return false;
    }

    private static boolean matchesConflictKey(String key,String text){
        if("relationship_baseline".equals(key))
            return containsAny(text,"원래","최근","예전","답장");
        if("recent_conflict".equals(key))
            return containsAny(text,"싸","갈등","다툼","서운");
        if("selective_change".equals(key))
            return containsAny(text,"나한테만","모두한테","누구에게나");
        if("work_stressor".equals(key))
            return containsAny(text,"회사","업무","평가","상사","일");
        return false;
    }

    private static boolean containsAny(String s,String... xs){
        for(String x:xs)if(s.contains(x))return true;
        return false;
    }
}
