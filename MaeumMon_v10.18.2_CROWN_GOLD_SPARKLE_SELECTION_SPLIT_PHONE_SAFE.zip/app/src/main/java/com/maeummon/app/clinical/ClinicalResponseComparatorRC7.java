package com.maeummon.app.clinical;

import java.util.*;
import java.util.regex.*;

public final class ClinicalResponseComparatorRC7 {
    private ClinicalResponseComparatorRC7(){}

    public static final class Result {
        public final int meaningScore;
        public final int continuityScore;
        public final int mechanicalPenalty;
        public final int total;
        public final List<String> issues;

        public Result(int meaningScore,int continuityScore,int mechanicalPenalty,int total,List<String> issues){
            this.meaningScore=meaningScore;
            this.continuityScore=continuityScore;
            this.mechanicalPenalty=mechanicalPenalty;
            this.total=total;
            this.issues=issues==null?new ArrayList<>():issues;
        }
    }

    public static Result compare(String userText,String original,String revised,String route,String target){
        String u=safe(userText);
        String o=safe(original);
        String r=safe(revised);

        int meaning=100;
        int continuity=100;
        int mechanicalPenalty=0;
        List<String> issues=new ArrayList<>();

        // Preserve salient user words/content markers.
        Set<String> salient=salientTokens(u);
        if(!salient.isEmpty()){
            int kept=0;
            for(String token:salient){
                if(r.contains(token))kept++;
            }
            double ratio=(double)kept/(double)salient.size();
            if(ratio<0.30){
                meaning-=45;
                issues.add("USER_MEANING_LOSS");
            }else if(ratio<0.55){
                meaning-=25;
                issues.add("USER_MEANING_WEAKENED");
            }
        }

        // Preserve core structure from original without requiring exact wording.
        Set<String> originalMarkers=salientTokens(o);
        if(!originalMarkers.isEmpty()){
            int kept=0;
            for(String token:originalMarkers){
                if(r.contains(token))kept++;
            }
            double ratio=(double)kept/(double)originalMarkers.size();
            if(ratio<0.18){
                continuity-=35;
                issues.add("ORIGINAL_CORE_DROPPED");
            }
        }

        // Penalize canned / robotic QA-repair leakage.
        String lower=r.toLowerCase(Locale.ROOT);
        String[] mechanical={
            "target_variable","route=","rc7","quality gate","문제 태그",
            "수정된 최종 답변","상담 목표를 재합의","현재 formulation"
        };
        for(String m:mechanical){
            if(lower.contains(m.toLowerCase(Locale.ROOT))){
                mechanicalPenalty+=25;
                issues.add("MECHANICAL_META_LANGUAGE");
                break;
            }
        }

        // Excessive template phrasing.
        String[] canned={
            "그 마음 충분히 이해해","그럴 수 있어","많이 힘들었겠다",
            "우선 한 가지 해보자","정리해보면"
        };
        int cannedCount=0;
        for(String c:canned)if(r.contains(c))cannedCount++;
        if(cannedCount>=3){
            mechanicalPenalty+=20;
            issues.add("CANNED_TONE_STACK");
        }

        // Route-sensitive preservation.
        if("ASK".equals(route)){
            int q=countQuestions(r);
            if(q!=1){
                continuity-=30;
                issues.add("ASK_SHAPE_CHANGED");
            }
        }
        if("ALLIANCE_REPAIR".equals(route)){
            if(!(r.contains("맞")||r.contains("어긋")||r.contains("원한")||r.contains("방향")||r.contains("질문"))){
                continuity-=20;
                issues.add("REPAIR_CONTEXT_LOST");
            }
        }
        if("STABILIZE".equals(route)){
            if(r.length()>700){
                continuity-=20;
                issues.add("STABILIZE_TOO_EXPANSIVE");
            }
        }

        int total=clamp((meaning+continuity)/2-mechanicalPenalty);
        return new Result(clamp(meaning),clamp(continuity),mechanicalPenalty,total,issues);
    }

    public static boolean shouldPreferRevised(
            ClinicalResponseQualityRC7.Result originalQuality,
            ClinicalResponseQualityRC7.Result revisedQuality,
            Result comparator
    ){
        if(revisedQuality==null||comparator==null)return false;
        if(comparator.total<65)return false;
        if(comparator.meaningScore<60)return false;
        if(comparator.mechanicalPenalty>=25)return false;
        if(originalQuality==null)return true;

        // Revised must meaningfully improve quality, or at least improve grade without semantic loss.
        int gain=revisedQuality.score-originalQuality.score;
        if(gain>=8)return true;
        if(gradeRank(revisedQuality.grade)>gradeRank(originalQuality.grade) && gain>=0)return true;
        return false;
    }

    private static Set<String> salientTokens(String text){
        Set<String> out=new LinkedHashSet<>();
        Matcher m=Pattern.compile("[가-힣]{2,}").matcher(text);
        String[] stop={"그냥","근데","그래서","그리고","나는","내가","진짜","너무","조금","정말","같아","같은","이거","저거","지금","오늘"};
        Set<String> stops=new HashSet<>(Arrays.asList(stop));
        while(m.find()){
            String s=m.group();
            if(s.length()>=2&&!stops.contains(s))out.add(s);
            if(out.size()>=12)break;
        }
        return out;
    }

    private static int countQuestions(String s){
        int n=0;
        for(int i=0;i<s.length();i++)if(s.charAt(i)=='?')n++;
        return n;
    }
    private static int gradeRank(String g){
        if("PASS".equalsIgnoreCase(g))return 3;
        if("WARN".equalsIgnoreCase(g))return 2;
        if("FAIL".equalsIgnoreCase(g))return 1;
        return 0;
    }
    private static int clamp(int v){return Math.max(0,Math.min(100,v));}
    private static String safe(String s){return s==null?"":s;}
}
