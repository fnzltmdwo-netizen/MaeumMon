package com.maeummon.app.clinical;

import android.content.Context;

public final class CentralTherapyIntegration {
    private CentralTherapyIntegration(){}

    public static String counseling(Context c){
        return TherapySurfaceContext.forSurface(c,TherapySurfaceContext.COUNSELING);
    }
    public static String focusCoaching(Context c){
        return TherapySurfaceContext.forSurface(c,TherapySurfaceContext.FOCUS_COACHING);
    }
    public static String checkIn(Context c){
        return TherapySurfaceContext.forSurface(c,TherapySurfaceContext.CHECK_IN);
    }
    public static String dailyLetter(Context c){
        return TherapySurfaceContext.forSurface(c,TherapySurfaceContext.DAILY_LETTER);
    }
    public static String diarySummary(Context c){
        return TherapySurfaceContext.forSurface(c,TherapySurfaceContext.DIARY_SUMMARY);
    }
    public static String weeklyReport(Context c){
        return TherapySurfaceContext.forSurface(c,TherapySurfaceContext.WEEKLY_REPORT);
    }
    public static String monthlyReport(Context c){
        return TherapySurfaceContext.forSurface(c,TherapySurfaceContext.MONTHLY_REPORT);
    }
    public static String widget(Context c){
        return TherapySurfaceContext.forSurface(c,TherapySurfaceContext.WIDGET);
    }
    public static String tamagotchi(Context c){
        return TherapySurfaceContext.forSurface(c,TherapySurfaceContext.TAMAGOTCHI);
    }
}
