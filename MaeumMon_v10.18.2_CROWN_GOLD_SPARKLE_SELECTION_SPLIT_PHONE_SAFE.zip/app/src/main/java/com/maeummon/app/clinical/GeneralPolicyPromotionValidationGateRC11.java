package com.maeummon.app.clinical;

import android.content.Context;
import org.json.*;

public final class GeneralPolicyPromotionValidationGateRC11 {
    private GeneralPolicyPromotionValidationGateRC11(){}

    public enum PromotionState {
        NONE,
        CANDIDATE,
        PROMOTED_GENERAL,
        BLOCKED,
        DEMOTED_CONTEXT_BOUND
    }

    public static final class Result {
        public boolean evaluated=false;
        public boolean changed=false;
        public PromotionState state=PromotionState.NONE;
        public String mechanism="";
        public String interventionId="";
        public int distinctContexts=0;
        public int positiveCommits=0;
        public int negativeCommits=0;
        public boolean cleanAcrossContexts=false;
        public String reason="";
        public String summary="";
    }

    public static Result evaluate(Context c,ClinicalDecisionRC7 d){
        Result r=new Result();
        if(c==null||d==null){
            r.summary="NONE | NO_CONTEXT_OR_DECISION";
            return r;
        }

        try{
            JSONObject p=CentralTherapyProfile.loadProfile(c);

            String mechanism=p.optString(
                    "generalization_candidate_mechanism",
                    safe(d.centralMechanism));

            String intervention=p.optString(
                    "generalization_candidate_intervention",
                    safe(d.selectedInterventionId));

            if(mechanism.isEmpty()||intervention.isEmpty()){
                r.summary="NONE | NO_CANDIDATE";
                return r;
            }

            r.evaluated=true;
            r.mechanism=mechanism;
            r.interventionId=intervention;

            JSONArray h=p.optJSONArray("cross_context_transfer_history");
            if(h==null){
                r.state=PromotionState.BLOCKED;
                r.reason="NO_TRANSFER_HISTORY";
                return finish(r);
            }

            JSONArray contexts=new JSONArray();

            for(int i=0;i<h.length();i++){
                JSONObject x=h.optJSONObject(i);
                if(x==null)continue;

                if(!mechanism.equals(x.optString("mechanism","")))
                    continue;
                if(!intervention.equals(x.optString("intervention_id","")))
                    continue;

                String outcome=x.optString("outcome","UNKNOWN");
                String context=x.optString("target_context","UNKNOWN");

                if("HELPED".equals(outcome)||"PARTIAL".equals(outcome)){
                    r.positiveCommits++;
                    addUnique(contexts,context);
                }else if("NO_CHANGE".equals(outcome)||"WORSE".equals(outcome)){
                    r.negativeCommits++;
                }
            }

            r.distinctContexts=contexts.length();
            r.cleanAcrossContexts=
                    r.negativeCommits==0
                    && r.distinctContexts>=3
                    && r.positiveCommits>=4;

            // Any negative cross-context evidence blocks GENERAL promotion.
            if(r.negativeCommits>0){
                r.state=PromotionState.BLOCKED;
                r.reason="CROSS_CONTEXT_NEGATIVE_PRESENT";
                p.put("generalization_candidate_ready",false);
                p.put("generalization_candidate_block_reason",r.reason);
                CentralTherapyProfile.replaceProfile(c,p);
                return finish(r);
            }

            if(r.distinctContexts<3 || r.positiveCommits<4){
                r.state=PromotionState.CANDIDATE;
                r.reason="INSUFFICIENT_MULTI_CONTEXT_EVIDENCE";
                return finish(r);
            }

            // Promote or refresh GENERAL policy.
            JSONArray policies=p.optJSONArray("intervention_policy_memory");
            if(policies==null)policies=new JSONArray();

            JSONObject general=findGeneral(policies,mechanism,intervention);

            if(general==null){
                general=new JSONObject();
                general.put("key",mechanism+"__"+intervention+"__GENERAL");
                general.put("mechanism",mechanism);
                general.put("intervention_id",intervention);
                general.put("context_scope","GENERAL");
                general.put("context_bounded",false);
                general.put("policy_status","ACTIVE");
                general.put("confidence","MEDIUM");
                general.put("positive_commits",r.positiveCommits);
                general.put("negative_commits",0);
                general.put("multi_context_count",r.distinctContexts);
                general.put("promotion_reason","MULTI_CONTEXT_VALIDATED");
                general.put("updated_at",System.currentTimeMillis());
                policies.put(general);
            }else{
                general.put("policy_status","ACTIVE");
                general.put("confidence",
                        r.positiveCommits>=6 && r.distinctContexts>=4
                                ?"HIGH":"MEDIUM");
                general.put("positive_commits",r.positiveCommits);
                general.put("negative_commits",0);
                general.put("multi_context_count",r.distinctContexts);
                general.put("promotion_reason","MULTI_CONTEXT_REVALIDATED");
                general.put("updated_at",System.currentTimeMillis());
            }

            p.put("intervention_policy_memory",trimPolicies(policies,24));
            p.put("generalization_candidate_ready",false);
            p.put("last_general_policy_key",
                    mechanism+"__"+intervention+"__GENERAL");
            p.put("last_general_policy_promotion_at",
                    System.currentTimeMillis());

            CentralTherapyProfile.replaceProfile(c,p);

            r.state=PromotionState.PROMOTED_GENERAL;
            r.changed=true;
            r.reason="MULTI_CONTEXT_VALIDATED";
            return finish(r);
        }catch(Exception e){
            r.state=PromotionState.BLOCKED;
            r.changed=false;
            r.reason="GENERAL_POLICY_PROMOTION_PERSIST_FAILED";
            return finish(r);
        }
    }

    public static Result demoteIfContradicted(
            Context c,ClinicalDecisionRC7 d){

        Result r=new Result();
        if(c==null||d==null){
            r.summary="NONE | NO_CONTEXT_OR_DECISION";
            return r;
        }

        if(!"COMMIT".equals(d.outcomeCommitState)){
            r.summary="NONE | NO_COMMITTED_OUTCOME";
            return r;
        }

        String outcome=safe(d.outcomeCommitValue);
        if(!"NO_CHANGE".equals(outcome)&&!"WORSE".equals(outcome)){
            r.summary="NONE | NO_NEGATIVE_OUTCOME";
            return r;
        }

        JSONObject p=CentralTherapyProfile.loadProfile(c);
        JSONArray policies=p.optJSONArray("intervention_policy_memory");
        if(policies==null){
            r.summary="NONE | NO_POLICY_MEMORY";
            return r;
        }

        String mechanism=safe(d.centralMechanism);
        String intervention=safe(d.selectedInterventionId);
        JSONObject general=findGeneral(policies,mechanism,intervention);

        if(general==null){
            r.summary="NONE | NO_GENERAL_POLICY";
            return r;
        }

        r.evaluated=true;
        r.mechanism=mechanism;
        r.interventionId=intervention;
        r.state=PromotionState.DEMOTED_CONTEXT_BOUND;
        r.changed=true;
        r.reason="GENERAL_POLICY_CONTRADICTED_IN_CONTEXT";

        try{
            general.put("policy_status","DEMOTED");
            general.put("confidence","LOW");
            general.put("context_scope","GENERAL");
            general.put("context_bounded",true);
            general.put("demotion_reason",r.reason);
            general.put("updated_at",System.currentTimeMillis());

            p.put("last_general_policy_demotion_key",
                    general.optString("key",""));
            p.put("last_general_policy_demotion_at",
                    System.currentTimeMillis());

            CentralTherapyProfile.replaceProfile(c,p);
        }catch(Exception ignored){}

        return finish(r);
    }

    public static String instruction(Result r){
        if(r==null||!r.evaluated)return "";

        switch(r.state){
            case PROMOTED_GENERAL:
                return "GENERAL_POLICY_PROMOTION=YES. 여러 context에서 반복 검증된 policy를 GENERAL weak prior로 승격하지만 현재 formulation/bridge를 계속 우선한다.";
            case CANDIDATE:
                return "GENERAL_POLICY_PROMOTION=PENDING. 다른 context에서의 evidence가 아직 부족해 GENERAL로 승격하지 않는다.";
            case BLOCKED:
                return "GENERAL_POLICY_PROMOTION=BLOCKED. cross-context negative evidence가 있어 일반화를 중단한다.";
            case DEMOTED_CONTEXT_BOUND:
                return "GENERAL_POLICY_DEMOTION=YES. GENERAL policy가 현재 context의 negative evidence와 충돌해 confidence를 낮추고 다시 제한적으로 취급한다.";
            default:
                return "";
        }
    }

    private static JSONObject findGeneral(
            JSONArray policies,String mechanism,String intervention){

        for(int i=0;i<policies.length();i++){
            JSONObject x=policies.optJSONObject(i);
            if(x==null)continue;

            if(!"GENERAL".equals(x.optString("context_scope","")))
                continue;

            if(!mechanism.equals(x.optString("mechanism","")))
                continue;

            if(!intervention.equals(x.optString("intervention_id","")))
                continue;

            return x;
        }
        return null;
    }

    private static JSONArray trimPolicies(JSONArray a,int max){
        JSONArray out=new JSONArray();
        int start=Math.max(0,a.length()-max);
        for(int i=start;i<a.length();i++)
            out.put(a.opt(i));
        return out;
    }

    private static void addUnique(JSONArray a,String value)
            throws JSONException{
        for(int i=0;i<a.length();i++)
            if(value.equals(a.optString(i)))return;
        a.put(value);
    }

    private static Result finish(Result r){
        r.summary=r.state.name()
                +" | changed="+r.changed
                +" | mechanism="+r.mechanism
                +" | intervention="+r.interventionId
                +" | contexts="+r.distinctContexts
                +" | positive="+r.positiveCommits
                +" | negative="+r.negativeCommits
                +" | clean="+r.cleanAcrossContexts
                +" | reason="+r.reason;
        return r;
    }

    private static String safe(String s){
        return s==null?"":s;
    }
}
