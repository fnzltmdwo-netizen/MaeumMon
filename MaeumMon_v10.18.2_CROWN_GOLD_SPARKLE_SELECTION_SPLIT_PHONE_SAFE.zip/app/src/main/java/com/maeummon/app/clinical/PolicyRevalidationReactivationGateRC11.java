package com.maeummon.app.clinical;

import android.content.Context;
import org.json.*;

public final class PolicyRevalidationReactivationGateRC11 {
    private PolicyRevalidationReactivationGateRC11(){}

    public enum ReactivationState {
        NONE,
        REVALIDATION_PENDING,
        REACTIVATED_LOW,
        REACTIVATED_MEDIUM,
        ACTIVE_UNCHANGED
    }

    public static final class Result {
        public boolean evaluated=false;
        public boolean changed=false;
        public ReactivationState state=ReactivationState.NONE;
        public String policyKey="";
        public String oldStatus="";
        public String newStatus="";
        public String oldConfidence="";
        public String newConfidence="";
        public int recentPositive=0;
        public int recentNegative=0;
        public boolean sameContextEvidence=false;
        public boolean sameMechanismEvidence=false;
        public String reason="";
        public String summary="";
    }

    public static Result evaluate(Context c,ClinicalDecisionRC7 d){
        Result r=new Result();
        if(c==null||d==null){
            r.summary="NO_EVALUATION | NO_CONTEXT_OR_DECISION";
            return r;
        }

        if(!"COMMIT".equals(d.outcomeCommitState)){
            r.summary="NO_EVALUATION | NO_COMMITTED_OUTCOME";
            return r;
        }

        String committed=safe(d.outcomeCommitValue);
        boolean positive=
                "HELPED".equals(committed)
                ||"PARTIAL".equals(committed);

        if(!positive){
            r.summary="NO_EVALUATION | COMMIT_NOT_POSITIVE";
            return r;
        }

        JSONObject p=CentralTherapyProfile.loadProfile(c);
        JSONObject f=CentralTherapyProfile.loadFormulation(c);
        JSONArray policies=p.optJSONArray("intervention_policy_memory");

        if(policies==null||policies.length()==0){
            r.summary="NO_EVALUATION | NO_POLICY_MEMORY";
            return r;
        }

        String mechanism=safe(d.centralMechanism);
        String intervention=safe(d.selectedInterventionId);
        String context=f.optString("current_context_scope","UNKNOWN");

        JSONObject policy=null;
        int idx=-1;

        for(int i=0;i<policies.length();i++){
            JSONObject x=policies.optJSONObject(i);
            if(x==null)continue;

            if(!mechanism.equals(x.optString("mechanism","")))
                continue;

            if(!intervention.equals(x.optString("intervention_id","")))
                continue;

            String px=x.optString("context_scope","UNKNOWN");
            if(!context.equals(px) && !"GENERAL".equals(px))
                continue;

            policy=x;
            idx=i;
            break;
        }

        if(policy==null){
            r.summary="NO_EVALUATION | NO_MATCHING_POLICY";
            return r;
        }

        r.evaluated=true;
        r.policyKey=policy.optString("key","");
        r.oldStatus=policy.optString("policy_status","ACTIVE");
        r.oldConfidence=policy.optString("confidence","LOW");
        r.newStatus=r.oldStatus;
        r.newConfidence=r.oldConfidence;
        r.sameContextEvidence=true;
        r.sameMechanismEvidence=true;

        countRecentEvidence(
                p,intervention,
                new int[]{0,0},
                r);

        // ACTIVE policies do not need reactivation.
        if("ACTIVE".equals(r.oldStatus)
                && !"LOW".equals(r.oldConfidence)){
            r.state=ReactivationState.ACTIVE_UNCHANGED;
            r.reason="POLICY_ALREADY_ACTIVE";
            return finish(r);
        }

        // One new positive result is never enough.
        if(r.recentPositive<2){
            r.state=ReactivationState.REVALIDATION_PENDING;
            r.reason="INSUFFICIENT_REVALIDATION_EVIDENCE";
            persistMarker(c,p,policy,r);
            return finish(r);
        }

        // Recent contradiction still blocks reactivation.
        if(r.recentNegative>0){
            r.state=ReactivationState.REVALIDATION_PENDING;
            r.reason="RECENT_NEGATIVE_STILL_PRESENT";
            persistMarker(c,p,policy,r);
            return finish(r);
        }

        // RETIRED requires stronger evidence: 3 clean positives.
        if("RETIRED".equals(r.oldStatus)){
            if(r.recentPositive>=3){
                r.state=ReactivationState.REACTIVATED_LOW;
                r.newStatus="DEMOTED";
                r.newConfidence="LOW";
                r.reason="RETIRED_POLICY_CLEAN_REVALIDATION";
                r.changed=true;
                apply(c,p,policy,r);
            }else{
                r.state=ReactivationState.REVALIDATION_PENDING;
                r.reason="RETIRED_REQUIRES_THREE_POSITIVE";
                persistMarker(c,p,policy,r);
            }
            return finish(r);
        }

        // DEMOTED LOW -> MEDIUM only after 2 clean positives.
        if("DEMOTED".equals(r.oldStatus)
                && "LOW".equals(r.oldConfidence)){
            r.state=ReactivationState.REACTIVATED_MEDIUM;
            r.newStatus="ACTIVE";
            r.newConfidence="MEDIUM";
            r.reason="DEMOTED_LOW_REVALIDATED";
            r.changed=true;
            apply(c,p,policy,r);
            return finish(r);
        }

        // DEMOTED MEDIUM/HIGH -> ACTIVE without confidence jump.
        if("DEMOTED".equals(r.oldStatus)){
            r.state=ReactivationState.REACTIVATED_MEDIUM;
            r.newStatus="ACTIVE";
            r.newConfidence=r.oldConfidence;
            r.reason="DEMOTED_POLICY_REVALIDATED";
            r.changed=true;
            apply(c,p,policy,r);
            return finish(r);
        }

        // ACTIVE LOW can regain MEDIUM after clean repeat evidence.
        if("ACTIVE".equals(r.oldStatus)
                && "LOW".equals(r.oldConfidence)){
            r.state=ReactivationState.REACTIVATED_MEDIUM;
            r.newStatus="ACTIVE";
            r.newConfidence="MEDIUM";
            r.reason="ACTIVE_LOW_REVALIDATED";
            r.changed=true;
            apply(c,p,policy,r);
            return finish(r);
        }

        r.state=ReactivationState.NONE;
        r.reason="NO_REACTIVATION_RULE";
        return finish(r);
    }

    private static void countRecentEvidence(
            JSONObject p,String intervention,
            int[] ignored,Result r){

        JSONArray commits=p.optJSONArray(
                "micro_experiment_outcome_commit_history");
        if(commits==null)return;

        int seen=0;
        for(int i=commits.length()-1;i>=0 && seen<6;i--){
            JSONObject item=commits.optJSONObject(i);
            if(item==null)continue;
            if(!"COMMIT".equals(item.optString("commit_state","")))
                continue;

            String exp=item.optString("experiment_id","");
            if(!intervention.isEmpty()&&!exp.contains(intervention))
                continue;

            seen++;
            String o=item.optString("outcome","UNKNOWN");

            if("HELPED".equals(o)||"PARTIAL".equals(o))
                r.recentPositive++;
            else if("NO_CHANGE".equals(o)||"WORSE".equals(o))
                r.recentNegative++;
        }
    }

    public static String instruction(Result r){
        if(r==null||!r.evaluated)return "";

        if(r.state==ReactivationState.REVALIDATION_PENDING){
            return "POLICY_REVALIDATION=PENDING. 새 긍정 evidence는 기록하되 아직 과거 policy를 다시 prior로 승격하지 않는다.";
        }

        if(r.state==ReactivationState.REACTIVATED_LOW){
            return "POLICY_REVALIDATION=REACTIVATED_LOW. retired policy를 즉시 강하게 복구하지 않고 LOW/DEMOTED 상태로 제한적으로 되살린다.";
        }

        if(r.state==ReactivationState.REACTIVATED_MEDIUM){
            return "POLICY_REVALIDATION=REACTIVATED_MEDIUM. 반복된 깨끗한 긍정 evidence로 policy를 다시 ACTIVE 후보로 복구하되 현재 evidence를 계속 우선한다.";
        }

        return "";
    }

    private static void apply(
            Context c,JSONObject p,
            JSONObject policy,Result r){

        try{
            long now=System.currentTimeMillis();

            policy.put("policy_status",r.newStatus);
            policy.put("confidence",r.newConfidence);
            policy.put("reactivation_reason",r.reason);
            policy.put("last_revalidation_at",now);
            policy.put("recent_revalidation_positive",
                    r.recentPositive);
            policy.put("recent_revalidation_negative",
                    r.recentNegative);

            p.put("last_policy_reactivation_key",r.policyKey);
            p.put("last_policy_reactivation_state",
                    r.state.name());
            p.put("last_policy_reactivation_at",now);

            CentralTherapyProfile.replaceProfile(c,p);
        }catch(Exception ignored){}
    }

    private static void persistMarker(
            Context c,JSONObject p,
            JSONObject policy,Result r){

        try{
            long now=System.currentTimeMillis();

            policy.put("last_revalidation_state",
                    r.state.name());
            policy.put("last_revalidation_reason",
                    r.reason);
            policy.put("last_revalidation_at",now);
            policy.put("recent_revalidation_positive",
                    r.recentPositive);
            policy.put("recent_revalidation_negative",
                    r.recentNegative);

            p.put("last_policy_reactivation_key",r.policyKey);
            p.put("last_policy_reactivation_state",
                    r.state.name());
            p.put("last_policy_reactivation_at",now);

            CentralTherapyProfile.replaceProfile(c,p);
        }catch(Exception ignored){}
    }

    public static boolean mayReturnToRetrieval(
            Result r){
        return r!=null
                && r.changed
                && "ACTIVE".equals(r.newStatus)
                && ("MEDIUM".equals(r.newConfidence)
                    ||"HIGH".equals(r.newConfidence));
    }

    private static Result finish(Result r){
        r.summary=r.state.name()
                +" | changed="+r.changed
                +" | status="+r.oldStatus+"->"+r.newStatus
                +" | confidence="+r.oldConfidence+"->"+r.newConfidence
                +" | pos="+r.recentPositive
                +" | neg="+r.recentNegative
                +" | reason="+r.reason;
        return r;
    }

    private static String safe(String s){
        return s==null?"":s;
    }
}
