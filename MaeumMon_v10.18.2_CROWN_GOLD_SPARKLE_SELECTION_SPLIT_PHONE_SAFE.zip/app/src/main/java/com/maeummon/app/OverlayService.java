package com.maeummon.app;

import com.maeummon.app.clinical.CentralTherapyProfile;

import com.maeummon.app.clinical.TherapySurfaceContext;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ValueAnimator;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.app.usage.UsageEvents;
import android.app.usage.UsageStatsManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.animation.LinearInterpolator;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.Calendar;
import java.util.Random;

public class OverlayService extends Service {

    private static final int NOTIFICATION_ID = 7701;
    private static final String CHANNEL_ID = "maeummon_overlay";

    private WindowManager wm;
    private WindowManager.LayoutParams params;
    private LinearLayout root;
    private AnimatedYoungSeungjaeView mascot;
    private TextView speech;

    private Handler handler;
    private final Random random = new Random();

    private ValueAnimator moveAnimator;
    private boolean dragging = false;
    private boolean visibleOnHome = false;
    private long homeCandidateSince = 0L;
    private static final long HOME_STABLE_SHOW_MS = 700L;

    private String launcherPackage;
    private String lastForegroundPackage = "";
    private String lastForegroundClass = "";
    private long lastUsageEventCheckTime = 0L;
    private boolean foregroundSeeded = false;

    private int screenW;
    private int screenH;

    private long lastTapAt = 0L;
    private Runnable pendingSingleTap;
    private String lastComfortLine = "";
    private String recentComfortHistory = "";
    private boolean comfortLoading = false;
    private long speechHoldUntil = 0L;
    private long lastComfortTapAt = 0L;
    private static final long COMFORT_HOLD_MIN_MS = 18000L;
    private static final long COMFORT_HOLD_MAX_MS = 60000L;
    private static final long COMFORT_HOLD_PER_CHAR_MS = 260L;
    private static final long TAP_COOLDOWN_MS = 900L;
    private static final String KEY_DAILY_SMALL_EVENT_DATE = "daily_small_event_date_v180";

    private static final String[] DAILY_SMALL_EVENTS = {
            "오늘의 작은 이벤트! 어린 승재가 손 흔들러 왔어 👋",
            "짜잔! 오늘도 만나서 반가워. 좋은 일 하나 생기길 빌어줄게 ✨",
            "오늘의 보너스 포옹 도착! 너무 무리하지 말기 🤍",
            "구름 이벤트 ☁️ 오늘은 네 속도로 가는 날이야.",
            "달 조각 하나 선물할게 🌙 오늘 마음이 조금 가벼워졌으면 좋겠다.",
            "오늘의 미션은 아주 작게! 물 한 모금 마시면 성공이야 💧",
            "어린 승재가 오늘의 행운을 주웠어. 승재한테 줄게 🍀"
    };

    private long lastProactiveAt = 0L;
    private long nextProactiveDelay = 150000L;

    private final Runnable visibilityCheck = new Runnable() {
        @Override
        public void run() {
            boolean home;

            if (LauncherSurfaceAccessibilityService.isEnabled(OverlayService.this)) {
                // 접근성 서비스가 켜져 있으면 active-window 판정을 단일 source로 사용한다.
                // UsageStats와 섞으면 홈/최근앱 전환 순간 서로 다른 값을 내서 깜빡일 수 있다.
                String surfaceMode = getSharedPreferences(AppPrefs.PREFS, MODE_PRIVATE)
                        .getString(LauncherSurfaceAccessibilityService.PREF_MODE,
                                LauncherSurfaceAccessibilityService.MODE_UNKNOWN);
                home = LauncherSurfaceAccessibilityService.MODE_HOME.equals(surfaceMode);
            } else {
                // 접근성 서비스가 꺼져 있을 때만 기존 UsageStats fallback.
                updateForegroundPackage();
                home = launcherPackage != null
                        && !launcherPackage.isEmpty()
                        && launcherPackage.equals(lastForegroundPackage);

                String cls = lastForegroundClass == null ? "" : lastForegroundClass.toLowerCase();
                if (cls.contains("recents") || cls.contains("overview") || cls.contains("allapps")
                        || cls.contains("drawer") || cls.contains("appslist") || cls.contains("finder")
                        || cls.contains("folder") || cls.contains("folderview") || cls.contains("openfolder")) {
                    home = false;
                }
            }

            long now = System.currentTimeMillis();
            if (home) {
                if (homeCandidateSince == 0L) homeCandidateSince = now;
                // 홈 판정이 일정 시간 연속 유지된 뒤에만 표시한다.
                // Finder/앱서랍 전환 중 잠깐 HOME으로 오판되는 플래시를 막는다.
                home = (now - homeCandidateSince) >= HOME_STABLE_SHOW_MS;
            } else {
                homeCandidateSince = 0L;
            }

            if (root != null) {
                if (home && !visibleOnHome) {
                    visibleOnHome = true;
                    root.clearAnimation();
                    root.setVisibility(View.VISIBLE);
                    root.setAlpha(1f);
                    mascot.setOutfit(YoungSeungjaeHome.getOutfit(OverlayService.this));
                    if (isSleepTime()) {
                        mascot.setState(AnimatedYoungSeungjaeView.State.SLEEP);
                        if (System.currentTimeMillis() >= speechHoldUntil) {
                            updateSpeech(sleepGreeting());
                        }
                    } else {
                        mascot.setState(AnimatedYoungSeungjaeView.State.IDLE);
                        if (!maybeShowDailySmallEvent() && System.currentTimeMillis() >= speechHoldUntil) {
                            updateSpeech(timeGreeting());
                        }
                    }
                    startLoops();
                } else if (!home && visibleOnHome) {
                    // 최근 앱/앱 목록/다른 앱에서는 애니메이션 없이 즉시 제거한다.
                    // fade animation 때문에 잠깐 남아 보이는 현상 방지.
                    visibleOnHome = false;
                    stopLoops();
                    root.clearAnimation();
                    root.setVisibility(View.GONE);
                }
            }

            handler.postDelayed(this, 180L);
        }
    };

    private final Runnable behaviorLoop = new Runnable() {
        @Override
        public void run() {
            if (!visibleOnHome || dragging) return;
            if (System.currentTimeMillis() < speechHoldUntil) {
                handler.postDelayed(this, 1200L);
                return;
            }

            if (isSleepTime()) {
                cancelMovement();
                setState(AnimatedYoungSeungjaeView.State.SLEEP);
                updateSpeech(sleepGreeting());
                handler.postDelayed(this, 8000L);
                return;
            }

            mascot.setOutfit(YoungSeungjaeHome.getOutfit(OverlayService.this));

            PetStateManager.tick(OverlayService.this);
            PetStateManager.State petState = PetStateManager.get(OverlayService.this);
            int hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
            int r = random.nextInt(100);

            if (petState.energy < 28 && r < 62) {
                setState(AnimatedYoungSeungjaeView.State.SLEEP);
                handler.postDelayed(this, 3600L);
                return;
            }
            if (petState.calm < 35 && r < 48) {
                setState(AnimatedYoungSeungjaeView.State.SIT);
                handler.postDelayed(this, 2800L);
                return;
            }
            if (petState.lonely > 70 && r < 45) {
                setState(AnimatedYoungSeungjaeView.State.WAVE);
                handler.postDelayed(this, 2500L);
                return;
            }

            if (hour >= 23 || hour < 6) {
                if (r < 40) {
                    setState(AnimatedYoungSeungjaeView.State.SLEEP);
                    updateSpeech("승재야, 늦었어. 오늘은 자고 내일 다시 생각해도 돼.");
                    handler.postDelayed(this, 4300L);
                } else if (r < 70) {
                    setState(AnimatedYoungSeungjaeView.State.SIT);
                    updateSpeech("오늘 하루도 여기까지면 충분해.");
                    handler.postDelayed(this, 2600L);
                } else {
                    setState(AnimatedYoungSeungjaeView.State.IDLE);
                    handler.postDelayed(this, 1800L);
                }
                return;
            }

            if (r < 34) {
                setState(AnimatedYoungSeungjaeView.State.WALK);
                startWalk();
                handler.postDelayed(this, 3100L + random.nextInt(1800));
            } else if (r < 48) {
                setState(AnimatedYoungSeungjaeView.State.WAVE);
                updateSpeech(randomPrompt());
                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        if (visibleOnHome && !dragging) {
                            setState(AnimatedYoungSeungjaeView.State.IDLE);
                        }
                    }
                }, 1700L);
                handler.postDelayed(this, 3200L);
            } else if (r < 63) {
                setState(AnimatedYoungSeungjaeView.State.THINK);
                updateSpeech("오늘 제일 크게 남은 감정이 뭐였는지 같이 볼까?");
                handler.postDelayed(this, 2500L);
            } else if (r < 76) {
                setState(AnimatedYoungSeungjaeView.State.JUMP);
                updateSpeech("헤헤, 승재야! 나 여기 있어.");
                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        if (visibleOnHome && !dragging) {
                            setState(AnimatedYoungSeungjaeView.State.IDLE);
                        }
                    }
                }, 1100L);
                handler.postDelayed(this, 2500L);
            } else if (r < 88) {
                setState(AnimatedYoungSeungjaeView.State.SIT);
                updateSpeech("잠깐 멈춰도 괜찮아.");
                handler.postDelayed(this, 2400L);
            } else {
                setState(AnimatedYoungSeungjaeView.State.IDLE);
                handler.postDelayed(this, 1800L + random.nextInt(1200));
            }
        }
    };

    private final Runnable speechLoop = new Runnable() {
        @Override
        public void run() {
            long now = System.currentTimeMillis();
            if (visibleOnHome && !dragging && now >= speechHoldUntil && !comfortLoading && !isSleepTime()) {
                updateSpeech(randomPrompt());
            }
            handler.postDelayed(this, 26000L);
        }
    };

    private final Runnable proactiveLoop = new Runnable() {
        @Override
        public void run() {
            long now = System.currentTimeMillis();
            if (visibleOnHome && !dragging && !comfortLoading && now >= speechHoldUntil && !isSleepTime()) {
                org.json.JSONObject due = MemoryManager.nextDue(OverlayService.this);
                if (due != null) {
                    String subject = due.optString("text", "그 일");
                    if (subject.length() > 34) subject = subject.substring(0, 34) + "…";
                    setState(AnimatedYoungSeungjaeView.State.WAVE);
                    updateSpeech("승재야, 전에 말했던 ‘" + subject + "’는 지금 좀 어때?");
                    MemoryManager.markAsked(OverlayService.this, due.optLong("id"));
                    PetStateManager.markSeen(OverlayService.this);
                    speechHoldUntil = now + 12000L;
                    lastProactiveAt = now;
                    nextProactiveDelay = 150000L + random.nextInt(180001);
                } else if (RoutineMissionManager.shouldShowSpecialEvent(OverlayService.this)) {
                    setState(AnimatedYoungSeungjaeView.State.JUMP);
                    updateSpeech(RoutineMissionManager.specialEvent(OverlayService.this));
                    RoutineMissionManager.markSpecialEventSeen(OverlayService.this);
                    speechHoldUntil = now + 12000L;
                    lastProactiveAt = now;
                } else if (RoutineMissionManager.shouldShowRoutine(OverlayService.this)) {
                    setState(AnimatedYoungSeungjaeView.State.WAVE);
                    updateSpeech(RoutineMissionManager.routineLine(OverlayService.this));
                    RoutineMissionManager.markRoutineShown(OverlayService.this);
                    speechHoldUntil = now + 10000L;
                    lastProactiveAt = now;
                } else if (now - lastProactiveAt >= nextProactiveDelay) {
                    PetStateManager.tick(OverlayService.this);
                    setState(PetStateManager.recommendedAnimation(OverlayService.this));
                    updateSpeech(PetStateManager.proactiveLine(OverlayService.this));
                PetStateManager.markSeen(OverlayService.this);
                lastProactiveAt = now;
                // 2.5~5.5분 사이 랜덤. 계속 말 거는 느낌을 피함.
                nextProactiveDelay = 150000L + random.nextInt(180001);
                speechHoldUntil = now + 8000L;
                }
            }
            handler.postDelayed(this, 15000L);
        }
    };

    @Override
    public void onCreate() {
        super.onCreate();

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            stopSelf();
            return;
        }

        handler = new Handler(Looper.getMainLooper());
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        launcherPackage = resolveLauncherPackage();
        readScreenSize();

        createChannel();
        startForeground(NOTIFICATION_ID, buildNotification());
        createOverlay();

        updateForegroundPackage();
        handler.post(visibilityCheck);
        handler.postDelayed(proactiveLoop, 30000L);
    }

    private void startLoops() {
        stopLoopCallbacks();
        handler.postDelayed(behaviorLoop, 900L);
        handler.postDelayed(speechLoop, 13000L);
    }

    private void stopLoops() {
        cancelMovement();
        stopLoopCallbacks();
    }

    private void stopLoopCallbacks() {
        handler.removeCallbacks(behaviorLoop);
        handler.removeCallbacks(speechLoop);
    }

    private void setState(AnimatedYoungSeungjaeView.State state) {
        if (mascot != null) {
            mascot.setState(state);
        }
    }

    private String randomPrompt() {
        // v10.9.3: the floating young Seungjae follows the exact PT selected on the home screen.
        String currentPt = CentralMindPtState.mascotLine(this);
        if (!currentPt.isEmpty()) return currentPt;
        String shared = UnifiedTherapyProfile.mascotLine(this);
        String centralHint = CentralTherapyProfile.reportHint(this, "오늘");
        if (!centralHint.isEmpty() && random.nextInt(100) < 35) {
            String oneLine = centralHint.replace("\n", " ").replace("• ", "").trim();
            if (oneLine.length() > 46) oneLine = oneLine.substring(0, 46);
            if (!oneLine.isEmpty()) return oneLine;
        }
        if (!shared.isEmpty() && random.nextInt(100) < 55) return shared;
        int affection = CompanionProfile.getAffection(this);
        int level = CompanionProfile.level(affection);
        String[] lines;

        if (level >= 5) {
            lines = new String[]{
                    "승재야, 오늘도 내가 네 편이야.",
                    "오늘 힘든 일 있었으면 여기다 잠깐 내려놔.",
                    "하나씩만 해도 괜찮아. 지금도 충분히 잘하고 있어.",
                    "너무 많은 걸 한꺼번에 해결하려고 하진 않았지?",
                    "오늘 잘한 거 하나만 나한테 말해줘.",
                    "지금은 쉬는 게 제일 중요한 시간일 수도 있어."
            };
        } else if (level >= 3) {
            lines = new String[]{
                    "승재야, 오늘 마음은 어때?",
                    "오늘 제일 힘들었던 건 뭐야?",
                    "지금 제일 신경 쓰이는 건 뭐야?",
                    "기분이 복잡하면 이유를 하나씩 나눠보자.",
                    "조금 쉬어도 되는 날인지 같이 보자.",
                    "마음에 걸리는 말이 있으면 나한테 먼저 말해봐."
            };
        } else {
            lines = new String[]{
                    "승재야, 천천히 말해줘.",
                    "급하게 괜찮아질 필요는 없어.",
                    "지금 드는 마음을 한 단어로 말해볼까?",
                    "오늘은 어떤 하루였어?",
                    "네가 느끼는 걸 내가 같이 듣고 있을게."
            };
        }
        return lines[random.nextInt(lines.length)];
    }

    private String timeGreeting() {
        int hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
        if (hour < 6) return "승재야, 너무 늦었어. 오늘은 자고 내일 다시 생각해도 돼.";
        if (hour < 11) return "좋은 아침이야, 승재야. 오늘 컨디션은 어때?";
        if (hour < 17) return "승재야, 오늘 마음은 어때?";
        if (hour < 22) return "오늘도 애썼어. 지금 마음을 조금만 풀어놔도 돼.";
        return "승재야, 오늘 하루도 거의 끝났네. 고생했어.";
    }

    private void updateSpeech(String message) {
        if (speech == null) return;
        // v10.9.6: when a Mind PT is selected, every mascot bubble follows that same PT.
        // Generic time/routine lines must not make the mascot feel disconnected from the active training.
        String pt = CentralMindPtState.mascotLine(this);
        if (pt != null && !pt.trim().isEmpty()) {
            speech.setText(pt);
            return;
        }
        speech.setText(message);
    }

    private String resolveLauncherPackage() {
        Intent intent = new Intent(Intent.ACTION_MAIN);
        intent.addCategory(Intent.CATEGORY_HOME);
        android.content.pm.ResolveInfo info = getPackageManager().resolveActivity(intent, android.content.pm.PackageManager.MATCH_DEFAULT_ONLY);
        if (info != null && info.activityInfo != null) {
            return info.activityInfo.packageName;
        }
        return null;
    }

    private void updateForegroundPackage() {
        if (!UsageAccessHelper.hasPermission(this)) return;

        UsageStatsManager usm = (UsageStatsManager) getSystemService(Context.USAGE_STATS_SERVICE);
        if (usm == null) return;

        long now = System.currentTimeMillis();
        long start = foregroundSeeded ? Math.max(lastUsageEventCheckTime - 300L, now - 2000L) : now - 5000L;
        UsageEvents events = usm.queryEvents(start, now);
        UsageEvents.Event event = new UsageEvents.Event();

        String newestPackage = null;
        String newestClass = null;
        long newestTimestamp = 0L;

        while (events.hasNextEvent()) {
            events.getNextEvent(event);
            if (event.getEventType() == UsageEvents.Event.ACTIVITY_RESUMED
                    || event.getEventType() == UsageEvents.Event.MOVE_TO_FOREGROUND) {
                if (event.getTimeStamp() >= newestTimestamp) {
                    newestTimestamp = event.getTimeStamp();
                    newestPackage = event.getPackageName();
                    newestClass = event.getClassName();
                }
            }
        }

        if (newestPackage != null) {
            lastForegroundPackage = newestPackage;
            lastForegroundClass = newestClass == null ? "" : newestClass;
        }

        lastUsageEventCheckTime = now;
        foregroundSeeded = true;
    }

    private void readScreenSize() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            android.view.WindowMetrics metrics = wm.getCurrentWindowMetrics();
            screenW = metrics.getBounds().width();
            screenH = metrics.getBounds().height();
        } else {
            android.util.DisplayMetrics dm = new android.util.DisplayMetrics();
            wm.getDefaultDisplay().getMetrics(dm);
            screenW = dm.widthPixels;
            screenH = dm.heightPixels;
        }
    }

    private void createOverlay() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);

        speech = new TextView(this);
        speech.setText(timeGreeting());
        speech.setTextSize(12f);
        speech.setTextColor(0xFF4F5569);
        speech.setBackgroundResource(R.drawable.bg_bubble);
        speech.setGravity(Gravity.CENTER);
        speech.setPadding(dp(10), dp(7), dp(10), dp(7));
        root.addView(speech, new LinearLayout.LayoutParams(dp(196), LinearLayout.LayoutParams.WRAP_CONTENT));

        mascot = new AnimatedYoungSeungjaeView(this);
        mascot.setOutfit(YoungSeungjaeHome.getOutfit(this));
        LinearLayout.LayoutParams mascotParams = new LinearLayout.LayoutParams(dp(150), dp(168));
        mascotParams.topMargin = dp(4);
        root.addView(mascot, mascotParams);

        int type = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;

        params = new WindowManager.LayoutParams(
                dp(212),
                WindowManager.LayoutParams.WRAP_CONTENT,
                type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT
        );

        params.gravity = Gravity.TOP | Gravity.START;
        params.x = dp(24);
        params.y = dp(190);
        root.setVisibility(View.GONE);

        root.setOnTouchListener(new View.OnTouchListener() {
            int startX, startY;
            float downX, downY;
            long downAt;
            boolean moved;
            boolean longPressTriggered;
            Runnable longPressRunnable;

            @Override
            public boolean onTouch(View v, MotionEvent e) {
                switch (e.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        dragging = true;
                        cancelMovement();
                        stopLoopCallbacks();

                        startX = params.x;
                        startY = params.y;
                        downX = e.getRawX();
                        downY = e.getRawY();
                        downAt = System.currentTimeMillis();
                        moved = false;
                        longPressTriggered = false;

                        longPressRunnable = new Runnable() {
                            @Override
                            public void run() {
                                if (!moved && dragging) {
                                    longPressTriggered = true;
                                    setState(AnimatedYoungSeungjaeView.State.THINK);
                                    updateSpeech("왜애~? 승재야, 무슨 생각하고 있어?");
                                }
                            }
                        };
                        handler.postDelayed(longPressRunnable, 650L);
                        return true;

                    case MotionEvent.ACTION_MOVE:
                        float dx = e.getRawX() - downX;
                        float dy = e.getRawY() - downY;
                        if (Math.abs(dx) > dp(6) || Math.abs(dy) > dp(6)) {
                            moved = true;
                            handler.removeCallbacks(longPressRunnable);
                        }

                        params.x = clamp(startX + (int) dx, 0, Math.max(0, screenW - dp(212)));
                        params.y = clamp(startY + (int) dy, dp(60), Math.max(dp(60), screenH - dp(280)));
                        try {
                            wm.updateViewLayout(root, params);
                        } catch (Exception ignored) {}
                        return true;

                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        handler.removeCallbacks(longPressRunnable);
                        dragging = false;

                        if (longPressTriggered) {
                            handler.postDelayed(new Runnable() {
                                @Override
                                public void run() {
                                    if (visibleOnHome) startLoops();
                                }
                            }, 1500L);
                            return true;
                        }

                        if (!moved && System.currentTimeMillis() - downAt < 420L) {
                            handleTap();
                        } else if (visibleOnHome) {
                            startLoops();
                        }
                        return true;
                }
                return false;
            }
        });

        wm.addView(root, params);
    }

    private void handleTap() {
        long now = System.currentTimeMillis();

        // 연타로 말풍선이 너무 빠르게 바뀌는 것을 막는다.
        if (now - lastComfortTapAt < TAP_COOLDOWN_MS) return;
        lastComfortTapAt = now;

        // 터치 즉시 랜덤 포즈/랜덤 멘트는 사용하지 않고, 이전처럼 상황형 위로로 바로 연결한다.
        stopLoopCallbacks();
        cancelMovement();
        speechHoldUntil = now + comfortHoldMs("생각해볼게…");

        if (comfortLoading) return;

        PetStateManager.markSeen(this);
        setState(AnimatedYoungSeungjaeView.State.THINK);
        updateSpeech("생각해볼게…");
        requestContextualComfort();
    }

    private boolean isSleepTime() {
        Calendar c = Calendar.getInstance();
        int h = c.get(Calendar.HOUR_OF_DAY);
        int m = c.get(Calendar.MINUTE);
        return h >= 23 || h < 6 || (h == 22 && m >= 45);
    }

    private String sleepGreeting() {
        String[] lines = {
                "쿨쿨… 승재야, 오늘은 여기까지 해도 돼 🌙",
                "어린 승재는 먼저 잘게. 승재도 푹 쉬자 💤",
                "밤에는 해결보다 잠이 먼저야. 내일 다시 보자.",
                "이불 속으로 쏙… 오늘도 수고했어 🌙"
        };
        return lines[random.nextInt(lines.length)];
    }

    private boolean maybeShowDailySmallEvent() {
        String today = EmotionDiaryStorage.today();
        android.content.SharedPreferences p = getSharedPreferences(AppPrefs.PREFS, MODE_PRIVATE);
        if (today.equals(p.getString(KEY_DAILY_SMALL_EVENT_DATE, ""))) return false;
        p.edit().putString(KEY_DAILY_SMALL_EVENT_DATE, today).apply();

        final String event = DAILY_SMALL_EVENTS[random.nextInt(DAILY_SMALL_EVENTS.length)];
        setState(random.nextBoolean() ? AnimatedYoungSeungjaeView.State.WAVE : AnimatedYoungSeungjaeView.State.JUMP);
        updateSpeech(event);
        speechHoldUntil = System.currentTimeMillis() + 6500L;
        handler.postDelayed(new Runnable() {
            @Override public void run() {
                if (visibleOnHome && !dragging && !isSleepTime()) {
                    setState(AnimatedYoungSeungjaeView.State.IDLE);
                }
            }
        }, 1800L);
        return true;
    }

    private long comfortHoldMs(String message) {
        int len = message == null ? 0 : message.replace("\n", "").trim().length();
        long byLength = 6000L + (len * COMFORT_HOLD_PER_CHAR_MS);
        return Math.max(COMFORT_HOLD_MIN_MS, Math.min(COMFORT_HOLD_MAX_MS, byLength));
    }

    private void rememberComfortLine(String line) {
        if (line == null || line.trim().isEmpty()) return;
        String clean = line.trim().replace("\n", " ");
        if (recentComfortHistory.isEmpty()) {
            recentComfortHistory = clean;
        } else {
            recentComfortHistory = clean + " || " + recentComfortHistory;
        }
        // 최근 6개 정도만 보관해서 API에 반복 금지 힌트로 넘긴다.
        String[] parts = recentComfortHistory.split(" \\|\\| ");
        if (parts.length > 6) {
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < 6; i++) {
                if (i > 0) sb.append(" || ");
                sb.append(parts[i]);
            }
            recentComfortHistory = sb.toString();
        }
    }

    private boolean isTaskPlanningLine(String line) {
        if (line == null) return false;
        String s = line.replace(" ", "");
        return (s.contains("할일") || s.contains("해야할일") || s.contains("내일할"))
                && (s.contains("세가지") || s.contains("3개") || s.contains("세개")
                || s.contains("골라") || s.contains("적어") || s.contains("정해"));
    }

    private boolean taskSuggestionAlreadyShownToday() {
        android.content.SharedPreferences prefs = getSharedPreferences(AppPrefs.PREFS, MODE_PRIVATE);
        String today = EmotionDiaryStorage.today();
        return today.equals(prefs.getString("comfort_task_suggestion_date", ""));
    }

    private void markTaskSuggestionShownToday() {
        getSharedPreferences(AppPrefs.PREFS, MODE_PRIVATE)
                .edit()
                .putString("comfort_task_suggestion_date", EmotionDiaryStorage.today())
                .apply();
    }

    private void requestContextualComfort() {
        if (comfortLoading) return;
        comfortLoading = true;

        final String apiKey = getSharedPreferences(AppPrefs.PREFS, MODE_PRIVATE)
                .getString(AppPrefs.KEY_API_KEY, "").trim();

        // API를 기다리는 동안에는 사용자가 눌렀다는 피드백을 바로 보여준다.
        // 최종 응답이 오기 전 자동 대사 타이머는 이미 멈춘 상태다.
        if (!apiKey.isEmpty()) {
            updateSpeech("생각해볼게…");
            setState(AnimatedYoungSeungjaeView.State.THINK);
        }

        new Thread(new Runnable() {
            @Override public void run() {
                String line;
                try {
                    String weather = ContextWeather.getWeather(OverlayService.this);
                    String context = buildContextText(weather);

                    if (!apiKey.isEmpty()) {
                        line = OpenAiClient.getContextualComfort(
                                apiKey,
                                context,
                                recentComfortHistory.isEmpty() ? lastComfortLine : recentComfortHistory,
                                System.nanoTime()
                        );
                    } else {
                        line = localContextLineWithWeather(weather);
                    }
                } catch (Exception e) {
                    line = localContextLine();
                }

                if (line == null || line.trim().isEmpty()) {
                    line = localContextLine();
                }

                String filtered = line.trim();

                // '할 일 세 개 적어보자' 류의 계획 제안은 하루에 한 번만 허용한다.
                // 같은 날 또 생성되면 다른 상황형 위로 문장으로 교체한다.
                if (isTaskPlanningLine(filtered)) {
                    if (taskSuggestionAlreadyShownToday()) {
                        filtered = localContextLineWithoutTask();
                    } else {
                        markTaskSuggestionShownToday();
                    }
                }

                final String result = filtered;

                handler.post(new Runnable() {
                    @Override public void run() {
                        lastComfortLine = result;
                        rememberComfortLine(result);
                        updateSpeech(result);
                        if (getSharedPreferences(AppPrefs.PREFS, MODE_PRIVATE)
                                .getBoolean(AppPrefs.KEY_OVERLAY_VOICE, false)) {
                            TtsManager.speak(OverlayService.this, result);
                        }
                        comfortLoading = false;

                        // 문장 길이에 맞춰 유지 시간을 잡는다.
                        // 짧은 고정 타이머 때문에 사용자가 읽거나 TTS가 말하는 도중
                        // 다음 자동 대사로 바뀌는 현상을 막는다.
                        final long holdMs = comfortHoldMs(result);
                        speechHoldUntil = System.currentTimeMillis() + holdMs;

                        setState(AnimatedYoungSeungjaeView.State.IDLE);

                        // 최종 문장을 충분히 보여준 뒤에만 자동 행동/자동 대사를 다시 시작한다.
                        handler.postDelayed(new Runnable() {
                            @Override public void run() {
                                if (visibleOnHome && !dragging && !comfortLoading
                                        && System.currentTimeMillis() >= speechHoldUntil) {
                                    startLoops();
                                }
                            }
                        }, holdMs + 250L);
                    }
                });
            }
        }).start();
    }

    private String buildContextText(String weather) {
        Calendar c = Calendar.getInstance();
        int hour = c.get(Calendar.HOUR_OF_DAY);
        String part = hour < 6 ? "새벽" : hour < 11 ? "아침" : hour < 14 ? "점심" : hour < 18 ? "오후" : hour < 22 ? "저녁" : "밤";
        android.content.SharedPreferences prefs = getSharedPreferences(AppPrefs.PREFS, MODE_PRIVATE);
        int score = prefs.getInt(AppPrefs.KEY_LAST_CHECKIN_SCORE, 0);
        String check = CompanionProfile.checkedInToday(this) ? (score + "점") : "미체크";
        org.json.JSONObject diary = EmotionDiaryStorage.getEntryByDate(this, EmotionDiaryStorage.today());
        String emotion = diary == null ? "일기 없음" : diary.optString("label", "잔잔");
        String liveMind = LiveMindManager.recentContext(this);
        String therapy = TherapyMemoryManager.buildContext(this);
        if (liveMind.length() > 2600) liveMind = liveMind.substring(0, 2600);
        if (therapy.length() > 6200) therapy = therapy.substring(0, 6200);

        return "시간대=" + part
                + ", 현재시각=" + hour + "시"
                + ", 날씨=" + weather
                + ", 오늘 마음체크=" + check
                + ", 오늘 감정=" + emotion
                + ", 친밀도=" + CompanionProfile.level(CompanionProfile.getAffection(this))
                + "\n\n[최근 상담·일기]\n" + liveMind
                + "\n\n[승재 장기 상담 맥락과 변화기록]\n" + therapy
                + "\n\n" + UnifiedTherapyProfile.buildSharedContext(this)
                + "\n\n" + TherapySurfaceContext.forSurface(
                        this, TherapySurfaceContext.TAMAGOTCHI);
    }

    private String localContextLine() {
        return localContextLineWithWeather("날씨 확인 안 됨");
    }

    private String localContextLineWithWeather(String weather) {
        int hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
        String shared = UnifiedTherapyProfile.mascotLine(this);
        if (!shared.isEmpty() && hour >= 6 && hour < 23 && !weather.contains("비") && !weather.contains("눈") && random.nextInt(100) < 60) {
            return shared;
        }
        String[] lines;
        if (weather.contains("비")) {
            lines = new String[]{"승재야, 비 오는 날은 마음도 처질 수 있어. 오늘은 속도를 조금 낮추자.", "밖이 축축하네. 우산 챙기고, 마음까지 급하게 몰아붙이진 말자."};
        } else if (weather.contains("눈")) {
            lines = new String[]{"승재야, 눈 오는 날은 발걸음부터 천천히. 오늘 마음도 그렇게 가자.", "밖이 미끄러울 수 있어. 오늘은 서두르지 않는 게 제일 잘하는 거야."};
        } else if (weather.contains("맑음")) {
            lines = new String[]{"오늘 하늘은 맑네. 승재야, 잠깐이라도 바깥 공기 한 번 쐬어볼래?", "날이 맑아도 마음까지 꼭 밝아야 하는 건 아니야. 네 속도대로 가자."};
        } else if (hour < 6) {
            lines = new String[]{"승재야, 지금은 해결보다 잠이 먼저야. 오늘 생각은 내일의 너한테 맡기자.", "새벽엔 걱정이 더 커 보여. 지금 결론 내리지 말고 쉬자."};
        } else if (hour < 11) {
            lines = new String[]{"좋은 아침이야, 승재야. 오늘은 딱 하나만 잘 해도 충분해.", "아침부터 완벽할 필요 없어. 천천히 시동 걸자."};
        } else if (hour < 18) {
            lines = new String[]{"승재야, 지금까지 한 것만 해도 있어. 남은 건 하나씩만 보자.", "오후엔 집중력이 좀 떨어질 수 있어. 물 한 잔 마시고 제일 작은 일부터 하자."};
        } else if (hour < 22) {
            lines = new String[]{"오늘도 꽤 오래 버텼네. 승재야, 이제 마음을 조금 내려놔도 돼.", "저녁엔 평가보다 정리가 먼저야. 오늘 괜찮았던 것 하나만 기억하자."};
        } else {
            lines = new String[]{"승재야, 오늘은 여기까지면 됐어. 못한 건 내일 다시 보면 돼.", "밤엔 걱정을 해결하려 하지 말자. 몸부터 쉬게 해주자."};
        }
        String pick = lines[random.nextInt(lines.length)];
        if (lines.length > 1 && pick.equals(lastComfortLine)) {
            for (String candidate : lines) {
                if (!candidate.equals(lastComfortLine)) {
                    pick = candidate;
                    break;
                }
            }
        }
        return pick;
    }

    private String localContextLineWithoutTask() {
        int hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
        String[] lines;
        if (hour < 6) {
            lines = new String[]{
                    "승재야, 새벽엔 생각이 더 커 보여. 지금은 결론보다 잠이 먼저야.",
                    "오늘 마음은 여기 잠깐 내려놓고 자자. 내일의 네가 다시 보면 돼."
            };
        } else if (hour < 11) {
            lines = new String[]{
                    "승재야, 아침부터 잘하려고 애쓰지 않아도 돼. 천천히 몸부터 깨우자.",
                    "좋은 아침이야. 지금 컨디션부터 살펴보고 네 속도로 시작하자."
            };
        } else if (hour < 18) {
            lines = new String[]{
                    "승재야, 지금 마음이 복잡하면 잠깐 어깨 힘부터 빼자.",
                    "여기까지 온 것만 해도 충분해. 잠깐 쉬었다 다시 봐도 괜찮아."
            };
        } else if (hour < 22) {
            lines = new String[]{
                    "승재야, 오늘 있었던 일 중 마음에 남는 게 있으면 나한테 말해줘.",
                    "저녁엔 오늘을 평가하기보다 네 마음을 좀 편하게 해주자."
            };
        } else {
            lines = new String[]{
                    "승재야, 오늘은 여기까지 해도 돼. 네 몸이 쉬어야 마음도 따라와.",
                    "밤에는 못한 것보다 버틴 걸 봐주자. 오늘도 고생했어."
            };
        }
        String pick = lines[random.nextInt(lines.length)];
        if (pick.equals(lastComfortLine) && lines.length > 1) {
            pick = lines[0].equals(pick) ? lines[1] : lines[0];
        }
        return pick;
    }

    private void startWalk() {
        cancelMovement();

        int maxX = Math.max(0, screenW - dp(212));
        int minY = dp(96);
        int maxY = Math.max(minY, screenH - dp(290));

        int dxRange = Math.max(dp(80), screenW / 3);
        int dyRange = Math.max(dp(40), screenH / 9);

        int targetX = clamp(params.x + random.nextInt(dxRange * 2 + 1) - dxRange, 0, maxX);
        int targetY = clamp(params.y + random.nextInt(dyRange * 2 + 1) - dyRange, minY, maxY);

        final int startX = params.x;
        final int startY = params.y;
        final int endX = targetX;
        final int endY = targetY;

        mascot.setFacingRight(endX >= startX);
        mascot.setState(AnimatedYoungSeungjaeView.State.WALK);

        int distance = Math.abs(endX - startX) + Math.abs(endY - startY);
        long duration = Math.max(1500L, Math.min(4200L, 900L + distance * 4L));

        moveAnimator = ValueAnimator.ofFloat(0f, 1f);
        moveAnimator.setInterpolator(new LinearInterpolator());
        moveAnimator.setDuration(duration);
        moveAnimator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator animation) {
                if (dragging || !visibleOnHome) return;
                float f = (float) animation.getAnimatedValue();
                params.x = startX + Math.round((endX - startX) * f);
                params.y = startY + Math.round((endY - startY) * f);
                try {
                    wm.updateViewLayout(root, params);
                } catch (Exception ignored) {}
            }
        });
        moveAnimator.addListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(Animator animation) {
                if (visibleOnHome && !dragging) {
                    setState(AnimatedYoungSeungjaeView.State.IDLE);
                }
            }
        });
        moveAnimator.start();
    }

    private void cancelMovement() {
        if (moveAnimator != null) {
            moveAnimator.cancel();
            moveAnimator = null;
        }
    }

    private int clamp(int value, int min, int max) {
        return Math.max(min, Math.min(max, value));
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private Notification buildNotification() {
        Intent openIntent = new Intent(this, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(this, 0, openIntent,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);

        Notification.Builder builder = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? new Notification.Builder(this, CHANNEL_ID)
                : new Notification.Builder(this);

        builder.setContentTitle("마음몬")
                .setContentText("어린 승재가 바탕화면에서 기다리고 있어.")
                .setSmallIcon(R.drawable.ic_stat_maeummon)
                .setContentIntent(pi)
                .setOnlyAlertOnce(true)
                .setOngoing(true);

        return builder.build();
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel c = new NotificationChannel(
                    CHANNEL_ID,
                    "마음몬 바탕화면 친구",
                    NotificationManager.IMPORTANCE_LOW
            );
            c.setDescription("홈 화면에서 움직이는 어린 승재 도우미");
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null) nm.createNotificationChannel(c);
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        cancelMovement();
        if (handler != null) handler.removeCallbacksAndMessages(null);
        if (wm != null && root != null) {
            try {
                wm.removeView(root);
            } catch (Exception ignored) {}
        }
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
