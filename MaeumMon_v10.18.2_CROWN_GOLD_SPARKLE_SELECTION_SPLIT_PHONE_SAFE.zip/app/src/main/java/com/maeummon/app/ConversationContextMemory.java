package com.maeummon.app;

import android.content.Context;
import android.content.SharedPreferences;

/** v3.5 GPT Context Layer의 최신 사실 지도를 상담기억과 분리해 로컬 보관한다. */
public final class ConversationContextMemory {
    private static final String PREFS = "maeummon_gpt_context_layer";
    private static final String KEY_LATEST = "latest_context_json";

    private ConversationContextMemory() {}

    public static String get(Context context) {
        SharedPreferences p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        return p.getString(KEY_LATEST, "");
    }

    public static void save(Context context, String json) {
        if (json == null || json.trim().isEmpty()) return;
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .edit().putString(KEY_LATEST, json).apply();
    }

    public static void clear(Context context) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .edit().remove(KEY_LATEST).apply();
    }
}
