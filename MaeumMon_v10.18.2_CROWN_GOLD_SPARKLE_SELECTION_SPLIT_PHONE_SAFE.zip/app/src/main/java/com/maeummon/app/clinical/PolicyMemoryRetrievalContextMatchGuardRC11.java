package com.maeummon.app.clinical;

import android.content.Context;
import org.json.*;

public final class PolicyMemoryRetrievalContextMatchGuardRC11 {
    private PolicyMemoryRetrievalContextMatchGuardRC11(){}

    public static final class Result {
        public boolean policyFound=false;
        public boolean applicable=false;
        public boolean mechanismMatch=false;
        public boolean contextMatch=false;
        public boolean confidenceSufficient=false;
        public boolean blockedByCurrentEvidence=false;
        public String policyKey="";
        public String policyInterventionId="";
        public String policyMode="";
        public String policyDose="";
        public String policyConfidence="NONE";
        public String currentContext="";
        public String reason="";
        public String summary="";
    }

    public static Result retrieve(Context c,ClinicalDecisionRC7 d){
        Result r=new Result();
        if(c==null||d==null){
            r.summary="NO_POLICY | NO_CONTEXT_OR_DECISION";
            return r;
        }

        JSONObject f=CentralTherapyProfile.loadFormulation(c);
        String mechanism=safe(d.centralMechanism);
        String context=f.optString("current_context_scope","UNKNOWN");
        r.currentContext=context;

        if(mechanism.isEmpty()){
            r.summary="NO_POLICY | NO_MECHANISM";
            return r;
        }

        JSONObject policy=
                InterventionLearningPolicyMemoryRC11.findApplicablePolicy(
                        c,mechanism,context);

        if(policy==null){
            r.summary="NO_POLICY | NO_APPLICABLE_POLICY";
            return r;
        }

        r.policyFound=true;
        r.policyKey=policy.optString("key","");
        r.policyInterventionId=policy.optString("intervention_id","");
        r.policyMode=policy.optString("preferred_mode","");
        r.policyDose=policy.optString("preferred_dose","");
        r.policyConfidence=policy.optString("confidence","LOW");

        r.mechanismMatch=mechanism.equals(
                policy.optString("mechanism",""));

        String policyContext=policy.optString("context_scope","UNKNOWN");
        r.contextMatch=
                "GENERAL".equals(policyContext)
                || context.equals(policyContext);

        r.confidenceSufficient=
                "MEDIUM".equals(r.policyConfidence)
                ||"HIGH".equals(r.policyConfidence);

        // Current evidence always wins.
        boolean reopened=f.optBoolean("formulation_reopened",false);
        int unresolved=f.optInt("unresolved_evidence_conflicts",0);
        boolean centralUsable=f.optBoolean("central_insight_usable",false);

        if(reopened || unresolved>0 || !centralUsable){
            r.blockedByCurrentEvidence=true;
        }

        // Safety/alliance always block policy use.
        if(d.safetyOverride || d.allianceRupture){
            r.blockedByCurrentEvidence=true;
        }

        r.applicable=
                r.policyFound
                &&r.mechanismMatch
                &&r.contextMatch
                &&r.confidenceSufficient
                &&!r.blockedByCurrentEvidence;

        if(!r.mechanismMatch)
            r.reason="MECHANISM_MISMATCH";
        else if(!r.contextMatch)
            r.reason="CONTEXT_MISMATCH";
        else if(!r.confidenceSufficient)
            r.reason="LOW_POLICY_CONFIDENCE";
        else if(r.blockedByCurrentEvidence)
            r.reason="CURRENT_EVIDENCE_BLOCK";
        else
            r.reason="APPLICABLE_WEAK_PRIOR";

        r.summary=(r.applicable?"APPLICABLE":"BLOCKED")
                +" | confidence="+r.policyConfidence
                +" | mechanismMatch="+r.mechanismMatch
                +" | contextMatch="+r.contextMatch
                +" | reason="+r.reason;

        persist(c,r);
        return r;
    }

    public static String instruction(Result r){
        if(r==null||!r.applicable)return "";

        StringBuilder b=new StringBuilder();
        b.append("INTERVENTION_POLICY_PRIOR_AVAILABLE=true. ");
        b.append("같은 mechanism/context에서 과거에 반복적으로 긍정 결과가 있었던 intervention을 약한 prior로 참고한다. ");

        if(r.policyInterventionId!=null&&!r.policyInterventionId.isEmpty())
            b.append("policy_intervention=").append(r.policyInterventionId).append(". ");

        if(r.policyMode!=null&&!r.policyMode.isEmpty())
            b.append("preferred_mode=").append(r.policyMode).append(". ");

        if(r.policyDose!=null&&!r.policyDose.isEmpty())
            b.append("preferred_dose=").append(r.policyDose).append(". ");

        b.append("단, 현재 formulation/bridge/safety/alliance 판단을 절대 덮어쓰지 않는다.");
        return b.toString();
    }

    public static boolean mayBiasSelection(
            Result r,ClinicalDecisionRC7 d){

        if(r==null||d==null||!r.applicable)return false;

        // Only bias if current bridge selected intervention is compatible
        // or empty; never replace an incompatible current bridge choice.
        String current=safe(d.selectedInterventionId);
        if(current.isEmpty())return true;

        return current.equals(r.policyInterventionId);
    }

    public static boolean mayBiasMode(Result r){
        return r!=null
                &&r.applicable
                &&r.policyMode!=null
                &&!r.policyMode.isEmpty();
    }

    public static boolean mayBiasDose(Result r){
        return r!=null
                &&r.applicable
                &&r.policyDose!=null
                &&!r.policyDose.isEmpty();
    }

    private static void persist(Context c,Result r){
        try{
            JSONObject f=CentralTherapyProfile.loadFormulation(c);
            f.put("policy_retrieval_found",r.policyFound);
            f.put("policy_retrieval_applicable",r.applicable);
            f.put("policy_retrieval_key",r.policyKey);
            f.put("policy_retrieval_confidence",r.policyConfidence);
            f.put("policy_retrieval_reason",r.reason);
            f.put("policy_retrieval_updated_at",System.currentTimeMillis());
            CentralTherapyProfile.replaceFormulation(c,f);
        }catch(Exception ignored){}
    }

    private static String safe(String s){
        return s==null?"":s;
    }
}
