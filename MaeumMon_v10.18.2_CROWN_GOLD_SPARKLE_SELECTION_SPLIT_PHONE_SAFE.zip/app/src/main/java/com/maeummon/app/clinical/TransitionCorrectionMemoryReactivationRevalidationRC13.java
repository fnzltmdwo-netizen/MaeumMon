package com.maeummon.app.clinical;

import android.content.Context;
import org.json.*;

public final class TransitionCorrectionMemoryReactivationRevalidationRC13 {
    private TransitionCorrectionMemoryReactivationRevalidationRC13(){}

    public enum State {
        NONE,
        REVALIDATION_PENDING,
        REACTIVATED_LOW,
        REACTIVATED_MEDIUM,
        BLOCKED
    }

    public static final class Result {
        public boolean evaluated=false;
        public boolean pending=false;
        public boolean reactivated=false;
        public State state=State.NONE;
        public String transitionKey="";
        public String contextScope="";
        public String correctedCause="";
        public String correctedReason="";
        public int confirmations=0;
        public int contradictions=0;
        public String reason="";
        public String summary="";
    }

    public static Result evaluate(
            Context c,
            ClinicalDecisionRC7 d){

        Result r=new Result();

        if(c==null||d==null){
            r.summary="NONE | MISSING_INPUT";
            return r;
        }

        r.evaluated=true;

        JSONObject p=CentralTherapyProfile.loadProfile(c);
        JSONObject f=CentralTherapyProfile.loadFormulation(c);

        r.contextScope=
                f.optString("current_context_scope","UNKNOWN");

        r.transitionKey=
                safe(d.decisionTransitionFromState)
                +"->"
                +safe(d.decisionTransitionToState)
                +"::"
                +r.contextScope;

        // Only fresh user-applied correction can revalidate stale memory.
        if(!d.transitionExplanationCorrectionApplied){
            r.reason="NO_FRESH_USER_CORRECTION";
            return finish(r);
        }

        r.correctedCause=
                safe(d.transitionExplanationCorrectedCause);

        r.correctedReason=
                safe(d.transitionExplanationCorrectedReason);

        JSONArray history=
                p.optJSONArray(
                        "transition_correction_revalidation_history");

        if(history==null)
            history=new JSONArray();

        int confirmations=0;
        int contradictions=0;

        for(int i=history.length()-1;i>=0;i--){
            JSONObject x=history.optJSONObject(i);
            if(x==null)continue;

            if(!r.transitionKey.equals(
                    x.optString("transition_key","")))
                continue;

            String cause=
                    x.optString("corrected_cause","");

            if(cause.equals(r.correctedCause))
                confirmations++;
            else if(!cause.isEmpty())
                contradictions++;
        }

        // Include current correction itself.
        confirmations++;

        r.confirmations=confirmations;
        r.contradictions=contradictions;

        try{
            JSONObject item=new JSONObject();
            item.put("transition_key",r.transitionKey);
            item.put("context_scope",r.contextScope);
            item.put("corrected_cause",r.correctedCause);
            item.put("corrected_reason",r.correctedReason);
            item.put("time",System.currentTimeMillis());
            history.put(item);

            JSONArray trimmed=new JSONArray();
            int start=Math.max(0,history.length()-30);
            for(int i=start;i<history.length();i++)
                trimmed.put(history.opt(i));

            p.put("transition_correction_revalidation_history",
                    trimmed);

            if(contradictions>0){
                r.state=State.BLOCKED;
                r.reason="CONTRADICTORY_CORRECTION_HISTORY";
                p.put("transition_correction_revalidation_state",
                        r.state.name());
                p.put("transition_correction_revalidation_key",
                        r.transitionKey);
                CentralTherapyProfile.replaceProfile(c,p);
                return finish(r);
            }

            if(confirmations>=3){
                r.state=State.REACTIVATED_MEDIUM;
                r.reactivated=true;
                r.reason="THREE_CLEAN_CONFIRMATIONS";
            }else if(confirmations>=2){
                r.state=State.REACTIVATED_LOW;
                r.reactivated=true;
                r.reason="TWO_CLEAN_CONFIRMATIONS";
            }else{
                r.state=State.REVALIDATION_PENDING;
                r.pending=true;
                r.reason="ONE_CONFIRMATION_NOT_ENOUGH";
            }

            p.put("transition_correction_revalidation_state",
                    r.state.name());
            p.put("transition_correction_revalidation_key",
                    r.transitionKey);
            p.put("transition_correction_revalidation_confirmations",
                    r.confirmations);
            p.put("transition_correction_revalidation_contradictions",
                    r.contradictions);
            p.put("transition_correction_revalidation_cause",
                    r.correctedCause);
            p.put("transition_correction_revalidation_reason_text",
                    r.correctedReason);
            p.put("transition_correction_revalidation_at",
                    System.currentTimeMillis());

            CentralTherapyProfile.replaceProfile(c,p);

            return finish(r);
        }catch(Exception e){
            r.state=State.BLOCKED;
            r.reactivated=false;
            r.pending=false;
            r.reason="REVALIDATION_PERSIST_FAILED";
            return finish(r);
        }
    }

    public static boolean reusableAsWeakPrior(Result r){
        return r!=null
                &&r.reactivated
                &&(r.state==State.REACTIVATED_LOW
                    ||r.state==State.REACTIVATED_MEDIUM);
    }

    public static String instruction(Result r){
        if(r==null||!r.evaluated)return "";

        if(r.state==State.REVALIDATION_PENDING)
            return "CORRECTION_MEMORY_REVALIDATION=PENDING. 같은 전환에서 교정이 한 번만 다시 확인됐으므로 자동 기억으로 재활성화하지 않는다.";

        if(r.state==State.REACTIVATED_LOW)
            return "CORRECTION_MEMORY_REVALIDATION=LOW. 같은 전환/맥락에서 같은 교정이 두 번 확인되어 약한 설명 prior로만 재사용 가능하다.";

        if(r.state==State.REACTIVATED_MEDIUM)
            return "CORRECTION_MEMORY_REVALIDATION=MEDIUM. 같은 전환/맥락에서 같은 교정이 세 번 이상 모순 없이 확인되어 중간 수준의 설명 prior로 재사용 가능하다.";

        if(r.state==State.BLOCKED)
            return "CORRECTION_MEMORY_REVALIDATION=BLOCKED. 같은 전환에서 서로 다른 교정이 있어 자동 재활성화하지 않는다.";

        return "";
    }

    private static Result finish(Result r){
        r.summary=r.state.name()
                +" | key="+r.transitionKey
                +" | confirmations="+r.confirmations
                +" | contradictions="+r.contradictions
                +" | cause="+r.correctedCause
                +" | reason="+r.reason;
        return r;
    }

    private static String safe(String s){
        return s==null?"":s;
    }
}
