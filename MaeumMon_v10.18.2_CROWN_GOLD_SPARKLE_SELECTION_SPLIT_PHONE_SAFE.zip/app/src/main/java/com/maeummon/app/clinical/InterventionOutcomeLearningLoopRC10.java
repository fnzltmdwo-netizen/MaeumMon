package com.maeummon.app.clinical;

import android.content.Context;
import org.json.*;
import java.util.*;

public final class InterventionOutcomeLearningLoopRC10 {
    private InterventionOutcomeLearningLoopRC10(){}

    public enum Outcome {
        UNKNOWN, NOT_TRIED, HELPED, PARTIAL, NO_CHANGE, WORSE
    }

    public static final class Result {
        public Outcome outcome=Outcome.UNKNOWN;
        public boolean reviewRequired=false;
        public boolean reopenSuggested=false;
        public boolean keepIntervention=false;
        public boolean allowDoseIncrease=false;
        public boolean reduceDose=false;
        public String learned="";
        public String nextMoveHint="";
        public String action="";
        public String summary="";
    }

    public static Result capture(
            Context c,String userText,ClinicalDecisionRC7 d){

        Result r=new Result();
        String u=userText==null?"":userText.trim();
        JSONObject p=CentralTherapyProfile.loadProfile(c);
        JSONObject f=CentralTherapyProfile.loadFormulation(c);
        JSONObject s=CentralTherapyProfile.loadSessionState(c);

        String lastIntervention=s.optString("last_intervention_id",
                p.optString("last_intervention_id",""));
        String lastDose=s.optString("last_intervention_dose",
                p.optString("last_intervention_dose",""));

        r.outcome=detectOutcome(u);

        if(r.outcome==Outcome.UNKNOWN){
            r.summary="UNKNOWN";
            return r;
        }

        r.reviewRequired=true;

        switch(r.outcome){
            case NOT_TRIED:
                r.keepIntervention=true;
                r.allowDoseIncrease=false;
                r.reduceDose=false;
                r.learned="개입 효과를 판단할 evidence가 아직 없다.";
                r.nextMoveHint="REVIEW_OR_BARRIER_CHECK";
                break;

            case HELPED:
                r.keepIntervention=true;
                r.allowDoseIncrease=true;
                r.reduceDose=false;
                r.learned="현재 개입 방향에 긍정적 반응이 있었다.";
                r.nextMoveHint="MAINTAIN_OR_GENTLY_ADVANCE";
                break;

            case PARTIAL:
                r.keepIntervention=true;
                r.allowDoseIncrease=true;
                r.reduceDose=false;
                r.learned="일부 효과는 있으나 충분하지 않다.";
                r.nextMoveHint="REFINE_SAME_MECHANISM";
                break;

            case NO_CHANGE:
                r.keepIntervention=false;
                r.allowDoseIncrease=false;
                r.reduceDose=false;
                r.learned="현재 개입만으로는 변화 evidence가 부족하다.";
                r.nextMoveHint="REVIEW_MECHANISM_BEFORE_SWITCH";
                break;

            case WORSE:
                r.keepIntervention=false;
                r.allowDoseIncrease=false;
                r.reduceDose=true;
                r.reopenSuggested=true;
                r.learned="개입 후 악화 신호가 있어 강도 상승을 금지하고 formulation 재검토가 필요하다.";
                r.nextMoveHint="REOPEN_AND_REASSESS";
                break;
        }

        persist(c,r,lastIntervention,lastDose,u,p,f,s);
        r.summary=r.outcome.name()+" | "+r.nextMoveHint+" | "+r.learned;
        return r;
    }

    public static String instruction(Result r){
        if(r==null||r.outcome==Outcome.UNKNOWN)return "";

        switch(r.outcome){
            case NOT_TRIED:
                return "INTERVENTION_OUTCOME=NOT_TRIED. 효과가 없었다고 결론내리지 말고 실행 장벽부터 확인한다.";
            case HELPED:
                return "INTERVENTION_OUTCOME=HELPED. 같은 기전을 유지하고 필요하면 한 단계만 확장한다.";
            case PARTIAL:
                return "INTERVENTION_OUTCOME=PARTIAL. 기전은 유지하되 같은 개입을 더 구체화하거나 작은 수정만 한다.";
            case NO_CHANGE:
                return "INTERVENTION_OUTCOME=NO_CHANGE. 무작정 강도를 올리지 말고 왜 안 먹혔는지 먼저 REVIEW한다.";
            case WORSE:
                return "INTERVENTION_OUTCOME=WORSE. 강도를 낮추고 새 개입을 밀어붙이지 말며 formulation을 REOPEN한다.";
            default:
                return "";
        }
    }

    public static Outcome detectOutcome(String u){
        if(u==null||u.trim().isEmpty())return Outcome.UNKNOWN;
        String s=u.trim();

        if(containsAny(s,
                "안 해봤","못 했","못해봤","아직 안 했","아직 못 했",
                "실행 못","해보진 않았"))
            return Outcome.NOT_TRIED;

        if(containsAny(s,
                "더 나빠","더 불안","악화","오히려 힘들","더 힘들어",
                "더 심해","더 괴로","별로였고 더"))
            return Outcome.WORSE;

        if(containsAny(s,
                "도움 됐","도움됐","괜찮아졌","확실히 나아",
                "좋아졌","훨씬 나아","효과 있었","먹혔"))
            return Outcome.HELPED;

        if(containsAny(s,
                "조금 도움","약간 도움","조금 나아","조금 괜찮",
                "반반","일부는","조금은 효과","살짝 나아"))
            return Outcome.PARTIAL;

        if(containsAny(s,
                "별 차이 없","똑같아","변화 없","효과 없","잘 모르겠",
                "그대로야","달라진 거 없"))
            return Outcome.NO_CHANGE;

        return Outcome.UNKNOWN;
    }

    private static void persist(
            Context c,Result r,String intervention,String dose,String userText,
            JSONObject p,JSONObject f,JSONObject s){

        try{
            long now=System.currentTimeMillis();

            JSONObject item=new JSONObject();
            item.put("intervention_id",intervention);
            item.put("dose",dose);
            item.put("outcome",r.outcome.name());
            item.put("user_evidence",compact(userText,500));
            item.put("learned",r.learned);
            item.put("next_move_hint",r.nextMoveHint);
            item.put("time",now);

            JSONArray history=p.optJSONArray("intervention_outcome_history");
            if(history==null)history=new JSONArray();
            history.put(item);

            JSONArray trimmed=new JSONArray();
            int start=Math.max(0,history.length()-30);
            for(int i=start;i<history.length();i++)trimmed.put(history.opt(i));

            p.put("intervention_outcome_history",trimmed);
            p.put("last_intervention_outcome",r.outcome.name());
            p.put("last_intervention_id",intervention);
            p.put("last_intervention_dose",dose);
            p.put("last_intervention_outcome_at",now);

            f.put("last_intervention_outcome",r.outcome.name());
            f.put("last_intervention_outcome_learning",r.learned);
            f.put("last_intervention_next_move_hint",r.nextMoveHint);

            if(r.reopenSuggested){
                f.put("formulation_reopened",true);
                f.put("formulation_reopen_reason","INTERVENTION_OUTCOME_WORSE");
            }

            s.put("last_intervention_outcome",r.outcome.name());
            s.put("last_intervention_outcome_at",now);

            CentralTherapyProfile.replaceProfile(c,p);
            CentralTherapyProfile.replaceFormulation(c,f);
            CentralTherapyProfile.replaceSessionState(c,s);
        }catch(Exception ignored){}
    }

    private static void persist(
            Context c,ClinicalDecisionRC7 d,Result r,String userText){

        JSONObject p=CentralTherapyProfile.loadProfile(c);
        JSONObject f=CentralTherapyProfile.loadFormulation(c);
        JSONObject s=CentralTherapyProfile.loadSessionState(c);

        String intervention="";
        String dose="";

        if(d!=null){
            intervention=d.selectedInterventionId==null?"":d.selectedInterventionId;
            dose=d.interventionDose==null?"":d.interventionDose;
        }

        if(intervention.isEmpty())
            intervention=s.optString("last_intervention_id",
                    p.optString("last_intervention_id",""));

        if(dose.isEmpty())
            dose=s.optString("last_intervention_dose",
                    p.optString("last_intervention_dose",""));

        r.nextMoveHint=actionForOutcomeGate(r.outcome);
        persist(c,r,intervention,dose,userText,p,f,s);
    }

    public static boolean hasOutcomeSignal(String u){
        return detectOutcome(u)!=Outcome.UNKNOWN;
    }

    private static boolean containsAny(String s,String... xs){
        for(String x:xs)if(s.contains(x))return true;
        return false;
    }

    private static String compact(String s,int max){
        s=s==null?"":s.trim();
        return s.length()<=max?s:s.substring(0,max);
    }

    public static Result captureWithEligibilityGate(
            Context c,
            String userText,
            ClinicalDecisionRC7 d,
            boolean allowed,
            String forcedOutcome){

        if(!allowed){
            Result r=new Result();
            r.outcome=Outcome.UNKNOWN;
            r.action="ATTRIBUTION_HOLD";
            r.summary="UNKNOWN | OUTCOME_LEARNING_NOT_ELIGIBLE";
            return r;
        }

        if(forcedOutcome!=null
                && !forcedOutcome.isEmpty()
                && !"UNKNOWN".equals(forcedOutcome)){

            Result r=new Result();
            try{
                r.outcome=Outcome.valueOf(forcedOutcome);
            }catch(Exception e){
                r.outcome=Outcome.UNKNOWN;
            }

            r.action=actionForOutcomeGate(r.outcome);
            r.summary=r.outcome.name()
                    +" | forced_by_attribution_commit=true";

            if(r.outcome!=Outcome.UNKNOWN){
                persist(c,d,r,userText);
            }
            return r;
        }

        return capture(c,userText,d);
    }


    private static String actionForOutcomeGate(Outcome o){
        if(o==Outcome.NOT_TRIED)return "REVIEW_OR_BARRIER_CHECK";
        if(o==Outcome.HELPED)return "MAINTAIN_OR_GENTLY_ADVANCE";
        if(o==Outcome.PARTIAL)return "REFINE_SAME_MECHANISM";
        if(o==Outcome.NO_CHANGE)return "REVIEW_BEFORE_SWITCH";
        if(o==Outcome.WORSE)return "REDUCE_DOSE_AND_REOPEN";
        return "NONE";
    }

}
