package com.maeummon.app.clinical;
import android.content.Context;
import org.json.*;
public final class InterventionAdaptationSwitchDecisionGateRC10 {
  private InterventionAdaptationSwitchDecisionGateRC10(){}
  public enum Action { NONE,CHECK_BARRIER,MAINTAIN,REFINE,REVIEW_MECHANISM,REOPEN_FORMULATION,SWITCH_INTERVENTION }
  public static final class Result {
    public Action action=Action.NONE; public boolean switchAllowed=false,switchRequired=false,reviewBeforeSwitch=false,reopenFormulation=false;
    public String currentInterventionId="",candidateInterventionId="",rationale="",blockedReason="",summary="";
  }
  public static Result decide(Context c,ClinicalDecisionRC7 d,InterventionOutcomeLearningLoopRC10.Result outcome){
    Result r=new Result(); if(d==null){r.blockedReason="NO_DECISION"; return finish(r);} JSONObject p=CentralTherapyProfile.loadProfile(c); JSONObject f=CentralTherapyProfile.loadFormulation(c);
    String current=safe(d.selectedInterventionId); if(current.isEmpty()) current=p.optString("last_intervention_id",""); r.currentInterventionId=current;
    InterventionOutcomeLearningLoopRC10.Outcome o=outcome==null?InterventionOutcomeLearningLoopRC10.Outcome.UNKNOWN:outcome.outcome;
    if(o==InterventionOutcomeLearningLoopRC10.Outcome.UNKNOWN){r.blockedReason="NO_OUTCOME_SIGNAL"; return finish(r);}
    if(o==InterventionOutcomeLearningLoopRC10.Outcome.NOT_TRIED){r.action=Action.CHECK_BARRIER; r.reviewBeforeSwitch=true; r.rationale="개입을 실행하지 못했으므로 효과 실패로 판단하지 않고 실행 장벽을 먼저 본다."; return finish(r);}
    if(o==InterventionOutcomeLearningLoopRC10.Outcome.HELPED){r.action=Action.MAINTAIN; r.rationale="도움이 확인되어 현재 기전과 개입을 유지한다."; return finish(r);}
    if(o==InterventionOutcomeLearningLoopRC10.Outcome.PARTIAL){r.action=Action.REFINE; r.reviewBeforeSwitch=true; r.rationale="부분 효과가 있어 같은 기전을 유지한 채 전달 방식이나 강도만 조정한다."; return finish(r);}
    if(o==InterventionOutcomeLearningLoopRC10.Outcome.NO_CHANGE){int n=countRecentOutcome(p,current,"NO_CHANGE",3); if(n>=2){r.action=Action.SWITCH_INTERVENTION; r.switchAllowed=true; r.reviewBeforeSwitch=true; r.candidateInterventionId=selectAlternative(d,current); r.rationale="같은 개입에서 NO_CHANGE가 반복되어 mechanism review 후 대안 개입 전환을 허용한다.";} else {r.action=Action.REVIEW_MECHANISM; r.reviewBeforeSwitch=true; r.rationale="첫 NO_CHANGE에서는 강도 상승이나 즉시 전환 대신 mechanism 적합성을 먼저 검토한다.";} return finish(r);}
    if(o==InterventionOutcomeLearningLoopRC10.Outcome.WORSE){int n=countRecentOutcome(p,current,"WORSE",3); r.action=Action.REOPEN_FORMULATION; r.reopenFormulation=true; r.reviewBeforeSwitch=true; r.switchAllowed=n>=2; r.switchRequired=n>=2; if(n>=2) r.candidateInterventionId=selectAlternative(d,current); r.rationale=n>=2?"같은 개입에서 WORSE가 반복되어 formulation reopen 후 개입 전환이 필요하다.":"악화 신호가 있어 우선 formulation을 reopen하고 강도를 낮춘다."; try{f.put("formulation_reopened",true); f.put("formulation_reopen_reason",n>=2?"REPEATED_INTERVENTION_WORSE":"INTERVENTION_OUTCOME_WORSE"); CentralTherapyProfile.replaceFormulation(c,f);}catch(Exception ignored){} return finish(r);}
    return finish(r);
  }
  public static String instruction(Result r){ if(r==null)return ""; switch(r.action){case CHECK_BARRIER:return "INTERVENTION_ADAPTATION=CHECK_BARRIER. 안 해본 이유와 실행 장벽부터 확인한다."; case MAINTAIN:return "INTERVENTION_ADAPTATION=MAINTAIN. 효과가 확인되어 같은 개입을 유지한다."; case REFINE:return "INTERVENTION_ADAPTATION=REFINE. 같은 mechanism 안에서 전달 방식이나 강도만 작게 조정한다."; case REVIEW_MECHANISM:return "INTERVENTION_ADAPTATION=REVIEW_MECHANISM. NO_CHANGE를 강도 부족으로 단정하지 말고 mechanism 적합성을 먼저 본다."; case REOPEN_FORMULATION:return "INTERVENTION_ADAPTATION=REOPEN_FORMULATION. WORSE 신호가 있어 강도를 낮추고 formulation을 다시 확인한다."; case SWITCH_INTERVENTION:return "INTERVENTION_ADAPTATION=SWITCH_INTERVENTION. 반복된 NO_CHANGE 후 대안 개입 하나로만 전환한다."; default:return "";} }
  public static boolean canSwitch(Result r){return r!=null&&r.switchAllowed&&!safe(r.candidateInterventionId).isEmpty();}
  private static String selectAlternative(ClinicalDecisionRC7 d,String current){String m=safe(d.centralMechanism); if("AMBIGUITY_TO_REJECTION".equals(m)) return "REALITY_TEST".equals(current)?"AMBIGUITY_TOLERANCE":"REALITY_TEST"; if("ACTUAL_RELATIONSHIP_CHANGE".equals(m)) return "COMMUNICATION_SCRIPT".equals(current)?"REPAIR_OR_BOUNDARY":"COMMUNICATION_SCRIPT"; if("REAL_CONFLICT_OR_REJECTION".equals(m))return "REPAIR_OR_BOUNDARY"; if("NORMAL_VARIATION".equals(m))return "AMBIGUITY_TOLERANCE"; if("EVALUATION_THREAT".equals(m))return "FACT_VS_EVALUATION"; if("LOAD_EXCEEDS_CAPACITY".equals(m))return "LOAD_REDUCTION"; if("INTERPERSONAL_THREAT".equals(m))return "WORK_BOUNDARY_SCRIPT"; if("RECOVERY_DEFICIT".equals(m))return "RECOVERY_FIRST"; if("SHORT_TERM_RELIEF_MAINTAINS_AVOIDANCE".equals(m))return "GRADED_APPROACH"; return "";}
  private static int countRecentOutcome(JSONObject p,String iid,String outcome,int max){JSONArray a=p.optJSONArray("intervention_outcome_history"); if(a==null)return 0; int seen=0,count=0; for(int i=a.length()-1;i>=0&&seen<max;i--){JSONObject o=a.optJSONObject(i); if(o==null)continue; if(!iid.isEmpty()&&!iid.equals(o.optString("intervention_id","")))continue; seen++; if(outcome.equals(o.optString("outcome","")))count++;} return count;}
  private static Result finish(Result r){r.summary=r.action.name()+" | switchAllowed="+r.switchAllowed+" | switchRequired="+r.switchRequired+" | candidate="+r.candidateInterventionId+(r.blockedReason.isEmpty()?"":" | blocked="+r.blockedReason); return r;}
  private static String safe(String s){return s==null?"":s;}
}
