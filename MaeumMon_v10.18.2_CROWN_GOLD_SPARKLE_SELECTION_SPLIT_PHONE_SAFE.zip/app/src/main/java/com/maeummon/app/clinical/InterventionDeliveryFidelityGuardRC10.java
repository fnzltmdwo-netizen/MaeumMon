package com.maeummon.app.clinical;

import android.content.Context;
import java.util.*;

public final class InterventionDeliveryFidelityGuardRC10 {
    private InterventionDeliveryFidelityGuardRC10(){}

    public static final class Check {
        public boolean pass=true;
        public boolean rewriteRequired=false;
        public final List<String> failures=new ArrayList<>();
        public String instruction="";
        public String summary="PASS";

        void fail(String code){
            pass=false;
            rewriteRequired=true;
            failures.add(code);
        }
    }

    public static Check inspect(
            Context c,String response,ClinicalDecisionRC7 d){

        Check x=new Check();
        if(d==null || !d.isIntervene()) return x;

        String r=response==null?"":response.trim();
        String dose=safe(d.interventionDose);
        int maxSteps=d.interventionMaxSteps;
        boolean homework=d.interventionHomeworkAllowed;
        int minutes=d.interventionExerciseMinutes;

        if("NONE".equals(dose)){
            if(hasActionLanguage(r))
                x.fail("ACTION_PRESENT_WHEN_DOSE_NONE");
            return finish(x,d);
        }

        int stepCount=countSteps(r);
        int actionCount=countActionMarkers(r);
        int homeworkCount=countHomeworkMarkers(r);

        // 1. Enforce max steps.
        if(maxSteps>0 && stepCount>maxSteps)
            x.fail("TOO_MANY_INTERVENTION_STEPS");

        // 2. MICRO must be tiny and homework-free.
        if("MICRO".equals(dose)){
            if(r.length()>420)
                x.fail("MICRO_TOO_VERBOSE");
            if(actionCount>1)
                x.fail("MICRO_TOO_MANY_ACTIONS");
            if(homeworkCount>0)
                x.fail("MICRO_HOMEWORK_LEAK");
            if(mentionsDurationOver(r,2))
                x.fail("MICRO_EXERCISE_TOO_LONG");
        }

        // 3. LIGHT stays one concrete step, no complex homework.
        if("LIGHT".equals(dose)){
            if(r.length()>650)
                x.fail("LIGHT_TOO_VERBOSE");
            if(actionCount>2)
                x.fail("LIGHT_TOO_MANY_ACTIONS");
            if(homeworkCount>=2)
                x.fail("LIGHT_HOMEWORK_OVERLOAD");
            if(mentionsDurationOver(r,5))
                x.fail("LIGHT_EXERCISE_TOO_LONG");
        }

        // 4. STANDARD should include rationale + one experiment + review criterion.
        if("STANDARD".equals(dose)){
            if(!containsAny(r,"이유","왜냐하면","핵심","흐름을 끊","이 방법은"))
                x.fail("STANDARD_MISSING_RATIONALE");
            if(!hasActionLanguage(r))
                x.fail("STANDARD_MISSING_EXPERIMENT");
            if(!containsAny(r,"다음에","해보고","어땠는지","도움됐는지","변화가 있는지","확인"))
                x.fail("STANDARD_MISSING_REVIEW_CRITERION");
            if(actionCount>3)
                x.fail("STANDARD_TOO_MANY_ACTIONS");
        }

        // 5. DEEP still means one structured exercise, not many techniques.
        if("DEEP".equals(dose)){
            if(stepCount>1)
                x.fail("DEEP_MULTIPLE_EXERCISES");
            if(!containsAny(r,"연습","실험","적어","기록","단계","해보"))
                x.fail("DEEP_NOT_STRUCTURED");
            if(minutes>0 && mentionsDurationOver(r,minutes))
                x.fail("DEEP_EXCEEDS_TIME_CAP");
            if(actionCount>4)
                x.fail("DEEP_TECHNIQUE_PILEUP");
        }

        // 6. Homework prohibition is global.
        if(!homework && homeworkCount>0)
            x.fail("HOMEWORK_NOT_ALLOWED");

        // 7. Intervention must remain aligned to chosen bridge intervention.
        if(d.centralBridgeReady && d.centralBridgeInterventionId!=null
                && !d.centralBridgeInterventionId.isEmpty()
                && d.selectedInterventionId!=null
                && !d.centralBridgeInterventionId.equals(d.selectedInterventionId))
            x.fail("DELIVERY_INTERVENTION_ID_MISMATCH");

        // 8. User-facing response should not expose dose jargon.
        if(containsAny(r,
                "INTERVENTION_DOSE","MICRO dose","LIGHT dose","STANDARD dose",
                "DEEP dose","maxSteps","homeworkAllowed","exerciseMinutes"))
            x.fail("DOSE_JARGON_LEAK");

        return finish(x,d);
    }

    public static String minimalActionPlan(ClinicalDecisionRC7 d){
        if(d==null || !d.isIntervene()) return "";

        String dose=safe(d.interventionDose);
        String target=safe(d.selectedInterventionTarget);

        if("NONE".equals(dose)) return "";

        if("MICRO".equals(dose))
            return "지금은 한 가지만 해보자. "+plainTarget(target)+"을 아주 작게 확인해보는 거야.";

        if("LIGHT".equals(dose))
            return "이번에는 한 단계만 해보자. "+plainTarget(target)+"을 실제 상황에서 한 번만 적용해봐.";

        if("STANDARD".equals(dose))
            return "이번에는 한 가지 실험만 해보자. "+plainTarget(target)
                    +"을 적용해보고, 다음에 불안이나 행동이 어떻게 달라졌는지만 확인하자.";

        if("DEEP".equals(dose))
            return "이번에는 한 가지 연습을 조금 더 구조적으로 해보자. "
                    +plainTarget(target)+"을 중심으로 최대 "+Math.max(1,d.interventionExerciseMinutes)
                    +"분만 해보고, 끝난 뒤 어떤 변화가 있었는지 확인하자.";

        return "";
    }

    public static String rewriteInstruction(Check x,ClinicalDecisionRC7 d){
        if(x==null||x.pass)return "";
        return "INTERVENTION_FIDELITY_FAIL=true. 실제 답변을 현재 intervention dose에 맞게 다시 쓴다. "
                +"개입은 하나만 유지하고, 허용된 step 수/숙제 여부/시간 상한을 넘지 않는다. "
                +"dose="+safe(d==null?"":d.interventionDose)
                +", max_steps="+(d==null?0:d.interventionMaxSteps)
                +", homework_allowed="+(d!=null&&d.interventionHomeworkAllowed)
                +", exercise_minutes="+(d==null?0:d.interventionExerciseMinutes)
                +", failures="+x.failures;
    }

    private static Check finish(Check x,ClinicalDecisionRC7 d){
        if(!x.pass)x.instruction=rewriteInstruction(x,d);
        x.summary=x.pass?"PASS":"FAIL "+x.failures;
        return x;
    }

    private static int countSteps(String r){
        int n=0;
        String[] markers={"1.","2.","3.","①","②","③","첫째","둘째","셋째","첫 번째","두 번째","세 번째"};
        for(String m:markers) if(r.contains(m)) n++;
        return n==0 && hasActionLanguage(r)?1:n;
    }

    private static int countActionMarkers(String r){
        int n=0;
        String[] xs={"해봐","해보자","적어","기록","말해","연락","시도","연습","확인","보내","줄여","거절","쉬어"};
        for(String x:xs) if(r.contains(x)) n++;
        return n;
    }

    private static int countHomeworkMarkers(String r){
        int n=0;
        String[] xs={"숙제","매일","일주일","이번 주","하루에","반복해서","계속 기록","매번 적어"};
        for(String x:xs) if(r.contains(x)) n++;
        return n;
    }

    private static boolean hasActionLanguage(String r){
        return countActionMarkers(r)>0;
    }

    private static boolean mentionsDurationOver(String r,int cap){
        if(r==null||r.isEmpty())return false;
        java.util.regex.Matcher m=
                java.util.regex.Pattern.compile("(\\\\d{1,2})\\\\s*분").matcher(r);
        while(m.find()){
            try{
                if(Integer.parseInt(m.group(1))>cap)return true;
            }catch(Exception ignored){}
        }
        return false;
    }

    private static String plainTarget(String t){
        if(t==null||t.isEmpty())return "지금 핵심을";
        if(t.contains("interpretation_not_fact"))return "사실과 해석을 나눠보는 것";
        if(t.contains("clarify_relationship_change"))return "관계가 실제로 달라졌는지 확인하는 것";
        if(t.contains("repair_or_boundary"))return "수리할지 경계를 세울지 구분하는 것";
        if(t.contains("tolerate_uncertainty"))return "애매함을 바로 거절로 확정하지 않는 것";
        if(t.contains("global_self_judgment"))return "실수와 자기평가를 분리하는 것";
        if(t.contains("task_load"))return "부담을 한 단계 줄이는 것";
        if(t.contains("threat_exposure"))return "불필요한 대인 위협 노출을 줄이는 것";
        if(t.contains("regulation_capacity"))return "회복 여력을 먼저 되찾는 것";
        if(t.contains("small_approach"))return "회피 대신 아주 작은 접근 행동을 해보는 것";
        return t.replace('_',' ');
    }

    private static boolean containsAny(String s,String... xs){
        if(s==null)return false;
        for(String x:xs) if(x!=null&&!x.isEmpty()&&s.contains(x)) return true;
        return false;
    }

    private static String safe(String s){ return s==null?"":s; }
}
