package com.maeummon.app.clinical;

import android.content.Context;
import org.json.*;
import java.util.*;

public final class ResponseRelevanceGenericnessGuardRC9 {
    private ResponseRelevanceGenericnessGuardRC9(){}

    public static final class Check {
        public boolean pass=true;
        public boolean rewriteRequired=false;
        public final List<String> failures=new ArrayList<>();
        public String instruction="";
        public String summary="PASS";

        void fail(String code){
            pass=false;
            rewriteRequired=true;
            failures.add(code);
        }
    }

    public static Check inspect(
            Context c,String userText,String response,ClinicalDecisionRC7 d){

        Check x=new Check();
        String u=userText==null?"":userText.trim();
        String r=response==null?"":response.trim();
        JSONObject f=CentralTherapyProfile.loadFormulation(c);

        String need=f.optString("response_need","");
        String move=d==null?"":safe(d.move);
        String target=d==null?"":safe(d.target);
        String centralInsight=f.optString("central_insight","");
        boolean centralUsable=f.optBoolean("central_insight_usable",false);

        // 1. Generic empathy-only response with no user-specific anchor.
        boolean genericEmpathy=containsAny(r,
                "많이 힘들었겠다","정말 속상했겠다","그럴 수 있어",
                "그 마음 이해해","많이 지쳤겠다","쉽지 않았겠다");
        boolean hasSpecificAnchor=sharesMeaningfulToken(u,r)
                || containsAny(r, target)
                || (centralUsable && sharesMeaningfulToken(centralInsight,r));

        if(genericEmpathy && !hasSpecificAnchor && r.length()<220){
            x.fail("GENERIC_EMPATHY_ONLY");
        }

        // 2. User explicitly asks "why" but response gives no explanatory structure.
        if(containsAny(u,"왜 그런","왜 이래","왜 그랬","이유가 뭐","왜 나는")
                && !containsAny(r,
                    "때문","흐름","구조","가능성","핵심은","즉","그래서","유지"))
            x.fail("WHY_QUESTION_NOT_ANSWERED");

        // 3. User asks what to do, but reply has no actionable next step,
        // unless response need says understanding/venting or phase blocks intervention.
        boolean asksAction=containsAny(u,"어떻게 해야","어쩌면 좋","뭘 해야","방법","어떡해");
        boolean phaseBlocks=d!=null&&(
                "ORIENT".equals(d.sessionPhase)
                ||"UNDERSTAND".equals(d.sessionPhase)
                ||"COMPLETE".equals(d.sessionPhase));
        if(asksAction
                && !"UNDERSTANDING".equalsIgnoreCase(need)
                && !"VENTING".equalsIgnoreCase(need)
                && !phaseBlocks
                && !containsAny(r,"해볼 수","방법은","먼저","한 가지","다음에는","시도"))
            x.fail("ACTION_REQUEST_NOT_ANSWERED");

        // 4. FORMULATE should contain a concrete central understanding, not only a question.
        if("FORMULATE".equals(move)
                && r.endsWith("?")
                && count(r,'?')>=1
                && !containsAny(r,"핵심","지금 보면","정리하면","가까워","가능성"))
            x.fail("FORMULATE_COLLAPSED_TO_QUESTION");

        // 5. ASK should not include long lectures before the one question.
        if("ASK".equals(move) && r.length()>420){
            x.fail("ASK_TOO_VERBOSE");
        }

        // 6. Repetitive response.
        if(repeatedSentenceRatio(r)>=0.45){
            x.fail("REPETITIVE_RESPONSE");
        }

        // 7. Excessive length for ordinary counseling turn.
        if(!"STABILIZE".equals(move)
                && !"REVIEW".equals(move)
                && r.length()>1200){
            x.fail("RESPONSE_TOO_LONG");
        }

        // 8. Internal jargon leakage.
        if(containsAny(r,
                "alternative_hypotheses","confidence_band","central_mechanism",
                "response_need","SESSION_PHASE","target_variable",
                "FORMULATION_REOPEN","evidence_conflict_matrix")){
            x.fail("INTERNAL_JARGON_LEAK");
        }

        // 9. Percentage / score leakage from internal heuristics.
        if(containsAny(r,"가설 확률","confidence","진행도 점수","progress score")
                || r.matches("(?s).*\\b\\d{1,3}%\\b.*")){
            x.fail("INTERNAL_SCORE_LEAK");
        }

        // 10. Advice without explaining why it fits current formulation.
        if("INTERVENE".equals(move)
                && containsAny(r,"해봐","시도해","연습해","말해봐")
                && !containsAny(r,"왜냐하면","지금 핵심","이 방법은","이유는","흐름을 끊"))
            x.fail("INTERVENTION_WITHOUT_RATIONALE");

        if(!x.pass){
            x.instruction=buildRewriteInstruction(x,d);
        }
        x.summary=x.pass?"PASS":"FAIL "+x.failures.toString();
        return x;
    }

    public static String buildRewriteInstruction(Check x,ClinicalDecisionRC7 d){
        String move=d==null?"":safe(d.move);
        return "RESPONSE_RELEVANCE_GUARD_FAIL=true. 응답을 다시 쓸 때 "
                +"사용자 직전 발화의 구체적 사실/표현을 최소 1개 반영하고, "
                +"현재 move="+move+"의 목적에 직접 답한다. "
                +"뻔한 공감만 반복하지 말고 핵심 이해 1개를 먼저 말한다. "
                +"내부 점수/필드명/가설 확률은 노출하지 않는다. "
                +"ASK는 짧게 질문 1개, FORMULATE는 질문보다 정리, INTERVENE는 개입 이유를 함께 제시한다. "
                +"failures="+x.failures;
    }

    private static boolean sharesMeaningfulToken(String a,String b){
        if(a==null||b==null)return false;
        String[] xs=a.replaceAll("[^가-힣A-Za-z0-9 ]"," ").split("\\s+");
        int hits=0;
        for(String x:xs){
            if(x.length()<2)continue;
            if(isStopword(x))continue;
            if(b.contains(x)){
                hits++;
                if(hits>=1)return true;
            }
        }
        return false;
    }

    private static boolean isStopword(String x){
        return "그냥".equals(x)||"근데".equals(x)||"나는".equals(x)
                ||"내가".equals(x)||"그게".equals(x)||"이거".equals(x)
                ||"저거".equals(x)||"진짜".equals(x)||"너무".equals(x);
    }

    private static double repeatedSentenceRatio(String r){
        if(r==null||r.isEmpty())return 0.0;
        String[] ss=r.split("[.!?\\n]+");
        List<String> clean=new ArrayList<>();
        for(String s:ss){
            String x=s.trim();
            if(x.length()>=8)clean.add(x);
        }
        if(clean.size()<3)return 0.0;

        int repeats=0;
        for(int i=0;i<clean.size();i++){
            for(int j=0;j<i;j++){
                if(similar(clean.get(i),clean.get(j))){
                    repeats++;
                    break;
                }
            }
        }
        return (double)repeats/(double)clean.size();
    }

    private static boolean similar(String a,String b){
        String aa=a.replace(" ","");
        String bb=b.replace(" ","");
        if(aa.equals(bb))return true;
        int min=Math.min(aa.length(),bb.length());
        if(min<8)return false;
        int prefix=0;
        while(prefix<min && aa.charAt(prefix)==bb.charAt(prefix))prefix++;
        return ((double)prefix/(double)min)>=0.72;
    }

    private static int count(String s,char c){
        int n=0;
        if(s==null)return 0;
        for(int i=0;i<s.length();i++)if(s.charAt(i)==c)n++;
        return n;
    }

    private static boolean containsAny(String s,String... xs){
        if(s==null)return false;
        for(String x:xs){
            if(x!=null&&!x.isEmpty()&&s.contains(x))return true;
        }
        return false;
    }

    private static String safe(String s){return s==null?"":s;}
}
