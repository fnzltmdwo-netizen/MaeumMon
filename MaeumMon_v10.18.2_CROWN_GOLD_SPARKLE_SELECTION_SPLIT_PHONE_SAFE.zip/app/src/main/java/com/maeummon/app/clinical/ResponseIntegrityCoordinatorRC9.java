package com.maeummon.app.clinical;

import android.content.Context;

public final class ResponseIntegrityCoordinatorRC9 {
    private ResponseIntegrityCoordinatorRC9(){}

    public static final class Result {
        public String text="";
        public boolean rewriteRequired=false;
        public String rewriteInstruction="";
        public String factGuardSummary="PASS";
    }

    public static Result inspect(
            Context c,String userText,String draft,ClinicalDecisionRC7 decision){
        Result r=new Result();
        r.text=draft==null?"":draft;

        ResponseContradictionHallucinationGuardRC9.Check fact =
                ResponseContradictionHallucinationGuardRC9.inspect(c,userText,r.text);

        ResponseSafetyOverreachGuardRC9.Check overreach =
                ResponseSafetyOverreachGuardRC9.inspect(c,userText,r.text,decision);

        ResponseRelevanceGenericnessGuardRC9.Check relevance =
                ResponseRelevanceGenericnessGuardRC9.inspect(c,userText,r.text,decision);

        ResponseAttunementValidationCalibrationGuardRC9.Check attunement =
                ResponseAttunementValidationCalibrationGuardRC9.inspect(c,userText,r.text,decision);

        ResponsePrecisionDirectnessGuardRC9.Check precision =
                ResponsePrecisionDirectnessGuardRC9.inspect(c,userText,r.text,decision);

        ResponseSpecificityEvidenceAnchoringGuardRC9.Check specificity =
                ResponseSpecificityEvidenceAnchoringGuardRC9.inspect(c,userText,r.text,decision);

        ResponseContinuityTurnCoherenceGuardRC9.Check continuity =
                ResponseContinuityTurnCoherenceGuardRC9.inspect(c,userText,r.text,decision);

        ResponseTimingStopRuleGuardRC9.Check timing =
                ResponseTimingStopRuleGuardRC9.inspect(c,userText,r.text,decision);

        InterventionDeliveryFidelityGuardRC10.Check fidelity =
                InterventionDeliveryFidelityGuardRC10.inspect(c,r.text,decision);

        r.rewriteRequired=fact.rewriteRequired || overreach.rewriteRequired
                || relevance.rewriteRequired || attunement.rewriteRequired
                || precision.rewriteRequired || specificity.rewriteRequired || continuity.rewriteRequired || timing.rewriteRequired || fidelity.rewriteRequired;
        r.rewriteInstruction=
                (fact.instruction==null?"":fact.instruction+" ")
                +(overreach.instruction==null?"":overreach.instruction+" ")
                +(relevance.instruction==null?"":relevance.instruction+" ")
                +(attunement.instruction==null?"":attunement.instruction+" ")
                +(precision.instruction==null?"":precision.instruction+" ")
                +(specificity.instruction==null?"":specificity.instruction+" ")
                +(continuity.instruction==null?"":continuity.instruction+" ")
                +(timing.instruction==null?"":timing.instruction+" ")
                +(fidelity.instruction==null?"":fidelity.instruction);
        r.factGuardSummary=fact.summary;

        if(decision!=null){
            decision.responseFactGuardSummary=fact.summary;
            decision.responseRewriteRequired=fact.rewriteRequired;
            decision.responseOverreachGuardSummary=overreach.summary;
            decision.responseOverreachRewriteRequired=overreach.rewriteRequired;
            decision.responseRelevanceGuardSummary=relevance.summary;
            decision.responseRelevanceRewriteRequired=relevance.rewriteRequired;
            decision.responseAttunementGuardSummary=attunement.summary;
            decision.responseAttunementRewriteRequired=attunement.rewriteRequired;
            decision.responsePrecisionGuardSummary=precision.summary;
            decision.responsePrecisionRewriteRequired=precision.rewriteRequired;
            decision.responseSpecificityGuardSummary=specificity.summary;
            decision.responseSpecificityRewriteRequired=specificity.rewriteRequired;
            decision.responseEvidenceAnchorUsed=specificity.anchorUsed;
            decision.responseContinuityGuardSummary=continuity.summary;
            decision.responseContinuityRewriteRequired=continuity.rewriteRequired;
            decision.responseTimingGuardSummary=timing.summary;
            decision.responseTimingRewriteRequired=timing.rewriteRequired;
            decision.interventionFidelitySummary=fidelity.summary;
            decision.interventionFidelityRewriteRequired=fidelity.rewriteRequired;
            decision.minimalActionPlan=InterventionDeliveryFidelityGuardRC10.minimalActionPlan(decision);

            if(r.rewriteRequired){
                decision.responseInstruction=
                        (decision.responseInstruction==null?"":decision.responseInstruction+" ")
                                +r.rewriteInstruction;
            }
        }
        return r;
    }
    public static RepairVerificationFinalAcceptanceGateRC9.Result verifyAfterRepair(
            Context c,String userText,String repairedText,ClinicalDecisionRC7 decision){
        RepairVerificationFinalAcceptanceGateRC9.Result result =
                RepairVerificationFinalAcceptanceGateRC9.verify(
                        c,userText,repairedText,decision);

        if(decision!=null){
            decision.finalAcceptanceSummary=result.summary;
            decision.finalResponseAccepted=result.accepted;
            decision.finalFallbackUsed=result.fallbackRequired;

            String instruction =
                    RepairVerificationFinalAcceptanceGateRC9.instruction(result);
            if(instruction!=null&&!instruction.isEmpty()){
                decision.responseInstruction=
                        (decision.responseInstruction==null?"":decision.responseInstruction+" ")
                                +instruction;
            }
        }
        return result;
    }

}
