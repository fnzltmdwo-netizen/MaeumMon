package com.maeummon.app.clinical;

import android.content.Context;
import org.json.JSONObject;
import java.util.*;

public final class ClinicalBrainRC7 {
    private ClinicalBrainRC7(){}

    public static ClinicalDecisionRC7 decide(Context c,String text,String history){
        ClinicalDecisionRC7 d=new ClinicalDecisionRC7();
        DecisionTransitionSnapshotContinuityRC13.Snapshot previousDecisionSnapshot =
                DecisionTransitionSnapshotContinuityRC13.loadPrevious(c);
        DecisionTransitionSnapshotContinuityRC13.applyPreviousToDecision(
                d,previousDecisionSnapshot);
        d.decisionTransitionSnapshotLoaded=previousDecisionSnapshot.loaded;

        String t=normalize(text==null?"":text);
        detectSignals(t,d.signals); detectKnown(t,d.known);
        ClinicalSessionMemoryRC7.State st=ClinicalSessionMemoryRC7.load(c); st.turns++;

        // Safety negation before safety override.
        boolean noSuicide=has(t,"죽고 싶은 건 아니","죽고싶진않","자살할 생각은 없","죽을 생각은 없");
        if((d.signals.contains("self_harm")&&!noSuicide)||d.signals.contains("psychosis")||d.signals.contains("mania")||d.signals.contains("eating_disorders")){
            d.move="STABILIZE"; d.safetyOverride=true; d.responseInstruction="안전 우선. 분석을 멈추고 현재 위험·계획·즉시 지원 필요성을 짧게 확인한다.";
            d.directText="지금은 원인 분석보다 안전부터 확인할게. 지금 당장 스스로를 다치게 할 계획이나 실행할 가능성이 있어?";
            finish(c,st,d,text); return d;
        }

        // Alliance rupture has priority over content counseling.
        String repairTarget=repairTarget(t);
        if(!repairTarget.isEmpty()){
            d.move="ALLIANCE_REPAIR"; d.allianceRupture=true; st.allianceRupture=true; d.target=repairTarget;
            ClinicalKnowledgeRC7.Unit q=exact(c,repairTarget,st.askedIds);
            if(q!=null){d.unitId=q.id;d.directText=q.question;} else d.directText="내가 지금 어디서 너랑 어긋났는지 먼저 맞출게. 제일 답답했던 부분이 뭐였어?";
            d.responseInstruction="내용상담을 잠시 멈추고 변명하지 말고 목표/질문방식/오해 중 어긋난 한 지점을 수리한다.";
            finish(c,st,d,text); return d;
        }
        if(st.allianceRupture&&has(t,"응 그거야","맞아 그거","이제 맞아","그 방향이 맞아","이제 괜찮"))st.allianceRupture=false;

        buildHypotheses(d); buildMissing(d);
        removeKnownFromMissing(d);

        EvidenceConflictResolutionRC8.Result liveEvidenceConflict =
                EvidenceConflictResolutionRC8.resolve(c,text);
        d.evidenceConflictCount=liveEvidenceConflict.conflicts;
        d.unresolvedEvidenceConflictCount=liveEvidenceConflict.unresolved;
        d.evidenceConflictSummary=liveEvidenceConflict.summary;

        EvidenceProvenanceTraceabilityRC8.TraceResult provenance =
                EvidenceProvenanceTraceabilityRC8.trace(c,text);
        d.evidenceProvenanceSummary=provenance.summary;
        d.unknownEvidenceCount=provenance.unknown;
        d.staleEvidenceCount=provenance.stale;

        TherapeuticGoalProgressRC8.Update goalUpdate =
                TherapeuticGoalProgressRC8.detect(c,text);
        TherapeuticGoalProgressRC8.apply(c,goalUpdate);
        d.therapeuticGoal=goalUpdate.activeGoal;
        d.progressSignal=goalUpdate.signal;

        GoalDriftCompletionRC8.Result goalTransition =
                GoalDriftCompletionRC8.evaluate(c,text);
        GoalDriftCompletionRC8.apply(c,goalTransition,text);
        d.goalTransitionStatus=goalTransition.status;
        d.goalTransitionReason=goalTransition.reason;
        if(!"UNCHANGED".equals(goalTransition.status)){
            d.responseInstruction=(d.responseInstruction==null?"":d.responseInstruction+" ")
                    +GoalDriftCompletionRC8.instruction(goalTransition);
        }

        InterventionOutcomeLearningRC8.Review interventionReview =
                InterventionOutcomeLearningRC8.review(c,text);
        if(interventionReview.outcomeMentioned){
            InterventionOutcomeLearningRC8.apply(c,interventionReview);
            AdaptiveTreatmentPlannerRC8.Plan adaptivePlan =
                    AdaptiveTreatmentPlannerRC8.plan(c,interventionReview);
            AdaptiveTreatmentPlannerRC8.apply(c,adaptivePlan);

            d.move=adaptivePlan.reopenFormulation ? "FORMULATE" : "REVIEW";
            d.interventionReviewOutcome=interventionReview.outcome;
            d.interventionReviewNextMove=interventionReview.nextMove;
            d.adaptivePlanAction=adaptivePlan.action;
            d.adaptivePlanRationale=adaptivePlan.rationale;
            d.responseInstruction=
                    InterventionOutcomeLearningRC8.reviewInstruction(interventionReview)
                    +" "+AdaptiveTreatmentPlannerRC8.instruction(adaptivePlan);
            finish(c,st,d,text); return d;
        }

        if(has(t,"어떻게 해야","뭘 해야","뭐 하면","방법 알려","조언해줘","이제 어떻게 해")){
            InterventionSelectorRC8.Selection intervention =
                    InterventionSelectorRC8.select(c,d,text);
            d.move="INTERVENE";
            d.selectedInterventionId=intervention.interventionId;
            d.interventionTarget=intervention.target;
            d.interventionScore=intervention.score;
            d.interventionRationale=intervention.rationale;
            d.unitId=intervention.unit==null?"":intervention.unit.id;
            d.responseInstruction=InterventionSelectorRC8.instruction(intervention);
            finish(c,st,d,text); return d;
        }

        // Explicit readiness.
        if(has(t,"이제 뭐라도 바꿔","행동해보고","뭔가 해보고 싶","실제로 바꿔")){
            InterventionSelectorRC8.Selection intervention =
                    InterventionSelectorRC8.select(c,d,text);
            d.move="INTERVENE";
            d.selectedInterventionId=intervention.interventionId;
            d.interventionTarget=intervention.target;
            d.interventionScore=intervention.score;
            d.interventionRationale=intervention.rationale;
            d.unitId=intervention.unit==null?"":intervention.unit.id;
            d.responseInstruction=InterventionSelectorRC8.instruction(intervention);
            finish(c,st,d,text); return d;
        }

        // Information-rich utterance -> formulate rather than interrogate.
        if(formulationReady(d.known,t)){
            d.move="FORMULATE"; d.responseInstruction="FACT와 INTERPRETATION을 분리해 2~4문장으로 가설을 정리하고 맞는지 확인한다."; finish(c,st,d,text); return d;
        }

        // Hard assessment question cap.
        if(st.askedIds.size()>=3){
            d.move="FORMULATE"; d.responseInstruction="질문 예산이 찼다. 지금까지 확인된 정보만으로 잠정 formulation을 정리한다."; finish(c,st,d,text); return d;
        }

        InformationGainQuestionSelectorRC8.Selection selection =
                InformationGainQuestionSelectorRC8.select(
                        c,d,st.askedIds,history==null?"":history);
        QuestionStopPolicyRC8.Result stopResult =
                QuestionStopPolicyRC8.evaluate(c,d,selection,st,text);

        if(stopResult.stopAsking){
            d.move="FORMULATE";
            d.questionStopTriggered=true;
            d.questionStopReason=stopResult.reason;
            d.informationGain=selection.informationGain;
            d.questionRationale=selection.rationale;
            d.responseInstruction=QuestionStopPolicyRC8.formulateInstruction(stopResult);
            finish(c,st,d,text); return d;
        }

        ClinicalKnowledgeRC7.Unit q=selection.unit;
        if(q==null){
            String target=nextTarget(d);
            q=exact(c,target,st.askedIds);
            if(q==null)q=bestQuestion(c,d,st.askedIds,history==null?"":history);
        }
        SessionPhaseTherapeuticPacingRC8.State phaseBeforeAsk =
                SessionPhaseTherapeuticPacingRC8.infer(c,d,text);
        if(q!=null && !SessionPhaseTherapeuticPacingRC8.phaseAllowsAsk(phaseBeforeAsk)){
            d.move="FORMULATE";
            d.questionStopTriggered=true;
            d.questionStopReason="SESSION_PHASE_LIMIT";
            d.responseInstruction="현재 session phase에서는 추가 질문보다 지금까지 이해한 내용을 정리하는 것이 우선이다. "
                    +SessionPhaseTherapeuticPacingRC8.responseInstruction(phaseBeforeAsk);
            finish(c,st,d,text); return d;
        }

        if(q!=null){
            d.move="ASK"; d.target=q.target; d.unitId=q.id; d.directText=q.question;
            d.informationGain=selection.unit==q?selection.informationGain:0.0;
            d.questionRationale=selection.unit==q?selection.rationale:"legacy fallback";
            d.responseInstruction="분석/조언 없이 고가치 질문 하나만 출력. 이미 말한 정보 재질문 금지.";
            st.askedIds.add(q.id); if(!q.target.isEmpty()){st.lastTarget=q.target;st.lastAskedTarget=q.target;}
        }else{
            d.move="FORMULATE"; d.responseInstruction="추가 질문보다 잠정 formulation이 낫다.";
        }
        finish(c,st,d,text);                 ProvenanceLineageGraphAuditTraceRC12.Result provenanceLineage =
                ProvenanceLineageGraphAuditTraceRC12.update(c,d);

        d.provenanceLineageEvaluated=provenanceLineage.evaluated;
        d.provenanceLineageUpdated=provenanceLineage.updated;
        d.provenanceLineageNodesAdded=provenanceLineage.nodesAdded;
        d.provenanceLineageEdgesAdded=provenanceLineage.edgesAdded;
        d.provenanceLineageExperimentId=provenanceLineage.activeExperimentId;
        d.provenanceLineagePolicyKey=provenanceLineage.activePolicyKey;
        d.provenanceLineageRootKey=provenanceLineage.lineageRootKey;
        d.provenanceLineageReason=provenanceLineage.reason;
        d.provenanceLineageSummary=provenanceLineage.summary;

        String provenanceLineageInstruction=
                ProvenanceLineageGraphAuditTraceRC12.instruction(
                        provenanceLineage);
        if(provenanceLineageInstruction!=null
                && !provenanceLineageInstruction.isEmpty()){
            d.responseInstruction=
                    (d.responseInstruction==null
                            ?""
                            :d.responseInstruction+" ")
                            +provenanceLineageInstruction;
        }

        PolicyExplainabilityDecisionRationaleRC12.Result decisionRationale =
                PolicyExplainabilityDecisionRationaleRC12.compose(c,d);

        d.decisionRationaleEvaluated=decisionRationale.evaluated;
        d.decisionRationaleUsable=decisionRationale.usable;
        d.decisionRationalePolicyReferenced=decisionRationale.policyReferenced;
        d.decisionRationaleCurrentEvidencePrimary=decisionRationale.currentEvidencePrimary;
        d.decisionRationaleText=decisionRationale.rationale;
        d.decisionRationaleCompact=decisionRationale.compactReason;
        d.decisionRationaleSourceTier=decisionRationale.sourceTier;
        d.decisionRationaleReason=decisionRationale.reason;
        d.decisionRationaleSummary=decisionRationale.summary;

        DecisionRationaleFidelityEvidenceGroundingGateRC12.Result rationaleFidelity =
                DecisionRationaleFidelityEvidenceGroundingGateRC12.validate(
                        c,d,decisionRationale);

        d.decisionRationaleFidelityEvaluated=rationaleFidelity.evaluated;
        d.decisionRationaleFidelityRepaired=rationaleFidelity.repaired;
        d.decisionRationaleFidelityBlocked=rationaleFidelity.blocked;
        d.decisionRationaleMoveMismatch=rationaleFidelity.moveMismatch;
        d.decisionRationalePolicyOverclaim=rationaleFidelity.policyOverclaim;
        d.decisionRationaleUnsupportedCertainty=rationaleFidelity.unsupportedCertainty;
        d.decisionRationaleInternalJargonLeak=rationaleFidelity.internalJargonLeak;
        d.decisionRationaleEvidenceMismatch=rationaleFidelity.evidenceMismatch;
        d.decisionRationaleFidelityState=rationaleFidelity.state.name();
        d.decisionRationaleFinal=rationaleFidelity.finalRationale;
        d.decisionRationaleFidelityReason=rationaleFidelity.reason;
        d.decisionRationaleFidelitySummary=rationaleFidelity.summary;

                d.decisionTransitionMoveChanged=
                DecisionTransitionSnapshotContinuityRC13.meaningfulMoveTransition(d);
        d.decisionTransitionInterventionChanged=
                DecisionTransitionSnapshotContinuityRC13.meaningfulInterventionTransition(d);
        d.decisionTransitionTargetChanged=
                DecisionTransitionSnapshotContinuityRC13.meaningfulTargetTransition(d);
        d.decisionTransitionSummary=
                DecisionTransitionSnapshotContinuityRC13.transitionSummary(d);

        DecisionTransitionCauseAttributionRC13.Result decisionTransitionCause =
                DecisionTransitionCauseAttributionRC13.attribute(c,d);

        d.decisionTransitionCauseEvaluated=decisionTransitionCause.evaluated;
        d.decisionTransitionCauseDetected=decisionTransitionCause.transitionDetected;
        d.decisionTransitionPrimaryCause=decisionTransitionCause.primaryCause.name();
        d.decisionTransitionSecondaryCause=decisionTransitionCause.secondaryCause;
        d.decisionTransitionFromState=decisionTransitionCause.fromState;
        d.decisionTransitionToState=decisionTransitionCause.toState;
        d.decisionTransitionHumanReason=decisionTransitionCause.humanReason;
        d.decisionTransitionCauseReason=decisionTransitionCause.reason;
        d.decisionTransitionCauseSummary=decisionTransitionCause.summary;

        String transitionCauseInstruction=
                DecisionTransitionCauseAttributionRC13.instruction(
                        decisionTransitionCause);
        if(transitionCauseInstruction!=null
                && !transitionCauseInstruction.isEmpty()){
            d.responseInstruction=
                    (d.responseInstruction==null
                            ?""
                            :d.responseInstruction+" ")
                            +transitionCauseInstruction;
        }

        DecisionTransitionCauseFidelityConfidenceGateRC13.Result transitionCauseFidelity =
                DecisionTransitionCauseFidelityConfidenceGateRC13.validate(
                        c,d,decisionTransitionCause);

        d.decisionTransitionCauseFidelityEvaluated=transitionCauseFidelity.evaluated;
        d.decisionTransitionCauseFidelityRepaired=transitionCauseFidelity.repaired;
        d.decisionTransitionCauseFidelityBlocked=transitionCauseFidelity.blocked;
        d.decisionTransitionMultiCause=transitionCauseFidelity.multiCause;
        d.decisionTransitionCauseFidelityState=transitionCauseFidelity.state.name();
        d.decisionTransitionCauseConfidence=transitionCauseFidelity.confidence.name();
        d.decisionTransitionFidelityPrimaryCause=transitionCauseFidelity.primaryCause;
        d.decisionTransitionFidelitySecondaryCause=transitionCauseFidelity.secondaryCause;
        d.decisionTransitionFidelityHumanReason=transitionCauseFidelity.finalHumanReason;
        d.decisionTransitionCauseFidelityReason=transitionCauseFidelity.reason;
        d.decisionTransitionCauseFidelitySummary=transitionCauseFidelity.summary;

        if(!transitionCauseFidelity.finalHumanReason.isEmpty()){
            d.decisionTransitionHumanReason=
                    transitionCauseFidelity.finalHumanReason;
            d.decisionTransitionPrimaryCause=
                    transitionCauseFidelity.primaryCause;
            d.decisionTransitionSecondaryCause=
                    transitionCauseFidelity.secondaryCause;
        }

        String transitionCauseFidelityInstruction=
                DecisionTransitionCauseFidelityConfidenceGateRC13.instruction(
                        transitionCauseFidelity);
        if(transitionCauseFidelityInstruction!=null
                && !transitionCauseFidelityInstruction.isEmpty()){
            d.responseInstruction=
                    (d.responseInstruction==null
                            ?""
                            :d.responseInstruction+" ")
                            +transitionCauseFidelityInstruction;
        }

        CorrectionProvenanceIntegrityBackfillQuarantineRC14.Result correctionProvenanceIntegrity =
                CorrectionProvenanceIntegrityBackfillQuarantineRC14.validateAndBackfill(c);

        d.correctionProvenanceIntegrityEvaluated=
                correctionProvenanceIntegrity.evaluated;
        d.correctionProvenanceIntegrityRepaired=
                correctionProvenanceIntegrity.repaired;
        d.correctionProvenanceIntegrityQuarantined=
                correctionProvenanceIntegrity.quarantined;
        d.correctionProvenanceIntegrityRowsChecked=
                correctionProvenanceIntegrity.rowsChecked;
        d.correctionProvenanceIntegrityRowsValid=
                correctionProvenanceIntegrity.rowsValid;
        d.correctionProvenanceIntegrityRowsRepaired=
                correctionProvenanceIntegrity.rowsRepaired;
        d.correctionProvenanceIntegrityRowsQuarantined=
                correctionProvenanceIntegrity.rowsQuarantined;
        d.correctionProvenanceIntegrityLegacyUnresolved=
                correctionProvenanceIntegrity.rowsLegacyUnresolved;
        d.correctionProvenanceIntegrityReason=
                correctionProvenanceIntegrity.reason;
        d.correctionProvenanceIntegritySummary=
                correctionProvenanceIntegrity.summary;

        String correctionProvenanceIntegrityInstruction=
                CorrectionProvenanceIntegrityBackfillQuarantineRC14.instruction(
                        correctionProvenanceIntegrity);

        if(correctionProvenanceIntegrityInstruction!=null
                &&!correctionProvenanceIntegrityInstruction.isEmpty()){
            d.responseInstruction=
                    (d.responseInstruction==null
                            ?""
                            :d.responseInstruction+" ")
                    +correctionProvenanceIntegrityInstruction;
        }

        CooldownEvidenceLedgerIntegrityAntiSyntheticRC14.Result cooldownEvidenceIntegrity =
                CooldownEvidenceLedgerIntegrityAntiSyntheticRC14.validate(c);

        d.cooldownEvidenceIntegrityEvaluated=
                cooldownEvidenceIntegrity.evaluated;
        d.cooldownEvidenceIntegrityRepaired=
                cooldownEvidenceIntegrity.repaired;
        d.cooldownEvidenceIntegrityQuarantined=
                cooldownEvidenceIntegrity.quarantined;
        d.cooldownEvidenceSyntheticBlocked=
                cooldownEvidenceIntegrity.syntheticBlocked;
        d.cooldownEvidenceIntegrityRowsChecked=
                cooldownEvidenceIntegrity.rowsChecked;
        d.cooldownEvidenceIntegrityRowsValid=
                cooldownEvidenceIntegrity.rowsValid;
        d.cooldownEvidenceIntegrityRowsRepaired=
                cooldownEvidenceIntegrity.rowsRepaired;
        d.cooldownEvidenceIntegrityRowsQuarantined=
                cooldownEvidenceIntegrity.rowsQuarantined;
        d.cooldownEvidenceSyntheticBlockedRows=
                cooldownEvidenceIntegrity.rowsSyntheticBlocked;
        d.cooldownEvidenceIntegrityReason=
                cooldownEvidenceIntegrity.reason;
        d.cooldownEvidenceIntegritySummary=
                cooldownEvidenceIntegrity.summary;

        String cooldownEvidenceIntegrityInstruction=
                CooldownEvidenceLedgerIntegrityAntiSyntheticRC14.instruction(
                        cooldownEvidenceIntegrity);

        if(cooldownEvidenceIntegrityInstruction!=null
                &&!cooldownEvidenceIntegrityInstruction.isEmpty()){
            d.responseInstruction=
                    (d.responseInstruction==null
                            ?""
                            :d.responseInstruction+" ")
                    +cooldownEvidenceIntegrityInstruction;
        }

        CooldownEvidenceIndependenceParaphraseGuardRC14.Result cooldownEvidenceIndependence =
                CooldownEvidenceIndependenceParaphraseGuardRC14.evaluate(
                        c,d,text);

        d.cooldownEvidenceIndependenceEvaluated=
                cooldownEvidenceIndependence.evaluated;
        d.cooldownEvidenceIndependent=
                cooldownEvidenceIndependence.independent;
        d.cooldownEvidenceDuplicate=
                cooldownEvidenceIndependence.duplicate;
        d.cooldownEvidenceNearDuplicate=
                cooldownEvidenceIndependence.nearDuplicate;
        d.cooldownEvidenceIndependenceBlocked=
                cooldownEvidenceIndependence.blocked;
        d.cooldownEvidenceIndependenceState=
                cooldownEvidenceIndependence.state.name();
        d.cooldownEvidenceIndependenceMatchedEvidenceId=
                cooldownEvidenceIndependence.matchedEvidenceId;
        d.cooldownEvidenceSimilarity=
                String.valueOf(cooldownEvidenceIndependence.similarity);
        d.cooldownEvidenceIndependenceReason=
                cooldownEvidenceIndependence.reason;
        d.cooldownEvidenceIndependenceSummary=
                cooldownEvidenceIndependence.summary;

        String cooldownEvidenceIndependenceInstruction=
                CooldownEvidenceIndependenceParaphraseGuardRC14.instruction(
                        cooldownEvidenceIndependence);

        if(cooldownEvidenceIndependenceInstruction!=null
                &&!cooldownEvidenceIndependenceInstruction.isEmpty()){
            d.responseInstruction=
                    (d.responseInstruction==null
                            ?""
                            :d.responseInstruction+" ")
                    +cooldownEvidenceIndependenceInstruction;
        }

        CooldownEvidenceTemporalIndependenceBurstGuardRC14.Result cooldownEvidenceTemporal =
                CooldownEvidenceTemporalIndependenceBurstGuardRC14.evaluate(
                        c,d);

        d.cooldownEvidenceTemporalIndependenceEvaluated=
                cooldownEvidenceTemporal.evaluated;
        d.cooldownEvidenceTemporallyIndependent=
                cooldownEvidenceTemporal.temporallyIndependent;
        d.cooldownEvidenceBurstBlocked=
                cooldownEvidenceTemporal.burstBlocked;
        d.cooldownEvidenceTemporalWaiting=
                cooldownEvidenceTemporal.waiting;
        d.cooldownEvidenceTemporalIndependenceState=
                cooldownEvidenceTemporal.state.name();
        d.cooldownEvidenceTemporalTransitionKey=
                cooldownEvidenceTemporal.transitionKey;
        d.cooldownEvidenceTemporalCurrentCause=
                cooldownEvidenceTemporal.currentCause;
        d.cooldownEvidenceTemporalLastEligibleAt=
                cooldownEvidenceTemporal.lastEligibleEvidenceAt;
        d.cooldownEvidenceTemporalSeparationMs=
                cooldownEvidenceTemporal.separationMs;
        d.cooldownEvidenceTemporalReason=
                cooldownEvidenceTemporal.reason;
        d.cooldownEvidenceTemporalSummary=
                cooldownEvidenceTemporal.summary;

        String cooldownEvidenceTemporalInstruction=
                CooldownEvidenceTemporalIndependenceBurstGuardRC14.instruction(
                        cooldownEvidenceTemporal);

        if(cooldownEvidenceTemporalInstruction!=null
                &&!cooldownEvidenceTemporalInstruction.isEmpty()){
            d.responseInstruction=
                    (d.responseInstruction==null
                            ?""
                            :d.responseInstruction+" ")
                    +cooldownEvidenceTemporalInstruction;
        }

        CooldownCleanConfirmationEvidenceLedgerRC14.Result cooldownEvidenceLedger =
                CooldownCleanConfirmationEvidenceLedgerRC14.commitCurrentTurn(
                        c,d,text,cooldownEvidenceIndependence,cooldownEvidenceTemporal);

        d.cooldownEvidenceLedgerEvaluated=
                cooldownEvidenceLedger.evaluated;
        d.cooldownEvidenceLedgerCommitted=
                cooldownEvidenceLedger.committed;
        d.cooldownEvidenceLedgerDuplicate=
                cooldownEvidenceLedger.duplicate;
        d.cooldownEvidenceLedgerEligible=
                cooldownEvidenceLedger.eligible;
        d.cooldownEvidenceLedgerContradiction=
                cooldownEvidenceLedger.contradiction;
        d.cooldownEvidenceLedgerState=
                cooldownEvidenceLedger.state.name();
        d.cooldownEvidenceLedgerEvidenceId=
                cooldownEvidenceLedger.evidenceId;
        d.cooldownEvidenceLedgerIdentity=
                cooldownEvidenceLedger.ledgerIdentity;
        d.cooldownEvidenceLedgerTransitionKey=
                cooldownEvidenceLedger.transitionKey;
        d.cooldownEvidenceLedgerReason=
                cooldownEvidenceLedger.reason;
        d.cooldownEvidenceLedgerSummary=
                cooldownEvidenceLedger.summary;

        String cooldownEvidenceLedgerInstruction=
                CooldownCleanConfirmationEvidenceLedgerRC14.instruction(
                        cooldownEvidenceLedger);

        if(cooldownEvidenceLedgerInstruction!=null
                &&!cooldownEvidenceLedgerInstruction.isEmpty()){
            d.responseInstruction=
                    (d.responseInstruction==null
                            ?""
                            :d.responseInstruction+" ")
                    +cooldownEvidenceLedgerInstruction;
        }

        JSONObject cooldownDiversityFormulation =
                CentralTherapyProfile.loadFormulation(c);

        String cooldownDiversityContext =
                cooldownDiversityFormulation.optString(
                        "current_context_scope",
                        "UNKNOWN");

        String cooldownDiversityTransition =
                (d.decisionTransitionFromState==null
                        ?""
                        :d.decisionTransitionFromState)
                +"->"
                +(d.decisionTransitionToState==null
                        ?""
                        :d.decisionTransitionToState)
                +"::"
                +cooldownDiversityContext;

        String cooldownDiversityCause =
                d.transitionExplanationCorrectedCause==null
                        ?""
                        :d.transitionExplanationCorrectedCause;

        CooldownEvidenceTemporalDiversityMultiDayRC14.Result cooldownEvidenceTemporalDiversity =
                CooldownEvidenceTemporalDiversityMultiDayRC14.evaluate(
                        c,
                        cooldownDiversityTransition,
                        cooldownDiversityCause);

        d.cooldownEvidenceTemporalDiversityEvaluated=
                cooldownEvidenceTemporalDiversity.evaluated;
        d.cooldownEvidenceTemporalDiversityThresholdMet=
                cooldownEvidenceTemporalDiversity.thresholdMet;
        d.cooldownEvidenceTemporalDiversityCleanEvidenceCount=
                cooldownEvidenceTemporalDiversity.cleanEvidenceCount;
        d.cooldownEvidenceTemporalDiversityDistinctDays=
                cooldownEvidenceTemporalDiversity.distinctDayCount;
        d.cooldownEvidenceTemporalDiversityState=
                cooldownEvidenceTemporalDiversity.state.name();
        d.cooldownEvidenceTemporalDiversityTransitionKey=
                cooldownEvidenceTemporalDiversity.transitionKey;
        d.cooldownEvidenceTemporalDiversityCause=
                cooldownEvidenceTemporalDiversity.quarantinedCause;
        d.cooldownEvidenceTemporalDiversityReason=
                cooldownEvidenceTemporalDiversity.reason;
        d.cooldownEvidenceTemporalDiversitySummary=
                cooldownEvidenceTemporalDiversity.summary;

        String cooldownEvidenceTemporalDiversityInstruction=
                CooldownEvidenceTemporalDiversityMultiDayRC14.instruction(
                        cooldownEvidenceTemporalDiversity);

        if(cooldownEvidenceTemporalDiversityInstruction!=null
                &&!cooldownEvidenceTemporalDiversityInstruction.isEmpty()){
            d.responseInstruction=
                    (d.responseInstruction==null
                            ?""
                            :d.responseInstruction+" ")
                    +cooldownEvidenceTemporalDiversityInstruction;
        }

        CorrectionProvenanceRequarantineCooldownRC14.Result requarantineCooldown =
                CorrectionProvenanceRequarantineCooldownRC14.evaluate(
                        c,d);

        d.requarantineCooldownEvaluated=
                requarantineCooldown.evaluated;
        d.requarantineCooldownActive=
                requarantineCooldown.cooldownActive;
        d.requarantineCooldownReleased=
                requarantineCooldown.released;
        d.requarantineLoopBlocked=
                requarantineCooldown.loopBlocked;
        d.requarantineCooldownState=
                requarantineCooldown.state.name();
        d.requarantineCooldownTransitionKey=
                requarantineCooldown.transitionKey;
        d.requarantineCooldownQuarantinedCause=
                requarantineCooldown.quarantinedCause;
        d.requarantineCooldownCurrentCause=
                requarantineCooldown.currentCause;
        d.requarantineCooldownCleanConfirmations=
                requarantineCooldown.cleanConfirmations;
        d.requarantineCooldownContradictions=
                requarantineCooldown.contradictions;
        d.requarantineCooldownReason=
                requarantineCooldown.reason;
        d.requarantineCooldownSummary=
                requarantineCooldown.summary;

        String requarantineCooldownInstruction=
                CorrectionProvenanceRequarantineCooldownRC14.instruction(
                        requarantineCooldown);

        if(requarantineCooldownInstruction!=null
                &&!requarantineCooldownInstruction.isEmpty()){
            d.responseInstruction=
                    (d.responseInstruction==null
                            ?""
                            :d.responseInstruction+" ")
                    +requarantineCooldownInstruction;
        }

        QuarantinedCorrectionProvenanceReviewReinstatementRC14.Result correctionProvenanceReinstatement =
                QuarantinedCorrectionProvenanceReviewReinstatementRC14.review(
                        c,d,text);

        if(correctionProvenanceReinstatement.ready
                &&CorrectionProvenanceRequarantineCooldownRC14
                    .blocksReinstatement(requarantineCooldown)){
            correctionProvenanceReinstatement.ready=false;
            correctionProvenanceReinstatement.blocked=true;
            correctionProvenanceReinstatement.state=
                    QuarantinedCorrectionProvenanceReviewReinstatementRC14.State.REINSTATEMENT_BLOCKED;
            correctionProvenanceReinstatement.reason=
                    "REQUARANTINE_COOLDOWN_BLOCK";
        }

        CorrectionProvenanceReinstatementIdempotencyRC14.Result correctionReinstatementIdempotency =
                CorrectionProvenanceReinstatementIdempotencyRC14.evaluate(
                        c,d,correctionProvenanceReinstatement);

        if(correctionProvenanceReinstatement.ready
                &&correctionReinstatementIdempotency.allow){
            QuarantinedCorrectionProvenanceReviewReinstatementRC14.reinstate(
                    c,d,correctionProvenanceReinstatement,text);
        }

        CorrectionProvenanceReinstatementIdempotencyRC14.record(
                c,
                correctionReinstatementIdempotency,
                correctionProvenanceReinstatement.reinstatedRows);

        d.correctionProvenanceReinstatementIdempotencyEvaluated=
                correctionReinstatementIdempotency.evaluated;
        d.correctionProvenanceReinstatementIdempotencyAllow=
                correctionReinstatementIdempotency.allow;
        d.correctionProvenanceReinstatementDuplicateSuppressed=
                correctionReinstatementIdempotency.duplicateSuppressed;
        d.correctionProvenanceReinstatementAlreadyActive=
                correctionReinstatementIdempotency.alreadyActive;
        d.correctionProvenanceReinstatementIdempotencyBlocked=
                correctionReinstatementIdempotency.blocked;
        d.correctionProvenanceReinstatementIdempotencyState=
                correctionReinstatementIdempotency.state.name();
        d.correctionProvenanceReinstatementIdentity=
                correctionReinstatementIdempotency.identity;
        d.correctionProvenanceReinstatementIdempotencyReason=
                correctionReinstatementIdempotency.reason;
        d.correctionProvenanceReinstatementIdempotencySummary=
                correctionReinstatementIdempotency.summary;

        String correctionReinstatementIdempotencyInstruction=
                CorrectionProvenanceReinstatementIdempotencyRC14.instruction(
                        correctionReinstatementIdempotency);

        if(correctionReinstatementIdempotencyInstruction!=null
                &&!correctionReinstatementIdempotencyInstruction.isEmpty()){
            d.responseInstruction=
                    (d.responseInstruction==null
                            ?""
                            :d.responseInstruction+" ")
                    +correctionReinstatementIdempotencyInstruction;
        }

        d.correctionProvenanceReinstatementEvaluated=
                correctionProvenanceReinstatement.evaluated;
        d.correctionProvenanceReinstatementReviewRequired=
                correctionProvenanceReinstatement.reviewRequired;
        d.correctionProvenanceReinstatementReady=
                correctionProvenanceReinstatement.ready;
        d.correctionProvenanceReinstated=
                correctionProvenanceReinstatement.reinstated;
        d.correctionProvenanceReinstatementBlocked=
                correctionProvenanceReinstatement.blocked;
        d.correctionProvenanceReinstatementMatchingRows=
                correctionProvenanceReinstatement.matchingRows;
        d.correctionProvenanceReinstatedRows=
                correctionProvenanceReinstatement.reinstatedRows;
        d.correctionProvenanceReinstatementState=
                correctionProvenanceReinstatement.state.name();
        d.correctionProvenanceReinstatementTransitionKey=
                correctionProvenanceReinstatement.transitionKey;
        d.correctionProvenanceReinstatementContext=
                correctionProvenanceReinstatement.contextScope;
        d.correctionProvenanceReinstatementCause=
                correctionProvenanceReinstatement.correctedCause;
        d.correctionProvenanceReinstatementReason=
                correctionProvenanceReinstatement.reason;
        d.correctionProvenanceReinstatementSummary=
                correctionProvenanceReinstatement.summary;

        String correctionProvenanceReinstatementInstruction=
                QuarantinedCorrectionProvenanceReviewReinstatementRC14.instruction(
                        correctionProvenanceReinstatement);

        if(correctionProvenanceReinstatementInstruction!=null
                &&!correctionProvenanceReinstatementInstruction.isEmpty()){
            d.responseInstruction=
                    (d.responseInstruction==null
                            ?""
                            :d.responseInstruction+" ")
                    +correctionProvenanceReinstatementInstruction;
        }

        PostReinstatementCorrectionVerificationRC14.Result postReinstatementVerification =
                PostReinstatementCorrectionVerificationRC14.evaluate(
                        c,d);

        d.postReinstatementVerificationEvaluated=
                postReinstatementVerification.evaluated;
        d.postReinstatementVerificationRequired=
                postReinstatementVerification.verifyRequired;
        d.postReinstatementVerifiedKeep=
                postReinstatementVerification.verifiedKeep;
        d.postReinstatementRequarantined=
                postReinstatementVerification.requarantined;
        d.postReinstatementVerificationState=
                postReinstatementVerification.state.name();
        d.postReinstatementTransitionKey=
                postReinstatementVerification.transitionKey;
        d.postReinstatementReinstatedCause=
                postReinstatementVerification.reinstatedCause;
        d.postReinstatementCurrentCause=
                postReinstatementVerification.currentCause;
        d.postReinstatementVerificationReason=
                postReinstatementVerification.reason;
        d.postReinstatementVerificationSummary=
                postReinstatementVerification.summary;

        String postReinstatementVerificationInstruction=
                PostReinstatementCorrectionVerificationRC14.instruction(
                        postReinstatementVerification);

        if(postReinstatementVerificationInstruction!=null
                &&!postReinstatementVerificationInstruction.isEmpty()){
            d.responseInstruction=
                    (d.responseInstruction==null
                            ?""
                            :d.responseInstruction+" ")
                    +postReinstatementVerificationInstruction;
        }

        TransitionCorrectionMemoryBoundaryGuardRC13.Result transitionCorrectionMemory =
                TransitionCorrectionMemoryBoundaryGuardRC13.retrieve(c,d);

        d.transitionCorrectionMemoryEvaluated=transitionCorrectionMemory.evaluated;
        d.transitionCorrectionMemoryReusable=transitionCorrectionMemory.reusable;
        d.transitionCorrectionMemoryExact=transitionCorrectionMemory.exact;
        d.transitionCorrectionMemoryBlocked=transitionCorrectionMemory.blocked;
        d.transitionCorrectionMemoryMatch=transitionCorrectionMemory.match.name();
        d.transitionCorrectionMemoryCause=transitionCorrectionMemory.correctedCause;
        d.transitionCorrectionMemoryReasonText=transitionCorrectionMemory.correctedReason;
        d.transitionCorrectionMemorySourceContext=transitionCorrectionMemory.sourceContext;
        d.transitionCorrectionMemoryCurrentContext=transitionCorrectionMemory.currentContext;
        d.transitionCorrectionMemoryReason=transitionCorrectionMemory.reason;
        d.transitionCorrectionMemorySummary=transitionCorrectionMemory.summary;

        if(TransitionCorrectionMemoryBoundaryGuardRC13
                .shouldApply(transitionCorrectionMemory)
                &&!transitionCorrectionMemory.correctedReason.isEmpty()){
            d.decisionTransitionHumanReason=
                    transitionCorrectionMemory.correctedReason;
            d.decisionTransitionPrimaryCause=
                    transitionCorrectionMemory.correctedCause;
        }

        String transitionCorrectionMemoryInstruction=
                TransitionCorrectionMemoryBoundaryGuardRC13.instruction(
                        transitionCorrectionMemory);
        if(transitionCorrectionMemoryInstruction!=null
                &&!transitionCorrectionMemoryInstruction.isEmpty()){
            d.responseInstruction=
                    (d.responseInstruction==null
                            ?""
                            :d.responseInstruction+" ")
                    +transitionCorrectionMemoryInstruction;
        }

        TransitionExplanationCorrectionReconciliationRC13.Result transitionExplanationCorrection =
                TransitionExplanationCorrectionReconciliationRC13.reconcile(
                        c,d,text);

        d.transitionExplanationCorrectionEvaluated=
                transitionExplanationCorrection.evaluated;
        d.transitionExplanationCorrectionDetected=
                transitionExplanationCorrection.correctionDetected;
        d.transitionExplanationClarificationRequired=
                transitionExplanationCorrection.clarificationRequired;
        d.transitionExplanationCorrectionApplied=
                transitionExplanationCorrection.correctionApplied;
        d.transitionExplanationCorrectionRejected=
                transitionExplanationCorrection.correctionRejected;
        d.transitionExplanationCorrectionState=
                transitionExplanationCorrection.state.name();
        d.transitionExplanationPriorCause=
                transitionExplanationCorrection.priorCause;
        d.transitionExplanationCorrectedCause=
                transitionExplanationCorrection.correctedCause;
        d.transitionExplanationCorrectedReason=
                transitionExplanationCorrection.correctedReason;
        d.transitionExplanationClarificationQuestion=
                transitionExplanationCorrection.clarificationQuestion;
        d.transitionExplanationCorrectionReason=
                transitionExplanationCorrection.reason;
        d.transitionExplanationCorrectionSummary=
                transitionExplanationCorrection.summary;

        if(transitionExplanationCorrection.correctionApplied){
            d.decisionTransitionPrimaryCause=
                    transitionExplanationCorrection.correctedCause;
            d.decisionTransitionHumanReason=
                    transitionExplanationCorrection.correctedReason;
            d.decisionTransitionFidelityPrimaryCause=
                    transitionExplanationCorrection.correctedCause;
            d.decisionTransitionFidelityHumanReason=
                    transitionExplanationCorrection.correctedReason;
            TransitionCorrectionMemoryBoundaryGuardRC13
                    .annotateLatestCorrectionWithContext(c,d);
        }

        TransitionCorrectionMemoryReactivationRevalidationRC13.Result transitionCorrectionRevalidation =
                TransitionCorrectionMemoryReactivationRevalidationRC13.evaluate(
                        c,d);

        d.transitionCorrectionRevalidationEvaluated=
                transitionCorrectionRevalidation.evaluated;
        d.transitionCorrectionRevalidationPending=
                transitionCorrectionRevalidation.pending;
        d.transitionCorrectionReactivated=
                transitionCorrectionRevalidation.reactivated;
        d.transitionCorrectionRevalidationState=
                transitionCorrectionRevalidation.state.name();
        d.transitionCorrectionRevalidationKey=
                transitionCorrectionRevalidation.transitionKey;
        d.transitionCorrectionRevalidationContext=
                transitionCorrectionRevalidation.contextScope;
        d.transitionCorrectionRevalidationCause=
                transitionCorrectionRevalidation.correctedCause;
        d.transitionCorrectionRevalidationConfirmations=
                transitionCorrectionRevalidation.confirmations;
        d.transitionCorrectionRevalidationContradictions=
                transitionCorrectionRevalidation.contradictions;
        d.transitionCorrectionRevalidationReason=
                transitionCorrectionRevalidation.reason;
        d.transitionCorrectionRevalidationSummary=
                transitionCorrectionRevalidation.summary;

        String transitionCorrectionRevalidationInstruction=
                TransitionCorrectionMemoryReactivationRevalidationRC13.instruction(
                        transitionCorrectionRevalidation);

        if(transitionCorrectionRevalidationInstruction!=null
                &&!transitionCorrectionRevalidationInstruction.isEmpty()){
            d.responseInstruction=
                    (d.responseInstruction==null
                            ?""
                            :d.responseInstruction+" ")
                    +transitionCorrectionRevalidationInstruction;
        }


        if(TransitionExplanationCorrectionReconciliationRC13
                .shouldForceClarification(
                        transitionExplanationCorrection)){
            d.move="ASK";
            d.targetVariable=
                    "transition_explanation_correction";
            d.responseInstruction=
                    (d.responseInstruction==null
                            ?""
                            :d.responseInstruction+" ")
                    +"TRANSITION_EXPLANATION_CORRECTION_ONLY=true. "
                    +"다른 개입이나 새 해석을 추가하지 말고 확인 질문 1개만 한다: "
                    +transitionExplanationCorrection.clarificationQuestion;
        }

        TransitionCorrectionMemoryConflictResolutionRetirementRC13.Result transitionCorrectionConflict =
                TransitionCorrectionMemoryConflictResolutionRetirementRC13.resolve(
                        c,d);

        d.transitionCorrectionConflictEvaluated=
                transitionCorrectionConflict.evaluated;
        d.transitionCorrectionConflicted=
                transitionCorrectionConflict.conflicted;
        d.transitionCorrectionReplacementPending=
                transitionCorrectionConflict.replacementPending;
        d.transitionCorrectionReplaced=
                transitionCorrectionConflict.replaced;
        d.transitionCorrectionRetired=
                transitionCorrectionConflict.retired;
        d.transitionCorrectionConflictState=
                transitionCorrectionConflict.state.name();
        d.transitionCorrectionConflictKey=
                transitionCorrectionConflict.transitionKey;
        d.transitionCorrectionConflictIncumbent=
                transitionCorrectionConflict.incumbentCause;
        d.transitionCorrectionConflictChallenger=
                transitionCorrectionConflict.challengerCause;
        d.transitionCorrectionConflictIncumbentCount=
                transitionCorrectionConflict.incumbentCount;
        d.transitionCorrectionConflictChallengerCount=
                transitionCorrectionConflict.challengerCount;
        d.transitionCorrectionConflictDistinctCauses=
                transitionCorrectionConflict.distinctCauseCount;
        d.transitionCorrectionConflictActiveCause=
                transitionCorrectionConflict.activeCause;
        d.transitionCorrectionConflictActiveReason=
                transitionCorrectionConflict.activeReason;
        d.transitionCorrectionConflictReason=
                transitionCorrectionConflict.reason;
        d.transitionCorrectionConflictSummary=
                transitionCorrectionConflict.summary;

        if(TransitionCorrectionMemoryConflictResolutionRetirementRC13
                .reusable(transitionCorrectionConflict)
                &&!transitionCorrectionConflict.activeReason.isEmpty()){
            d.decisionTransitionHumanReason=
                    transitionCorrectionConflict.activeReason;
            d.decisionTransitionPrimaryCause=
                    transitionCorrectionConflict.activeCause;
        }

        if(TransitionCorrectionMemoryConflictResolutionRetirementRC13
                .mustBlock(transitionCorrectionConflict)){
            d.transitionCorrectionMemoryReusable=false;
            d.transitionCorrectionMemoryBlocked=true;
        }

        String transitionCorrectionConflictInstruction=
                TransitionCorrectionMemoryConflictResolutionRetirementRC13.instruction(
                        transitionCorrectionConflict);

        if(transitionCorrectionConflictInstruction!=null
                &&!transitionCorrectionConflictInstruction.isEmpty()){
            d.responseInstruction=
                    (d.responseInstruction==null
                            ?""
                            :d.responseInstruction+" ")
                    +transitionCorrectionConflictInstruction;
        }

        String transitionCorrectionInstruction=
                TransitionExplanationCorrectionReconciliationRC13.instruction(
                        transitionExplanationCorrection);

        if(transitionCorrectionInstruction!=null
                &&!transitionCorrectionInstruction.isEmpty()){
            d.responseInstruction=
                    (d.responseInstruction==null
                            ?""
                            :d.responseInstruction+" ")
                    +transitionCorrectionInstruction;
        }

        TransitionCorrectionFreshEvidenceSupremacyRC13.Result correctionFreshEvidence =
                TransitionCorrectionFreshEvidenceSupremacyRC13.arbitrate(
                        c,d,text);

        d.transitionCorrectionFreshEvidenceEvaluated=
                correctionFreshEvidence.evaluated;
        d.transitionCorrectionMemoryAllowed=
                correctionFreshEvidence.memoryAllowed;
        d.transitionCorrectionCurrentTurnOverride=
                correctionFreshEvidence.currentTurnOverride;
        d.transitionCorrectionFreshEvidenceBlocked=
                correctionFreshEvidence.blocked;
        d.transitionCorrectionFreshEvidenceState=
                correctionFreshEvidence.state.name();
        d.transitionCorrectionFreshEvidenceMemoryCause=
                correctionFreshEvidence.memoryCause;
        d.transitionCorrectionFreshEvidenceCurrentCause=
                correctionFreshEvidence.currentCause;
        d.transitionCorrectionFreshEvidenceEffectiveCause=
                correctionFreshEvidence.effectiveCause;
        d.transitionCorrectionFreshEvidenceEffectiveReason=
                correctionFreshEvidence.effectiveReason;
        d.transitionCorrectionFreshEvidenceReason=
                correctionFreshEvidence.reason;
        d.transitionCorrectionFreshEvidenceSummary=
                correctionFreshEvidence.summary;

        if(correctionFreshEvidence.currentTurnOverride){
            if(!correctionFreshEvidence.effectiveCause.isEmpty()){
                d.decisionTransitionPrimaryCause=
                        correctionFreshEvidence.effectiveCause;
                d.decisionTransitionHumanReason=
                        correctionFreshEvidence.effectiveReason;
            }else{
                d.transitionCorrectionMemoryReusable=false;
                d.transitionCorrectionMemoryBlocked=true;
            }
        }else if(TransitionCorrectionFreshEvidenceSupremacyRC13
                .memoryMayInfluence(correctionFreshEvidence)){
            d.decisionTransitionPrimaryCause=
                    correctionFreshEvidence.effectiveCause;
            d.decisionTransitionHumanReason=
                    correctionFreshEvidence.effectiveReason;
        }

        String correctionFreshEvidenceInstruction=
                TransitionCorrectionFreshEvidenceSupremacyRC13.instruction(
                        correctionFreshEvidence);

        if(correctionFreshEvidenceInstruction!=null
                &&!correctionFreshEvidenceInstruction.isEmpty()){
            d.responseInstruction=
                    (d.responseInstruction==null
                            ?""
                            :d.responseInstruction+" ")
                    +correctionFreshEvidenceInstruction;
        }

        TransitionCorrectionOverrideIsolationCommitGuardRC13.Result correctionOverrideIsolation =
                TransitionCorrectionOverrideIsolationCommitGuardRC13.evaluate(
                        c,d);

        d.transitionCorrectionOverrideIsolationEvaluated=
                correctionOverrideIsolation.evaluated;
        d.transitionCorrectionOverrideEphemeral=
                correctionOverrideIsolation.ephemeral;
        d.transitionCorrectionCommitAllowed=
                correctionOverrideIsolation.commitAllowed;
        d.transitionCorrectionCommitBlocked=
                correctionOverrideIsolation.commitBlocked;
        d.transitionCorrectionDuplicateCommitSuppressed=
                correctionOverrideIsolation.duplicateSuppressed;
        d.transitionCorrectionOverrideIsolationState=
                correctionOverrideIsolation.state.name();
        d.transitionCorrectionCommitIdentity=
                correctionOverrideIsolation.commitIdentity;
        d.transitionCorrectionOverrideIsolationReason=
                correctionOverrideIsolation.reason;
        d.transitionCorrectionOverrideIsolationSummary=
                correctionOverrideIsolation.summary;

        if(TransitionCorrectionOverrideIsolationCommitGuardRC13
                .mayPersistCorrection(correctionOverrideIsolation)){
            TransitionCorrectionOverrideIsolationCommitGuardRC13
                    .recordCommitIdentity(c,correctionOverrideIsolation);
        }

        String correctionOverrideIsolationInstruction=
                TransitionCorrectionOverrideIsolationCommitGuardRC13.instruction(
                        correctionOverrideIsolation);

        if(correctionOverrideIsolationInstruction!=null
                &&!correctionOverrideIsolationInstruction.isEmpty()){
            d.responseInstruction=
                    (d.responseInstruction==null
                            ?""
                            :d.responseInstruction+" ")
                    +correctionOverrideIsolationInstruction;
        }

        ExplicitCorrectionCommitProvenanceIdentityRC13.Result correctionCommitProvenance =
                ExplicitCorrectionCommitProvenanceIdentityRC13.prepare(
                        c,d,text);

        if(correctionCommitProvenance.ready){
            ExplicitCorrectionCommitProvenanceIdentityRC13.commit(
                    c,d,correctionCommitProvenance);
        }

        d.transitionCorrectionCommitProvenanceEvaluated=
                correctionCommitProvenance.evaluated;
        d.transitionCorrectionCommitProvenanceReady=
                correctionCommitProvenance.ready;
        d.transitionCorrectionCommitProvenanceCommitted=
                correctionCommitProvenance.committed;
        d.transitionCorrectionCommitProvenanceBlocked=
                correctionCommitProvenance.blocked;
        d.transitionCorrectionCommitProvenanceDuplicate=
                correctionCommitProvenance.duplicate;
        d.transitionCorrectionCommitProvenanceState=
                correctionCommitProvenance.state.name();
        d.transitionCorrectionCommitEvidenceId=
                correctionCommitProvenance.evidenceId;
        d.transitionCorrectionCanonicalCommitKey=
                correctionCommitProvenance.canonicalCommitKey;
        d.transitionCorrectionCommitTransitionKey=
                correctionCommitProvenance.transitionKey;
        d.transitionCorrectionCommitContext=
                correctionCommitProvenance.contextScope;
        d.transitionCorrectionCommitProvenanceReason=
                correctionCommitProvenance.reason;
        d.transitionCorrectionCommitProvenanceSummary=
                correctionCommitProvenance.summary;

        String correctionCommitProvenanceInstruction=
                ExplicitCorrectionCommitProvenanceIdentityRC13.instruction(
                        correctionCommitProvenance);

        if(correctionCommitProvenanceInstruction!=null
                &&!correctionCommitProvenanceInstruction.isEmpty()){
            d.responseInstruction=
                    (d.responseInstruction==null
                            ?""
                            :d.responseInstruction+" ")
                    +correctionCommitProvenanceInstruction;
        }

        TransitionCorrectionLifecycleOrderingIntegrityRC14.Result correctionLifecycleIntegrity =
                TransitionCorrectionLifecycleOrderingIntegrityRC14.evaluate(d);

        d.transitionCorrectionLifecycleOrderingIntegrityEvaluated=
                correctionLifecycleIntegrity.evaluated;
        d.transitionCorrectionLifecycleRetired=
                correctionLifecycleIntegrity.retired;
        d.transitionCorrectionLifecycleOrderingIntegrityState=
                correctionLifecycleIntegrity.state.name();
        d.transitionCorrectionLifecycleOrderingIntegrityReason=
                correctionLifecycleIntegrity.reason;
        d.transitionCorrectionLifecycleOrderingIntegritySummary=
                correctionLifecycleIntegrity.summary;

        String correctionLifecycleIntegrityInstruction=
                TransitionCorrectionLifecycleOrderingIntegrityRC14.instruction(
                        correctionLifecycleIntegrity);

        if(correctionLifecycleIntegrityInstruction!=null
                &&!correctionLifecycleIntegrityInstruction.isEmpty()){
            d.responseInstruction=
                    (d.responseInstruction==null
                            ?""
                            :d.responseInstruction+" ")
                    +correctionLifecycleIntegrityInstruction;
        }

        ExplainabilityDeliveryTriggerPlacementVerbosityGateRC12.Result explainabilityDelivery =
                ExplainabilityDeliveryTriggerPlacementVerbosityGateRC12.decide(
                        c,d,text);

        d.explainabilityDeliveryEvaluated=explainabilityDelivery.evaluated;
        d.explainabilityShouldSurface=explainabilityDelivery.shouldSurface;
        d.explainabilityUserAskedWhy=explainabilityDelivery.userAskedWhy;
        d.explainabilityDecisionNeedsJustification=explainabilityDelivery.decisionNeedsJustification;
        d.explainabilityRecentRationaleShown=explainabilityDelivery.recentRationaleShown;
        d.explainabilitySuppressedForRepetition=explainabilityDelivery.suppressedForRepetition;
        d.explainabilityDeliveryMode=explainabilityDelivery.mode.name();
        d.explainabilityDeliveryText=explainabilityDelivery.text;
        d.explainabilityPlacement=explainabilityDelivery.placement;
        d.explainabilityMaxSentences=explainabilityDelivery.maxSentences;
        d.explainabilityDeliveryReason=explainabilityDelivery.reason;
        d.explainabilityDeliverySummary=explainabilityDelivery.summary;

        String explainabilityDeliveryInstruction=
                ExplainabilityDeliveryTriggerPlacementVerbosityGateRC12.instruction(
                        explainabilityDelivery);
        if(explainabilityDeliveryInstruction!=null
                && !explainabilityDeliveryInstruction.isEmpty()){
            d.responseInstruction=
                    (d.responseInstruction==null
                            ?""
                            :d.responseInstruction+" ")
                            +explainabilityDeliveryInstruction;
        }

        String rationaleFidelityInstruction=
                DecisionRationaleFidelityEvidenceGroundingGateRC12.instruction(
                        rationaleFidelity);
        if(rationaleFidelityInstruction!=null
                && !rationaleFidelityInstruction.isEmpty()){
            d.responseInstruction=
                    (d.responseInstruction==null
                            ?""
                            :d.responseInstruction+" ")
                            +rationaleFidelityInstruction;
        }

        String decisionRationaleInstruction=
                PolicyExplainabilityDecisionRationaleRC12.instruction(
                        decisionRationale);
        if(decisionRationaleInstruction!=null
                && !decisionRationaleInstruction.isEmpty()){
            d.responseInstruction=
                    (d.responseInstruction==null
                            ?""
                            :d.responseInstruction+" ")
                            +decisionRationaleInstruction;
        }

AdaptivePolicyLoopReleaseInvariantGateRC12.Result adaptiveReleaseGate =
                AdaptivePolicyLoopReleaseInvariantGateRC12.verify(c,d);

        d.adaptivePolicyReleaseGatePassed=adaptiveReleaseGate.passed;
        d.adaptivePolicyReleaseGateRepaired=adaptiveReleaseGate.repaired;
        d.adaptivePolicyReleaseOutcomeLeakBlocked=adaptiveReleaseGate.outcomeLeakBlocked;
        d.adaptivePolicyReleaseHierarchyLeakBlocked=adaptiveReleaseGate.hierarchyLeakBlocked;
        d.adaptivePolicyReleaseRetiredLeakBlocked=adaptiveReleaseGate.retiredLeakBlocked;
        d.adaptivePolicyReleaseExceptionLeakBlocked=adaptiveReleaseGate.exceptionLeakBlocked;
        d.adaptivePolicyReleaseBridgeOverrideBlocked=adaptiveReleaseGate.bridgeOverrideBlocked;
        d.adaptivePolicyReleaseViolationCount=adaptiveReleaseGate.violationCount;
        d.adaptivePolicyReleaseViolations=adaptiveReleaseGate.violations;
        d.adaptivePolicyReleaseSummary=adaptiveReleaseGate.summary;

        String adaptiveReleaseInstruction=
                AdaptivePolicyLoopReleaseInvariantGateRC12.instruction(
                        adaptiveReleaseGate);
        if(adaptiveReleaseInstruction!=null
                && !adaptiveReleaseInstruction.isEmpty()){
            d.responseInstruction=
                    (d.responseInstruction==null
                            ?""
                            :d.responseInstruction+" ")
                            +adaptiveReleaseInstruction;
        }

        DecisionTransitionSnapshotContinuityRC13.persistCurrent(c,d);

return d;
    }

    private static void finish(Context c,ClinicalSessionMemoryRC7.State s,ClinicalDecisionRC7 d,String text){
        s.lastMove=d.move; s.lastTarget=d.target; s.allianceRupture=d.allianceRupture||s.allianceRupture;
        for(String k:d.known) if(isTargetLike(k)) s.answeredTargets.add(k);
        // 질문 예산은 '연속 assessment 질문'에만 적용한다. formulation/intervention/safety 뒤에는 새 사이클을 연다.
        if (d.isFormulate() || d.isIntervene() || d.isStabilize()) s.askedIds.clear();
        ClinicalSessionMemoryRC7.save(c,s);
        d.confidence=d.hypotheses.size()>0&&d.missing.size()<=1?"MEDIUM":"LOW";

        SessionPhaseTherapeuticPacingRC8.State phase =
                SessionPhaseTherapeuticPacingRC8.infer(c,d,"");
        d.sessionPhase=phase.phase;
        d.therapeuticPacing=phase.pacing;
        d.phaseRationale=phase.rationale;
        d.phaseQuestionBudget=phase.questionBudget;

        String phaseInstruction =
                SessionPhaseTherapeuticPacingRC8.responseInstruction(phase);
        if(phaseInstruction!=null&&!phaseInstruction.isEmpty()){
            d.responseInstruction=(d.responseInstruction==null?"":d.responseInstruction+" ")
                    +phaseInstruction;
        }

        EvidenceAdmissionPromotionGateRC8.Result evidenceGate =
                EvidenceAdmissionPromotionGateRC8.evaluate(c);
        d.evidenceGateSummary=evidenceGate.summary;
        d.promotedEvidenceCount=evidenceGate.promoted;

        String gateInstruction=
                EvidenceAdmissionPromotionGateRC8.instruction(evidenceGate);
        if(gateInstruction!=null&&!gateInstruction.isEmpty()){
            d.responseInstruction=(d.responseInstruction==null?"":d.responseInstruction+" ")
                    +gateInstruction;
        }

        StableMemoryPromotionDemotionRC8.Result stableSync =
                StableMemoryPromotionDemotionRC8.sync(c);
        d.stableMemorySyncSummary=stableSync.summary;
        d.stableMemoryPromoted=stableSync.promoted;
        d.stableMemoryDemoted=stableSync.demoted;

        ContextBoundedPatternGeneralizationRC8.Result contextBoundary =
                ContextBoundedPatternGeneralizationRC8.apply(c,text);
        d.contextGeneralizationSummary=contextBoundary.summary;
        d.currentContextScope=contextBoundary.currentContext;
        d.contextBlockedMemoryCount=contextBoundary.blocked;

        String stableSyncInstruction =
                StableMemoryPromotionDemotionRC8.instruction(stableSync);
        if(stableSyncInstruction!=null&&!stableSyncInstruction.isEmpty()){
            d.responseInstruction=(d.responseInstruction==null?"":d.responseInstruction+" ")
                    +stableSyncInstruction;
        }

        String contextBoundaryInstruction =
                ContextBoundedPatternGeneralizationRC8.instruction(contextBoundary);
        if(contextBoundaryInstruction!=null&&!contextBoundaryInstruction.isEmpty()){
            d.responseInstruction=(d.responseInstruction==null?"":d.responseInstruction+" ")
                    +contextBoundaryInstruction;
        }

        FormulationCompressionCentralInsightRC8.Result centralInsight =
                FormulationCompressionCentralInsightRC8.build(c);
        FormulationCompressionCentralInsightRC8.apply(c,centralInsight);
        d.centralInsight=centralInsight.insight;
        d.centralMechanism=centralInsight.mechanism;
        d.centralInsightUsable=centralInsight.usable;

        String centralInsightInstruction =
                FormulationCompressionCentralInsightRC8.instruction(centralInsight);
        if(centralInsightInstruction!=null&&!centralInsightInstruction.isEmpty()){
            d.responseInstruction=(d.responseInstruction==null?"":d.responseInstruction+" ")
                    +centralInsightInstruction;
        }

        CentralInsightInterventionBridgeRC8.Bridge centralBridge =
                CentralInsightInterventionBridgeRC8.select(c,d);
        CentralInsightInterventionBridgeRC8.apply(c,centralBridge);

        d.centralBridgeReady=centralBridge.ready;
        d.centralBridgeInterventionId=centralBridge.interventionId;
        d.centralBridgeTarget=centralBridge.target;
        d.centralBridgeBlockedReason=centralBridge.blockedReason;

        String bridgeInstruction =
                CentralInsightInterventionBridgeRC8.instruction(centralBridge);
        if(bridgeInstruction!=null&&!bridgeInstruction.isEmpty()){
            d.responseInstruction=(d.responseInstruction==null?"":d.responseInstruction+" ")
                    +bridgeInstruction;
        }

        // If the brain already chose INTERVENE but the bridge has a stronger
        // mechanism-linked intervention, align the selected intervention.
        if(d.isIntervene() && centralBridge.ready){
            d.selectedInterventionId=centralBridge.interventionId;
            d.selectedInterventionTarget=centralBridge.target;
            d.interventionRationale=centralBridge.rationale;
        }

        EvidenceWeightingRecencyCalibrationRC8.Result evidenceCalibration =
                EvidenceWeightingRecencyCalibrationRC8.calibrate(c);
        d.evidenceCalibrationBand=evidenceCalibration.confidenceBand;
        d.evidenceCalibrationRationale=evidenceCalibration.rationale;

        String calibrationInstruction =
                EvidenceWeightingRecencyCalibrationRC8.instruction(evidenceCalibration);
        if(calibrationInstruction!=null&&!calibrationInstruction.isEmpty()){
            d.responseInstruction=(d.responseInstruction==null?"":d.responseInstruction+" ")
                    +calibrationInstruction;
        }

        EvidenceConflictResolutionRC8.Result evidenceConflict =
                EvidenceConflictResolutionRC8.resolve(c,"");
        d.evidenceConflictCount=evidenceConflict.conflicts;
        d.unresolvedEvidenceConflictCount=evidenceConflict.unresolved;
        d.evidenceConflictSummary=evidenceConflict.summary;

        String conflictInstruction =
                EvidenceConflictResolutionRC8.instruction(evidenceConflict);
        if(conflictInstruction!=null&&!conflictInstruction.isEmpty()){
            d.responseInstruction=(d.responseInstruction==null?"":d.responseInstruction+" ")
                    +conflictInstruction;
        }

        EvidenceProvenanceTraceabilityRC8.TraceResult provenanceFinal =
                EvidenceProvenanceTraceabilityRC8.trace(c,"");
        d.evidenceProvenanceSummary=provenanceFinal.summary;
        d.unknownEvidenceCount=provenanceFinal.unknown;
        d.staleEvidenceCount=provenanceFinal.stale;

        String provenanceInstruction =
                EvidenceProvenanceTraceabilityRC8.instruction(provenanceFinal);
        if(provenanceInstruction!=null&&!provenanceInstruction.isEmpty()){
            d.responseInstruction=(d.responseInstruction==null?"":d.responseInstruction+" ")
                    +provenanceInstruction;
        }

        FormulationStabilityReopenRC8.Result stability =
                FormulationStabilityReopenRC8.evaluate(c);
        if(stability.reopen && !d.isStabilize() && !d.isAllianceRepair()){
            FormulationStabilityReopenRC8.apply(c,stability);
            d.formulationReopened=true;
            d.formulationReopenReason=stability.reason;
            String reopenInstruction=FormulationStabilityReopenRC8.instruction(stability);
            d.responseInstruction=(d.responseInstruction==null?"":d.responseInstruction+" ")
                    +reopenInstruction;

            ReopenRecoveryHypothesisRetirementRC8.Plan recovery =
                    ReopenRecoveryHypothesisRetirementRC8.plan(c);
            ReopenRecoveryHypothesisRetirementRC8.apply(c,recovery);

            d.reopenRecoveryTarget=recovery.target;
            d.reopenRecoveryMove=recovery.move;
            d.reopenRecoveryAskBudget=recovery.askBudget;
            d.retiredHypothesisCount=recovery.retiredCount;

            String recoveryInstruction =
                    ReopenRecoveryHypothesisRetirementRC8.instruction(recovery);
            if(recoveryInstruction!=null&&!recoveryInstruction.isEmpty()){
                d.responseInstruction=(d.responseInstruction==null?"":d.responseInstruction+" ")
                        +recoveryInstruction;
            }
        }

        MicroExperimentReviewEvidenceMapperRC10.Result microExperimentReview =
                MicroExperimentReviewEvidenceMapperRC10.map(
                        c,text,d);

        d.microExperimentActive=microExperimentReview.activeExperiment;
        d.microExperimentAttribution=
                microExperimentReview.attribution.name();
        d.microExperimentOutcomeEligible=
                microExperimentReview.outcomeEligible;
        d.microExperimentOutcomeNeedsClarification=
                microExperimentReview.needsClarification;
        d.microExperimentMappedOutcome=
                microExperimentReview.mappedOutcome;
        d.microExperimentMatchedEvidence=
                microExperimentReview.matchedEvidence;
        d.microExperimentReviewMappingSummary=
                microExperimentReview.summary;

        String microReviewInstruction=
                MicroExperimentReviewEvidenceMapperRC10.instruction(
                        microExperimentReview);
        if(microReviewInstruction!=null
                && !microReviewInstruction.isEmpty()){
            d.responseInstruction=
                    (d.responseInstruction==null
                            ?""
                            :d.responseInstruction+" ")
                            +microReviewInstruction;
        }

        ReviewQuestionTargetingClarificationRC10.Result reviewClarification =
                ReviewQuestionTargetingClarificationRC10.build(
                        c,text,d,microExperimentReview);

        d.reviewAttributionClarificationNeeded=
                reviewClarification.clarificationNeeded;
        d.reviewAttributionAskAllowed=
                reviewClarification.askAllowed;
        d.reviewAttributionQuestion=
                reviewClarification.question;
        d.reviewAttributionTarget=
                reviewClarification.target;
        d.reviewAttributionSource=
                reviewClarification.source;
        d.reviewAttributionReason=
                reviewClarification.reason;
        d.reviewAttributionSummary=
                reviewClarification.summary;

        if(reviewClarification.askAllowed){
            ReviewQuestionTargetingClarificationRC10.persistPendingClarification(
                    c,reviewClarification);

            d.move="ASK";
            d.target=reviewClarification.target;

            String clarificationInstruction=
                    ReviewQuestionTargetingClarificationRC10.instruction(
                            reviewClarification);
            if(clarificationInstruction!=null
                    && !clarificationInstruction.isEmpty()){
                d.responseInstruction=
                        (d.responseInstruction==null
                                ?""
                                :d.responseInstruction+" ")
                                +clarificationInstruction;
            }
        }

        AttributionResolutionOutcomeCommitGateRC10.Result outcomeCommit =
                AttributionResolutionOutcomeCommitGateRC10.resolve(
                        c,text,d,microExperimentReview);

        d.outcomeCommitState=outcomeCommit.state.name();
        d.outcomeCommitLearningAllowed=
                outcomeCommit.outcomeLearningAllowed;
        d.outcomeCommitSuppressGeneric=
                outcomeCommit.suppressGenericOutcomeLearning;
        d.outcomeCommitValue=
                outcomeCommit.committedOutcome;
        d.outcomeCommitResolution=
                outcomeCommit.attributionResolution;
        d.outcomeCommitReason=
                outcomeCommit.reason;
        d.outcomeCommitSummary=
                outcomeCommit.summary;
        d.outcomeCommitExperimentId=outcomeCommit.experimentId;

        if(d.outcomeCommitLearningAllowed){
            StructuredOutcomeProvenanceCanonicalIdentityRC12.Result structuredProvenance =
                StructuredOutcomeProvenanceCanonicalIdentityRC12.apply(c,d);

        d.structuredProvenanceEvaluated=structuredProvenance.evaluated;
        d.structuredProvenanceEnriched=structuredProvenance.enriched;
        d.structuredProvenanceLegacyMigrated=structuredProvenance.migratedLegacyRows;
        d.structuredProvenanceRowsEnriched=structuredProvenance.rowsEnriched;
        d.structuredProvenanceLegacyRowsMigrated=structuredProvenance.legacyRowsMigrated;
        d.structuredProvenanceCanonicalKey=structuredProvenance.canonicalLearningKey;
        d.structuredProvenanceReason=structuredProvenance.reason;
        d.structuredProvenanceSummary=structuredProvenance.summary;

        ProvenanceIntegrityValidationBackfillGateRC12.Result provenanceIntegrity =
                ProvenanceIntegrityValidationBackfillGateRC12.validateAndBackfill(
                        c,d);

        d.provenanceIntegrityEvaluated=provenanceIntegrity.evaluated;
        d.provenanceIntegrityRepaired=provenanceIntegrity.repaired;
        d.provenanceIntegrityQuarantined=provenanceIntegrity.quarantined;
        d.provenanceIntegrityRowsChecked=provenanceIntegrity.rowsChecked;
        d.provenanceIntegrityRowsRepaired=provenanceIntegrity.rowsRepaired;
        d.provenanceIntegrityRowsQuarantined=provenanceIntegrity.rowsQuarantined;
        d.provenanceIntegrityLegacyUnresolved=provenanceIntegrity.legacyUnresolved;
        d.provenanceIntegrityReason=provenanceIntegrity.reason;
        d.provenanceIntegritySummary=provenanceIntegrity.summary;

        String provenanceIntegrityInstruction=
                ProvenanceIntegrityValidationBackfillGateRC12.instruction(
                        provenanceIntegrity);
        if(provenanceIntegrityInstruction!=null
                && !provenanceIntegrityInstruction.isEmpty()){
            d.responseInstruction=
                    (d.responseInstruction==null
                            ?""
                            :d.responseInstruction+" ")
                            +provenanceIntegrityInstruction;
        }

        String structuredProvenanceInstruction=
                StructuredOutcomeProvenanceCanonicalIdentityRC12.instruction(structuredProvenance);
        if(structuredProvenanceInstruction!=null&&!structuredProvenanceInstruction.isEmpty()){
            d.responseInstruction=(d.responseInstruction==null?"":d.responseInstruction+" ")
                    +structuredProvenanceInstruction;
        }

        CrossContextTransferGeneralizationGuardRC11.registerTransferredOutcome(
                    c,d);
        }

        GeneralPolicyPromotionValidationGateRC11.Result generalPromotion =
                GeneralPolicyPromotionValidationGateRC11.evaluate(c,d);

        GeneralPolicyPromotionValidationGateRC11.Result generalDemotion =
                GeneralPolicyPromotionValidationGateRC11.demoteIfContradicted(c,d);

        GeneralPolicyPromotionValidationGateRC11.Result generalPolicyResult =
                generalDemotion.changed ? generalDemotion : generalPromotion;

        d.generalPolicyPromotionEvaluated=
                generalPolicyResult.evaluated;
        d.generalPolicyPromotionChanged=
                generalPolicyResult.changed;
        d.generalPolicyPromotionState=
                generalPolicyResult.state.name();
        d.generalPolicyDistinctContexts=
                generalPolicyResult.distinctContexts;
        d.generalPolicyPositiveCommits=
                generalPolicyResult.positiveCommits;
        d.generalPolicyNegativeCommits=
                generalPolicyResult.negativeCommits;
        d.generalPolicyCleanAcrossContexts=
                generalPolicyResult.cleanAcrossContexts;
        d.generalPolicyPromotionReason=
                generalPolicyResult.reason;
        d.generalPolicyPromotionSummary=
                generalPolicyResult.summary;

        GeneralPolicyExceptionBoundaryRC11.Result generalBoundary =
                GeneralPolicyExceptionBoundaryRC11.evaluate(c,d);

        d.generalPolicyBoundaryEvaluated=
                generalBoundary.evaluated;
        d.generalPolicyBoundaryChanged=
                generalBoundary.changed;
        d.generalPolicyBoundaryState=
                generalBoundary.state.name();
        d.generalPolicyBoundaryContext=
                generalBoundary.context;
        d.generalPolicyBoundaryRecentPositive=
                generalBoundary.recentPositive;
        d.generalPolicyBoundaryRecentNegative=
                generalBoundary.recentNegative;
        d.generalPolicyBoundaryExcluded=
                generalBoundary.excluded;
        d.generalPolicyBoundaryReason=
                generalBoundary.reason;
        d.generalPolicyBoundarySummary=
                generalBoundary.summary;

        String generalBoundaryInstruction=
                GeneralPolicyExceptionBoundaryRC11.instruction(
                        generalBoundary);
        if(generalBoundaryInstruction!=null
                && !generalBoundaryInstruction.isEmpty()){
            d.responseInstruction=
                    (d.responseInstruction==null
                            ?""
                            :d.responseInstruction+" ")
                            +generalBoundaryInstruction;
        }

        String generalPolicyInstruction=
                GeneralPolicyPromotionValidationGateRC11.instruction(
                        generalPolicyResult);
        if(generalPolicyInstruction!=null
                && !generalPolicyInstruction.isEmpty()){
            d.responseInstruction=
                    (d.responseInstruction==null
                            ?""
                            :d.responseInstruction+" ")
                            +generalPolicyInstruction;
        }

        InterventionLearningPolicyMemoryRC11.Result interventionPolicy;
        if(d.outcomeCommitLearningAllowed){
            interventionPolicy=
                    InterventionLearningPolicyMemoryRC11.consolidate(c,d);
        }else{
            interventionPolicy=
                    new InterventionLearningPolicyMemoryRC11.Result();
            interventionPolicy.summary=
                    "NO_UPDATE | DUPLICATE_COMMIT_SUPPRESSED";
        }

        d.interventionPolicyMemoryUpdated=
                interventionPolicy.updated;
        d.interventionPolicyMechanism=
                interventionPolicy.mechanism;
        d.interventionPolicyInterventionId=
                interventionPolicy.interventionId;
        d.interventionPolicyPreferredMode=
                interventionPolicy.preferredMode;
        d.interventionPolicyPreferredDose=
                interventionPolicy.preferredDose;
        d.interventionPolicyConfidence=
                interventionPolicy.confidence.name();
        d.interventionPolicyPositiveCommits=
                interventionPolicy.positiveCommits;
        d.interventionPolicyNegativeCommits=
                interventionPolicy.negativeCommits;
        d.interventionPolicyRelevantCommits=
                interventionPolicy.totalRelevantCommits;
        d.interventionPolicyContextScope=
                interventionPolicy.contextScope;
        d.interventionPolicyRecommendation=
                interventionPolicy.recommendation;
        d.interventionPolicySummary=
                interventionPolicy.summary;

        String policyInstruction=
                InterventionLearningPolicyMemoryRC11.instruction(
                        interventionPolicy);
        if(policyInstruction!=null&&!policyInstruction.isEmpty()){
            d.responseInstruction=
                    (d.responseInstruction==null
                            ?""
                            :d.responseInstruction+" ")
                            +policyInstruction;
        }

        String outcomeCommitInstruction=
                AttributionResolutionOutcomeCommitGateRC10.instruction(
                        outcomeCommit);
        if(outcomeCommitInstruction!=null
                && !outcomeCommitInstruction.isEmpty()){
            d.responseInstruction=
                    (d.responseInstruction==null
                            ?""
                            :d.responseInstruction+" ")
                            +outcomeCommitInstruction;
        }

        OutcomeCommitIdempotencyDuplicateLearningGuardRC12.Result outcomeIdempotency =
                OutcomeCommitIdempotencyDuplicateLearningGuardRC12.evaluate(
                        c,d,text);

        d.outcomeCommitIdempotencyEvaluated=outcomeIdempotency.evaluated;
        d.outcomeCommitLearningAllowed=outcomeIdempotency.allowLearning;
        d.outcomeCommitDuplicate=outcomeIdempotency.duplicate;
        d.outcomeCommitConflictingDuplicate=outcomeIdempotency.conflictingDuplicate;
        d.outcomeCommitIdempotencyState=outcomeIdempotency.state.name();
        d.outcomeCommitIdempotencyKey=outcomeIdempotency.commitKey;
        d.outcomeCommitIdempotencyReason=outcomeIdempotency.reason;
        d.outcomeCommitIdempotencySummary=outcomeIdempotency.summary;

        String outcomeIdempotencyInstruction=
                OutcomeCommitIdempotencyDuplicateLearningGuardRC12.instruction(
                        outcomeIdempotency);
        if(outcomeIdempotencyInstruction!=null
                && !outcomeIdempotencyInstruction.isEmpty()){
            d.responseInstruction=
                    (d.responseInstruction==null
                            ?""
                            :d.responseInstruction+" ")
                            +outcomeIdempotencyInstruction;
        }

        ConflictingOutcomeReconciliationRevisionGateRC12.Result outcomeRevision =
                ConflictingOutcomeReconciliationRevisionGateRC12.evaluate(
                        c,d,text);

        d.outcomeRevisionEvaluated=outcomeRevision.evaluated;
        d.outcomeRevisionReviewRequired=outcomeRevision.reviewRequired;
        d.outcomeRevisionApplied=outcomeRevision.revisionApplied;
        d.outcomeRevisionRejected=outcomeRevision.revisionRejected;
        d.outcomeRevisionState=outcomeRevision.state.name();
        d.outcomeRevisionExperimentId=outcomeRevision.experimentId;
        d.outcomeRevisionPrior=outcomeRevision.priorOutcome;
        d.outcomeRevisionProposed=outcomeRevision.proposedOutcome;
        d.outcomeRevisionFinal=outcomeRevision.finalOutcome;
        d.outcomeRevisionQuestion=outcomeRevision.question;
        d.outcomeRevisionReason=outcomeRevision.reason;
        d.outcomeRevisionSummary=outcomeRevision.summary;

        OutcomeRevisionPropagationLearningRecomputeRC12.Result revisionPropagation =
                OutcomeRevisionPropagationLearningRecomputeRC12.propagate(
                        c,d,outcomeRevision);

        d.outcomeRevisionPropagationEvaluated=
                revisionPropagation.evaluated;
        d.outcomeRevisionPropagationRecomputed=
                revisionPropagation.recomputed;
        d.outcomeRevisionPropagationState=
                revisionPropagation.state.name();
        d.outcomeRevisionPropagationCommitRows=
                revisionPropagation.commitRowsUpdated;
        d.outcomeRevisionPropagationTransferRows=
                revisionPropagation.transferRowsUpdated;
        d.outcomeRevisionPropagationPolicies=
                revisionPropagation.policiesRecomputed;
        d.outcomeRevisionPropagationGeneralization=
                revisionPropagation.generalizationRecomputed;
        d.outcomeRevisionPropagationReason=
                revisionPropagation.reason;
        d.outcomeRevisionPropagationSummary=
                revisionPropagation.summary;

        String revisionPropagationInstruction=
                OutcomeRevisionPropagationLearningRecomputeRC12.instruction(
                        revisionPropagation);
        if(revisionPropagationInstruction!=null
                && !revisionPropagationInstruction.isEmpty()){
            d.responseInstruction=
                    (d.responseInstruction==null
                            ?""
                            :d.responseInstruction+" ")
                            +revisionPropagationInstruction;
        }

        if(ConflictingOutcomeReconciliationRevisionGateRC12
                .shouldForceReview(outcomeRevision)){

            d.move="REVIEW";
            d.reviewRequired=true;

            String revisionInstruction=
                    ConflictingOutcomeReconciliationRevisionGateRC12
                            .instruction(outcomeRevision);

            d.responseInstruction=
                    (d.responseInstruction==null
                            ?""
                            :d.responseInstruction+" ")
                            +revisionInstruction;
        }

        boolean outcomeLearningAllowedByAttribution =
                (!microExperimentReview.activeExperiment
                    || outcomeCommit.outcomeLearningAllowed)
                && OutcomeCommitIdempotencyDuplicateLearningGuardRC12
                        .shouldAllowLearning(outcomeIdempotency)
                && !outcomeRevision.reviewRequired
                && !outcomeRevision.revisionApplied
                && !outcomeRevision.revisionRejected;

        String forcedCommittedOutcome =
                outcomeCommit.outcomeLearningAllowed
                        ? outcomeCommit.committedOutcome
                        : "UNKNOWN";

        InterventionOutcomeLearningLoopRC10.Result interventionOutcome =
                InterventionOutcomeLearningLoopRC10.captureWithEligibilityGate(
                        c,text,d,
                        outcomeLearningAllowedByAttribution,
                        forcedCommittedOutcome);

        d.interventionOutcome=interventionOutcome.outcome.name();
        d.interventionOutcomeReviewRequired=interventionOutcome.reviewRequired;
        d.interventionOutcomeReopenSuggested=interventionOutcome.reopenSuggested;
        d.interventionOutcomeKeepIntervention=interventionOutcome.keepIntervention;
        d.interventionOutcomeAllowDoseIncrease=interventionOutcome.allowDoseIncrease;
        d.interventionOutcomeReduceDose=interventionOutcome.reduceDose;
        d.interventionOutcomeLearning=interventionOutcome.learned;
        d.interventionOutcomeNextMoveHint=interventionOutcome.nextMoveHint;

        String outcomeInstruction=
                InterventionOutcomeLearningLoopRC10.instruction(interventionOutcome);
        if(outcomeInstruction!=null&&!outcomeInstruction.isEmpty()){
            d.responseInstruction=
                    (d.responseInstruction==null?"":d.responseInstruction+" ")
                            +outcomeInstruction;
        }

        InterventionAdaptationSwitchDecisionGateRC10.Result interventionAdaptation =
                InterventionAdaptationSwitchDecisionGateRC10.decide(c,d,interventionOutcome);
        d.interventionAdaptationAction=interventionAdaptation.action.name();
        d.interventionSwitchAllowed=interventionAdaptation.switchAllowed;
        d.interventionSwitchRequired=interventionAdaptation.switchRequired;
        d.interventionReviewBeforeSwitch=interventionAdaptation.reviewBeforeSwitch;
        d.interventionAdaptationReopen=interventionAdaptation.reopenFormulation;
        d.interventionSwitchCandidateId=interventionAdaptation.candidateInterventionId;
        d.interventionAdaptationRationale=interventionAdaptation.rationale;
        d.interventionAdaptationSummary=interventionAdaptation.summary;
        String adaptationInstruction=InterventionAdaptationSwitchDecisionGateRC10.instruction(interventionAdaptation);
        if(adaptationInstruction!=null&&!adaptationInstruction.isEmpty()) d.responseInstruction=(d.responseInstruction==null?"":d.responseInstruction+" ")+adaptationInstruction;
        if(InterventionAdaptationSwitchDecisionGateRC10.canSwitch(interventionAdaptation) && interventionAdaptation.action==InterventionAdaptationSwitchDecisionGateRC10.Action.SWITCH_INTERVENTION) d.selectedInterventionId=interventionAdaptation.candidateInterventionId;

        InterventionBarrierFrictionReductionRC10.Result interventionBarrier =
                InterventionBarrierFrictionReductionRC10.analyze(
                        c,text,d);

        d.interventionBarrier=interventionBarrier.barrier.name();
        d.interventionBarrierShrink=interventionBarrier.shouldShrink;
        d.interventionBarrierClarify=interventionBarrier.shouldClarify;
        d.interventionBarrierCue=interventionBarrier.shouldCue;
        d.interventionBarrierReduceDose=interventionBarrier.shouldReduceDose;
        d.interventionBarrierChangeContext=interventionBarrier.shouldChangeContext;
        d.interventionBarrierAdjustment=interventionBarrier.microAdjustment;
        d.interventionBarrierRationale=interventionBarrier.rationale;
        d.interventionBarrierSummary=interventionBarrier.summary;

        String barrierInstruction=
                InterventionBarrierFrictionReductionRC10.instruction(
                        interventionBarrier);
        if(barrierInstruction!=null&&!barrierInstruction.isEmpty()){
            d.responseInstruction=
                    (d.responseInstruction==null
                            ?""
                            :d.responseInstruction+" ")
                            +barrierInstruction;
        }

        PolicyHierarchyArbitrationSpecificityRC11.Result policyHierarchy =
                PolicyHierarchyArbitrationSpecificityRC11.arbitrate(c,d);

        d.policyHierarchyEvaluated=policyHierarchy.evaluated;
        d.policyHierarchyWinner=policyHierarchy.winner.name();
        d.policyHierarchyContextFound=policyHierarchy.contextPolicyFound;
        d.policyHierarchyGeneralFound=policyHierarchy.generalPolicyFound;
        d.policyHierarchyBothFound=policyHierarchy.bothFound;
        d.policyHierarchyContextKey=policyHierarchy.contextPolicyKey;
        d.policyHierarchyGeneralKey=policyHierarchy.generalPolicyKey;
        d.policyHierarchySelectedKey=policyHierarchy.selectedPolicyKey;
        d.policyHierarchySelectedIntervention=policyHierarchy.selectedInterventionId;
        d.policyHierarchySelectedMode=policyHierarchy.selectedMode;
        d.policyHierarchySelectedDose=policyHierarchy.selectedDose;
        d.policyHierarchyReason=policyHierarchy.reason;
        d.policyHierarchySummary=policyHierarchy.summary;

        String policyHierarchyInstruction=
                PolicyHierarchyArbitrationSpecificityRC11.instruction(
                        policyHierarchy);
        if(policyHierarchyInstruction!=null
                && !policyHierarchyInstruction.isEmpty()){
            d.responseInstruction=
                    (d.responseInstruction==null
                            ?""
                            :d.responseInstruction+" ")
                            +policyHierarchyInstruction;
        }

        PolicyMemoryRetrievalContextMatchGuardRC11.Result policyRetrieval =
                PolicyMemoryRetrievalContextMatchGuardRC11.retrieve(c,d);

        d.policyRetrievalFound=policyRetrieval.policyFound;
        d.policyRetrievalApplicable=policyRetrieval.applicable;
        d.policyMechanismMatch=policyRetrieval.mechanismMatch;
        d.policyContextMatch=policyRetrieval.contextMatch;
        d.policyConfidenceSufficient=policyRetrieval.confidenceSufficient;
        d.policyBlockedByCurrentEvidence=policyRetrieval.blockedByCurrentEvidence;
        d.policyRetrievalKey=policyRetrieval.policyKey;
        d.policyRetrievalInterventionId=policyRetrieval.policyInterventionId;
        d.policyRetrievalMode=policyRetrieval.policyMode;
        d.policyRetrievalDose=policyRetrieval.policyDose;
        d.policyRetrievalConfidence=policyRetrieval.policyConfidence;
        d.policyRetrievalReason=policyRetrieval.reason;
        d.policyRetrievalSummary=policyRetrieval.summary;

        String policyRetrievalInstruction=
                PolicyMemoryRetrievalContextMatchGuardRC11.instruction(
                        policyRetrieval);
        if(policyRetrievalInstruction!=null
                && !policyRetrievalInstruction.isEmpty()){
            d.responseInstruction=
                    (d.responseInstruction==null
                            ?""
                            :d.responseInstruction+" ")
                            +policyRetrievalInstruction;
        }

        PolicySelectionEnforcementConsistencyGateRC11.Result policySelection =
                PolicySelectionEnforcementConsistencyGateRC11.enforce(
                        c,d,policyHierarchy,policyRetrieval);

        d.policySelectionEnforcementEvaluated=policySelection.evaluated;
        d.policySelectionMismatchDetected=policySelection.mismatchDetected;
        d.policySelectionReboundApplied=policySelection.reboundApplied;
        d.policySelectionSuppressed=policySelection.policySuppressed;
        d.policySelectionEnforcementState=policySelection.state.name();
        d.policySelectionHierarchyKey=policySelection.hierarchyPolicyKey;
        d.policySelectionRetrievalKey=policySelection.retrievalPolicyKey;
        d.policySelectionEffectiveKey=policySelection.effectivePolicyKey;
        d.policySelectionEffectiveIntervention=policySelection.effectiveIntervention;
        d.policySelectionEffectiveMode=policySelection.effectiveMode;
        d.policySelectionEffectiveDose=policySelection.effectiveDose;
        d.policySelectionReason=policySelection.reason;
        d.policySelectionSummary=policySelection.summary;

        String policySelectionInstruction=
                PolicySelectionEnforcementConsistencyGateRC11.instruction(
                        policySelection);
        if(policySelectionInstruction!=null
                && !policySelectionInstruction.isEmpty()){
            d.responseInstruction=
                    (d.responseInstruction==null
                            ?""
                            :d.responseInstruction+" ")
                            +policySelectionInstruction;
        }

        CrossContextTransferGeneralizationGuardRC11.Result policyTransfer =
                CrossContextTransferGeneralizationGuardRC11.evaluate(
                        c,d,policyRetrieval);

        d.policyTransferEvaluated=policyTransfer.evaluated;
        d.policyTransferState=policyTransfer.transfer.name();
        d.policyTransferSourceContext=policyTransfer.sourceContext;
        d.policyTransferTargetContext=policyTransfer.targetContext;
        d.policyTransferMechanismMatch=policyTransfer.mechanismMatch;
        d.policyTransferContextSimilarity=policyTransfer.contextSimilarity;
        d.policyTransferEvidenceSufficient=policyTransfer.evidenceSufficient;
        d.policyTransferTrialOnly=policyTransfer.trialOnly;
        d.policyTransferGeneralEligible=policyTransfer.generalPolicyEligible;
        d.policyTransferReason=policyTransfer.reason;
        d.policyTransferSummary=policyTransfer.summary;

        String policyTransferInstruction=
                CrossContextTransferGeneralizationGuardRC11.instruction(
                        policyTransfer);
        if(policyTransferInstruction!=null
                && !policyTransferInstruction.isEmpty()){
            d.responseInstruction=
                    (d.responseInstruction==null
                            ?""
                            :d.responseInstruction+" ")
                            +policyTransferInstruction;
        }

        PolicyMemoryConflictOverrideResolutionRC11.Result policyConflict =
                PolicyMemoryConflictOverrideResolutionRC11.resolve(
                        c,d,policyRetrieval);

        d.policyConflictDetected=policyConflict.conflictDetected;
        d.policyConflictResolution=policyConflict.resolution.name();
        d.policyCanAffectIntervention=policyConflict.policyCanAffectIntervention;
        d.policyCanAffectMode=policyConflict.policyCanAffectMode;
        d.policyCanAffectDose=policyConflict.policyCanAffectDose;
        d.policyConflictReason=policyConflict.reason;
        d.policyConflictSummary=policyConflict.summary;

        PolicyMemoryConflictOverrideResolutionRC11.applyAllowedBias(
                policyConflict,d);

        PolicyMemoryDecayContradictionDemotionRC11.Result policyDecay =
                PolicyMemoryDecayContradictionDemotionRC11.evaluate(c,d);

        d.policyDecayEvaluated=policyDecay.evaluated;
        d.policyDecayChanged=policyDecay.changed;
        d.policyDecayStatus=policyDecay.status.name();
        d.policyDecayOldConfidence=policyDecay.oldConfidence;
        d.policyDecayNewConfidence=policyDecay.newConfidence;
        d.policyDecayRecentPositive=policyDecay.recentPositive;
        d.policyDecayRecentNegative=policyDecay.recentNegative;
        d.policyDecayAgeDays=policyDecay.ageDays;
        d.policyDecayStale=policyDecay.stale;
        d.policyDecayContradicted=policyDecay.contradicted;
        d.policyDecayReason=policyDecay.reason;
        d.policyDecaySummary=policyDecay.summary;

        PolicyRevalidationReactivationGateRC11.Result policyRevalidation =
                PolicyRevalidationReactivationGateRC11.evaluate(c,d);

        d.policyRevalidationEvaluated=policyRevalidation.evaluated;
        d.policyRevalidationChanged=policyRevalidation.changed;
        d.policyRevalidationState=policyRevalidation.state.name();
        d.policyRevalidationOldStatus=policyRevalidation.oldStatus;
        d.policyRevalidationNewStatus=policyRevalidation.newStatus;
        d.policyRevalidationOldConfidence=policyRevalidation.oldConfidence;
        d.policyRevalidationNewConfidence=policyRevalidation.newConfidence;
        d.policyRevalidationRecentPositive=policyRevalidation.recentPositive;
        d.policyRevalidationRecentNegative=policyRevalidation.recentNegative;
        d.policyRevalidationReason=policyRevalidation.reason;
        d.policyRevalidationSummary=policyRevalidation.summary;

        String policyRevalidationInstruction=
                PolicyRevalidationReactivationGateRC11.instruction(
                        policyRevalidation);
        if(policyRevalidationInstruction!=null
                && !policyRevalidationInstruction.isEmpty()){
            d.responseInstruction=
                    (d.responseInstruction==null
                            ?""
                            :d.responseInstruction+" ")
                            +policyRevalidationInstruction;
        }

        String policyDecayInstruction=
                PolicyMemoryDecayContradictionDemotionRC11.instruction(
                        policyDecay);
        if(policyDecayInstruction!=null&&!policyDecayInstruction.isEmpty()){
            d.responseInstruction=
                    (d.responseInstruction==null
                            ?""
                            :d.responseInstruction+" ")
                            +policyDecayInstruction;
        }

        String policyConflictInstruction=
                PolicyMemoryConflictOverrideResolutionRC11.instruction(
                        policyConflict);
        if(policyConflictInstruction!=null
                && !policyConflictInstruction.isEmpty()){
            d.responseInstruction=
                    (d.responseInstruction==null
                            ?""
                            :d.responseInstruction+" ")
                            +policyConflictInstruction;
        }

        InterventionPreferenceFitCalibrationRC10.Result interventionPreference =
                InterventionPreferenceFitCalibrationRC10.calibrate(
                        c,text,d);

        d.interventionPreferenceMode=
                interventionPreference.mode.name();
        d.preferenceMode=d.interventionPreferenceMode;
        d.interventionPreferenceExplicit=
                interventionPreference.explicitPreference;
        d.interventionPreferenceInferred=
                interventionPreference.inferredPreference;
        d.interventionPreferenceModalityChanged=
                interventionPreference.modalityChanged;
        d.interventionPreferenceMechanismPreserved=
                interventionPreference.mechanismPreserved;
        d.interventionPreferenceSource=
                interventionPreference.source;
        d.interventionPreferenceInstruction=
                interventionPreference.adaptedInstruction;
        d.interventionPreferenceRationale=
                interventionPreference.rationale;
        d.interventionPreferenceSummary=
                interventionPreference.summary;

        String preferenceInstruction=
                InterventionPreferenceFitCalibrationRC10.instruction(
                        interventionPreference);
        if(preferenceInstruction!=null
                && !preferenceInstruction.isEmpty()){
            d.responseInstruction=
                    (d.responseInstruction==null
                            ?""
                            :d.responseInstruction+" ")
                            +preferenceInstruction;
        }

        InterventionDoseIntensityCalibrationRC10.Result interventionDose =
                InterventionDoseIntensityCalibrationRC10.calibrate(c,d);

        d.interventionDose=interventionDose.dose.name();
        d.interventionMaxSteps=interventionDose.maxSteps;
        d.interventionHomeworkAllowed=interventionDose.homeworkAllowed;
        d.interventionExerciseMinutes=interventionDose.exerciseMinutes;
        d.interventionDoseRationale=interventionDose.rationale;
        d.interventionDeliveryStyle=interventionDose.deliveryStyle;
        d.interventionDoseBlockedReason=interventionDose.blockedReason;

        MicroExperimentReviewContractRC10.Result microExperiment =
                MicroExperimentReviewContractRC10.build(c,d);

        d.microExperimentReady=microExperiment.ready;
        d.microExperimentId=microExperiment.experimentId;
        d.microExperimentAction=microExperiment.action;
        d.microExperimentReviewCriterion=microExperiment.reviewCriterion;
        d.microExperimentStopCondition=microExperiment.stopCondition;
        d.microExperimentMode=microExperiment.mode;
        d.microExperimentDose=microExperiment.dose;
        d.microExperimentMaxMinutes=microExperiment.maxMinutes;
        d.microExperimentRationale=microExperiment.rationale;
        d.microExperimentSummary=microExperiment.summary;

        MicroExperimentReviewEvidenceMapperRC10.activate(c,d);

        String experimentInstruction=
                MicroExperimentReviewContractRC10.instruction(microExperiment);
        if(experimentInstruction!=null&&!experimentInstruction.isEmpty()){
            d.responseInstruction=
                    (d.responseInstruction==null
                            ?""
                            :d.responseInstruction+" ")
                            +experimentInstruction;
        }

        if(d.isIntervene()){
            String doseInstruction=
                    InterventionDoseIntensityCalibrationRC10.instruction(interventionDose);
            if(doseInstruction!=null&&!doseInstruction.isEmpty()){
                d.responseInstruction=
                        (d.responseInstruction==null?"":d.responseInstruction+" ")
                                +doseInstruction;
            }
        }

        ClinicalReleaseResponseIntegrityRC9.Check releaseIntegrity =
                ClinicalReleaseResponseIntegrityRC9.validate(c,d);
        ClinicalReleaseResponseIntegrityRC9.applyRepair(d,releaseIntegrity);

        d.releaseIntegrityPass=releaseIntegrity.pass;
        d.releaseIntegrityBlocked=releaseIntegrity.blockResponse;
        d.releaseIntegritySummary=
                ClinicalReleaseResponseIntegrityRC9.summary(releaseIntegrity);

        String releaseInstruction =
                ClinicalReleaseResponseIntegrityRC9.instruction(releaseIntegrity);
        if(releaseInstruction!=null&&!releaseInstruction.isEmpty()){
            d.responseInstruction=(d.responseInstruction==null?"":d.responseInstruction+" ")
                    +releaseInstruction;
        }

        ClinicalDiagnosticsRC7.record(c,d);
    }

    private static ClinicalKnowledgeRC7.Unit exact(Context c,String target,Set<String> asked){
        if(target==null||target.isEmpty())return null; ClinicalKnowledgeRC7.Unit best=null;
        for(ClinicalKnowledgeRC7.Unit u:ClinicalKnowledgeRC7.all(c)){
            if(!"QDU".equals(u.type)||!target.equals(u.target)||asked.contains(u.id)||u.question.isEmpty())continue;
            if(best==null||u.weight>best.weight)best=u;
        }
        if(best==null){
            ClinicalKnowledgeRC7.Unit fallback=ClinicalKnowledgeRC7.fallbackForTarget(target);
            if(fallback!=null&&!asked.contains(fallback.id))best=fallback;
        }
        return best;
    }
    private static ClinicalKnowledgeRC7.Unit bestQuestion(Context c,ClinicalDecisionRC7 d,Set<String> asked,String history){
        ClinicalKnowledgeRC7.Unit best=null; double bs=-999;
        for(ClinicalKnowledgeRC7.Unit u:ClinicalKnowledgeRC7.all(c)){
            if(!"QDU".equals(u.type)||u.question.isEmpty()||asked.contains(u.id)||d.known.contains(u.target))continue;
            int overlap=0;for(String s:u.signals)if(d.signals.contains(s))overlap++;
            if(overlap==0)continue; double score=u.weight*100+overlap*20+(d.missing.contains(u.target)?35:0);
            if(history.contains(u.question))score-=100;
            if(score>bs){bs=score;best=u;}
        }return best;
    }

    private static String nextTarget(ClinicalDecisionRC7 d){
        if((d.known.contains("recent_change")||d.known.contains("selective_change"))&&!d.known.contains("recent_conflict"))return "recent_conflict";
        if(d.known.contains("recent_conflict")&&!d.known.contains("meaning_attribution"))return "meaning_attribution";
        if(d.known.contains("people_pleasing")&&!d.known.contains("conditional_rule"))return "conditional_rule";
        if(d.known.contains("body_activation")&&!d.known.contains("emotion_differentiation"))return "emotion_differentiation";
        if(d.known.contains("experiential_avoidance")&&!d.known.contains("values"))return "values";
        return d.missing.isEmpty()?"":d.missing.get(0);
    }

    private static void buildHypotheses(ClinicalDecisionRC7 d){
        if(d.signals.contains("reply_delay")){Collections.addAll(d.hypotheses,"정상적인 답장 패턴/우선순위 차이","실제 관계거리 변화","거절해석 확대 가능성","실제 갈등/거절 가능성");}
        else if(d.signals.contains("work_stress")){Collections.addAll(d.hypotheses,"업무량 부담","평가 위협","직장 대인스트레스","소진/회복 부족");}
        if(d.signals.contains("anxiety")&&d.signals.contains("avoidance"))d.hypotheses.add("회피의 단기안도가 불안을 유지하는 가능성");
        while(d.hypotheses.size()>4)d.hypotheses.remove(d.hypotheses.size()-1);
    }
    private static void buildMissing(ClinicalDecisionRC7 d){
        if(d.signals.contains("reply_delay"))Collections.addAll(d.missing,"baseline_relationship_change","recent_conflict","meaning_attribution");
        if(d.signals.contains("work_stress"))Collections.addAll(d.missing,"recent_specific_episode","evaluation_meaning","workload_vs_relationship");
        if(d.signals.contains("anxiety"))Collections.addAll(d.missing,"body_activation","emotion_differentiation");
        if(d.signals.contains("avoidance"))Collections.addAll(d.missing,"short_term_relief","values");
        LinkedHashSet<String>x=new LinkedHashSet<>(d.missing);d.missing.clear();d.missing.addAll(x);
    }
    private static void removeKnownFromMissing(ClinicalDecisionRC7 d){d.missing.removeIf(d.known::contains);}

    private static void detectSignals(String t,Set<String>s){
        if(has(t,"답장","카톡","읽씹","연락이 안","답이 한참"))s.add("reply_delay");
        if(has(t,"싫어하","버려질","미움받","멀어질","거절"))s.add("rejection_fear");
        if(has(t,"회사","직장","업무","상사","팀장","출근"))s.add("work_stress");
        if(has(t,"불안","초조","무서","걱정","답답"))s.add("anxiety");
        if(has(t,"화나","빡쳐","짜증","분노"))s.add("anger");
        if(has(t,"피하","회피","도망","안 만나"))s.add("avoidance");
        if(has(t,"죽고 싶","죽고싶","자살","자해"))s.add("self_harm");
        if(has(t,"환청","환각","감시","목소리가 들"))s.add("psychosis");
        if(has(t,"며칠 안 자","잠 안 자도","안 피곤하고 너무 들떠","뭐든 할 수"))s.add("mania");
        if(has(t,"먹고 토","토하는 일이 반복","먹는 걸 극단적으로"))s.add("eating_disorders");
    }
    private static void detectKnown(String t,Set<String>k){
        if(has(t,"답장이 늦","답장 느","답이 늦","답이 한참"))k.add("observable_fact");
        if(has(t,"원래","평소","늘")&&has(t,"답장","카톡","답이"))k.add("baseline_relationship_change");
        if(has(t,"최근부터","요즘부터","갑자기","최근 들어")&&has(t,"답장","달라","느려","늦어")){k.add("baseline_relationship_change");k.add("recent_change");}
        if(has(t,"나한테만","나만")&&has(t,"늦","느려","안 읽"))k.add("selective_change");
        if(has(t,"싸운 일은 없어","다툰 적 없어","갈등은 없어","싸우진 않았"))k.add("recent_conflict");
        if(has(t,"싸웠","다퉜","갈등이 있었"))k.add("recent_conflict");
        if(has(t,"날 싫어","나를 싫어","무시하나","중요하지 않","뭘 잘못했나"))k.add("meaning_attribution");
        if(has(t,"버려질까","멀어질까","미움받을까"))k.add("core_fear");
        if(has(t,"거절을 못","다 맞춰","맞춰줘")){k.add("people_pleasing");k.add("coping_mode");}
        if(has(t,"상사가 한마디","실수 하나","피드백 받","오늘 실수"))k.add("recent_specific_episode");
        if(has(t,"무능","일을 못","일 못하는 사람","평가할까","능력이 의심"))k.add("evaluation_meaning");
        if(has(t,"업무량보다","사람 눈치","상사 눈치","사람 때문에"))k.add("workload_vs_relationship");
        if(has(t,"심장이 빨리","가슴이 답답","손이 떨","숨이 막"))k.add("body_activation");
        if(has(t,"차단하고 싶","연락하고 싶","도망가고 싶","확인하고 싶"))k.add("action_urge");
        if(has(t,"시작이 안","시작을 못","손이 안 가"))k.add("task_initiation");
        if(has(t,"회사와 집 둘 다","집에서도","회사에서도"))k.add("cross_setting");
        if(has(t,"불안을 없애","감정을 없애","안 느끼려고","피해서 버티","불안해서")&&has(t,"피하","회피","안 만나"))k.add("experiential_avoidance");
        if(has(t,"중요한 관계","소중해서","중요한 일"))k.add("values");
        if(has(t,"확인하면 잠깐 안심","답장 오면 안심"))k.add("reassurance_relief");
    }
    private static boolean formulationReady(Set<String>k,String t){
        if(k.contains("meaning_attribution")||k.contains("evaluation_meaning")||k.contains("body_activation")||k.contains("action_urge")||k.contains("task_initiation")||k.contains("cross_setting")||k.contains("experiential_avoidance")||k.contains("values")||k.contains("reassurance_relief"))return true;
        return k.contains("observable_fact")&&k.contains("baseline_relationship_change")&&!k.contains("recent_change")&&!k.contains("selective_change");
    }
    private static String repairTarget(String t){
        if(has(t,"원하는 건 이해","이해받는 건데","해결책만"))return "goal_agreement";
        if(has(t,"질문만 계속","질문이 너무 많","또 물어보","같은 걸 또"))return "task_agreement";
        if(has(t,"네 답변","내 말 안 듣","네가 내 말","안 맞는 방향")&&has(t,"답답","안 듣","안 맞"))return "rupture_point";
        return "";
    }
    private static String normalize(String x){return x.toLowerCase(Locale.KOREA).replace("친한 애","친구").replace("팀장","상사").replace("손이 안 가","시작이 안 돼").replace("초조","불안").replace("답이 한참 뒤에 와","답장이 늦어");}
    private static boolean has(String t,String...xs){for(String x:xs)if(t.contains(x))return true;return false;}
    private static boolean isTargetLike(String k){return k.contains("_");}
}
