package com.maeummon.app.clinical;

import android.content.Context;
import org.json.*;
import java.util.*;

public final class QuestionStopPolicyRC8 {
    private QuestionStopPolicyRC8(){}

    public static final class Result {
        public final boolean stopAsking;
        public final String reason;
        public final double topConfidence;
        public final double secondConfidence;
        public final double separation;
        public final double candidateInformationGain;
        public final int knownCount;
        public final int missingCount;

        Result(boolean stopAsking,String reason,double topConfidence,double secondConfidence,
               double separation,double candidateInformationGain,int knownCount,int missingCount){
            this.stopAsking=stopAsking;
            this.reason=reason;
            this.topConfidence=topConfidence;
            this.secondConfidence=secondConfidence;
            this.separation=separation;
            this.candidateInformationGain=candidateInformationGain;
            this.knownCount=knownCount;
            this.missingCount=missingCount;
        }
    }

    public static Result evaluate(
            Context c,
            ClinicalDecisionRC7 d,
            InformationGainQuestionSelectorRC8.Selection selection,
            ClinicalSessionMemoryRC7.State session,
            String userText
    ){
        JSONObject formulation=CentralTherapyProfile.loadFormulation(c);
        JSONArray hs=formulation.optJSONArray("alternative_hypotheses");

        double top=0,second=0;
        if(hs!=null){
            for(int i=0;i<hs.length();i++){
                JSONObject h=hs.optJSONObject(i);
                if(h==null)continue;
                double v=h.optDouble("confidence",0);
                if(v>top){second=top;top=v;}
                else if(v>second)second=v;
            }
        }
        double separation=Math.max(0,top-second);
        double ig=(selection==null?0:selection.informationGain);
        int known=d==null?0:d.known.size();
        int missing=d==null?0:d.missing.size();
        int questions=(session==null?0:session.askedIds.size());
        String t=userText==null?"":userText;

        // Explicit user preference: stop interrogation.
        if(containsAny(t,
                "질문 그만","그만 물어","이제 정리해","정리해줘",
                "질문 말고","계속 질문해서 답답")){
            return r(true,"USER_REQUESTED_FORMULATION",top,second,separation,ig,known,missing);
        }

        // Strongly separated leading hypothesis with enough known information.
        if(top>=0.62 && separation>=0.16 && known>=2){
            return r(true,"LEADING_HYPOTHESIS_SUFFICIENTLY_SEPARATED",top,second,separation,ig,known,missing);
        }

        // Little information gain remains.
        if(ig>0 && ig<0.34 && known>=2){
            return r(true,"LOW_MARGINAL_INFORMATION_GAIN",top,second,separation,ig,known,missing);
        }

        // Most clinically relevant missing variables resolved.
        if(missing<=1 && known>=3){
            return r(true,"MOST_KEY_INFORMATION_RESOLVED",top,second,separation,ig,known,missing);
        }

        // Avoid too many consecutive assessment questions even before hard cap.
        if(questions>=2 && known>=2 && ig<0.46){
            return r(true,"QUESTION_FATIGUE_PREVENTION",top,second,separation,ig,known,missing);
        }

        // Information-rich answer should be honored by formulating rather than reopening intake.
        if(isRichAnswer(t) && known>=3){
            return r(true,"INFORMATION_RICH_ANSWER",top,second,separation,ig,known,missing);
        }

        return r(false,"ASK_STILL_HIGH_VALUE",top,second,separation,ig,known,missing);
    }

    public static String formulateInstruction(Result x){
        String reason=x==null?"":x.reason;
        return "추가 질문을 멈춘다. 지금까지 확인된 FACT와 INTERPRETATION을 분리하고, "
                +"경쟁 가설 중 현재 가장 설명력이 높은 가설과 남아 있는 불확실성을 2~4문장으로 정리한다. "
                +"단정하지 말고 잠정적으로 표현한다. stop_reason="+reason;
    }

    private static boolean isRichAnswer(String t){
        if(t==null)return false;
        int signals=0;
        if(containsAny(t,"왜냐하면","그래서","그때","원래","최근","예전"))signals++;
        if(containsAny(t,"불안","서운","화","무서","답답","슬퍼"))signals++;
        if(containsAny(t,"싸웠","갈등","답장","회사","상사","약속","회피"))signals++;
        if(containsAny(t,"싶었","생각했","느꼈","했어"))signals++;
        return t.length()>=55 && signals>=3;
    }

    private static Result r(boolean stop,String reason,double top,double second,double sep,double ig,int known,int missing){
        return new Result(stop,reason,round(top),round(second),round(sep),round(ig),known,missing);
    }
    private static boolean containsAny(String s,String... xs){
        for(String x:xs)if(s.contains(x))return true;
        return false;
    }
    private static double round(double x){return Math.round(x*1000.0)/1000.0;}
}
