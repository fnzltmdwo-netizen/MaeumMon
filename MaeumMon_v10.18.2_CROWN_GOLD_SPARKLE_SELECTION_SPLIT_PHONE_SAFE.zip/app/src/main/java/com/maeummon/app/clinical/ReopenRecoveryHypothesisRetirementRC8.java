package com.maeummon.app.clinical;

import android.content.Context;
import org.json.*;
import java.util.*;

public final class ReopenRecoveryHypothesisRetirementRC8 {
    private ReopenRecoveryHypothesisRetirementRC8(){}

    public static final class Plan {
        public boolean active=false;
        public String reopenReason="";
        public String target="";
        public String move="FORMULATE";
        public String rationale="";
        public int askBudget=0;
        public int retiredCount=0;
        public final List<String> retiredIds=new ArrayList<>();
    }

    public static Plan plan(Context c){
        Plan p=new Plan();
        if(c==null)return p;

        JSONObject f=CentralTherapyProfile.loadFormulation(c);
        boolean reopened=f.optBoolean("formulation_reopened",false);
        if(!reopened)return p;

        p.active=true;
        p.reopenReason=f.optString("formulation_reopen_reason","");
        JSONArray hs=f.optJSONArray("alternative_hypotheses");

        // Retire only hypotheses with repeated strong counterevidence.
        if(hs!=null){
            for(int i=0;i<hs.length();i++){
                JSONObject h=hs.optJSONObject(i);
                if(h==null)continue;
                JSONArray against=h.optJSONArray("evidence_against");
                int strong=strongCounterEvidenceCount(against);
                double confidence=h.optDouble("confidence",0.0);

                if(strong>=2 && confidence<=0.18){
                    try{
                        h.put("active",false);
                        h.put("retired_reason","repeated_counterevidence");
                        h.put("retired_at",System.currentTimeMillis());
                    }catch(Exception ignored){}
                    p.retiredIds.add(h.optString("id",""));
                    p.retiredCount++;
                }
            }
        }

        // Pick the smallest useful recovery target based on why formulation reopened.
        String reason=p.reopenReason;

        if("NO_ACTIVE_HYPOTHESES".equals(reason)){
            p.move="ASK";
            p.target="recent_specific_episode";
            p.askBudget=1;
            p.rationale="rebuild from one concrete recent episode rather than broad intake";
        }else if("DIFFUSE_HYPOTHESES".equals(reason)
                || "INSUFFICIENT_HYPOTHESIS_SEPARATION".equals(reason)){
            p.move="ASK";
            p.target=bestDiscriminatingTarget(f);
            p.askBudget=1;
            p.rationale="ask one high-information discriminator between top hypotheses";
        }else if("LOW_FORMULATION_CONFIDENCE".equals(reason)){
            p.move="ASK";
            p.target=firstMissing(f);
            if(p.target.isEmpty())p.target=bestDiscriminatingTarget(f);
            p.askBudget=1;
            p.rationale="resolve one missing variable without restarting intake";
        }else if("INTERVENTION_WORSENED_EXPERIENCE".equals(reason)){
            p.move="FORMULATE";
            p.target="intervention_mismatch";
            p.askBudget=0;
            p.rationale="first reformulate why the intervention worsened the experience";
        }else if("STRONG_CONTRADICTORY_ANSWER_EVIDENCE".equals(reason)){
            p.move="FORMULATE";
            p.target="contradictory_evidence";
            p.askBudget=0;
            p.rationale="update interpretation using explicit counterevidence before asking more";
        }else if("ADAPTIVE_PLANNER_REQUESTED_REOPEN".equals(reason)){
            p.move="ASK";
            p.target=bestDiscriminatingTarget(f);
            p.askBudget=1;
            p.rationale="adaptive failure requires one targeted reassessment";
        }else{
            p.move="FORMULATE";
            p.askBudget=0;
            p.rationale="reopen reason unknown; summarize uncertainty before further questioning";
        }

        // Never ask a target already known.
        JSONArray known=f.optJSONArray("known_variables");
        if(p.askBudget>0 && contains(known,p.target)){
            String replacement=firstMissing(f);
            if(!replacement.isEmpty()&&!contains(known,replacement)){
                p.target=replacement;
            }else{
                p.move="FORMULATE";
                p.askBudget=0;
                p.rationale+="; intended target already known";
            }
        }

        return p;
    }

    public static void apply(Context c,Plan p){
        if(c==null||p==null||!p.active)return;
        try{
            JSONObject f=CentralTherapyProfile.loadFormulation(c);
            JSONArray hs=f.optJSONArray("alternative_hypotheses");
            if(hs!=null)f.put("alternative_hypotheses",hs);

            f.put("reopen_recovery_target",p.target);
            f.put("reopen_recovery_move",p.move);
            f.put("reopen_recovery_ask_budget",p.askBudget);
            f.put("reopen_recovery_rationale",p.rationale);
            f.put("retired_hypotheses",new JSONArray(p.retiredIds));
            f.put("updated_at",System.currentTimeMillis());

            CentralTherapyProfile.replaceFormulation(c,f);
        }catch(Exception ignored){}
    }

    public static String instruction(Plan p){
        if(p==null||!p.active)return "";
        StringBuilder b=new StringBuilder();
        b.append("REOPEN_RECOVERY=true. ");
        if("ASK".equals(p.move)){
            b.append("처음부터 다시 묻지 않는다. recovery_target=")
                    .append(p.target)
                    .append(" 하나만 확인한다. ");
        }else{
            b.append("추가 질문보다 기존 evidence를 다시 묶어 formulation을 수정한다. ");
        }
        if(p.retiredCount>0){
            b.append("반복 반증된 가설 ").append(p.retiredIds)
                    .append(" 은 active 후보에서 제외했다. ");
        }
        b.append("known information 재질문 금지. rationale=").append(p.rationale);
        return b.toString();
    }

    private static String bestDiscriminatingTarget(JSONObject f){
        JSONArray hs=f.optJSONArray("alternative_hypotheses");
        Set<String> ids=new HashSet<>();
        if(hs!=null){
            for(int i=0;i<hs.length();i++){
                JSONObject h=hs.optJSONObject(i);
                if(h!=null&&h.optBoolean("active",true))
                    ids.add(h.optString("id",""));
            }
        }

        if(ids.contains("normal_response_variation")
                &&ids.contains("relationship_distance_change"))
            return "baseline_relationship_change";

        if(ids.contains("actual_rejection_or_conflict")
                &&ids.contains("rejection_interpretation_amplification"))
            return "recent_conflict";

        if(ids.contains("evaluation_threat")
                &&ids.contains("workload_stress"))
            return "evaluation_meaning";

        if(ids.contains("workload_stress")
                &&ids.contains("interpersonal_work_stress"))
            return "workload_vs_relationship";

        if(ids.contains("avoidance_negative_reinforcement"))
            return "short_term_relief";

        String missing=firstMissing(f);
        return missing.isEmpty()?"recent_specific_episode":missing;
    }

    private static String firstMissing(JSONObject f){
        JSONArray a=f.optJSONArray("missing_information");
        if(a==null)return "";
        for(int i=0;i<a.length();i++){
            String x=a.optString(i,"");
            if(!x.isEmpty())return x;
        }
        return "";
    }

    private static int strongCounterEvidenceCount(JSONArray a){
        if(a==null)return 0;
        int n=0;
        for(int i=0;i<a.length();i++){
            String s=a.optString(i,"").toLowerCase();
            if(s.contains("contradict")
                    ||s.contains("absence")
                    ||s.contains("no recent")
                    ||s.contains("not selective")
                    ||s.contains("against")
                    ||s.contains("반증")
                    ||s.contains("없음")) n++;
        }
        return n;
    }

    private static boolean contains(JSONArray a,String target){
        if(a==null||target==null||target.isEmpty())return false;
        for(int i=0;i<a.length();i++)if(target.equals(a.optString(i,"")))return true;
        return false;
    }
}
