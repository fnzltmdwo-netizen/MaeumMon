package com.maeummon.app.clinical;

import android.content.Context;
import org.json.*;

public final class StructuredOutcomeProvenanceCanonicalIdentityRC12 {
    private StructuredOutcomeProvenanceCanonicalIdentityRC12(){}

    public static final class Result {
        public boolean evaluated=false;
        public boolean enriched=false;
        public boolean migratedLegacyRows=false;
        public int rowsEnriched=0;
        public int legacyRowsMigrated=0;
        public String experimentId="";
        public String mechanism="";
        public String interventionId="";
        public String contextScope="";
        public String mode="";
        public String dose="";
        public String canonicalLearningKey="";
        public String reason="";
        public String summary="";
    }

    public static Result apply(Context c,ClinicalDecisionRC7 d){
        Result r=new Result();
        if(c==null||d==null){
            r.summary="NO_EVALUATION | NO_CONTEXT_OR_DECISION";
            return r;
        }

        JSONObject p=CentralTherapyProfile.loadProfile(c);
        JSONObject f=CentralTherapyProfile.loadFormulation(c);

        r.evaluated=true;
        r.experimentId=firstNonEmpty(safe(d.outcomeCommitExperimentId),safe(d.microExperimentId));
        r.mechanism=safe(d.centralMechanism);
        r.interventionId=safe(d.selectedInterventionId);
        r.contextScope=f.optString("current_context_scope","UNKNOWN");
        r.mode=firstNonEmpty(safe(d.preferenceMode),safe(d.policySelectionEffectiveMode));
        r.dose=firstNonEmpty(safe(d.interventionDose),safe(d.policySelectionEffectiveDose));
        r.canonicalLearningKey=buildKey(r.mechanism,r.interventionId,r.contextScope,r.experimentId);

        if("COMMIT".equals(d.outcomeCommitState)){
            enrichMatching(p.optJSONArray("micro_experiment_outcome_commit_history"),r);
            enrichMatching(p.optJSONArray("outcome_commit_idempotency_history"),r);
            enrichMatching(p.optJSONArray("cross_context_transfer_history"),r);
        }

        migrateLegacyRows(p.optJSONArray("micro_experiment_outcome_commit_history"),r);
        migrateLegacyRows(p.optJSONArray("outcome_commit_idempotency_history"),r);
        migrateLegacyRows(p.optJSONArray("cross_context_transfer_history"),r);

        try{
            p.put("last_canonical_learning_key",r.canonicalLearningKey);
            p.put("last_canonical_learning_experiment_id",r.experimentId);
            p.put("last_canonical_learning_intervention_id",r.interventionId);
            p.put("last_canonical_learning_mechanism",r.mechanism);
            p.put("last_canonical_learning_context",r.contextScope);
            p.put("last_canonical_learning_identity_at",System.currentTimeMillis());
            CentralTherapyProfile.replaceProfile(c,p);
        }catch(Exception ignored){}

        r.enriched=r.rowsEnriched>0;
        r.reason=r.enriched?"COMMIT_PROVENANCE_ENRICHED":
                (r.migratedLegacyRows?"LEGACY_ROWS_MIGRATED":"NO_MATCHING_ROWS");
        r.summary="enriched="+r.enriched
                +" | rows="+r.rowsEnriched
                +" | legacyMigrated="+r.legacyRowsMigrated
                +" | key="+r.canonicalLearningKey
                +" | reason="+r.reason;
        return r;
    }

    public static boolean exactLearningMatch(JSONObject row,String mechanism,String interventionId,String contextScope){
        if(row==null)return false;

        String rm=row.optString("mechanism","");
        String ri=row.optString("intervention_id","");
        String rc=row.optString("context_scope","");

        if(!rm.isEmpty()||!ri.isEmpty()||!rc.isEmpty()){
            if(!safe(mechanism).equals(rm))return false;
            if(!safe(interventionId).equals(ri))return false;
            return "GENERAL".equals(safe(contextScope))||safe(contextScope).equals(rc);
        }

        String exp=row.optString("experiment_id","");
        return !safe(interventionId).isEmpty()&&exp.contains(safe(interventionId));
    }

    public static boolean exactInterventionMatch(JSONObject row,String interventionId){
        if(row==null)return false;
        String ri=row.optString("intervention_id","");
        if(!ri.isEmpty())return safe(interventionId).equals(ri);
        String exp=row.optString("experiment_id","");
        return !safe(interventionId).isEmpty()&&exp.contains(safe(interventionId));
    }

    public static String instruction(Result r){
        if(r==null||!r.evaluated)return "";
        if(r.enriched||r.migratedLegacyRows)
            return "STRUCTURED_OUTCOME_PROVENANCE=READY. outcome learning은 experiment 문자열 추측보다 mechanism/intervention/context/mode/dose의 구조화된 provenance를 우선 사용한다.";
        return "";
    }

    private static void enrichMatching(JSONArray a,Result r){
        if(a==null||r.experimentId.isEmpty())return;
        for(int i=0;i<a.length();i++){
            JSONObject x=a.optJSONObject(i);
            if(x==null)continue;
            if(!r.experimentId.equals(x.optString("experiment_id","")))continue;
            enrich(x,r);
            r.rowsEnriched++;
        }
    }

    private static void migrateLegacyRows(JSONArray a,Result r){
        if(a==null||r.interventionId.isEmpty())return;
        for(int i=0;i<a.length();i++){
            JSONObject x=a.optJSONObject(i);
            if(x==null)continue;
            if(!x.optString("intervention_id","").isEmpty())continue;
            String exp=x.optString("experiment_id","");
            if(!exp.contains(r.interventionId))continue;
            enrich(x,r);
            r.legacyRowsMigrated++;
            r.migratedLegacyRows=true;
        }
    }

    private static void enrich(JSONObject x,Result r){
        try{
            if(x.optString("mechanism","").isEmpty())x.put("mechanism",r.mechanism);
            if(x.optString("intervention_id","").isEmpty())x.put("intervention_id",r.interventionId);
            if(x.optString("context_scope","").isEmpty())x.put("context_scope",r.contextScope);
            if(x.optString("mode","").isEmpty())x.put("mode",r.mode);
            if(x.optString("dose","").isEmpty())x.put("dose",r.dose);
            x.put("canonical_learning_key",r.canonicalLearningKey);
            x.put("provenance_schema_version","6.7.4");
        }catch(Exception ignored){}
    }

    private static String buildKey(String mechanism,String intervention,String context,String experiment){
        return safe(mechanism)+"::"+safe(intervention)+"::"+safe(context)+"::"+safe(experiment);
    }
    private static String firstNonEmpty(String a,String b){ return a!=null&&!a.isEmpty()?a:(b==null?"":b); }
    private static String safe(String s){ return s==null?"":s; }
}
