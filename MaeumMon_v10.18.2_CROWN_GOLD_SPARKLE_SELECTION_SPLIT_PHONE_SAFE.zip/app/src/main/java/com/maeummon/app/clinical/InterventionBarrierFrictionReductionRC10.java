package com.maeummon.app.clinical;

import android.content.Context;
import org.json.*;

public final class InterventionBarrierFrictionReductionRC10 {
    private InterventionBarrierFrictionReductionRC10(){}

    public enum Barrier {
        NONE,
        TOO_BIG,
        FORGOT,
        FEAR_OR_AVOIDANCE,
        UNCLEAR,
        NO_TIME,
        LOW_ENERGY,
        ENVIRONMENT,
        RESISTANCE,
        UNKNOWN
    }

    public static final class Result {
        public Barrier barrier=Barrier.NONE;
        public boolean shouldShrink=false;
        public boolean shouldClarify=false;
        public boolean shouldCue=false;
        public boolean shouldReduceDose=false;
        public boolean shouldChangeContext=false;
        public boolean switchIntervention=false;
        public String microAdjustment="";
        public String rationale="";
        public String summary="";
    }

    public static Result analyze(
            Context c,String userText,ClinicalDecisionRC7 d){

        Result r=new Result();
        String u=userText==null?"":userText.trim();

        if(d==null){
            r.barrier=Barrier.UNKNOWN;
            r.summary="UNKNOWN | NO_DECISION";
            return r;
        }

        if(!"NOT_TRIED".equals(d.interventionOutcome)
                && !"CHECK_BARRIER".equals(d.interventionAdaptationAction)){
            r.barrier=Barrier.NONE;
            r.summary="NONE | BARRIER_ANALYSIS_NOT_NEEDED";
            return r;
        }

        r.barrier=detect(u);

        switch(r.barrier){
            case TOO_BIG:
                r.shouldShrink=true;
                r.shouldReduceDose=true;
                r.microAdjustment="기존 개입을 1분 이하의 한 행동으로 줄인다.";
                r.rationale="개입 자체의 방향보다 크기가 실행을 막았을 가능성이 높다.";
                break;

            case FORGOT:
                r.shouldCue=true;
                r.microAdjustment="새 과제를 추가하지 말고 기존 개입에 단일 cue를 붙인다.";
                r.rationale="의지 부족이 아니라 기억/실행 cue 문제일 수 있다.";
                break;

            case FEAR_OR_AVOIDANCE:
                r.shouldShrink=true;
                r.shouldReduceDose=true;
                r.microAdjustment="불안을 일으키는 행동의 가장 작은 버전으로 낮춘다.";
                r.rationale="회피가 장벽이면 더 강한 요구보다 접근 단위를 낮추는 게 우선이다.";
                break;

            case UNCLEAR:
                r.shouldClarify=true;
                r.microAdjustment="무엇을 언제 어떻게 할지 한 문장으로 다시 정의한다.";
                r.rationale="개입이 모호하면 실행 여부로 효과를 판단할 수 없다.";
                break;

            case NO_TIME:
                r.shouldShrink=true;
                r.shouldChangeContext=true;
                r.microAdjustment="별도 시간을 만들지 않고 이미 있는 일상 행동에 붙인다.";
                r.rationale="시간 부족이면 추가 일정이 아니라 기존 루틴에 삽입한다.";
                break;

            case LOW_ENERGY:
                r.shouldReduceDose=true;
                r.shouldShrink=true;
                r.microAdjustment="숙제 없이 가장 작은 행동 1개로 낮춘다.";
                r.rationale="에너지 부족 상태에서 강도를 올리면 실행 실패만 반복될 수 있다.";
                break;

            case ENVIRONMENT:
                r.shouldChangeContext=true;
                r.microAdjustment="실행 가능한 장소/상황으로 옮기고 조건을 단순화한다.";
                r.rationale="환경 제약은 개입 효과와 별개의 실행 조건 문제다.";
                break;

            case RESISTANCE:
                r.shouldClarify=true;
                r.microAdjustment="이 개입을 원치 않는 이유와 사용자에게 더 맞는 형태를 먼저 확인한다.";
                r.rationale="사용자 자율성과 합의가 없는 상태에서 순응을 강요하지 않는다.";
                break;

            case UNKNOWN:
                r.shouldClarify=true;
                r.microAdjustment="한 가지만 확인한다: 못 한 가장 큰 이유가 무엇이었는지 묻는다.";
                r.rationale="장벽을 추측하지 않고 discriminating question 하나로 확인한다.";
                break;

            default:
                break;
        }

        // Barrier alone never authorizes technique switching.
        r.switchIntervention=false;

        // Persist only when a real barrier state was evaluated.
        persist(c,r,u,d);

        r.summary=r.barrier.name()
                +" | shrink="+r.shouldShrink
                +" | clarify="+r.shouldClarify
                +" | cue="+r.shouldCue
                +" | reduceDose="+r.shouldReduceDose
                +" | context="+r.shouldChangeContext;
        return r;
    }

    public static String instruction(Result r){
        if(r==null||r.barrier==Barrier.NONE)return "";

        return "INTERVENTION_BARRIER="+r.barrier.name()
                +". 기존 intervention을 실패로 버리지 않는다. "
                +r.microAdjustment
                +" 새로운 기법으로 전환하지 말고 실행 마찰만 낮춘다.";
    }

    public static Barrier detect(String s){
        if(s==null||s.trim().isEmpty())return Barrier.UNKNOWN;
        String u=s.trim();

        if(containsAny(u,
                "너무 많","너무 커","부담돼","복잡해","할 게 많","벅차"))
            return Barrier.TOO_BIG;

        if(containsAny(u,
                "깜빡","잊어","기억 못","생각이 안 났"))
            return Barrier.FORGOT;

        if(containsAny(u,
                "무서워서","겁나서","피하고 싶","하기 싫어서 무서",
                "불안해서 못","마주치기 싫"))
            return Barrier.FEAR_OR_AVOIDANCE;

        if(containsAny(u,
                "뭘 해야 할지","어떻게 하는지","잘 모르겠","애매해",
                "무슨 말인지 모르"))
            return Barrier.UNCLEAR;

        if(containsAny(u,
                "시간이 없","바빠서","할 시간이","틈이 없"))
            return Barrier.NO_TIME;

        if(containsAny(u,
                "기운이 없","너무 지쳐","피곤해서","에너지가 없",
                "아무것도 하기 싫"))
            return Barrier.LOW_ENERGY;

        if(containsAny(u,
                "회사라서 못","사람들이 있어서","환경이 안 돼",
                "장소가","상황이 안 돼"))
            return Barrier.ENVIRONMENT;

        if(containsAny(u,
                "하기 싫어","이건 별로","이 방법 싫","굳이 하고 싶지",
                "나한테 안 맞는 것 같"))
            return Barrier.RESISTANCE;

        return Barrier.UNKNOWN;
    }

    private static void persist(
            Context c,Result r,String userText,ClinicalDecisionRC7 d){

        try{
            JSONObject p=CentralTherapyProfile.loadProfile(c);
            JSONObject f=CentralTherapyProfile.loadFormulation(c);

            p.put("last_intervention_barrier",r.barrier.name());
            p.put("last_intervention_barrier_adjustment",r.microAdjustment);
            p.put("last_intervention_barrier_at",System.currentTimeMillis());

            JSONArray history=p.optJSONArray("intervention_barrier_history");
            if(history==null)history=new JSONArray();

            JSONObject item=new JSONObject();
            item.put("barrier",r.barrier.name());
            item.put("intervention_id",d.selectedInterventionId==null?"":d.selectedInterventionId);
            item.put("dose",d.interventionDose==null?"":d.interventionDose);
            item.put("user_evidence",compact(userText,400));
            item.put("adjustment",r.microAdjustment);
            item.put("time",System.currentTimeMillis());
            history.put(item);

            JSONArray trimmed=new JSONArray();
            int start=Math.max(0,history.length()-20);
            for(int i=start;i<history.length();i++)trimmed.put(history.opt(i));
            p.put("intervention_barrier_history",trimmed);

            f.put("last_intervention_barrier",r.barrier.name());
            f.put("last_intervention_barrier_adjustment",r.microAdjustment);

            CentralTherapyProfile.replaceProfile(c,p);
            CentralTherapyProfile.replaceFormulation(c,f);
        }catch(Exception ignored){}
    }

    private static boolean containsAny(String s,String... xs){
        for(String x:xs)if(s.contains(x))return true;
        return false;
    }

    private static String compact(String s,int max){
        s=s==null?"":s.trim();
        return s.length()<=max?s:s.substring(0,max);
    }
}
