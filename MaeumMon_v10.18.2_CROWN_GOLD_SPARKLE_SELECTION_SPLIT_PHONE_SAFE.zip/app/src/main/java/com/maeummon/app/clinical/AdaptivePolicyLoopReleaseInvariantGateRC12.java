package com.maeummon.app.clinical;

import android.content.Context;
import org.json.*;
import java.util.*;

public final class AdaptivePolicyLoopReleaseInvariantGateRC12 {
    private AdaptivePolicyLoopReleaseInvariantGateRC12(){}

    public static final class Result {
        public boolean passed=true;
        public boolean repaired=false;
        public boolean outcomeLeakBlocked=false;
        public boolean hierarchyLeakBlocked=false;
        public boolean retiredLeakBlocked=false;
        public boolean exceptionLeakBlocked=false;
        public boolean bridgeOverrideBlocked=false;
        public int violationCount=0;
        public String violations="";
        public String summary="";
    }

    public static Result verify(Context c,ClinicalDecisionRC7 d){
        Result r=new Result();
        if(c==null||d==null){
            r.passed=false;
            r.violationCount=1;
            r.violations="NO_CONTEXT_OR_DECISION";
            r.summary="FAIL | NO_CONTEXT_OR_DECISION";
            return r;
        }

        ArrayList<String> v=new ArrayList<>();
        JSONObject p=CentralTherapyProfile.loadProfile(c);
        JSONObject f=CentralTherapyProfile.loadFormulation(c);

        // Invariant 1:
        // active micro-experiment + uncertain attribution must never become generic outcome learning.
        if(d.microExperimentActive
                && d.microExperimentOutcomeNeedsClarification
                && !"COMMIT".equals(d.outcomeCommitState)
                && !"UNKNOWN".equals(safe(d.interventionOutcome))){

            d.interventionOutcome="UNKNOWN";
            d.interventionOutcomeAction="REVIEW_OR_ATTRIBUTION_CLARIFICATION";
            r.outcomeLeakBlocked=true;
            r.repaired=true;
            v.add("UNATTRIBUTED_OUTCOME_LEARNING_BLOCKED");
        }

        // Invariant 2:
        // CURRENT_ONLY / suppressed hierarchy must leave no policy-affect flags.
        if("CURRENT_ONLY".equals(d.policyHierarchyWinner)
                || d.policySelectionSuppressed){

            if(d.policyRetrievalApplicable
                    ||d.policyCanAffectIntervention
                    ||d.policyCanAffectMode
                    ||d.policyCanAffectDose){

                d.policyRetrievalApplicable=false;
                d.policyCanAffectIntervention=false;
                d.policyCanAffectMode=false;
                d.policyCanAffectDose=false;
                d.policyRetrievalKey="";
                d.policyRetrievalInterventionId="";
                d.policyRetrievalMode="";
                d.policyRetrievalDose="";

                r.hierarchyLeakBlocked=true;
                r.repaired=true;
                v.add("HIERARCHY_POLICY_LEAK_BLOCKED");
            }
        }

        // Invariant 3:
        // effective policy may never be retired.
        String effectiveKey=safe(d.policySelectionEffectiveKey);
        JSONObject effective=findPolicyByKey(
                p.optJSONArray("intervention_policy_memory"),
                effectiveKey);

        if(effective!=null
                && "RETIRED".equals(
                        effective.optString("policy_status","ACTIVE"))){

            clearPolicyInfluence(d);
            r.retiredLeakBlocked=true;
            r.repaired=true;
            v.add("RETIRED_POLICY_LEAK_BLOCKED");
        }

        // Invariant 4:
        // GENERAL policy excluded in current context cannot remain effective.
        if(effective!=null
                && "GENERAL".equals(
                        effective.optString("context_scope",""))
                && !GeneralPolicyExceptionBoundaryRC11
                        .generalPolicyAllowedInContext(
                                effective,
                                f.optString("current_context_scope","UNKNOWN"))){

            clearPolicyInfluence(d);
            r.exceptionLeakBlocked=true;
            r.repaired=true;
            v.add("GENERAL_EXCEPTION_LEAK_BLOCKED");
        }

        // Invariant 5:
        // policy memory cannot replace current bridge intervention.
        if(d.policyCanAffectIntervention
                && !safe(d.policyRetrievalInterventionId).isEmpty()
                && !safe(d.selectedInterventionId).isEmpty()
                && !safe(d.policyRetrievalInterventionId)
                        .equals(safe(d.selectedInterventionId))){

            d.policyCanAffectIntervention=false;
            r.bridgeOverrideBlocked=true;
            r.repaired=true;
            v.add("POLICY_BRIDGE_OVERRIDE_BLOCKED");
        }

        r.violationCount=v.size();
        r.passed=v.isEmpty();

        StringBuilder sb=new StringBuilder();
        for(int i=0;i<v.size();i++){
            if(i>0)sb.append(",");
            sb.append(v.get(i));
        }
        r.violations=sb.toString();

        r.summary=(r.passed?"PASS":"REPAIRED")
                +" | violations="+r.violationCount
                +" | "+r.violations;

        persist(c,r);
        return r;
    }

    public static String instruction(Result r){
        if(r==null)return "";

        if(r.repaired){
            return "ADAPTIVE_POLICY_RELEASE_GATE=REPAIRED. 내부 personalization/learning 상태 모순을 정리했으며 현재 evidence와 Central Bridge를 최종 우선한다.";
        }

        if(r.passed){
            return "ADAPTIVE_POLICY_RELEASE_GATE=PASS. outcome attribution, policy hierarchy, exception, retirement, bridge invariants가 일치한다.";
        }

        return "";
    }

    private static void clearPolicyInfluence(ClinicalDecisionRC7 d){
        d.policyRetrievalApplicable=false;
        d.policyCanAffectIntervention=false;
        d.policyCanAffectMode=false;
        d.policyCanAffectDose=false;
        d.policyRetrievalKey="";
        d.policyRetrievalInterventionId="";
        d.policyRetrievalMode="";
        d.policyRetrievalDose="";
        d.policySelectionEffectiveKey="";
        d.policySelectionEffectiveIntervention="";
        d.policySelectionEffectiveMode="";
        d.policySelectionEffectiveDose="";
    }

    private static JSONObject findPolicyByKey(
            JSONArray a,String key){
        if(a==null||key==null||key.isEmpty())return null;
        for(int i=0;i<a.length();i++){
            JSONObject x=a.optJSONObject(i);
            if(x!=null&&key.equals(x.optString("key","")))
                return x;
        }
        return null;
    }

    private static void persist(Context c,Result r){
        try{
            JSONObject f=CentralTherapyProfile.loadFormulation(c);
            f.put("adaptive_policy_release_gate_passed",r.passed);
            f.put("adaptive_policy_release_gate_repaired",r.repaired);
            f.put("adaptive_policy_release_gate_violation_count",r.violationCount);
            f.put("adaptive_policy_release_gate_violations",r.violations);
            f.put("adaptive_policy_release_gate_updated_at",
                    System.currentTimeMillis());
            CentralTherapyProfile.replaceFormulation(c,f);
        }catch(Exception ignored){}
    }

    private static String safe(String s){
        return s==null?"":s;
    }
}
