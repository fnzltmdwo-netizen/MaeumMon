package com.maeummon.app;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MemoryManager {
    private static SharedPreferences p(Context c){return c.getSharedPreferences(AppPrefs.PREFS, Context.MODE_PRIVATE);}

    public static synchronized JSONArray memories(Context c){
        try{return new JSONArray(p(c).getString(AppPrefs.KEY_MEMORY_CARDS,"[]"));}catch(Exception e){return new JSONArray();}
    }

    public static synchronized void addMemory(Context c,String title,String text,String tag){
        if(text==null || text.trim().isEmpty()) return;
        try{
            JSONArray old=memories(c), out=new JSONArray();
            JSONObject n=new JSONObject();
            n.put("time",System.currentTimeMillis()); n.put("date",date(System.currentTimeMillis()));
            n.put("title",title==null?"기억":title); n.put("text",text.trim()); n.put("tag",tag==null?"마음":tag);
            out.put(n);
            for(int i=0;i<old.length() && i<29;i++) out.put(old.getJSONObject(i));
            p(c).edit().putString(AppPrefs.KEY_MEMORY_CARDS,out.toString()).apply();
        }catch(Exception ignored){}
    }

    public static void captureDiary(Context c,String label,String text){
        if(text==null) return;
        String s=text.trim(); if(s.isEmpty()) return;
        if(s.length()>110) s=s.substring(0,110)+"…";
        addMemory(c,"오늘의 마음 · "+(label==null?"기록":label),s,"일기");
    }

    public static synchronized void addFollowUp(Context c,String text,long dueAt){
        if(text==null || text.trim().isEmpty()) return;
        try{
            JSONArray arr=followUps(c); JSONObject o=new JSONObject();
            o.put("id",System.currentTimeMillis()); o.put("text",text.trim()); o.put("due",dueAt); o.put("asked",false);
            arr.put(o); p(c).edit().putString(AppPrefs.KEY_FOLLOW_UPS,arr.toString()).apply();
            addMemory(c,"다시 물어보기 약속",text,"약속");
        }catch(Exception ignored){}
    }

    public static synchronized JSONArray followUps(Context c){
        try{return new JSONArray(p(c).getString(AppPrefs.KEY_FOLLOW_UPS,"[]"));}catch(Exception e){return new JSONArray();}
    }

    public static synchronized JSONObject nextDue(Context c){
        JSONArray arr=followUps(c); long now=System.currentTimeMillis(); JSONObject best=null; long bestDue=Long.MAX_VALUE;
        for(int i=0;i<arr.length();i++){
            JSONObject o=arr.optJSONObject(i); if(o==null || o.optBoolean("asked",false)) continue;
            long due=o.optLong("due",Long.MAX_VALUE); if(due<=now && due<bestDue){best=o;bestDue=due;}
        }
        return best;
    }

    public static synchronized void markAsked(Context c,long id){
        JSONArray arr=followUps(c);
        for(int i=0;i<arr.length();i++){JSONObject o=arr.optJSONObject(i);if(o!=null&&o.optLong("id") == id){try{o.put("asked",true);o.put("askedAt",System.currentTimeMillis());}catch(Exception ignored){}}}
        p(c).edit().putString(AppPrefs.KEY_FOLLOW_UPS,arr.toString()).apply();
    }

    public static int pendingCount(Context c){JSONArray arr=followUps(c);int n=0;for(int i=0;i<arr.length();i++){JSONObject o=arr.optJSONObject(i);if(o!=null&&!o.optBoolean("asked",false))n++;}return n;}

    public static String preview(Context c){
        JSONArray arr=memories(c); if(arr.length()==0)return "아직 저장된 기억 카드가 없어.";
        StringBuilder sb=new StringBuilder(); int max=Math.min(3,arr.length());
        for(int i=0;i<max;i++){JSONObject o=arr.optJSONObject(i);if(o==null)continue;String text=o.optString("text");if(text.length()>45)text=text.substring(0,45)+"…";sb.append("• ").append(o.optString("title","기억")).append(" — ").append(text);if(i<max-1)sb.append("\n");}
        return sb.toString();
    }

    public static String date(long ms){return new SimpleDateFormat("yyyy.MM.dd HH:mm", Locale.KOREA).format(new Date(ms));}
}
