package com.maeummon.app;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

public final class TherapyMemoryManager {
    private static final String PREF = "maeummon_therapy_memory";
    private static final String K_PROFILE = "profile";
    private static final String K_LOG = "log";
    private static final String K_TURN_COUNT = "turn_count";

    private TherapyMemoryManager() {}

    private static SharedPreferences p(Context c) {
        return c.getSharedPreferences(PREF, Context.MODE_PRIVATE);
    }

    public static synchronized void save(Context c, OpenAiClient.CounselingResult r) {
        if (r == null) return;
        try {
            JSONObject profile = getProfile(c);
            putIfUseful(profile, "focus", r.focus);
            putIfUseful(profile, "pattern", r.pattern);
            putIfUseful(profile, "reframe", r.reframe);
            putIfUseful(profile, "experiment", r.experiment);
            putIfUseful(profile, "follow_up", r.followUp);
            putIfUseful(profile, "strength", r.strength);
            putIfUseful(profile, "summary", r.sessionSummary);
            putIfUseful(profile, "unmet_need", r.unmetNeed);
            putIfUseful(profile, "protective_strategy", r.protectiveStrategy);
            putIfUseful(profile, "corrective_experience", r.correctiveExperience);
            putIfUseful(profile, "trigger", r.trigger);
            putIfUseful(profile, "core_emotion", r.coreEmotion);
            putIfUseful(profile, "automatic_thought", r.automaticThought);
            putIfUseful(profile, "core_fear", r.coreFear);
            putIfUseful(profile, "relationship_pattern", r.relationshipPattern);
            putIfUseful(profile, "effective_intervention", r.effectiveIntervention);
            putIfUseful(profile, "recent_change", r.recentChange);
            if (r.emotionIntensity > 0) profile.put("emotion_intensity", r.emotionIntensity);
            putIfUseful(profile, "current_need", r.currentNeed);
            putIfUseful(profile, "user_goal", r.userGoal);
            putIfUseful(profile, "personalization_basis", r.personalizationBasis);
            putIfUseful(profile, "intervention_rationale", r.interventionRationale);
            putIfUseful(profile, "next_session_link", r.nextSessionLink);
            putIfUseful(profile, "confirmed_facts", r.confirmedFacts);
            putIfUseful(profile, "open_question", r.openQuestion);
            if (!"rejected".equals(r.hypothesisStatus)) {
                String oldWorking = profile.optString("working_hypothesis", "").trim();
                String newWorking = clean(r.workingHypothesis);
                if (!oldWorking.isEmpty() && !newWorking.isEmpty() && !oldWorking.equals(newWorking)
                        && ("confirmed".equals(r.hypothesisStatus) || r.hypothesisEvidenceCount >= 2)) {
                    profile.put("superseded_hypothesis", oldWorking);
                    profile.put("hypothesis_revision_at", System.currentTimeMillis());
                }
                putIfUseful(profile, "working_hypothesis", r.workingHypothesis);
                putIfUseful(profile, "hypothesis_status", r.hypothesisStatus);
                if (r.hypothesisEvidenceCount > 0) profile.put("hypothesis_evidence_count", r.hypothesisEvidenceCount);
            } else {
                String rejected = clean(r.workingHypothesis);
                String oldWorking = profile.optString("working_hypothesis", "").trim();
                if (!oldWorking.isEmpty()) profile.put("superseded_hypothesis", oldWorking);
                else if (!rejected.isEmpty()) profile.put("superseded_hypothesis", rejected);
                profile.put("hypothesis_revision_at", System.currentTimeMillis());
                profile.remove("working_hypothesis");
                profile.remove("hypothesis_status");
                profile.remove("hypothesis_evidence_count");
            }
            // 심층/핵심 믿음은 충분히 확인된 가설만 장기 기억으로 승격한다. v3.2.2부터는 독립 근거 3개가 있어야 한다.
            // 확인 전/기각 상태에서는 기존에 충분한 근거로 저장된 장기 가설을 함부로 덮어쓰거나 지우지 않는다.
            if ("confirmed".equals(r.hypothesisStatus) && r.hypothesisEvidenceCount >= 3) {
                String oldRoot = profile.optString("root_hypothesis", "").trim();
                String newRoot = clean(r.rootHypothesis);
                if (!oldRoot.isEmpty() && !newRoot.isEmpty() && !oldRoot.equals(newRoot)) {
                    profile.put("superseded_root_hypothesis", oldRoot);
                    profile.put("hypothesis_revision_at", System.currentTimeMillis());
                }
                putIfUseful(profile, "root_hypothesis", r.rootHypothesis);
                putIfUseful(profile, "core_belief", r.coreBelief);
            }
            putIfUseful(profile, "phase", r.phase);
            profile.put("updated_at", System.currentTimeMillis());

            JSONArray old = getLog(c);
            JSONObject item = new JSONObject();
            item.put("time", System.currentTimeMillis());
            item.put("focus", clean(r.focus));
            item.put("pattern", clean(r.pattern));
            item.put("reframe", clean(r.reframe));
            item.put("experiment", clean(r.experiment));
            item.put("follow_up", clean(r.followUp));
            item.put("strength", clean(r.strength));
            item.put("summary", clean(r.sessionSummary));
            item.put("root_hypothesis", clean(r.rootHypothesis));
            item.put("core_belief", clean(r.coreBelief));
            item.put("unmet_need", clean(r.unmetNeed));
            item.put("protective_strategy", clean(r.protectiveStrategy));
            item.put("corrective_experience", clean(r.correctiveExperience));
            item.put("trigger", clean(r.trigger));
            item.put("core_emotion", clean(r.coreEmotion));
            item.put("automatic_thought", clean(r.automaticThought));
            item.put("core_fear", clean(r.coreFear));
            item.put("relationship_pattern", clean(r.relationshipPattern));
            item.put("effective_intervention", clean(r.effectiveIntervention));
            item.put("recent_change", clean(r.recentChange));
            item.put("emotion_intensity", r.emotionIntensity);
            item.put("current_need", clean(r.currentNeed));
            item.put("user_goal", clean(r.userGoal));
            item.put("personalization_basis", clean(r.personalizationBasis));
            item.put("intervention_rationale", clean(r.interventionRationale));
            item.put("next_session_link", clean(r.nextSessionLink));
            item.put("confirmed_facts", clean(r.confirmedFacts));
            item.put("open_question", clean(r.openQuestion));
            item.put("working_hypothesis", clean(r.workingHypothesis));
            item.put("hypothesis_status", clean(r.hypothesisStatus));
            item.put("hypothesis_evidence_count", r.hypothesisEvidenceCount);
            item.put("phase", clean(r.phase));

            JSONArray next = new JSONArray();
            next.put(item);
            for (int i = 0; i < old.length() && i < 29; i++) next.put(old.optJSONObject(i));

            int turns = p(c).getInt(K_TURN_COUNT, 0) + 1;
            p(c).edit()
                    .putString(K_PROFILE, profile.toString())
                    .putString(K_LOG, next.toString())
                    .putInt(K_TURN_COUNT, turns)
                    .apply();

            TherapyJourneyManager.onCounselingSaved(c, r, turns);

            // 상담 변화지도와 하루 편지/현재 상태를 함께 갱신한다.
            ChangeMapManager.apply(c, r);
            LiveMindManager.onMindChanged(c);
        } catch (Exception ignored) {}
    }

    public static JSONObject getProfile(Context c) {
        try { return new JSONObject(p(c).getString(K_PROFILE, "{}")); }
        catch (Exception e) { return new JSONObject(); }
    }

    public static JSONArray getLog(Context c) {
        try { return new JSONArray(p(c).getString(K_LOG, "[]")); }
        catch (Exception e) { return new JSONArray(); }
    }

    public static int getTurnCount(Context c) {
        return p(c).getInt(K_TURN_COUNT, 0);
    }

    public static String getCurrentFocus(Context c) {
        String v = getProfile(c).optString("focus", "").trim();
        return v.isEmpty() ? "아직 첫 패턴을 함께 찾는 중" : v;
    }

    public static String getActiveExperiment(Context c) {
        String v = getProfile(c).optString("experiment", "").trim();
        return v.isEmpty() ? "상담을 이어가면 오늘의 작은 연습을 함께 정해." : v;
    }

    public static String buildContext(Context c) {
        StringBuilder sb = new StringBuilder();
        sb.append(PersonalTherapyProfile.baselineContext()).append("\n\n");
        sb.append(TherapyJourneyManager.context(c)).append("\n");
        sb.append(TherapyThreadManager.snapshot(c)).append("\n\n");
        sb.append("[해석 우선순위]\n")
          .append("1순위: 사용자의 방금 말과 오늘의 실제 사건\n")
          .append("2순위: 최근 상담/일기/행동 증거\n")
          .append("3순위: 앱에 누적된 변화상담 프로필\n")
          .append("4순위: 오래된 장기 배경 프로필\n")
          .append("최근 증거가 오래된 패턴과 다르면 최근 증거를 채택하고, 오래된 패턴을 성격처럼 고정하지 않는다.\n\n");
        JSONObject profile = getProfile(c);
        if (profile.length() > 0) {
            sb.append("[장기 변화상담 프로필]\n");
            append(sb, "현재 초점", profile.optString("focus"));
            append(sb, "반복 패턴", profile.optString("pattern"));
            append(sb, "도움이 된 새 관점", profile.optString("reframe"));
            append(sb, "현재 행동 실험", profile.optString("experiment"));
            append(sb, "다음에 확인할 것", profile.optString("follow_up"));
            append(sb, "최근 확인된 강점", profile.optString("strength"));
            append(sb, "직전 상담 요약", profile.optString("summary"));
            append(sb, "심층 사례개념화 가설", profile.optString("root_hypothesis"));
            append(sb, "핵심 믿음 가설", profile.optString("core_belief"));
            append(sb, "중요한 욕구/가치", profile.optString("unmet_need"));
            append(sb, "현재 보호전략", profile.optString("protective_strategy"));
            append(sb, "반복 트리거", profile.optString("trigger"));
            append(sb, "핵심 감정", profile.optString("core_emotion"));
            append(sb, "자동적 사고/해석", profile.optString("automatic_thought"));
            append(sb, "핵심 두려움", profile.optString("core_fear"));
            append(sb, "관계 패턴", profile.optString("relationship_pattern"));
            append(sb, "효과가 확인된 개입", profile.optString("effective_intervention"));
            append(sb, "최근 변화/새 증거", profile.optString("recent_change"));
            append(sb, "새로운 교정 경험", profile.optString("corrective_experience"));
            int intensity = profile.optInt("emotion_intensity", 0);
            if (intensity > 0) sb.append("최근 정서강도(내부 추정): ").append(intensity).append("/100\n");
            append(sb, "현재 핵심 필요", profile.optString("current_need"));
            append(sb, "현재 사용자의 목표", profile.optString("user_goal"));
            append(sb, "최근 개인화 근거", profile.optString("personalization_basis"));
            append(sb, "최근 개입 선택 이유", profile.optString("intervention_rationale"));
            append(sb, "다음 상담 연결고리", profile.optString("next_session_link"));
            append(sb, "이미 확인된 핵심 사실", profile.optString("confirmed_facts"));
            append(sb, "아직 모르는 핵심", profile.optString("open_question"));
            append(sb, "현재 작업가설", profile.optString("working_hypothesis"));
            append(sb, "작업가설 상태", profile.optString("hypothesis_status"));
            append(sb, "대체/폐기된 이전 작업가설", profile.optString("superseded_hypothesis"));
            append(sb, "대체된 이전 심층가설", profile.optString("superseded_root_hypothesis"));
            int hec = profile.optInt("hypothesis_evidence_count", 0);
            if (hec > 0) sb.append("작업가설 근거 수: ").append(hec).append("/3\n");
        }

        JSONArray log = getLog(c);
        if (log.length() > 0) {
            sb.append("\n[최근 변화 기록]\n");
            for (int i = 0; i < Math.min(log.length(), 6); i++) {
                JSONObject o = log.optJSONObject(i);
                if (o == null) continue;
                String s = o.optString("summary", "").trim();
                if (!s.isEmpty()) sb.append("- ").append(shorten(s, 240)).append('\n');
            }
        }

        sb.append("\n").append(ChangeMapManager.compact(c));
        sb.append("\n").append(LiveMindManager.recentContext(c));
        String casualContext = CasualChatStorage.getRecentUserContext(c, 12);
        if (!casualContext.trim().isEmpty()) {
            sb.append("\n\n").append(casualContext);
        }
        String out = sb.toString().trim();
        if (out.length() > 14000) out = out.substring(0, 6500) + "\n\n[최근 기록 이어짐]\n" + out.substring(out.length() - 7000);
        return out;
    }

    public static String compactForLiveMind(Context c) {
        JSONObject profile = getProfile(c);
        StringBuilder sb = new StringBuilder();
        append(sb, "변화상담 초점", profile.optString("focus"));
        append(sb, "반복 패턴", profile.optString("pattern"));
        append(sb, "현재 연습", profile.optString("experiment"));
        append(sb, "최근 강점", profile.optString("strength"));
        append(sb, "심층 가설", profile.optString("root_hypothesis"));
        append(sb, "핵심 믿음 가설", profile.optString("core_belief"));
        append(sb, "현재 보호전략", profile.optString("protective_strategy"));
        append(sb, "반복 트리거", profile.optString("trigger"));
        append(sb, "핵심 감정", profile.optString("core_emotion"));
        append(sb, "핵심 두려움", profile.optString("core_fear"));
        append(sb, "관계 패턴", profile.optString("relationship_pattern"));
        append(sb, "효과가 확인된 개입", profile.optString("effective_intervention"));
        append(sb, "최근 변화/새 증거", profile.optString("recent_change"));
        append(sb, "현재 핵심 필요", profile.optString("current_need"));
        append(sb, "현재 사용자 목표", profile.optString("user_goal"));
        append(sb, "다음 상담 연결고리", profile.optString("next_session_link"));
        return sb.toString().trim();
    }

    private static void putIfUseful(JSONObject o, String key, String value) throws Exception {
        String v = clean(value);
        if (!v.isEmpty() && !"없음".equals(v) && !"해당 없음".equals(v)) o.put(key, v);
    }

    private static void append(StringBuilder sb, String label, String value) {
        String v = clean(value);
        if (!v.isEmpty()) sb.append(label).append(": ").append(v).append('\n');
    }

    private static String clean(String s) { return s == null ? "" : s.trim(); }
    private static String shorten(String s, int n) { return s.length() <= n ? s : s.substring(0, n) + "..."; }
}
