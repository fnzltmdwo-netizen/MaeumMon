package com.maeummon.app.clinical;

import android.content.Context;

import java.util.*;

public final class ClinicalSelfCorrectionRC7 {
    private ClinicalSelfCorrectionRC7(){}

    public static final class Inspection {
        public final boolean correctionNeeded;
        public final String repairInstruction;
        public Inspection(boolean correctionNeeded,String repairInstruction){
            this.correctionNeeded=correctionNeeded;
            this.repairInstruction=repairInstruction==null?"":repairInstruction;
        }
    }

    public static Inspection inspect(
            String route,
            String target,
            String reply,
            ClinicalResponseQualityRC7.Result evaluation
    ){
        if(evaluation==null || !"FAIL".equalsIgnoreCase(evaluation.grade)){
            return new Inspection(false,"");
        }

        StringBuilder b=new StringBuilder();
        b.append("[RC7 QUALITY REPAIR]\n");
        b.append("아래 상담 답변을 문제점만 고쳐 한 번 다시 작성해.\n");
        b.append("route=").append(safe(route)).append("\n");
        b.append("target_variable=").append(safe(target)).append("\n");
        b.append("문제 태그:\n");
        if(evaluation.issues!=null){
            for(String issue:evaluation.issues)b.append("- ").append(issue).append("\n");
        }

        b.append("\n공통 규칙:\n");
        b.append("- 사용자가 이미 말한 사실을 다시 묻지 않는다.\n");
        b.append("- 진단명, 성격 낙인, 상대 의도를 사실처럼 단정하지 않는다.\n");
        b.append("- 같은 뜻을 반복하지 않는다.\n");
        b.append("- 기존 상담맥락과 핵심 의미는 유지한다.\n");

        if("ASK".equals(route)){
            b.append("- 질문은 정확히 하나만 출력한다.\n");
            b.append("- 질문 앞뒤에 분석·조언·긴 공감을 붙이지 않는다.\n");
        }else if("FORMULATE".equals(route)){
            b.append("- 관찰 사실과 사용자의 해석을 분리한다.\n");
            b.append("- 2~4문장으로 핵심만 정리하고 가설 언어를 쓴다.\n");
        }else if("INTERVENE".equals(route)){
            b.append("- 개입은 하나만 제안한다.\n");
            b.append("- 지금 실행 가능한 구체 행동으로 제시한다.\n");
        }else if("ALLIANCE_REPAIR".equals(route)){
            b.append("- 상담자 변명이나 방어를 하지 않는다.\n");
            b.append("- 어긋난 지점 하나를 확인하고 방향을 재합의한다.\n");
        }else if("STABILIZE".equals(route)){
            b.append("- 깊은 심리분석을 하지 않는다.\n");
            b.append("- 현재 안전과 즉시 필요한 지원에 집중한다.\n");
        }

        b.append("\n원래 답변:\n").append(safe(reply));
        b.append("\n\n수정된 최종 상담 답변만 출력해.");
        return new Inspection(true,b.toString());
    }

    public static String chooseBetter(
            String original,
            ClinicalResponseQualityRC7.Result originalEval,
            String revised,
            ClinicalResponseQualityRC7.Result revisedEval
    ){
        if(revised==null || revised.trim().isEmpty() || revisedEval==null)return original;
        if(originalEval==null)return revised;
        if(revisedEval.score>originalEval.score)return revised;
        if(revisedEval.score==originalEval.score){
            int rg=gradeRank(revisedEval.grade);
            int og=gradeRank(originalEval.grade);
            if(rg>og)return revised;
        }
        return original;
    }

    private static int gradeRank(String g){
        if("PASS".equalsIgnoreCase(g))return 3;
        if("WARN".equalsIgnoreCase(g))return 2;
        if("FAIL".equalsIgnoreCase(g))return 1;
        return 0;
    }
    private static String safe(String s){return s==null?"":s;}

    public static String buildFactGuardRepairPrompt(
            Context c,String userText,String draft,ClinicalDecisionRC7 decision){
        ResponseContradictionHallucinationGuardRC9.Check check =
                ResponseContradictionHallucinationGuardRC9.inspect(c,userText,draft);
        if(check.pass)return "";
        if(decision!=null){
            decision.responseFactGuardSummary=check.summary;
            decision.responseRewriteRequired=check.rewriteRequired;
        }
        return check.instruction;
    }


    public static String buildOverreachGuardRepairPrompt(
            Context c,String userText,String draft,ClinicalDecisionRC7 decision){
        ResponseSafetyOverreachGuardRC9.Check check =
                ResponseSafetyOverreachGuardRC9.inspect(c,userText,draft,decision);
        if(check.pass)return "";
        if(decision!=null){
            decision.responseOverreachGuardSummary=check.summary;
            decision.responseOverreachRewriteRequired=check.rewriteRequired;
        }
        return check.instruction;
    }


    public static String buildRelevanceGuardRepairPrompt(
            Context c,String userText,String draft,ClinicalDecisionRC7 decision){
        ResponseRelevanceGenericnessGuardRC9.Check check =
                ResponseRelevanceGenericnessGuardRC9.inspect(c,userText,draft,decision);
        if(check.pass)return "";
        if(decision!=null){
            decision.responseRelevanceGuardSummary=check.summary;
            decision.responseRelevanceRewriteRequired=check.rewriteRequired;
        }
        return check.instruction;
    }


    public static String buildAttunementGuardRepairPrompt(
            Context c,String userText,String draft,ClinicalDecisionRC7 decision){
        ResponseAttunementValidationCalibrationGuardRC9.Check check =
                ResponseAttunementValidationCalibrationGuardRC9.inspect(
                        c,userText,draft,decision);
        if(check.pass)return "";
        if(decision!=null){
            decision.responseAttunementGuardSummary=check.summary;
            decision.responseAttunementRewriteRequired=check.rewriteRequired;
        }
        return check.instruction;
    }


    public static String buildPrecisionGuardRepairPrompt(
            Context c,String userText,String draft,ClinicalDecisionRC7 decision){
        ResponsePrecisionDirectnessGuardRC9.Check check =
                ResponsePrecisionDirectnessGuardRC9.inspect(c,userText,draft,decision);
        if(check.pass)return "";
        if(decision!=null){
            decision.responsePrecisionGuardSummary=check.summary;
            decision.responsePrecisionRewriteRequired=check.rewriteRequired;
        }
        return check.instruction;
    }


    public static String buildSpecificityGuardRepairPrompt(
            Context c,String userText,String draft,ClinicalDecisionRC7 decision){
        ResponseSpecificityEvidenceAnchoringGuardRC9.Check check =
                ResponseSpecificityEvidenceAnchoringGuardRC9.inspect(c,userText,draft,decision);
        if(check.pass)return "";
        if(decision!=null){
            decision.responseSpecificityGuardSummary=check.summary;
            decision.responseSpecificityRewriteRequired=check.rewriteRequired;
            decision.responseEvidenceAnchorUsed=check.anchorUsed;
        }
        return check.instruction;
    }

    public static String buildContinuityGuardRepairPrompt(
            Context c,String userText,String draft,ClinicalDecisionRC7 decision){
        ResponseContinuityTurnCoherenceGuardRC9.Check check =
                ResponseContinuityTurnCoherenceGuardRC9.inspect(c,userText,draft,decision);
        if(check.pass)return "";
        if(decision!=null){
            decision.responseContinuityGuardSummary=check.summary;
            decision.responseContinuityRewriteRequired=check.rewriteRequired;
        }
        return check.instruction;
    }

    public static String buildTimingGuardRepairPrompt(
            Context c,String userText,String draft,ClinicalDecisionRC7 decision){
        ResponseTimingStopRuleGuardRC9.Check check =
                ResponseTimingStopRuleGuardRC9.inspect(c,userText,draft,decision);
        if(check.pass)return "";
        if(decision!=null){
            decision.responseTimingGuardSummary=check.summary;
            decision.responseTimingRewriteRequired=check.rewriteRequired;
        }
        return check.instruction;
    }

    public static RepairVerificationFinalAcceptanceGateRC9.Result verifyOneShotRepair(
            Context c,String userText,String repairedText,ClinicalDecisionRC7 decision){
        return ResponseIntegrityCoordinatorRC9.verifyAfterRepair(
                c,userText,repairedText,decision);
    }

    public static String buildInterventionFidelityRepairPrompt(
            Context c,String draft,ClinicalDecisionRC7 decision){
        InterventionDeliveryFidelityGuardRC10.Check check =
                InterventionDeliveryFidelityGuardRC10.inspect(c,draft,decision);
        if(check.pass)return "";
        if(decision!=null){
            decision.interventionFidelitySummary=check.summary;
            decision.interventionFidelityRewriteRequired=check.rewriteRequired;
            decision.minimalActionPlan=
                    InterventionDeliveryFidelityGuardRC10.minimalActionPlan(decision);
        }
        return check.instruction;
    }

}
