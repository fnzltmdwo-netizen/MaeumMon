package com.maeummon.app;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

public class DailyRoutineActivity extends Activity {
    private TextView routineText;
    private TextView missionText;
    private TextView eventText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_daily_routine);
        UiInsets.apply(this, findViewById(R.id.routineRoot));

        routineText = findViewById(R.id.routineText);
        missionText = findViewById(R.id.missionText);
        eventText = findViewById(R.id.eventText);

        findViewById(R.id.completeMissionButton).setOnClickListener(v -> {
            boolean changed = RoutineMissionManager.completeMission(this);
            Toast.makeText(this, changed ? "오늘 미션 완료! 친밀도 +2 💚" : "오늘 미션은 이미 완료했어.", Toast.LENGTH_SHORT).show();
            render();
        });

        render();
    }

    private void render() {
        routineText.setText(RoutineMissionManager.currentSlot() + " 루틴\n" + RoutineMissionManager.routineLine(this));
        missionText.setText(RoutineMissionManager.missionSummary(this));
        String event = RoutineMissionManager.specialEvent(this);
        eventText.setText(event.isEmpty() ? "아직 특별 이벤트는 없어. 기록과 친밀도가 쌓이면 어린 승재가 축하해줄 거야." : event);
    }
}
