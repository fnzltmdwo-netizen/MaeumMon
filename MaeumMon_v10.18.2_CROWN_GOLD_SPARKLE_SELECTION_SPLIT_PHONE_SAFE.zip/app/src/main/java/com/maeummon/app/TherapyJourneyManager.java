package com.maeummon.app;

import android.content.Context;
import android.content.SharedPreferences;

/**
 * 10-step longitudinal counseling journey.
 * This is an app-side coaching scaffold, not a claim of licensed psychotherapy sessions.
 */
public final class TherapyJourneyManager {
    private static final String PREF = "maeummon_therapy_journey";
    private static final String K_STEP = "journey_step";
    private static final String K_LAST_TURN = "last_promoted_turn";

    private TherapyJourneyManager() {}

    private static SharedPreferences p(Context c) {
        return c.getSharedPreferences(PREF, Context.MODE_PRIVATE);
    }

    public static synchronized void onCounselingSaved(Context c, OpenAiClient.CounselingResult r, int turnCount) {
        int current = getStep(c);
        int suggested = stepForTurnCount(turnCount);
        // Do not jump more than one step at a time; longitudinal change should feel cumulative.
        if (suggested > current) current = Math.min(10, current + 1);
        // Strong evidence of active change can move the journey from formulation to practice, but never skip wildly.
        if (r != null && current < 6 && !clean(r.experiment).isEmpty() && turnCount >= 18) current = Math.max(current, 5);
        p(c).edit().putInt(K_STEP, current).putInt(K_LAST_TURN, turnCount).apply();
    }

    public static int getStep(Context c) {
        int stored = p(c).getInt(K_STEP, 1);
        return Math.max(1, Math.min(10, stored));
    }

    private static int stepForTurnCount(int turns) {
        if (turns < 6) return 1;
        if (turns < 12) return 2;
        if (turns < 18) return 3;
        if (turns < 24) return 4;
        if (turns < 32) return 5;
        if (turns < 40) return 6;
        if (turns < 50) return 7;
        if (turns < 62) return 8;
        if (turns < 76) return 9;
        return 10;
    }

    public static String shortLabel(Context c) {
        int s = getStep(c);
        return s + "/10 · " + title(s);
    }

    public static String context(Context c) {
        int s = getStep(c);
        StringBuilder b = new StringBuilder();
        b.append("[10단계 변화상담 여정 — 현재 ").append(s).append("/10]\n");
        b.append("현재 단계: ").append(title(s)).append("\n");
        b.append("이번 단계의 주된 치료적 목적: ").append(goal(s)).append("\n");
        b.append("주의: 숫자는 앱의 누적 대화 진행을 정리하는 내부 여정 단계이며 실제 임상 회기 횟수라고 사용자에게 말하지 않는다. ")
         .append("한 턴에 모든 단계를 수행하지 말고 현재 단계의 목적을 우선한다. 새 증거가 나오면 이전 가설을 수정한다.\n");
        return b.toString();
    }

    private static String title(int s) {
        switch (s) {
            case 1: return "안전하게 말하기";
            case 2: return "반복 장면 찾기";
            case 3: return "마음이 붙이는 뜻 찾기";
            case 4: return "핵심 두려움과 욕구 이해";
            case 5: return "보호 습관과 비용 보기";
            case 6: return "새 관점 만들기";
            case 7: return "작은 행동 실험";
            case 8: return "새 경험을 반복해서 익히기";
            case 9: return "내 편이 되는 말과 기준 굳히기";
            default: return "변화 통합과 재발 방지";
        }
    }

    private static String goal(int s) {
        switch (s) {
            case 1: return "사용자가 평가받는 느낌 없이 사건과 감정을 충분히 말하도록 돕고, 성급한 해결보다 안전감과 신뢰를 만든다.";
            case 2: return "서로 다른 사건에서 반복되는 장면과 반응을 찾되 한 사건을 성격으로 일반화하지 않는다.";
            case 3: return "사건 자체보다 그 순간 사용자가 자동으로 붙이는 의미를 찾는다. 예: '답이 짧았다'에서 '나는 중요하지 않은가'로 가는 연결.";
            case 4: return "반복되는 의미 밑의 두려움과 중요한 욕구를 잠정 가설로 설명하고 사용자의 체감으로 검증한다.";
            case 5: return "눈치보기, 확인, 회피, 과잉설명, 자기비난 같은 보호전략이 당장은 무엇을 막아주고 장기적으로 어떤 비용을 만드는지 이해한다.";
            case 6: return "오래된 결론을 공격하지 않고 더 균형 잡힌 새 관점을 사용자와 함께 만든다.";
            case 7: return "생활에서 아주 작은 새 행동 하나를 시도한다. 성공 여부보다 예상과 실제의 차이를 배우는 것이 목적이다.";
            case 8: return "이미 해본 새 행동의 결과를 검토하고 교정경험을 반복해 오래된 믿음의 확신을 낮춘다.";
            case 9: return "자기비난 대신 자기편이 되는 말, 관계 기준, 경계 문장을 실제 생활어로 굳힌다.";
            default: return "무엇이 달라졌는지 통합하고 다시 흔들릴 때 알아차릴 신호와 돌아올 행동을 정리한다.";
        }
    }

    private static String clean(String s) { return s == null ? "" : s.trim(); }
}
