package com.maeummon.app.clinical;

import android.content.Context;

public final class TherapySurfaceContext {
    private TherapySurfaceContext(){}

    public static final String COUNSELING="COUNSELING";
    public static final String FOCUS_COACHING="FOCUS_COACHING";
    public static final String CHECK_IN="CHECK_IN";
    public static final String DAILY_LETTER="DAILY_LETTER";
    public static final String DIARY_SUMMARY="DIARY_SUMMARY";
    public static final String WEEKLY_REPORT="WEEKLY_REPORT";
    public static final String MONTHLY_REPORT="MONTHLY_REPORT";
    public static final String WIDGET="WIDGET";
    public static final String TAMAGOTCHI="TAMAGOTCHI";

    public static String forSurface(Context c,String surface){
        String base=CentralTherapyProfile.buildSharedContext(c,surface)
                + TherapeuticGoalProgressRC8.promptContext(c)
                + "경쟁 가설 규칙: alternative_hypotheses는 확정진단이 아니다. "
                + "상위 가설과 반대 증거를 함께 고려하고, 새 정보가 반증하면 기존 해석을 철회한다.\n";
        if(FOCUS_COACHING.equals(surface)){
            return base+"목표: 현재 formulation과 사용자의 장기패턴을 참고하되, 오늘 실행할 한 단계에 집중한다.\\n";
        }
        if(CHECK_IN.equals(surface)){
            return base+"목표: 현재 상태를 짧게 확인하고 새 정보만 profile에 추가한다. 과잉분석하지 않는다.\\n";
        }
        if(DAILY_LETTER.equals(surface)){
            return base+"목표: 최근 상태와 반복 패턴을 반영하되, 따뜻하고 짧은 하루 편지로 표현한다.\\n";
        }
        if(DIARY_SUMMARY.equals(surface)){
            return base+"목표: 일기 사실과 해석을 구분하고 반복 패턴/변화를 요약한다. 진단하지 않는다.\\n";
        }
        if(WEEKLY_REPORT.equals(surface)||MONTHLY_REPORT.equals(surface)){
            return base+"목표: 변화 추세, 반복 패턴, 도움이 된 대처, 다음 실험을 구조적으로 요약한다.\\n";
        }
        if(WIDGET.equals(surface)||TAMAGOTCHI.equals(surface)){
            return base+"목표: 긴 분석 대신 현재 맥락에 맞는 짧은 한 문장 코칭만 사용한다.\\n";
        }
        return base+"목표: 연속적인 상담맥락을 유지한다.\\n";
    }
}
