package com.maeummon.app.clinical;

import android.content.Context;
import org.json.*;

public final class GeneralPolicyExceptionBoundaryRC11 {
    private GeneralPolicyExceptionBoundaryRC11(){}

    public enum BoundaryState {
        NONE,
        APPLIES,
        EXCEPTION_PENDING,
        CONTEXT_EXCLUDED,
        EXCEPTION_CLEARED
    }

    public static final class Result {
        public boolean evaluated=false;
        public boolean changed=false;
        public BoundaryState state=BoundaryState.NONE;
        public String generalPolicyKey="";
        public String context="";
        public int recentPositive=0;
        public int recentNegative=0;
        public boolean excluded=false;
        public String reason="";
        public String summary="";
    }

    public static Result evaluate(Context c,ClinicalDecisionRC7 d){
        Result r=new Result();
        if(c==null||d==null){
            r.summary="NONE | NO_CONTEXT_OR_DECISION";
            return r;
        }

        JSONObject p=CentralTherapyProfile.loadProfile(c);
        JSONObject f=CentralTherapyProfile.loadFormulation(c);

        String context=f.optString("current_context_scope","UNKNOWN");
        String mechanism=safe(d.centralMechanism);
        String intervention=safe(d.selectedInterventionId);

        JSONObject general=findGeneral(
                p.optJSONArray("intervention_policy_memory"),
                mechanism,intervention);

        if(general==null){
            r.summary="NONE | NO_GENERAL_POLICY";
            return r;
        }

        r.evaluated=true;
        r.context=context;
        r.generalPolicyKey=general.optString("key","");

        JSONArray excluded=general.optJSONArray("excluded_contexts");
        if(excluded==null)excluded=new JSONArray();

        r.excluded=contains(excluded,context);

        if(r.excluded){
            // Check whether enough clean positive evidence exists to clear exception.
            countRecentContextEvidence(
                    p,mechanism,intervention,context,r);

            if(r.recentPositive>=3 && r.recentNegative==0){
                try{
                    JSONArray next=remove(excluded,context);
                    general.put("excluded_contexts",next);
                    general.put("last_exception_clear_context",context);
                    general.put("last_exception_clear_at",System.currentTimeMillis());
                    r.state=BoundaryState.EXCEPTION_CLEARED;
                    r.changed=true;
                    r.excluded=false;
                    r.reason="THREE_CLEAN_POSITIVES_CLEAR_EXCEPTION";
                    CentralTherapyProfile.replaceProfile(c,p);
                }catch(Exception e){
                    r.state=BoundaryState.CONTEXT_EXCLUDED;
                    r.changed=false;
                    r.excluded=true;
                    r.reason="EXCEPTION_CLEAR_PERSIST_FAILED";
                }
            }else{
                r.state=BoundaryState.CONTEXT_EXCLUDED;
                r.reason="CONTEXT_ALREADY_EXCLUDED";
            }
            return finish(r);
        }

        // A committed negative in this context begins/advances exception evidence.
        if("COMMIT".equals(d.outcomeCommitState)
                && ("NO_CHANGE".equals(d.outcomeCommitValue)
                    ||"WORSE".equals(d.outcomeCommitValue))){

            countRecentContextEvidence(
                    p,mechanism,intervention,context,r);

            if(r.recentNegative>=2
                    && r.recentNegative>r.recentPositive){

                try{
                    excluded.put(context);
                    general.put("excluded_contexts",excluded);
                    general.put("last_exception_context",context);
                    general.put("last_exception_reason",
                            "REPEATED_CONTEXT_SPECIFIC_NEGATIVE");
                    general.put("last_exception_at",
                            System.currentTimeMillis());

                    r.state=BoundaryState.CONTEXT_EXCLUDED;
                    r.changed=true;
                    r.excluded=true;
                    r.reason="REPEATED_CONTEXT_SPECIFIC_NEGATIVE";
                    CentralTherapyProfile.replaceProfile(c,p);
                }catch(Exception e){
                    r.state=BoundaryState.EXCEPTION_PENDING;
                    r.changed=false;
                    r.excluded=false;
                    r.reason="EXCEPTION_PERSIST_FAILED";
                }
            }else{
                r.state=BoundaryState.EXCEPTION_PENDING;
                r.reason="ONE_NEGATIVE_NOT_ENOUGH";
            }
            return finish(r);
        }

        r.state=BoundaryState.APPLIES;
        r.reason="NO_CONTEXT_EXCEPTION";
        return finish(r);
    }

    public static boolean generalPolicyAllowedInContext(
            JSONObject policy,String context){

        if(policy==null)return false;
        if(!"GENERAL".equals(policy.optString("context_scope","")))
            return true;

        JSONArray excluded=policy.optJSONArray("excluded_contexts");
        return !contains(excluded,context);
    }

    public static String instruction(Result r){
        if(r==null||!r.evaluated)return "";

        switch(r.state){
            case CONTEXT_EXCLUDED:
                return "GENERAL_POLICY_EXCEPTION=CONTEXT_EXCLUDED. GENERAL policy이지만 현재 context는 예외로 저장되어 있으므로 prior로 사용하지 않는다.";
            case EXCEPTION_PENDING:
                return "GENERAL_POLICY_EXCEPTION=PENDING. 한 번의 negative 결과만으로 예외를 확정하지 않고 추가 evidence를 본다.";
            case EXCEPTION_CLEARED:
                return "GENERAL_POLICY_EXCEPTION=CLEARED. 같은 context에서 깨끗한 긍정 결과가 반복되어 예외 경계를 해제한다.";
            default:
                return "";
        }
    }

    private static void countRecentContextEvidence(
            JSONObject p,String mechanism,
            String intervention,String context,Result r){

        JSONArray h=p.optJSONArray("cross_context_transfer_history");
        if(h==null)return;

        int seen=0;
        for(int i=h.length()-1;i>=0 && seen<8;i--){
            JSONObject x=h.optJSONObject(i);
            if(x==null)continue;
            if(!mechanism.equals(x.optString("mechanism","")))continue;
            if(!intervention.equals(x.optString("intervention_id","")))continue;
            if(!context.equals(x.optString("target_context","")))continue;

            seen++;
            String o=x.optString("outcome","UNKNOWN");
            if("HELPED".equals(o)||"PARTIAL".equals(o))
                r.recentPositive++;
            else if("NO_CHANGE".equals(o)||"WORSE".equals(o))
                r.recentNegative++;
        }
    }

    private static JSONObject findGeneral(
            JSONArray policies,String mechanism,String intervention){

        if(policies==null)return null;

        for(int i=0;i<policies.length();i++){
            JSONObject x=policies.optJSONObject(i);
            if(x==null)continue;

            if(!"GENERAL".equals(x.optString("context_scope","")))
                continue;

            if(!mechanism.equals(x.optString("mechanism","")))
                continue;

            if(!intervention.equals(x.optString("intervention_id","")))
                continue;

            return x;
        }
        return null;
    }

    private static boolean contains(JSONArray a,String v){
        if(a==null||v==null)return false;
        for(int i=0;i<a.length();i++)
            if(v.equals(a.optString(i)))return true;
        return false;
    }

    private static JSONArray remove(JSONArray a,String v){
        JSONArray out=new JSONArray();
        if(a==null)return out;
        for(int i=0;i<a.length();i++){
            String x=a.optString(i);
            if(!v.equals(x))out.put(x);
        }
        return out;
    }

    private static Result finish(Result r){
        r.summary=r.state.name()
                +" | context="+r.context
                +" | pos="+r.recentPositive
                +" | neg="+r.recentNegative
                +" | excluded="+r.excluded
                +" | reason="+r.reason;
        return r;
    }

    private static String safe(String s){
        return s==null?"":s;
    }
}
