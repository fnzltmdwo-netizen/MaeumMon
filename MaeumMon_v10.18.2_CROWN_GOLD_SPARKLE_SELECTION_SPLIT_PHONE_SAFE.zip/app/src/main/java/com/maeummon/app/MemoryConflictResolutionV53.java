package com.maeummon.app;

import android.content.Context;
import org.json.JSONObject;

/** Makes stored formulation provisional and lets newer evidence override it. */
public final class MemoryConflictResolutionV53 {
    private MemoryConflictResolutionV53() {}

    public static String buildContext(Context c) {
        JSONObject p = TherapyMemoryManager.getProfile(c);
        String working = p.optString("working_hypothesis", "").trim();
        String root = p.optString("root_hypothesis", "").trim();
        String recent = p.optString("recent_change", "").trim();
        String superseded = p.optString("superseded_hypothesis", "").trim();
        StringBuilder b = new StringBuilder("[MEMORY CONFLICT RESOLUTION v5.3]\n");
        if (!working.isEmpty()) b.append("현재 작업가설: ").append(working).append("\n");
        if (!root.isEmpty()) b.append("장기 가설: ").append(root).append("\n");
        if (!recent.isEmpty()) b.append("최근 새 증거: ").append(recent).append("\n");
        if (!superseded.isEmpty()) b.append("폐기/대체된 이전 가설: ").append(superseded).append("\n");
        b.append("- 기억은 사실 저장소와 작업가설을 구분한다. 오래 저장됐다는 이유만으로 더 진실인 것이 아니다.\n");
        b.append("- 우선순위: 사용자의 지금 직접 진술 > 최근 실제 행동/사건 > 반복 확인된 패턴 > 오래된 가설.\n");
        b.append("- 새 사실이 저장된 가설과 충돌하면 먼저 새 사실을 채택하고 기존 가설은 CONFIDENCE DOWN / SUPERSEDED 처리한다.\n");
        b.append("- 사용자가 명시적으로 '그건 아니다'라고 하면 그 가설을 사실처럼 재사용하지 않는다. 필요하면 처음부터 다시 formulation한다.\n");
        return b.toString();
    }

    public static String prompt() {
        return "[MEMORY CONFLICT RESOLUTION v5.3] 과거 프로필은 고정 성격표가 아니라 수정 가능한 작업기억이다. 현재 직접 진술과 최근 증거가 우선하며, 충돌 시 오래된 가설을 낮추거나 폐기한다. 폐기된 가설을 표현만 바꿔 되살리지 않는다.";
    }
}
