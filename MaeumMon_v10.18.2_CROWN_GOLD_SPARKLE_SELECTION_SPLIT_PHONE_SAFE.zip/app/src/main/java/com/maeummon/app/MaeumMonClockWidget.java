package com.maeummon.app;

import com.maeummon.app.clinical.TherapySurfaceContext;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.os.Bundle;
import android.text.format.DateFormat;
import android.util.TypedValue;
import android.widget.RemoteViews;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

public class MaeumMonClockWidget extends AppWidgetProvider {

    private static final String ACTION_REFRESH = "com.maeummon.app.action.WIDGET_REFRESH";
    private static final String ACTION_TICK = "com.maeummon.app.action.WIDGET_TICK";
    private static final String PREF_WIDGET = "maeummon_widget_prefs";
    private static final String KEY_INDEX = "comfort_index";
    private static final String KEY_GPT_LINE = "gpt_widget_line_";
    private static final String KEY_GPT_PERIOD = "gpt_widget_period_";
    private static final String KEY_GPT_RECENT = "gpt_widget_recent";
    private static final String EXTRA_WIDGET_ID = "widget_id";
    private static volatile Typeface cachedTypeface;

    private static final String[] MORNING_LINES = {
            "좋은 아침이야. 오늘은 한 번에 하나씩만 해보자.",
            "눈 뜬 것부터 잘했어. 오늘도 네 속도로 시작하면 돼.",
            "아침부터 완벽할 필요 없어. 몸부터 천천히 깨워보자.",
            "오늘 해야 할 일보다 먼저, 지금 네 마음부터 챙겨줘.",
            "작게 시작해도 충분해. 어린 승재가 옆에서 응원할게.",
            "따뜻한 물 한 모금처럼 오늘도 부드럽게 시작하자.",
            "오늘의 승재는 어제보다 잘할 필요 없어. 그냥 오늘이면 돼.",
            "급하게 달리지 않아도 괜찮아. 아침은 천천히 열어도 돼."
    };

    private static final String[] DAY_LINES = {
            "승재야, 오늘도 천천히 해도 괜찮아.",
            "지금까지 버틴 것만으로도 충분히 잘하고 있어.",
            "마음이 복잡하면 제일 작은 일 하나만 골라보자.",
            "잘해야만 괜찮은 하루가 되는 건 아니야.",
            "잠깐 멈춰도 하루가 망가지지 않아. 쉬어가도 돼.",
            "남들 속도 말고 네 속도로 가도 괜찮아.",
            "오늘 힘든 건 오늘의 네가 약해서가 아니라, 많이 썼기 때문일 수도 있어.",
            "모든 걸 해결하려 하지 말고 지금 필요한 것 하나만 챙기자.",
            "조금 지쳤다면 숨을 길게 내쉬고 어깨 힘부터 풀어보자.",
            "마음에 여유가 없을 땐 중요한 것만 남겨도 충분해.",
            "오늘의 작은 완료 하나도 진짜 완료야.",
            "기분이 흐린 날에도 너의 가치까지 흐려지는 건 아니야.",
            "잘 버티는 것보다 덜 무리하는 게 더 필요한 날도 있어.",
            "지금 마음을 한 단어로만 말해도 괜찮아. 내가 같이 들어줄게.",
            "오늘은 스스로한테 조금 더 편한 편이 되어주자.",
            "완벽하게 정리되지 않아도 괜찮아. 헝클어진 채로 쉬어도 돼."
    };

    private static final String[] NIGHT_LINES = {
            "오늘 하루 여기까지 온 것만으로도 충분해. 이제 조금 내려놓자.",
            "밤에는 해결보다 휴식이 먼저야. 내일의 승재에게 조금 남겨두자.",
            "오늘 마음에 남은 일은 잠깐 달빛 아래 내려놔도 괜찮아.",
            "잘하지 못한 것보다 견뎌낸 것부터 떠올려보자.",
            "지금은 평가하는 시간이 아니라 몸을 쉬게 해주는 시간이야.",
            "오늘의 걱정이 내일까지 전부 따라올 필요는 없어.",
            "잠들기 전엔 네 편인 말 하나만 남겨두자. 오늘도 수고했어.",
            "마음이 시끄러우면 답을 찾지 말고 숨만 천천히 세어도 돼.",
            "오늘 못 끝낸 일은 실패가 아니라 내일 이어갈 일일 뿐이야.",
            "이 밤만큼은 조금 느슨해도 괜찮아. 어린 승재가 옆에 있을게.",
            "오늘의 너를 혼내기보다 토닥여주고 끝내자.",
            "달이 뜬 시간엔 마음도 조금 어둑해질 수 있어. 그냥 지나가게 두자."
    };



    private static final String[] EVENING_LINES = {
            "오늘도 여기까지 오느라 수고했어. 이제 조금 힘을 빼자.",
            "퇴근 뒤엔 생산성보다 회복이 먼저야. 마음부터 편하게 두자.",
            "저녁에는 오늘 못한 것보다 해낸 것 하나만 떠올려보자.",
            "승재야, 하루 종일 쓴 마음도 충전이 필요해. 잠깐 쉬자.",
            "오늘의 긴장은 여기 두고 가도 돼. 저녁은 조금 느슨하게.",
            "이 시간엔 속도를 늦춰도 괜찮아. 오늘도 충분히 애썼어.",
            "저녁 공기처럼 마음도 조금 식혀주자. 서두를 일 없어.",
            "지금부터는 잘하기보다 편해지는 쪽을 골라도 돼."
    };

    private static final String[] COMPACT_MORNING_LINES = {
            "좋은 아침! 오늘도 천천히 시작하자.",
            "눈 뜬 것부터 잘했어. 서두르지 말자.",
            "아침엔 몸부터 천천히 깨워보자.",
            "오늘도 한 번에 하나씩이면 충분해.",
            "작게 시작해도 괜찮아. 내가 옆에 있어.",
            "따뜻한 물 한 모금부터 시작해볼까?",
            "아침부터 완벽할 필요는 없어.",
            "오늘의 속도는 네가 정해도 돼.",
            "기지개 한 번 펴고 천천히 출발하자.",
            "오늘도 네 편에서 같이 시작할게.",
            "해야 할 일보다 마음부터 한 번 살펴보자.",
            "조금 느린 아침이어도 괜찮아.",
            "오늘은 어제보다 잘할 필요 없어.",
            "숨 한 번 크게 쉬고 하루를 열어보자.",
            "아침 햇살만큼 가볍게 시작하자.",
            "오늘도 작은 완료 하나부터 만들어보자.",
            "피곤하면 천천히 시동 걸어도 돼.",
            "마음이 무거워도 아침은 새로 시작돼.",
            "오늘 하루도 너무 무리하지 말자.",
            "일단 씻고, 먹고, 하나씩 해보자.",
            "좋은 하루보다 편한 하루여도 충분해.",
            "아침의 너에게 부드러운 말을 하나 건네자.",
            "오늘도 네 리듬대로 가면 돼.",
            "천천히 시작해도 늦지 않아."
    };

    private static final String[] COMPACT_EVENING_LINES = {
            "오늘도 수고했어. 이제 조금 쉬자.",
            "저녁엔 마음도 충전하자.",
            "오늘 못한 건 내일 이어가면 돼.",
            "이제 조금 힘을 빼도 괜찮아.",
            "하루 종일 애썼어. 저녁은 느슨하게.",
            "오늘 해낸 것 하나만 떠올려보자.",
            "퇴근 뒤엔 회복이 먼저야.",
            "저녁 공기처럼 마음도 식혀주자.",
            "오늘의 긴장은 여기 두고 가도 돼.",
            "잘하기보다 편해지는 쪽을 골라도 돼.",
            "지금부터는 조금 천천히 가자.",
            "오늘 버틴 너도 충분히 대단해.",
            "저녁엔 해결보다 휴식이 먼저야.",
            "남은 일보다 남은 에너지를 챙기자.",
            "따뜻한 거 먹고 마음도 쉬게 해주자.",
            "오늘 하루도 여기까지 잘 왔어.",
            "조급함은 잠깐 내려두고 쉬어가자.",
            "저녁만큼은 네 편한 쪽으로 가도 돼.",
            "오늘의 실수보다 수고한 걸 기억하자.",
            "하루의 끝엔 스스로를 덜 몰아붙이자.",
            "지금은 천천히 숨 돌릴 시간이야.",
            "오늘 마음도 많이 썼지? 쉬어도 돼.",
            "남은 시간은 조금 포근하게 보내자.",
            "오늘도 잘 버텼어. 이제 편해져도 돼."
    };

    private static final String[] COMPACT_NIGHT_LINES = {
            "오늘은 여기까지. 푹 쉬자 🌙",
            "밤에는 해결보다 잠이 먼저야.",
            "오늘도 수고했어. 잘 자.",
            "걱정은 내일의 나에게 맡기자.",
            "오늘 마음은 달빛 아래 내려놓자.",
            "지금은 쉬어도 되는 시간이야.",
            "못 끝낸 일은 내일 이어가면 돼.",
            "밤에는 스스로를 조금 더 토닥여주자.",
            "오늘의 너를 혼내지 말고 재워주자.",
            "이제 생각은 잠깐 멈춰도 괜찮아.",
            "편안한 숨 한 번, 그리고 푹 쉬자.",
            "오늘 하루도 여기까지 잘 버텼어.",
            "잠들기 전엔 네 편인 말만 남기자.",
            "내일 걱정은 내일의 네가 해도 돼.",
            "오늘의 피곤함도 잠과 함께 풀리길.",
            "밤은 정답 찾는 시간이 아니야.",
            "조금 느슨해져도 괜찮아. 잘 자.",
            "이불 속에서는 아무것도 안 해도 돼.",
            "마음이 시끄러우면 숨만 세어보자.",
            "오늘 못한 것보다 버틴 걸 기억하자.",
            "이 밤만큼은 마음을 편히 놓아주자.",
            "달빛 아래 오늘을 조용히 마무리하자.",
            "푹 자고 나면 마음도 조금 가벼워질 거야.",
            "오늘도 고생 많았어. 어린 승재가 옆에 있을게."
    };

    private static final String[] COMPACT_LINES = {
            "승재야, 오늘도 천천히 해도 괜찮아.",
            "잠깐 멈춰도 괜찮아. 내가 옆에 있을게.",
            "지금까지 온 것만으로도 충분히 잘했어.",
            "오늘은 네 속도로 가도 괜찮아.",
            "하나씩만 해도 충분해. 서두르지 말자.",
            "조금 쉬어가도 괜찮아. 오늘도 네 편이야.",
            "마음이 복잡하면 숨부터 천천히 쉬어보자.",
            "완벽하지 않아도 괜찮아. 오늘도 충분해.",
            "지금 필요한 것 하나만 챙겨도 돼.",
            "작은 완료 하나도 진짜 완료야.",
            "잠깐 쉬는 것도 오늘 할 일에 포함이야.",
            "마음이 흐린 날에도 넌 그대로 소중해.",
            "다 잘하려 하지 않아도 괜찮아.",
            "힘들면 제일 작은 일부터 골라보자.",
            "오늘은 스스로에게 조금 더 친절하자.",
            "지친 마음엔 속도를 줄이는 게 먼저야.",
            "한꺼번에 말고, 딱 하나씩만 해보자.",
            "조금 늦어도 괜찮아. 네 리듬대로 가자.",
            "지금까지 버틴 것부터 칭찬해주자.",
            "잘해야만 좋은 하루인 건 아니야.",
            "마음에 여유가 없으면 중요한 것만 남기자.",
            "숨 한 번 길게 쉬고 어깨 힘을 풀어보자.",
            "오늘도 네 마음 편이 되어줄게.",
            "헝클어진 채로 잠깐 쉬어도 괜찮아."
    };

    @Override
    public void onEnabled(Context context) {
        super.onEnabled(context);
        scheduleNextUpdate(context);
    }

    @Override
    public void onDisabled(Context context) {
        super.onDisabled(context);
        cancelScheduledUpdate(context);
    }

    @Override
    public void onUpdate(Context context, AppWidgetManager appWidgetManager, int[] appWidgetIds) {
        for (int appWidgetId : appWidgetIds) {
            updateWidget(context, appWidgetManager, appWidgetId, false);
        }
        scheduleNextUpdate(context);
    }

    @Override
    public void onAppWidgetOptionsChanged(Context context, AppWidgetManager appWidgetManager,
                                          int appWidgetId, Bundle newOptions) {
        super.onAppWidgetOptionsChanged(context, appWidgetManager, appWidgetId, newOptions);
        updateWidget(context, appWidgetManager, appWidgetId, false);
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        super.onReceive(context, intent);
        String action = intent != null ? intent.getAction() : null;

        if (ACTION_REFRESH.equals(action)) {
            int widgetId = intent.getIntExtra(EXTRA_WIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID);
            final PendingResult pending = goAsync();
            final Context appContext = context.getApplicationContext();
            new Thread(() -> {
                try {
                    AppWidgetManager manager = AppWidgetManager.getInstance(appContext);
                    if (widgetId != AppWidgetManager.INVALID_APPWIDGET_ID) {
                        generateGptMessageAndUpdate(appContext, manager, widgetId);
                    } else {
                        ComponentName provider = new ComponentName(appContext, MaeumMonClockWidget.class);
                        for (int id : manager.getAppWidgetIds(provider)) {
                            generateGptMessageAndUpdate(appContext, manager, id);
                        }
                    }
                } finally {
                    pending.finish();
                }
            }, "MaeumMonWidgetGPT").start();
            return;
        }

        if (ACTION_TICK.equals(action)
                || Intent.ACTION_TIME_CHANGED.equals(action)
                || Intent.ACTION_TIMEZONE_CHANGED.equals(action)
                || Intent.ACTION_DATE_CHANGED.equals(action)) {
            AppWidgetManager manager = AppWidgetManager.getInstance(context);
            ComponentName provider = new ComponentName(context, MaeumMonClockWidget.class);
            int[] ids = manager.getAppWidgetIds(provider);
            for (int id : ids) updateWidget(context, manager, id, false);
            scheduleNextUpdate(context);
        }
    }

    private static void updateWidget(Context context, AppWidgetManager manager, int appWidgetId, boolean advance) {
        int layout = chooseLayout(manager, appWidgetId);
        RemoteViews views = new RemoteViews(context.getPackageName(), layout);

        Calendar now = Calendar.getInstance();
        int hour = now.get(Calendar.HOUR_OF_DAY);
        int minute = now.get(Calendar.MINUTE);
        boolean night = hour < 7 || hour >= 19;

        String[] pool;
        String label;
        if (hour >= 6 && hour < 10) {
            pool = MORNING_LINES;
            label = "☀ 아침의 구름 인사";
        } else if (hour >= 10 && hour < 17) {
            pool = DAY_LINES;
            label = "☁ 오늘의 구름 위로";
        } else if (hour >= 17 && hour < 23) {
            pool = EVENING_LINES;
            label = "🌆 저녁의 포근한 한마디";
        } else {
            pool = NIGHT_LINES;
            label = "🌙 밤의 달빛 위로";
        }
        if (layout == R.layout.widget_maeummon_medium || layout == R.layout.widget_maeummon_small) {
            if (hour >= 6 && hour < 10) pool = COMPACT_MORNING_LINES;
            else if (hour >= 17 && hour < 23) pool = COMPACT_EVENING_LINES;
            else if (hour >= 23 || hour < 6) pool = COMPACT_NIGHT_LINES;
            else pool = COMPACT_LINES;
        }
        int period = messagePeriod(hour);
        int index = chooseMessageIndex(context, appWidgetId, pool.length, period, advance, now);
        String line = pool[index];
        String activePtLine = CentralMindPtState.compactWidgetLine(context);
        if (!activePtLine.isEmpty()) {
            line = activePtLine;
            CentralMindPtState.Snapshot activePt = CentralMindPtState.current(context);
            label = activePt.active ? "🏋 오늘의 마음 PT" : label;
        }
        String sharedLine = UnifiedTherapyProfile.widgetLine(context);
        if (activePtLine.isEmpty() && !sharedLine.isEmpty() && ((now.get(Calendar.MINUTE) / 5) % 2 == 0)) line = sharedLine;
        android.content.SharedPreferences widgetPrefs = context.getSharedPreferences(PREF_WIDGET, Context.MODE_PRIVATE);
        int cachedPeriod = widgetPrefs.getInt(KEY_GPT_PERIOD + appWidgetId, -1);
        String cachedGptLine = widgetPrefs.getString(KEY_GPT_LINE + appWidgetId, "");
        // A selected/active PT is the single source of truth. Old cached comfort/GPT lines may never overwrite it.
        if (activePtLine.isEmpty() && !advance && cachedPeriod == period && cachedGptLine != null && !cachedGptLine.trim().isEmpty()) {
            line = cachedGptLine.trim();
        }
        // v5.0.1: never let a counseling-length sentence be clipped by launcher RemoteViews.
        int widgetMaxChars = (layout == R.layout.widget_maeummon_medium) ? 28
                : (layout == R.layout.widget_maeummon_clock) ? 32
                : (layout == R.layout.widget_maeummon_large) ? 42
                : 30;
        line = TherapySurfacePolicyV501.compactWidgetText(line, widgetMaxChars);
        views.setTextViewText(R.id.widgetMessage, line);
        views.setTextViewText(R.id.widgetLabel, label);

        views.setInt(R.id.widgetCard, "setBackgroundResource", night ? R.drawable.bg_widget_night : R.drawable.bg_widget_day);
        views.setInt(R.id.timeWrap, "setBackgroundResource", night ? R.drawable.bg_widget_time_night : R.drawable.bg_widget_time_day);
        views.setInt(R.id.widgetMessage, "setBackgroundResource", night ? R.drawable.bg_widget_message_night : R.drawable.bg_widget_message_day);
        views.setTextColor(R.id.widgetMessage, night ? 0xFF5D5D85 : 0xFF566287);
        views.setTextColor(R.id.widgetLabel, night ? 0xFF9D92C5 : 0xFFA79DC7);

        int pulseA = (minute % 3 == 0) ? 255 : 150;
        int pulseB = (minute % 3 == 1) ? 245 : 135;
        int pulseC = (minute % 3 == 2) ? 235 : 120;
        views.setInt(R.id.widgetBgSparkle1, "setImageAlpha", pulseA);
        views.setInt(R.id.widgetBgSparkle2, "setImageAlpha", pulseB);
        views.setInt(R.id.widgetBgSparkle3, "setImageAlpha", pulseC);
        views.setInt(R.id.widgetCloud1, "setImageAlpha", night ? 80 : 160);
        views.setInt(R.id.widgetCloud2, "setImageAlpha", night ? 70 : 145);

        String timeText = new SimpleDateFormat(DateFormat.is24HourFormat(context) ? "H:mm" : "h:mm", Locale.KOREA)
                .format(now.getTime());
        String dateText = new SimpleDateFormat("M월 d일 (E)", Locale.KOREA).format(now.getTime());

        TextSpec spec = specForLayout(layout);
        views.setImageViewBitmap(R.id.widgetTimeBitmap, renderClockText(context, timeText, spec, night));
        views.setImageViewBitmap(R.id.widgetDateBitmap, renderDateText(context, dateText, spec, night));

        // 배경/시계/캐릭터/달은 마음몬 홈으로 이동한다.
        Intent homeIntent = new Intent(context, MindPtActivity.class);
        homeIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent openHome = PendingIntent.getActivity(context, appWidgetId, homeIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        views.setOnClickPendingIntent(R.id.widgetRoot, openHome);
        views.setOnClickPendingIntent(R.id.widgetCharacter, openHome);
        views.setOnClickPendingIntent(R.id.widgetMoon, openHome);

        // 위로 문구를 누르면 홈으로 이동하지 않고 문구만 다음 문장으로 바꾼다.
        Intent refreshIntent = new Intent(context, MaeumMonClockWidget.class);
        refreshIntent.setAction(ACTION_REFRESH);
        refreshIntent.putExtra(EXTRA_WIDGET_ID, appWidgetId);
        PendingIntent refreshMessage = PendingIntent.getBroadcast(
                context, 20000 + appWidgetId, refreshIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        views.setOnClickPendingIntent(R.id.widgetMessage, refreshMessage);

        try {
            manager.updateAppWidget(appWidgetId, views);
        } catch (RuntimeException ignored) {
            // A launcher/RemoteViews failure must never take down the mascot process.
        }
    }

    private static void generateGptMessageAndUpdate(Context context, AppWidgetManager manager, int appWidgetId) {
        Calendar now = Calendar.getInstance();
        int hour = now.get(Calendar.HOUR_OF_DAY);
        int period = messagePeriod(hour);

        android.content.SharedPreferences appPrefs = context.getSharedPreferences(AppPrefs.PREFS, Context.MODE_PRIVATE);
        String apiKey = appPrefs.getString(AppPrefs.KEY_API_KEY, "");
        if (apiKey == null || apiKey.trim().isEmpty()) {
            updateWidget(context, manager, appWidgetId, true);
            return;
        }

        android.content.SharedPreferences widgetPrefs = context.getSharedPreferences(PREF_WIDGET, Context.MODE_PRIVATE);
        String recent = widgetPrefs.getString(KEY_GPT_RECENT, "");
        String periodName = periodName(period);

        try {
            String shared = UnifiedTherapyProfile.buildSharedContext(context)
                    + "\n\n" + TherapySurfaceContext.forSurface(
                            context, TherapySurfaceContext.WIDGET);
            String generated = OpenAiClient.getWidgetComfort(
                    apiKey.trim(), periodName, (recent == null ? "" : recent) + "\n" + shared, System.nanoTime());
            generated = sanitizeWidgetLine(generated);
            if (generated.isEmpty()) throw new RuntimeException("empty widget message");

            String updatedRecent = generated;
            if (recent != null && !recent.trim().isEmpty()) {
                updatedRecent += " | " + recent.trim();
            }
            if (updatedRecent.length() > 700) updatedRecent = updatedRecent.substring(0, 700);

            widgetPrefs.edit()
                    .putString(KEY_GPT_LINE + appWidgetId, generated)
                    .putInt(KEY_GPT_PERIOD + appWidgetId, period)
                    .putString(KEY_GPT_RECENT, updatedRecent)
                    .apply();
            updateWidget(context, manager, appWidgetId, false);
        } catch (Exception ignored) {
            // 네트워크/API 오류일 때는 기존 시간대별 내장 문구로 즉시 대체한다.
            widgetPrefs.edit()
                    .remove(KEY_GPT_LINE + appWidgetId)
                    .remove(KEY_GPT_PERIOD + appWidgetId)
                    .apply();
            updateWidget(context, manager, appWidgetId, true);
        }
    }

    public static void refreshAll(Context context) {
        try {
            AppWidgetManager manager = AppWidgetManager.getInstance(context.getApplicationContext());
            ComponentName provider = new ComponentName(context.getApplicationContext(), MaeumMonClockWidget.class);
            int[] ids = manager.getAppWidgetIds(provider);
            for (int id : ids) updateWidget(context.getApplicationContext(), manager, id, false);
        } catch (RuntimeException ignored) {
        }
    }

    private static String sanitizeWidgetLine(String text) {
        if (text == null) return "";
        String line = text.replace("\r", " ").replace("\n", " ").trim();
        line = line.replaceAll("^[\"'“”‘’]+|[\"'“”‘’]+$", "").trim();
        return TherapySurfacePolicyV501.compactWidgetText(line, 30);
    }

    private static String periodName(int period) {
        if (period == 1) return "아침(06:00~09:59)";
        if (period == 2) return "낮(10:00~16:59)";
        if (period == 3) return "저녁(17:00~22:59)";
        return "밤(23:00~05:59)";
    }

    private static int messagePeriod(int hour) {
        if (hour >= 6 && hour < 10) return 1;
        if (hour >= 10 && hour < 17) return 2;
        if (hour >= 17 && hour < 23) return 3;
        return 4;
    }

    private static int chooseMessageIndex(Context context, int appWidgetId, int poolSize,
                                          int period, boolean advance, Calendar now) {
        if (poolSize <= 1) return 0;
        String indexKey = KEY_INDEX + "_" + appWidgetId;
        String periodKey = "comfort_period_" + appWidgetId;
        android.content.SharedPreferences prefs = context.getSharedPreferences(PREF_WIDGET, Context.MODE_PRIVATE);
        int lastIndex = prefs.getInt(indexKey, -1);
        int lastPeriod = prefs.getInt(periodKey, -1);

        // 시간대가 바뀌었거나 최초 표시라면, 날짜/시간/위젯 ID를 섞어 시작 위치를 넓게 분산한다.
        if (lastIndex < 0 || lastIndex >= poolSize || lastPeriod != period) {
            long seed = now.getTimeInMillis()
                    ^ ((long) now.get(Calendar.DAY_OF_YEAR) << 17)
                    ^ ((long) appWidgetId << 7)
                    ^ (period * 0x9E3779B9L);
            int picked = (int) Math.floorMod(seed ^ (seed >>> 32), poolSize);
            prefs.edit().putInt(indexKey, picked).putInt(periodKey, period).apply();
            return picked;
        }

        if (!advance) return lastIndex;

        // 문구를 눌렀을 때는 단순 +1 순환이 아니라 매번 다른 위치로 점프한다.
        // 직전 문구와 같은 문구는 절대 연속으로 나오지 않는다.
        long mixed = System.nanoTime()
                ^ now.getTimeInMillis()
                ^ ((long) appWidgetId * 1103515245L)
                ^ ((long) lastIndex * 2654435761L);
        int jump = 1 + (int) Math.floorMod(mixed ^ (mixed >>> 29), poolSize - 1);
        int picked = (lastIndex + jump) % poolSize;
        prefs.edit().putInt(indexKey, picked).putInt(periodKey, period).apply();
        return picked;
    }

    private static int chooseLayout(AppWidgetManager manager, int appWidgetId) {
        Bundle options = manager.getAppWidgetOptions(appWidgetId);
        int minWidth = options.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 280);
        int minHeight = options.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT, 146);
        // 세로로 길고 폭이 좁은 삼성 홈 위젯을 먼저 분리한다.
        // 이전 버전은 높이만 보고 large 레이아웃을 선택해 시계가 오른쪽으로 잘렸다.
        if (minWidth < 170 && minHeight >= 220) return R.layout.widget_maeummon_narrow;
        if (minWidth < 170 || minHeight < 120) return R.layout.widget_maeummon_small;
        if (minWidth < 300 && minHeight < 300) return R.layout.widget_maeummon_medium;
        if (minWidth >= 300 && minHeight >= 260) return R.layout.widget_maeummon_large;
        return R.layout.widget_maeummon_clock;
    }

    private static TextSpec specForLayout(int layout) {
        // IMPORTANT: bitmap sizes are fixed PIXELS, not dp*density.
        // This keeps RemoteViews safely below Android Binder transaction limits.
        if (layout == R.layout.widget_maeummon_small) return new TextSpec(76f, 34f, 310, 108, 330, 64);
        if (layout == R.layout.widget_maeummon_narrow) return new TextSpec(82f, 38f, 350, 118, 370, 70);
        if (layout == R.layout.widget_maeummon_medium) return new TextSpec(132f, 58f, 520, 174, 540, 94);
        if (layout == R.layout.widget_maeummon_large) return new TextSpec(136f, 62f, 620, 196, 660, 108);
        return new TextSpec(128f, 56f, 560, 184, 600, 102);
    }

    private static Bitmap renderClockText(Context context, String text, TextSpec s, boolean night) {
        return renderStyledTextBitmap(context, text, s.timeSp, s.timeW, s.timeH,
                0xFFFFFFFF,
                night ? 0xFF9CA4FF : 0xFF91A5FF,
                night ? 0xFF6567D9 : 0xFF5F73DE,
                night ? 0x88D9D7FF : 0x77D7F2FF,
                true);
    }

    private static Bitmap renderDateText(Context context, String text, TextSpec s, boolean night) {
        return renderStyledTextBitmap(context, text, s.dateSp, s.dateW, s.dateH,
                0xFFFFFFFF,
                night ? 0xFFA9A5EA : 0xFFA5B3EC,
                night ? 0xFF7B74C5 : 0xFF7183C9,
                night ? 0x44E7DFFF : 0x44E0F4FF,
                false);
    }

    private static Bitmap renderStyledTextBitmap(Context context, String text, float textPx,
                                                  int widthPx, int heightPx,
                                                  int topColor, int midColor, int bottomColor,
                                                  int glowColor, boolean strongGlow) {
        widthPx = Math.max(1, widthPx);
        heightPx = Math.max(1, heightPx);
        Bitmap bitmap = Bitmap.createBitmap(widthPx, heightPx, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        canvas.drawColor(Color.TRANSPARENT);

        Typeface typeface = getWidgetTypeface(context);

        Paint glow = basePaint(typeface, textPx);
        glow.setColor(glowColor);
        glow.setShadowLayer(strongGlow ? 10f : 6f, 0f, 0f, glowColor);

        // Dark outline keeps the glossy bitmap readable on white/cloud backgrounds.
        Paint darkOutline = basePaint(typeface, textPx);
        darkOutline.setStyle(Paint.Style.STROKE);
        darkOutline.setStrokeJoin(Paint.Join.ROUND);
        darkOutline.setStrokeWidth(strongGlow ? 4.2f : 3.0f);
        darkOutline.setColor(strongGlow ? 0x88424F9E : 0x704E568E);

        // Thin white inner outline gives the lock-screen-like glossy edge.
        Paint lightOutline = basePaint(typeface, textPx);
        lightOutline.setStyle(Paint.Style.STROKE);
        lightOutline.setStrokeJoin(Paint.Join.ROUND);
        lightOutline.setStrokeWidth(strongGlow ? 2.0f : 1.5f);
        lightOutline.setColor(0xCCFFFFFF);

        Paint fill = basePaint(typeface, textPx);
        fill.setShader(new LinearGradient(0, 0, 0, heightPx,
                new int[]{topColor, midColor, bottomColor},
                new float[]{0f, 0.42f, 1f}, Shader.TileMode.CLAMP));
        fill.setShadowLayer(2.0f, 0f, 1.3f, 0x88FFFFFF);

        Paint.FontMetrics fm = fill.getFontMetrics();
        float baseline = (heightPx / 2f) - ((fm.ascent + fm.descent) / 2f);
        float centerX = widthPx / 2f;
        canvas.drawText(text, centerX, baseline, glow);
        canvas.drawText(text, centerX, baseline, darkOutline);
        canvas.drawText(text, centerX, baseline, lightOutline);
        canvas.drawText(text, centerX, baseline, fill);
        return bitmap;
    }

    private static Typeface getWidgetTypeface(Context context) {
        Typeface local = cachedTypeface;
        if (local != null) return local;
        synchronized (MaeumMonClockWidget.class) {
            if (cachedTypeface == null) {
                try {
                    cachedTypeface = Typeface.createFromAsset(context.getAssets(), "Jalnan2TTF.ttf");
                } catch (Exception e) {
                    cachedTypeface = Typeface.DEFAULT_BOLD;
                }
            }
            return cachedTypeface;
        }
    }

    private static Paint basePaint(Typeface tf, float sizePx) {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.SUBPIXEL_TEXT_FLAG);
        p.setTypeface(tf);
        p.setTextAlign(Paint.Align.CENTER);
        p.setTextSize(sizePx);
        p.setFakeBoldText(true);
        return p;
    }

    private static void scheduleNextUpdate(Context context) {
        AlarmManager alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (alarmManager == null) return;
        Calendar next = Calendar.getInstance();
        next.set(Calendar.SECOND, 2);
        next.set(Calendar.MILLISECOND, 0);
        next.add(Calendar.MINUTE, 1);
        // Exact alarm permission 없이도 동작하도록 일반 알람을 사용한다.
        // A scheduling failure must not affect the foreground mascot service.
        try {
            alarmManager.set(AlarmManager.RTC, next.getTimeInMillis(), getTickPendingIntent(context));
        } catch (RuntimeException ignored) {
        }
    }

    private static void cancelScheduledUpdate(Context context) {
        AlarmManager alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (alarmManager != null) alarmManager.cancel(getTickPendingIntent(context));
    }

    private static PendingIntent getTickPendingIntent(Context context) {
        Intent tickIntent = new Intent(context, MaeumMonClockWidget.class);
        tickIntent.setAction(ACTION_TICK);
        return PendingIntent.getBroadcast(context, 30000, tickIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    private static final class TextSpec {
        final float timeSp, dateSp;
        final int timeW, timeH, dateW, dateH;
        TextSpec(float timeSp, float dateSp, int timeW, int timeH, int dateW, int dateH) {
            this.timeSp = timeSp; this.dateSp = dateSp;
            this.timeW = timeW; this.timeH = timeH; this.dateW = dateW; this.dateH = dateH;
        }
    }
}
