package com.maeummon.app.clinical;

import android.content.Context;
import org.json.*;

public final class MicroExperimentReviewEvidenceMapperRC10 {
    private MicroExperimentReviewEvidenceMapperRC10(){}

    public enum Attribution {
        NONE,
        POSSIBLE,
        PROBABLE,
        DIRECT
    }

    public static final class Result {
        public boolean activeExperiment=false;
        public String experimentId="";
        public Attribution attribution=Attribution.NONE;
        public boolean outcomeEligible=false;
        public boolean needsClarification=false;
        public String matchedEvidence="";
        public String reviewCriterion="";
        public String mappedOutcome="UNKNOWN";
        public String rationale="";
        public String summary="";
    }

    public static Result map(
            Context c,String userText,ClinicalDecisionRC7 d){

        Result r=new Result();
        String u=userText==null?"":userText.trim();

        JSONObject s=CentralTherapyProfile.loadSessionState(c);
        JSONObject p=CentralTherapyProfile.loadProfile(c);

        String experimentId=s.optString(
                "active_micro_experiment_id",
                p.optString("active_micro_experiment_id",""));

        String action=s.optString(
                "active_micro_experiment_action",
                p.optString("active_micro_experiment_action",""));

        String review=s.optString(
                "active_micro_experiment_review_criterion",
                p.optString("active_micro_experiment_review_criterion",""));

        String intervention=s.optString(
                "active_micro_experiment_intervention_id",
                p.optString("active_micro_experiment_intervention_id",""));

        if(experimentId.isEmpty()){
            r.summary="NONE | NO_ACTIVE_EXPERIMENT";
            return r;
        }

        r.activeExperiment=true;
        r.experimentId=experimentId;
        r.reviewCriterion=review;

        boolean directReference=containsAny(u,
                "해봤어","해보니까","아까 말한 거","그거 해봤",
                "실험해봤","적어봤","말해봤","써봤","관찰해봤",
                "그 방법","방금 방법");

        boolean actionOverlap=sharesMeaningfulToken(action,u);
        boolean reviewOverlap=sharesMeaningfulToken(review,u);
        boolean outcomeSignal=InterventionOutcomeLearningLoopRC10.hasOutcomeSignal(u);

        if(directReference && outcomeSignal){
            r.attribution=Attribution.DIRECT;
        }else if(actionOverlap && outcomeSignal){
            r.attribution=Attribution.PROBABLE;
        }else if(reviewOverlap && outcomeSignal){
            r.attribution=Attribution.PROBABLE;
        }else if(outcomeSignal){
            r.attribution=Attribution.POSSIBLE;
            r.needsClarification=true;
        }else{
            r.attribution=Attribution.NONE;
        }

        r.outcomeEligible=
                r.attribution==Attribution.DIRECT
                ||r.attribution==Attribution.PROBABLE;

        if(r.outcomeEligible){
            InterventionOutcomeLearningLoopRC10.Outcome o =
                    InterventionOutcomeLearningLoopRC10.detectOutcome(u);
            r.mappedOutcome=o.name();
            r.matchedEvidence=compact(u,400);
            r.rationale="활성 micro-experiment와 사용자 결과 발화가 직접 또는 높은 가능성으로 연결된다.";
            persistAttribution(c,r,intervention);
        }else if(r.attribution==Attribution.POSSIBLE){
            r.mappedOutcome="UNKNOWN";
            r.rationale="결과 표현은 있으나 활성 experiment 결과인지 확실하지 않아 attribution을 보류한다.";
        }else{
            r.mappedOutcome="UNKNOWN";
            r.rationale="활성 experiment 결과로 볼 근거가 부족하다.";
        }

        r.summary=r.attribution.name()
                +" | eligible="+r.outcomeEligible
                +" | outcome="+r.mappedOutcome
                +" | experiment="+r.experimentId;
        return r;
    }

    public static void activate(
            Context c,ClinicalDecisionRC7 d){

        if(c==null||d==null||!d.microExperimentReady)return;

        try{
            JSONObject s=CentralTherapyProfile.loadSessionState(c);
            JSONObject p=CentralTherapyProfile.loadProfile(c);

            long now=System.currentTimeMillis();

            s.put("active_micro_experiment_id",safe(d.microExperimentId));
            s.put("active_micro_experiment_action",safe(d.microExperimentAction));
            s.put("active_micro_experiment_review_criterion",safe(d.microExperimentReviewCriterion));
            s.put("active_micro_experiment_stop_condition",safe(d.microExperimentStopCondition));
            s.put("active_micro_experiment_intervention_id",safe(d.selectedInterventionId));
            s.put("active_micro_experiment_dose",safe(d.interventionDose));
            s.put("active_micro_experiment_started_at",now);
            s.put("active_micro_experiment_status","ACTIVE");

            p.put("active_micro_experiment_id",safe(d.microExperimentId));
            p.put("active_micro_experiment_action",safe(d.microExperimentAction));
            p.put("active_micro_experiment_review_criterion",safe(d.microExperimentReviewCriterion));
            p.put("active_micro_experiment_intervention_id",safe(d.selectedInterventionId));
            p.put("active_micro_experiment_started_at",now);

            CentralTherapyProfile.replaceSessionState(c,s);
            CentralTherapyProfile.replaceProfile(c,p);
        }catch(Exception ignored){}
    }

    public static String instruction(Result r){
        if(r==null||!r.activeExperiment)return "";

        if(r.outcomeEligible){
            return "MICRO_EXPERIMENT_OUTCOME_ATTRIBUTED=true. "
                    +"이번 결과는 활성 experiment에 연결해 REVIEW한다. "
                    +"review criterion='"+r.reviewCriterion+"'을 기준으로 해석한다.";
        }

        if(r.needsClarification){
            return "MICRO_EXPERIMENT_OUTCOME_ATTRIBUTION=UNCERTAIN. "
                    +"사용자가 말한 결과가 직전 experiment에 대한 것인지 한 번만 확인하고, "
                    +"확인 전에는 HELPED/NO_CHANGE/WORSE로 학습하지 않는다.";
        }

        return "";
    }

    public static boolean shouldSuppressGenericOutcomeLearning(Result r){
        return r!=null
                && r.activeExperiment
                && !r.outcomeEligible
                && r.attribution!=Attribution.NONE;
    }

    private static void persistAttribution(
            Context c,Result r,String intervention){

        try{
            JSONObject p=CentralTherapyProfile.loadProfile(c);
            JSONObject s=CentralTherapyProfile.loadSessionState(c);

            JSONArray h=p.optJSONArray("micro_experiment_review_history");
            if(h==null)h=new JSONArray();

            JSONObject item=new JSONObject();
            item.put("experiment_id",r.experimentId);
            item.put("intervention_id",intervention);
            item.put("attribution",r.attribution.name());
            item.put("outcome",r.mappedOutcome);
            item.put("evidence",r.matchedEvidence);
            item.put("review_criterion",r.reviewCriterion);
            item.put("time",System.currentTimeMillis());
            h.put(item);

            JSONArray trimmed=new JSONArray();
            int start=Math.max(0,h.length()-30);
            for(int i=start;i<h.length();i++)trimmed.put(h.opt(i));

            p.put("micro_experiment_review_history",trimmed);
            p.put("last_micro_experiment_outcome",r.mappedOutcome);
            p.put("last_micro_experiment_attribution",r.attribution.name());
            p.put("last_micro_experiment_reviewed_at",System.currentTimeMillis());

            s.put("active_micro_experiment_status","REVIEWED");
            s.put("last_micro_experiment_outcome",r.mappedOutcome);
            s.put("last_micro_experiment_attribution",r.attribution.name());

            CentralTherapyProfile.replaceProfile(c,p);
            CentralTherapyProfile.replaceSessionState(c,s);
        }catch(Exception ignored){}
    }

    private static boolean sharesMeaningfulToken(String a,String b){
        if(a==null||b==null||a.isEmpty()||b.isEmpty())return false;
        String[] xs=a.replaceAll("[^가-힣A-Za-z0-9 ]"," ").split("\\s+");
        for(String x:xs){
            if(x.length()<2||isStopword(x))continue;
            if(b.contains(x))return true;
        }
        return false;
    }

    private static boolean isStopword(String x){
        return "그냥".equals(x)||"이번".equals(x)||"하나".equals(x)
                ||"해본다".equals(x)||"본다".equals(x)||"다음".equals(x)
                ||"상황".equals(x)||"조금".equals(x)||"한번".equals(x);
    }

    private static boolean containsAny(String s,String... xs){
        if(s==null)return false;
        for(String x:xs)if(x!=null&&!x.isEmpty()&&s.contains(x))return true;
        return false;
    }

    private static String compact(String s,int max){
        s=s==null?"":s.trim();
        return s.length()<=max?s:s.substring(0,max);
    }

    private static String safe(String s){
        return s==null?"":s;
    }
}
