package com.maeummon.app;

import com.maeummon.app.clinical.CentralTherapyProfile;
import com.maeummon.app.clinical.TherapySurfaceContext;

import android.app.Activity;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class DesiredSelfCoachActivity extends Activity {
    private EditText desiredSelfInput;
    private EditText coachingSituationInput;
    private TextView savedGoalText;
    private TextView coachingResultText;
    private TextView coachingStatusText;
    private SharedPreferences prefs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_desired_self_coach);
        UiInsets.apply(this, findViewById(R.id.desiredSelfRoot));
        prefs = getSharedPreferences(AppPrefs.PREFS, MODE_PRIVATE);

        desiredSelfInput = findViewById(R.id.desiredSelfInput);
        coachingSituationInput = findViewById(R.id.coachingSituationInput);
        savedGoalText = findViewById(R.id.savedGoalText);
        coachingResultText = findViewById(R.id.coachingResultText);
        coachingStatusText = findViewById(R.id.coachingStatusText);

        String goal = IdentityCoachStorage.getDesiredSelf(this);
        desiredSelfInput.setText(goal);
        updateSavedGoal(goal);

        String last = IdentityCoachStorage.getLastCoaching(this);
        if (!last.isEmpty()) coachingResultText.setText(last);

        String lastSituation = IdentityCoachStorage.getLastSituation(this);
        if (!lastSituation.isEmpty()) {
            coachingSituationInput.setHint("지난 코칭: " + shorten(lastSituation, 55));
        }

        findViewById(R.id.saveDesiredSelfButton).setOnClickListener(v -> saveGoal());
        findViewById(R.id.startFocusCoachingButton).setOnClickListener(v -> runCoaching());
    }

    private void saveGoal() {
        String goal = desiredSelfInput.getText().toString().trim();
        if (goal.isEmpty()) {
            Toast.makeText(this, "되고 싶은 모습을 한 문장이라도 적어줘.", Toast.LENGTH_SHORT).show();
            return;
        }
        IdentityCoachStorage.saveDesiredSelf(this, goal);
        updateSavedGoal(goal);
        Toast.makeText(this, "되고 싶은 모습을 저장했어 🎯", Toast.LENGTH_SHORT).show();
    }

    private void updateSavedGoal(String goal) {
        if (goal == null || goal.trim().isEmpty()) {
            savedGoalText.setText("아직 저장한 모습이 없어. 성격이 아니라 '어떻게 행동하는 사람인지' 적어도 좋아.");
        } else {
            savedGoalText.setText("내가 가고 싶은 방향\n" + goal.trim());
        }
    }

    private void runCoaching() {
        String goal = desiredSelfInput.getText().toString().trim();
        if (goal.isEmpty()) {
            Toast.makeText(this, "먼저 내가 되고 싶은 사람을 적어줘.", Toast.LENGTH_SHORT).show();
            return;
        }

        IdentityCoachStorage.saveDesiredSelf(this, goal);
        updateSavedGoal(goal);

        String situation = coachingSituationInput.getText().toString().trim();
        if (situation.isEmpty()) {
            situation = "지금까지의 상담 기록을 보고, 내가 되고 싶은 모습에 가까워지기 위해 지금 가장 먼저 바꿀 한 가지를 코칭해줘.";
        }

        String apiKey = prefs.getString(AppPrefs.KEY_API_KEY, "").trim();
        if (apiKey.isEmpty()) {
            coachingStatusText.setText("OpenAI API Key가 필요해. 상담사 설정에서 키를 저장해줘.");
            return;
        }

        final String requestSituation = situation;
        final String model = prefs.getString(AppPrefs.KEY_COUNSELING_MODEL, "gpt-5.6-terra");
        coachingStatusText.setText("지금까지 상담을 다시 읽고, 이번에 바꿀 한 가지를 고르는 중이야…");
        findViewById(R.id.startFocusCoachingButton).setEnabled(false);

        new Thread(() -> {
            try {
                String therapy = trimContext(
                        TherapyMemoryManager.buildContext(this)
                                + "\n\n" + TherapySurfaceContext.forSurface(this, TherapySurfaceContext.FOCUS_COACHING)
                                + "\n\n" + UnifiedTherapyProfile.buildSharedContext(this),
                        9000);
                String longTerm = trimContext(
                        LongTermConversationMemory.build(this, goal + "\n" + requestSituation),
                        6500
                );
                String recent = trimContext(LiveMindManager.recentContext(this), 5000);
                String history = trimContext(IdentityCoachStorage.compactHistory(this), 4000);

                String result = OpenAiClient.getIdentityCoaching(
                        apiKey,
                        model,
                        goal,
                        requestSituation,
                        therapy,
                        longTerm,
                        recent,
                        history
                );
                IdentityCoachStorage.saveCoaching(this, requestSituation, result);
                CentralTherapyProfile.mergeFocusCoaching(
                        this, goal, requestSituation, result);

                runOnUiThread(() -> {
                    coachingResultText.setText(result);
                    coachingStatusText.setText("이번 집중 코칭 완료 ✓ 다음에도 이 목표를 이어서 볼게.");
                    findViewById(R.id.startFocusCoachingButton).setEnabled(true);
                });
            } catch (Exception e) {
                runOnUiThread(() -> {
                    coachingStatusText.setText(shortError(e));
                    findViewById(R.id.startFocusCoachingButton).setEnabled(true);
                });
            }
        }).start();
    }

    private String shortError(Exception e) {
        String message = e == null || e.getMessage() == null ? "" : e.getMessage();
        if (message.contains("401")) return "API Key 인증이 안 됐어. 상담사 설정에서 키를 다시 확인해줘.";
        if (message.contains("429")) return "API 사용량 또는 한도에 걸렸어. 잠시 뒤 다시 해줘.";
        if (message.contains("404") || message.toLowerCase().contains("model_not_found")) {
            return "선택한 AI 모델을 사용할 수 없어. 상담사 설정의 모델을 확인해줘.";
        }
        return "집중 코칭 연결이 잠깐 안 됐어. 인터넷/API 설정을 확인하고 다시 눌러줘.";
    }

    private static String trimContext(String s, int max) {
        if (s == null) return "";
        s = s.trim();
        return s.length() <= max ? s : s.substring(s.length() - max);
    }

    private static String shorten(String s, int n) {
        if (s == null) return "";
        return s.length() <= n ? s : s.substring(0, n) + "…";
    }
}
