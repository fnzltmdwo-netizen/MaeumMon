package com.maeummon.app.clinical;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import java.util.*;

public final class ClinicalSessionMemoryRC7 {
    private ClinicalSessionMemoryRC7(){}
    private static final String PREF="clinical_rc7_session";

    public static final class State {
        public int turns=0;
        public final LinkedHashSet<String> askedIds=new LinkedHashSet<>();
        public final LinkedHashSet<String> answeredTargets=new LinkedHashSet<>();
        public boolean allianceRupture=false;
        public String lastMove="";
        public String lastTarget="";
        public String lastAskedTarget="";
        public String answerTarget="";
    }

    public static State load(Context c){
        State s=new State(); if(c==null)return s;
        SharedPreferences p=c.getSharedPreferences(PREF,Context.MODE_PRIVATE);
        s.turns=p.getInt("turns",0); s.allianceRupture=p.getBoolean("rupture",false);
        s.lastMove=p.getString("last_move",""); s.lastTarget=p.getString("last_target","");
        s.lastAskedTarget=p.getString("last_asked_target","");
        s.answerTarget=s.lastAskedTarget;
        readSet(p.getString("asked","[]"),s.askedIds); readSet(p.getString("answered","[]"),s.answeredTargets);
        return s;
    }
    public static void save(Context c,State s){
        if(c==null||s==null)return;
        c.getSharedPreferences(PREF,Context.MODE_PRIVATE).edit()
            .putInt("turns",s.turns).putBoolean("rupture",s.allianceRupture)
            .putString("last_move",s.lastMove).putString("last_target",s.lastTarget)
            .putString("last_asked_target",s.lastAskedTarget)
            .putString("asked",new JSONArray(s.askedIds).toString())
            .putString("answered",new JSONArray(s.answeredTargets).toString()).apply();
    }
    public static void reset(Context c){if(c!=null)c.getSharedPreferences(PREF,Context.MODE_PRIVATE).edit().clear().apply();}
    private static void readSet(String raw,Set<String> out){try{JSONArray a=new JSONArray(raw);for(int i=0;i<a.length();i++){String v=a.optString(i,"");if(!v.isEmpty())out.add(v);}}catch(Exception ignored){}}
}
