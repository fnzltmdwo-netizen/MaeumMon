package com.maeummon.app.clinical;

import android.content.Context;
import org.json.*;

public final class PolicyExplainabilityDecisionRationaleRC12 {
    private PolicyExplainabilityDecisionRationaleRC12(){}

    public static final class Result {
        public boolean evaluated=false;
        public boolean usable=false;
        public boolean policyReferenced=false;
        public boolean currentEvidencePrimary=true;
        public String rationale="";
        public String compactReason="";
        public String sourceTier="";
        public String reason="";
        public String summary="";
    }

    public static Result compose(Context c,ClinicalDecisionRC7 d){
        Result r=new Result();
        if(c==null||d==null){
            r.summary="NO_EVALUATION | NO_CONTEXT_OR_DECISION";
            return r;
        }

        r.evaluated=true;

        JSONObject f=CentralTherapyProfile.loadFormulation(c);

        String move=safe(d.move);
        String mechanism=safe(d.centralMechanism);
        String intervention=safe(d.selectedInterventionId);
        String currentContext=f.optString("current_context_scope","UNKNOWN");

        boolean safety=d.safetyOverride;
        boolean alliance=d.allianceRupture;
        boolean reopened=f.optBoolean("formulation_reopened",false);
        boolean conflict=f.optInt("unresolved_evidence_conflicts",0)>0;

        if(safety){
            r.sourceTier="SAFETY";
            r.rationale="지금은 문제를 더 분석하는 것보다 먼저 안전과 안정화를 확인하는 게 우선이야.";
            r.compactReason="안전·안정화 우선";
            r.reason="SAFETY_OVERRIDE";
            return finish(r);
        }

        if(alliance){
            r.sourceTier="ALLIANCE";
            r.rationale="지금은 해결책을 밀기보다 내가 네 말을 제대로 이해했는지부터 다시 맞추는 게 더 중요해.";
            r.compactReason="이해 맞추기 우선";
            r.reason="ALLIANCE_REPAIR";
            return finish(r);
        }

        if(reopened||conflict){
            r.sourceTier="CURRENT_EVIDENCE";
            r.rationale="지금 정보가 기존 해석과 충돌해서, 예전 결론을 그대로 쓰기보다 현재 상황을 다시 확인하는 쪽을 골랐어.";
            r.compactReason="현재 정보 재검증";
            r.reason="FORMULATION_UNSTABLE";
            return finish(r);
        }

        if("ASK".equals(move)){
            String target=safe(d.targetVariable);
            if(target.isEmpty())target="핵심 차이";

            r.sourceTier="CURRENT_EVIDENCE";
            r.rationale="지금은 바로 조언하기보다 '"+humanizeTarget(target)+"'을 확인해야 상담 방향이 달라질 수 있어서 이 질문을 고른 거야.";
            r.compactReason="방향을 가르는 정보 확인";
            r.reason="QUESTION_INFORMATION_GAIN";
            return finish(r);
        }

        if("FORMULATE".equals(move)){
            r.sourceTier="CURRENT_FORMULATION";
            r.rationale=formulationRationale(mechanism);
            r.compactReason="현재 패턴 정리";
            r.reason="FORMULATION_READY";
            return finish(r);
        }

        if("INTERVENE".equals(move)){
            String base=interventionRationale(intervention,mechanism);

            if("CONTEXT_SPECIFIC".equals(d.policyHierarchyWinner)
                    && !safe(d.policySelectionEffectiveKey).isEmpty()){

                r.policyReferenced=true;
                r.currentEvidencePrimary=true;
                r.sourceTier="CURRENT_EVIDENCE_PLUS_CONTEXT_POLICY";
                r.rationale=base+" 그리고 비슷한 "+humanizeContext(currentContext)
                        +" 상황에서 이 방식이 전에 도움이 된 기록이 있어서, 현재 판단과 맞는 범위에서 약하게 참고했어.";
                r.compactReason="현재 판단 + 같은 상황의 과거 결과";
                r.reason="CONTEXT_POLICY_SUPPORTS_CURRENT";
                return finish(r);
            }

            if("GENERAL".equals(d.policyHierarchyWinner)
                    && !safe(d.policySelectionEffectiveKey).isEmpty()){

                r.policyReferenced=true;
                r.currentEvidencePrimary=true;
                r.sourceTier="CURRENT_EVIDENCE_PLUS_GENERAL_POLICY";
                r.rationale=base+" 예전에 여러 상황에서 도움이 된 기록도 있지만, 그 기억보다는 지금 네 상황의 근거를 우선해서 선택했어.";
                r.compactReason="현재 판단 우선, 과거 기록은 보조";
                r.reason="GENERAL_POLICY_WEAK_PRIOR";
                return finish(r);
            }

            r.sourceTier="CURRENT_EVIDENCE";
            r.rationale=base;
            r.compactReason="현재 핵심 기전에 맞춘 개입";
            r.reason="CURRENT_BRIDGE_SELECTION";
            return finish(r);
        }

        if("REVIEW".equals(move)){
            r.sourceTier="OUTCOME_REVIEW";
            r.rationale="지금은 새 방법을 더 얹기보다, 방금 해본 방식이 실제로 어떤 영향을 줬는지 확인해야 다음 선택을 정확하게 할 수 있어.";
            r.compactReason="효과 확인 후 다음 결정";
            r.reason="REVIEW_BEFORE_NEXT_MOVE";
            return finish(r);
        }

        if("STABILIZE".equals(move)){
            r.sourceTier="STABILIZATION";
            r.rationale="지금은 해석이나 행동 계획보다 긴장을 조금 낮추고 버틸 수 있는 상태를 만드는 게 먼저라서 안정화 쪽을 골랐어.";
            r.compactReason="안정화 우선";
            r.reason="STABILIZE_FIRST";
            return finish(r);
        }

        r.sourceTier="CURRENT_EVIDENCE";
        r.rationale="지금까지 확인된 정보와 현재 상담 단계에 맞춰 다음 움직임을 정했어.";
        r.compactReason="현재 정보 기반";
        r.reason="DEFAULT_CURRENT_EVIDENCE";
        return finish(r);
    }

    public static String instruction(Result r){
        if(r==null||!r.usable)return "";

        return "DECISION_RATIONALE_USER_FACING="+r.rationale
                +" 이 설명은 내부 점수·policy key·진단명 없이 1~2문장으로 자연스럽게 녹이고, 사용자가 '왜?'를 물었을 때 우선 사용한다.";
    }

    private static String formulationRationale(String mechanism){
        if("AMBIGUITY_TO_REJECTION".equals(mechanism))
            return "지금 보이는 핵심은 상대의 애매한 반응 자체보다, 그 애매함이 빠르게 '거절당했다'는 해석으로 이어지면서 불안이 커지는 흐름이야.";
        if("ACTUAL_RELATIONSHIP_CHANGE".equals(mechanism))
            return "지금은 단순한 불안 해석만으로 보기보다 실제 관계 변화 가능성도 있어서, 사실과 추측을 분리해 정리하는 게 맞아 보여.";
        if("REAL_CONFLICT_OR_REJECTION".equals(mechanism))
            return "이번에는 단순한 오해보다 실제 갈등이나 거절 요소가 있어서, 마음을 달래는 것만보다 관계 대응을 같이 보는 게 중요해.";
        if("LOAD_EXCEEDS_CAPACITY".equals(mechanism))
            return "지금 핵심은 의지 부족보다 감당해야 할 일과 관계 부담이 현재 회복 여력을 넘어선 쪽에 가까워 보여.";
        if("RECOVERY_DEFICIT".equals(mechanism))
            return "지금은 문제를 더 밀어붙이기보다 회복 여력이 떨어져 있는지가 중요한 축이라 그 부분을 중심으로 정리했어.";
        return "지금까지 나온 사실, 해석, 감정과 행동의 연결을 보면 이 패턴이 현재 문제를 가장 잘 설명하는 가설이야.";
    }

    private static String interventionRationale(String intervention,String mechanism){
        if("REALITY_TEST".equals(intervention))
            return "지금은 사실과 해석이 빠르게 붙는 부분이 핵심이라, 둘을 잠깐 분리해서 보는 방법이 가장 직접적으로 맞아.";
        if("COMMUNICATION_SCRIPT".equals(intervention))
            return "실제 관계 변화 가능성을 확인해야 해서, 혼자 추측을 키우기보다 상대에게 확인할 수 있는 짧은 표현을 고른 거야.";
        if("REPAIR_OR_BOUNDARY".equals(intervention))
            return "실제 갈등 요소가 있는 만큼, 네 감정을 참기만 하기보다 관계를 복구할지 경계를 세울지 정하는 쪽이 필요해.";
        if("AMBIGUITY_TOLERANCE".equals(intervention))
            return "지금은 답이 바로 나오지 않는 애매함 자체를 견디는 힘이 문제를 키우지 않는 데 가장 중요해 보여.";
        if("FACT_VS_EVALUATION".equals(intervention))
            return "한 번의 결과가 곧바로 '내 전체 가치' 평가로 커지는 걸 막기 위해 사실과 자기평가를 분리하는 방법을 골랐어.";
        if("LOAD_REDUCTION".equals(intervention))
            return "지금은 더 잘 버티는 기술보다 실제 부담을 하나라도 줄이는 게 회복에 더 직접적이어서 이 방법을 고른 거야.";
        if("WORK_BOUNDARY_SCRIPT".equals(intervention))
            return "대인 압박이 계속 긴장을 올리는 상황이라, 참는 것보다 업무 관계에서 쓸 수 있는 짧은 경계 문장이 더 직접적이야.";
        if("RECOVERY_FIRST".equals(intervention))
            return "지금은 성과를 더 내는 것보다 회복 여력을 먼저 복구해야 다른 문제도 제대로 다룰 수 있어서 이 순서를 골랐어.";
        if("GRADED_APPROACH".equals(intervention))
            return "피하면 당장은 편해지지만 두려움이 유지될 수 있어서, 무리하지 않는 아주 작은 접근을 먼저 시도하는 쪽을 골랐어.";
        return "현재 가장 가능성 높은 기전 '"+mechanism+"'을 직접 건드리면서도 부담이 과하지 않은 방법을 골랐어.";
    }

    private static String humanizeTarget(String t){
        if("interpretation_not_fact".equals(t))return "그게 실제 사실인지, 네 해석이 섞인 건지";
        if("clarify_relationship_change".equals(t))return "실제로 관계가 달라진 건지";
        if("reduce_commitment_or_task_load".equals(t))return "지금 부담을 실제로 줄일 수 있는 지점";
        if("restore_regulation_capacity".equals(t))return "회복 여력이 얼마나 떨어져 있는지";
        if("experiment_outcome_attribution".equals(t))return "변화가 방금 해본 방법 때문인지";
        return t.replace("_"," ");
    }

    private static String humanizeContext(String c){
        if("RELATIONSHIP".equals(c))return "관계";
        if("ROMANTIC".equals(c))return "연애";
        if("FRIENDSHIP".equals(c))return "친구 관계";
        if("WORK".equals(c))return "직장";
        if("FAMILY".equals(c))return "가족";
        if("SOCIAL".equals(c))return "대인관계";
        return "비슷한";
    }

    private static Result finish(Result r){
        r.usable=!r.rationale.isEmpty();
        r.summary="usable="+r.usable
                +" | sourceTier="+r.sourceTier
                +" | policyReferenced="+r.policyReferenced
                +" | reason="+r.reason
                +" | compact="+r.compactReason;
        return r;
    }

    private static String safe(String s){
        return s==null?"":s;
    }
}
