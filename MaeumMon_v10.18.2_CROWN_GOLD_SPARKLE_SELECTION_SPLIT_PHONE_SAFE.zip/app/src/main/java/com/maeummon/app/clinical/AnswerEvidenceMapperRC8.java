package com.maeummon.app.clinical;

import org.json.*;
import java.util.*;

public final class AnswerEvidenceMapperRC8 {
    private AnswerEvidenceMapperRC8(){}

    public static final class Evidence {
        public final String target;
        public final LinkedHashMap<String,Double> deltas=new LinkedHashMap<>();
        public final List<String> notes=new ArrayList<>();
        public Evidence(String target){this.target=target==null?"":target;}
        public Evidence delta(String hypothesis,double value,String note){
            deltas.put(hypothesis,value);
            if(note!=null&&!note.isEmpty())notes.add(note);
            return this;
        }
    }

    public static Evidence map(String previousTarget,String userText){
        String t=safe(userText);
        String target=safe(previousTarget);
        Evidence e=new Evidence(target);

        if("baseline_relationship_change".equals(target)){
            if(containsAny(t,"원래도 느려","원래 답장이 느","늘 느렸","평소에도 그래")){
                e.delta("normal_response_variation",+0.34,"baseline supports normal response variation");
                e.delta("relationship_distance_change",-0.28,"no recent baseline shift");
            }else if(containsAny(t,"최근부터 느려","갑자기 느려","예전엔 빨랐","요즘 달라")){
                e.delta("relationship_distance_change",+0.36,"recent baseline shift supports relationship change");
                e.delta("normal_response_variation",-0.24,"recent change contradicts stable baseline");
            }
        }

        if("recent_conflict".equals(target)){
            if(containsAny(t,"싸웠","갈등 있었","서운한 일 있었","다퉜")){
                e.delta("actual_rejection_or_conflict",+0.38,"recent conflict supports actual conflict/rejection");
                e.delta("normal_response_variation",-0.12,"conflict reduces normal-variation explanation");
            }else if(containsAny(t,"싸운 일 없어","갈등 없어","다툰 적 없어","별일 없었")){
                e.delta("actual_rejection_or_conflict",-0.36,"explicit absence of conflict");
                e.delta("rejection_interpretation_amplification",+0.10,"absence of conflict leaves interpretation hypothesis more plausible");
            }
        }

        if("selective_change".equals(target)){
            if(containsAny(t,"나한테만","다른 사람한텐 안","나한테 유독")){
                e.delta("relationship_distance_change",+0.34,"selective change toward user");
                e.delta("normal_response_variation",-0.22,"selective pattern contradicts global response style");
            }else if(containsAny(t,"원래 다 그래","모두한테 그래","누구한테나 느려")){
                e.delta("normal_response_variation",+0.32,"global response style supports normal variation");
                e.delta("relationship_distance_change",-0.24,"not selective toward user");
            }
        }

        if("meaning_attribution".equals(target)){
            if(containsAny(t,"나 싫어","버려질","미워할","무시당한","관심 없어")){
                e.delta("rejection_interpretation_amplification",+0.34,"reply delay interpreted as rejection");
            }
            if(containsAny(t,"바쁜가 보다","그럴 수 있지","별 의미 없")){
                e.delta("rejection_interpretation_amplification",-0.22,"neutral meaning attribution");
            }
        }

        if("evaluation_meaning".equals(target)){
            if(containsAny(t,"무능","일 못하는 사람","능력 없","평가 나빠")){
                e.delta("evaluation_threat",+0.40,"evaluation meaning explicit");
            }
            if(containsAny(t,"일이 많아서","업무량 때문","시간이 부족")){
                e.delta("workload_stress",+0.30,"workload explanation explicit");
                e.delta("evaluation_threat",-0.12,"less centered on evaluation");
            }
        }

        if("workload_vs_relationship".equals(target)){
            if(containsAny(t,"사람 때문에","상사 때문에","동료 때문에","눈치 보여")){
                e.delta("interpersonal_work_stress",+0.36,"interpersonal work stress explicit");
                e.delta("workload_stress",-0.18,"less workload-centered");
            }
            if(containsAny(t,"일이 많아서","업무량","할 일이 너무 많")){
                e.delta("workload_stress",+0.36,"workload stress explicit");
                e.delta("interpersonal_work_stress",-0.14,"less interpersonal-centered");
            }
        }

        if("short_term_relief".equals(target)){
            if(containsAny(t,"피하면 편","안 만나면 편","회피하면 편","당장은 편")){
                e.delta("avoidance_negative_reinforcement",+0.44,"avoidance produces immediate relief");
            }else if(containsAny(t,"피해도 안 편","회피해도 불안","더 불안해")){
                e.delta("avoidance_negative_reinforcement",-0.26,"avoidance not reinforced by relief");
            }
        }

        if("consequence".equals(target)){
            if(containsAny(t,"나중에 더 불안","문제가 커져","더 힘들어","미뤄져")){
                e.delta("avoidance_negative_reinforcement",+0.24,"long-term cost after avoidance");
            }
        }

        // General explicit negation/confirmation support.
        if(containsAny(t,"아니","그건 아니","전혀 아니")){
            e.notes.add("explicit negation present");
        }
        if(containsAny(t,"맞아","응 맞아","그거야")){
            e.notes.add("explicit confirmation present");
        }

        return e;
    }

    public static JSONArray applyToHypotheses(JSONArray hypotheses,Evidence e){
        if(hypotheses==null)return new JSONArray();
        JSONArray out=new JSONArray();
        double sum=0.0;

        List<JSONObject> tmp=new ArrayList<>();
        for(int i=0;i<hypotheses.length();i++){
            JSONObject src=hypotheses.optJSONObject(i);
            if(src==null)continue;
            JSONObject h=cloneJson(src);
            String id=h.optString("id","");
            double c=h.optDouble("confidence",0.25);
            if(e!=null && e.deltas.containsKey(id)){
                double delta=e.deltas.get(id);
                c=clamp(c+delta);
                try{
                    JSONArray ef=h.optJSONArray(delta>=0?"evidence_for":"evidence_against");
                    if(ef==null)ef=new JSONArray();
                    String note=(e.notes.isEmpty()?"answer evidence":e.notes.get(0));
                    putUnique(ef,note+" ["+e.target+"]");
                    h.put(delta>=0?"evidence_for":"evidence_against",ef);
                }catch(Exception ignored){}
            }
            try{h.put("confidence",c);}catch(Exception ignored){}
            tmp.add(h); sum+=c;
        }

        if(sum<=0)sum=1.0;
        Collections.sort(tmp,(a,b)->Double.compare(
                b.optDouble("confidence",0),a.optDouble("confidence",0)));

        for(JSONObject h:tmp){
            try{
                h.put("confidence",round(h.optDouble("confidence",0)/sum));
                h.put("active",true);
            }catch(Exception ignored){}
            out.put(h);
        }
        return out;
    }

    public static String summary(Evidence e){
        if(e==null||e.deltas.isEmpty())return "";
        StringBuilder b=new StringBuilder("target=").append(e.target).append(" ");
        for(Map.Entry<String,Double> x:e.deltas.entrySet()){
            b.append(x.getKey()).append(x.getValue()>=0?"+":"")
                    .append(round(x.getValue())).append(" ");
        }
        return b.toString().trim();
    }

    private static JSONObject cloneJson(JSONObject o){
        try{return new JSONObject(o.toString());}catch(Exception ex){return new JSONObject();}
    }
    private static void putUnique(JSONArray a,String s){
        for(int i=0;i<a.length();i++)if(s.equals(a.optString(i)))return;
        a.put(s);
    }
    private static boolean containsAny(String s,String... xs){
        for(String x:xs)if(s.contains(x))return true;
        return false;
    }
    private static double clamp(double x){return Math.max(0.02,Math.min(0.95,x));}
    private static double round(double x){return Math.round(x*1000.0)/1000.0;}
    private static String safe(String s){return s==null?"":s;}
}
