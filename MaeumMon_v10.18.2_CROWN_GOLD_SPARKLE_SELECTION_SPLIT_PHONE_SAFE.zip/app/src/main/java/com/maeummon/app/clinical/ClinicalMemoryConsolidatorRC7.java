package com.maeummon.app.clinical;

import android.content.*;
import org.json.*;
import java.util.*;
import java.util.regex.*;

public final class ClinicalMemoryConsolidatorRC7 {
    private ClinicalMemoryConsolidatorRC7(){}

    private static final String PREF="rc7_memory_v608";
    private static final String KEY_STABLE="stable_profile";
    private static final String KEY_SESSION="session_summary";
    private static final int MAX_STABLE=24;
    private static final int MAX_SESSION=18;

    public static final class Snapshot {
        public final JSONArray stableProfile;
        public final JSONArray sessionSummary;
        public Snapshot(JSONArray stableProfile,JSONArray sessionSummary){
            this.stableProfile=stableProfile==null?new JSONArray():stableProfile;
            this.sessionSummary=sessionSummary==null?new JSONArray():sessionSummary;
        }
    }

    public static void observe(
            Context c,
            String userText,
            ClinicalDecisionRC7 decision,
            String finalReply
    ){
        if(c==null)return;
        try{
            Snapshot snap=load(c);
            List<JSONObject> stable=toList(snap.stableProfile);
            List<JSONObject> session=toList(snap.sessionSummary);

            // Session memory: concrete current-session facts/decisions.
            for(JSONObject candidate:extractSessionCandidates(userText,decision)){
                upsert(session,candidate,MAX_SESSION);
            }

            // Stable profile: only long-lived patterns with stronger evidence.
            for(JSONObject candidate:extractStableCandidates(userText,decision)){
                upsert(stable,candidate,MAX_STABLE);
            }

            // Never promote tentative/low-confidence hypothesis text as stable fact.
            removeUnsafePromotions(stable);

            save(c,stable,session);
        }catch(Exception ignored){}
    }

    public static Snapshot load(Context c){
        SharedPreferences p=c.getSharedPreferences(PREF,Context.MODE_PRIVATE);
        return new Snapshot(
                parseArray(p.getString(KEY_STABLE,"[]")),
                parseArray(p.getString(KEY_SESSION,"[]"))
        );
    }

    public static String buildContext(Context c){
        Snapshot s=load(c);
        StringBuilder b=new StringBuilder();
        if(s.stableProfile.length()>0){
            b.append("[STABLE_PROFILE]\\n");
            for(int i=0;i<s.stableProfile.length();i++){
                JSONObject o=s.stableProfile.optJSONObject(i);
                if(o!=null)b.append("- ").append(o.optString("text","")).append("\\n");
            }
        }
        if(s.sessionSummary.length()>0){
            b.append("[SESSION_SUMMARY]\\n");
            for(int i=0;i<s.sessionSummary.length();i++){
                JSONObject o=s.sessionSummary.optJSONObject(i);
                if(o!=null)b.append("- ").append(o.optString("text","")).append("\\n");
            }
        }
        return b.toString();
    }

    public static void clearSession(Context c){
        if(c==null)return;
        c.getSharedPreferences(PREF,Context.MODE_PRIVATE).edit()
                .putString(KEY_SESSION,"[]").apply();
    }

    public static void clearAll(Context c){
        if(c==null)return;
        c.getSharedPreferences(PREF,Context.MODE_PRIVATE).edit().clear().apply();
    }

    public static void replaceSnapshot(Context c,List<JSONObject> stable,List<JSONObject> session){
        if(c==null)return;
        save(c,
                stable==null?new ArrayList<>():stable,
                session==null?new ArrayList<>():session);
    }

    private static List<JSONObject> extractSessionCandidates(String text,ClinicalDecisionRC7 d)throws Exception{
        List<JSONObject> out=new ArrayList<>();
        String t=safe(text);

        if(containsAny(t,"원래도","예전에도","최근부터","요즘부터","갑자기")){
            out.add(memory("baseline",compact(t),0.82,"SESSION"));
        }
        if(containsAny(t,"싸운 일은 없어","갈등은 없어","다툰 건 없어")){
            out.add(memory("recent_conflict","최근 갈등이 없다고 사용자가 말함",0.92,"SESSION"));
        }
        if(containsAny(t,"해결책 말고 이해","이해받고 싶","조언 말고")){
            out.add(memory("response_need","현재는 해결보다 이해/공감을 우선 원함",0.92,"SESSION"));
        }
        if(containsAny(t,"어떻게 해야","방법 알려","뭘 하면 좋을까")){
            out.add(memory("response_need","현재는 구체적인 방법/행동을 원함",0.88,"SESSION"));
        }
        if(containsAny(t,"버려질까","미워할까","싫어할까")){
            out.add(memory("core_fear_current",compact(t),0.75,"SESSION"));
        }
        if(d!=null && "ALLIANCE_REPAIR".equals(d.move)){
            out.add(memory("therapy_process","상담 방식/목표의 어긋남이 발생해 수리 단계로 전환됨",0.90,"SESSION"));
        }
        return out;
    }

    private static List<JSONObject> extractStableCandidates(String text,ClinicalDecisionRC7 d)throws Exception{
        List<JSONObject> out=new ArrayList<>();
        String t=safe(text);

        // Require repetition/generalization language before stable promotion.
        if(containsAny(t,"항상","자주","매번","여러 관계에서","예전에도 비슷","반복돼")){
            if(containsAny(t,"답장","무시","거절","싫어할","버려질")){
                out.add(memory("relationship_pattern",
                        "관계의 애매한 신호를 거절/거리감으로 해석하며 불안이 반복되는 경향을 사용자가 보고함",
                        0.78,"STABLE"));
            }
            if(containsAny(t,"거절 못","싫다고 못","맞춰주","눈치")){
                out.add(memory("boundary_pattern",
                        "관계 악화를 우려해 거절이나 경계설정이 어려운 경향을 사용자가 보고함",
                        0.78,"STABLE"));
            }
            if(containsAny(t,"회피","피해","도망")){
                out.add(memory("avoidance_pattern",
                        "불편한 감정/상황을 피하면 단기적으로 편해지는 회피 패턴을 사용자가 보고함",
                        0.76,"STABLE"));
            }
        }

        // Strength/protective factor can be promoted when user describes repeated capacity.
        if(containsAny(t,"그래도 해냈","계속 출근","다시 해보","버텼")){
            out.add(memory("strength",
                    "힘든 상황에서도 기능을 유지하거나 다시 시도하는 능력이 있음",
                    0.72,"STABLE"));
        }
        return out;
    }

    private static JSONObject memory(String key,String text,double confidence,String scope)throws Exception{
        JSONObject o=new JSONObject();
        o.put("key",key);
        o.put("text",text);
        o.put("confidence",confidence);
        o.put("scope",scope);
        o.put("updated_at",System.currentTimeMillis());
        return o;
    }

    private static void upsert(List<JSONObject> xs,JSONObject item,int max){
        String key=item.optString("key","");
        String text=item.optString("text","");
        int found=-1;
        for(int i=0;i<xs.size();i++){
            JSONObject x=xs.get(i);
            if(key.equals(x.optString("key","")) && similar(text,x.optString("text",""))){
                found=i; break;
            }
        }
        if(found>=0){
            JSONObject old=xs.remove(found);
            double conf=Math.max(old.optDouble("confidence",0),item.optDouble("confidence",0));
            try{item.put("confidence",conf);}catch(Exception ignored){}
        }
        xs.add(0,item);
        while(xs.size()>max)xs.remove(xs.size()-1);
    }

    private static boolean similar(String a,String b){
        if(a.equals(b))return true;
        Set<String> aa=tokens(a),bb=tokens(b);
        if(aa.isEmpty()||bb.isEmpty())return false;
        int inter=0;
        for(String x:aa)if(bb.contains(x))inter++;
        double j=(double)inter/(double)(aa.size()+bb.size()-inter);
        return j>=0.55;
    }

    private static Set<String> tokens(String s){
        Set<String> out=new HashSet<>();
        Matcher m=Pattern.compile("[가-힣]{2,}").matcher(safe(s));
        while(m.find())out.add(m.group());
        return out;
    }

    private static void removeUnsafePromotions(List<JSONObject> stable){
        Iterator<JSONObject> it=stable.iterator();
        while(it.hasNext()){
            JSONObject o=it.next();
            String text=o.optString("text","");
            double conf=o.optDouble("confidence",0);
            if(conf<0.70 || containsAny(text,"아마","확실히","분명히","진단","장애")){
                it.remove();
            }
        }
    }

    private static void save(Context c,List<JSONObject> stable,List<JSONObject> session){
        c.getSharedPreferences(PREF,Context.MODE_PRIVATE).edit()
                .putString(KEY_STABLE,new JSONArray(stable).toString())
                .putString(KEY_SESSION,new JSONArray(session).toString())
                .apply();
    }

    private static JSONArray parseArray(String s){
        try{return new JSONArray(s);}catch(Exception e){return new JSONArray();}
    }

    private static List<JSONObject> toList(JSONArray a){
        List<JSONObject> out=new ArrayList<>();
        for(int i=0;i<a.length();i++){
            JSONObject o=a.optJSONObject(i);
            if(o!=null)out.add(o);
        }
        return out;
    }

    private static String compact(String s){
        s=safe(s).trim();
        if(s.length()>180)return s.substring(0,180);
        return s;
    }
    private static boolean containsAny(String s,String... xs){
        for(String x:xs)if(s.contains(x))return true;
        return false;
    }
    private static String safe(String s){return s==null?"":s;}
}
