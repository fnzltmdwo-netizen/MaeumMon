package com.maeummon.app.clinical;

import android.content.Context;
import org.json.*;
import java.util.*;

public final class ContextBoundedPatternGeneralizationRC8 {
    private ContextBoundedPatternGeneralizationRC8(){}

    public static final String RELATIONSHIP="RELATIONSHIP";
    public static final String WORK="WORK";
    public static final String FAMILY="FAMILY";
    public static final String SELF="SELF";
    public static final String HEALTH="HEALTH";
    public static final String GENERAL="GENERAL";
    public static final String UNKNOWN="UNKNOWN";

    public static final class Result {
        public int bounded=0;
        public int generalized=0;
        public int blocked=0;
        public String currentContext=UNKNOWN;
        public String summary="";
    }

    public static Result apply(Context c,String userText){
        Result r=new Result();
        if(c==null)return r;

        JSONObject p=CentralTherapyProfile.loadProfile(c);
        JSONArray stable=p.optJSONArray("stable_profile");
        if(stable==null)return r;

        r.currentContext=detectContext(userText);

        for(int i=0;i<stable.length();i++){
            JSONObject s=stable.optJSONObject(i);
            if(s==null)continue;

            String status=s.optString("status","ACTIVE");
            if(!"ACTIVE".equals(status))continue;

            String text=s.optString("text","");
            String storedContext=s.optString("context_scope","");
            if(storedContext.isEmpty()){
                storedContext=inferContextFromText(text);
                try{s.put("context_scope",storedContext);}catch(Exception ignored){}
            }

            JSONArray contexts=s.optJSONArray("confirmed_contexts");
            if(contexts==null)contexts=new JSONArray();

            if(!contains(contexts,storedContext) && !UNKNOWN.equals(storedContext)){
                contexts.put(storedContext);
            }

            boolean crossContextEvidence=
                    !UNKNOWN.equals(r.currentContext)
                    && !UNKNOWN.equals(storedContext)
                    && !r.currentContext.equals(storedContext)
                    && containsEquivalentPattern(stable,text,r.currentContext);

            if(crossContextEvidence){
                if(!contains(contexts,r.currentContext))contexts.put(r.currentContext);
            }

            int confirmed=countDistinct(contexts);

            try{
                s.put("confirmed_contexts",contexts);

                if(confirmed>=3){
                    s.put("generalization_status","GENERALIZED");
                    s.put("context_scope",GENERAL);
                    s.put("generalization_confidence","MEDIUM");
                    r.generalized++;
                }else{
                    s.put("generalization_status","CONTEXT_BOUNDED");
                    if(GENERAL.equals(storedContext) && confirmed<3)
                        s.put("context_scope",UNKNOWN);
                    s.put("generalization_confidence",
                            confirmed>=2 ? "LOW_TO_MEDIUM" : "LOW");
                    r.bounded++;
                }

                // Explicit guard: do not apply bounded memory outside its confirmed contexts.
                boolean allowed=
                        UNKNOWN.equals(r.currentContext)
                        || GENERAL.equals(s.optString("context_scope",""))
                        || contains(contexts,r.currentContext);

                s.put("usable_in_current_context",allowed);

                if(!allowed)r.blocked++;
            }catch(Exception ignored){}
        }

        try{
            p.put("stable_profile",stable);
            p.put("current_context_scope",r.currentContext);
            p.put("context_generalization_summary",
                    "bounded="+r.bounded+", generalized="+r.generalized+", blocked="+r.blocked);
            p.put("context_generalization_updated_at",System.currentTimeMillis());
            CentralTherapyProfile.replaceProfile(c,p);
        }catch(Exception ignored){}

        r.summary="context="+r.currentContext+", bounded="+r.bounded
                +", generalized="+r.generalized+", blocked="+r.blocked;
        return r;
    }

    public static String instruction(Result r){
        if(r==null)return "";
        return "CONTEXT_BOUNDARY=true. stable memory가 특정 관계/직장/가족 맥락에서만 확인됐다면 "
                +"다른 맥락에도 자동 일반화하지 않는다. usable_in_current_context=false인 기억은 "
                +"현재 formulation의 핵심 근거로 사용하지 않는다. 3개 이상의 독립 맥락에서 반복 확인될 때만 "
                +"GENERALIZED 후보로 취급한다. "+r.summary;
    }

    private static boolean containsEquivalentPattern(JSONArray stable,String text,String context){
        String fingerprint=fingerprint(text);
        if(fingerprint.isEmpty())return false;

        for(int i=0;i<stable.length();i++){
            JSONObject s=stable.optJSONObject(i);
            if(s==null)continue;
            String other=s.optString("text","");
            String otherContext=s.optString("context_scope",inferContextFromText(other));
            if(context.equals(otherContext)
                    && fingerprint.equals(fingerprint(other))
                    && "ACTIVE".equals(s.optString("status","ACTIVE"))){
                return true;
            }
        }
        return false;
    }

    private static String fingerprint(String text){
        if(text==null)return "";
        if(has(text,"거절","미워","버려","답장","연락","무시"))return "REJECTION_THREAT";
        if(has(text,"거절 못","싫다고 못","경계","부탁"))return "BOUNDARY_DIFFICULTY";
        if(has(text,"회피","피해","도망","미뤄"))return "AVOIDANCE";
        if(has(text,"평가","무능","실수","눈치"))return "EVALUATION_THREAT";
        if(has(text,"과하게 약속","무리","번아웃","지쳐"))return "OVERCOMMITMENT";
        return "";
    }

    private static String detectContext(String t){
        if(t==null||t.trim().isEmpty())return UNKNOWN;
        if(has(t,"친구","애인","연락","답장","단톡","관계"))return RELATIONSHIP;
        if(has(t,"회사","직장","상사","동료","업무","팀장"))return WORK;
        if(has(t,"엄마","아빠","부모","가족","형제","누나","언니"))return FAMILY;
        if(has(t,"내가 나를","자책","자존감","스스로"))return SELF;
        if(has(t,"병원","약","몸","수면","통증","건강"))return HEALTH;
        return UNKNOWN;
    }

    private static String inferContextFromText(String t){
        return detectContext(t);
    }

    private static int countDistinct(JSONArray a){
        Set<String> s=new HashSet<>();
        for(int i=0;i<a.length();i++){
            String x=a.optString(i,"");
            if(!x.isEmpty()&&!UNKNOWN.equals(x))s.add(x);
        }
        return s.size();
    }

    private static boolean contains(JSONArray a,String x){
        if(a==null||x==null||x.isEmpty())return false;
        for(int i=0;i<a.length();i++)if(x.equals(a.optString(i,"")))return true;
        return false;
    }

    private static boolean has(String s,String... xs){
        if(s==null)return false;
        for(String x:xs)if(s.contains(x))return true;
        return false;
    }
}
