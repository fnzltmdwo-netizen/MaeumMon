package com.maeummon.app;

import android.content.Context;
import android.content.SharedPreferences;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class CompanionProfile {

    public static int getAffection(Context context) {
        SharedPreferences prefs = context.getSharedPreferences(AppPrefs.PREFS, Context.MODE_PRIVATE);
        return prefs.getInt(AppPrefs.KEY_AFFECTION, 0);
    }

    public static int addAffection(Context context, int amount) {
        SharedPreferences prefs = context.getSharedPreferences(AppPrefs.PREFS, Context.MODE_PRIVATE);
        int value = Math.max(0, Math.min(100, prefs.getInt(AppPrefs.KEY_AFFECTION, 0) + amount));
        prefs.edit().putInt(AppPrefs.KEY_AFFECTION, value).apply();
        return value;
    }

    public static int level(int affection) {
        if (affection >= 80) return 5;
        if (affection >= 55) return 4;
        if (affection >= 30) return 3;
        if (affection >= 12) return 2;
        return 1;
    }

    public static String levelName(int affection) {
        switch (level(affection)) {
            case 5: return "꼭 붙어다니는 사이";
            case 4: return "많이 친한 사이";
            case 3: return "편한 사이";
            case 2: return "조금 친해진 사이";
            default: return "처음 알아가는 사이";
        }
    }

    public static String today() {
        return new SimpleDateFormat("yyyy-MM-dd", Locale.KOREA).format(new Date());
    }

    public static boolean checkedInToday(Context context) {
        SharedPreferences prefs = context.getSharedPreferences(AppPrefs.PREFS, Context.MODE_PRIVATE);
        return today().equals(prefs.getString(AppPrefs.KEY_LAST_CHECKIN_DATE, ""));
    }

    public static void saveCheckIn(Context context, int score) {
        SharedPreferences prefs = context.getSharedPreferences(AppPrefs.PREFS, Context.MODE_PRIVATE);
        prefs.edit()
                .putString(AppPrefs.KEY_LAST_CHECKIN_DATE, today())
                .putInt(AppPrefs.KEY_LAST_CHECKIN_SCORE, score)
                .apply();

        String[] words = {
                "오늘 마음 점수 1점 - 많이 힘든 날",
                "오늘 마음 점수 2점 - 지치고 버거운 날",
                "오늘 마음 점수 3점 - 그냥저냥 버틴 날",
                "오늘 마음 점수 4점 - 조금 숨통이 트인 날",
                "오늘 마음 점수 5점 - 기분이 살아난 날"
        };

        ChatStorage.addDiaryRecord(context, words[Math.max(1, Math.min(5, score)) - 1]);
        addAffection(context, 3);
    }

    public static String checkInReply(int score) {
        switch (score) {
            case 1:
                return "승재야, 오늘은 버티는 것만 해도 되는 날이야. 제일 안 급한 건 미뤄도 돼. 지금은 너를 덜 몰아붙이는 게 먼저야.";
            case 2:
                return "오늘 마음이 꽤 지쳤구나. 다 해내려 하기보다, 제일 부담되는 것 하나만 줄여보자.";
            case 3:
                return "무난한 날에도 마음은 왔다 갔다 할 수 있어. 오늘 편했던 순간 하나만 떠올려봐도 충분해.";
            case 4:
                return "오늘은 조금 괜찮았구나. 뭐가 너를 덜 힘들게 했는지 한 가지만 기억해두자.";
            case 5:
                return "좋은 날이네. 이 기분을 만든 장면 하나만 남겨두면, 힘든 날 다시 꺼내보기 좋아.";
            default:
                return "오늘 마음 알려줘서 고마워.";
        }
    }
}
