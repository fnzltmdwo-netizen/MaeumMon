package com.maeummon.app;

import android.content.Context;
import android.database.Cursor;

/**
 * v10.1 single source of truth for the currently active Mind PT.
 * Home, widget, mascot overlay and My Room read the same active session.
 */
public final class CentralMindPtState {
    private CentralMindPtState() {}

    public static class Snapshot {
        public long trainingId = -1;
        public String mode = "";
        public String muscle = "";
        public String exercise = "";
        public String criterion = "";
        public String rationale = "";
        public long createdAt = 0L;
        public boolean active = false;
    }

    public static Snapshot current(Context context) {
        Snapshot out = new Snapshot();
        MindTrainingDbHelper helper = new MindTrainingDbHelper(context.getApplicationContext());
        Cursor c = helper.getReadableDatabase().rawQuery(
                "SELECT t.id,t.mode,m.name,t.exercise_text,t.success_criterion,t.rationale,t.created_at " +
                        "FROM training_sessions t JOIN mind_muscles m ON m.id=t.muscle_id " +
                        "WHERE t.completed_at IS NULL AND t.superseded_at IS NULL ORDER BY t.created_at DESC LIMIT 1", null);
        try {
            if (!c.moveToFirst()) return out;
            out.trainingId = c.getLong(0);
            out.mode = safe(c.getString(1));
            out.muscle = safe(c.getString(2));
            out.exercise = safe(c.getString(3));
            out.criterion = safe(c.getString(4));
            out.rationale = safe(c.getString(5));
            out.createdAt = c.getLong(6);
            out.active = true;
            return out;
        } finally {
            c.close();
            helper.close();
        }
    }

    public static String compactWidgetLine(Context context) {
        Snapshot s = current(context);
        if (!s.active) return "";
        if ("RECOVERY".equals(s.mode)) return compact("오늘은 회복이 훈련이야 · " + s.exercise, 31);
        if ("STABILIZE".equals(s.mode)) return compact("지금은 속도를 늦추는 연습 · " + s.exercise, 31);
        if ("REVIEW".equals(s.mode)) return compact("오늘은 복기하는 날 · " + s.exercise, 31);
        if ("MAINTENANCE".equals(s.mode)) return compact("이미 키운 힘을 가볍게 써보자 · " + s.exercise, 31);
        String action = s.exercise.isEmpty() ? s.rationale : s.exercise;
        return compact("오늘의 PT · " + s.muscle + " · " + action, 31);
    }

    public static String mascotLine(Context context) {
        Snapshot s = current(context);
        if (!s.active) return "";
        if ("RECOVERY".equals(s.mode)) return "승재야, 오늘은 더 버티는 날보다 회복을 선택하는 날이야. " + compact(s.exercise, 50);
        if ("STABILIZE".equals(s.mode)) return "지금 마음이 세게 올라오면 바로 움직이지 말고, 오늘 정한 연습부터 써보자. " + compact(s.exercise, 48);
        if ("REVIEW".equals(s.mode)) return "오늘은 잘잘못보다 다음에 알아차릴 신호 하나만 찾으면 돼. " + compact(s.exercise, 48);
        if ("MAINTENANCE".equals(s.mode)) return "이건 이미 조금씩 네 힘이 된 부분이야. 오늘도 가볍게 한 번 써보자. " + compact(s.exercise, 48);
        String action = s.exercise.isEmpty() ? s.rationale : s.exercise;
        if (!action.isEmpty()) {
            return "오늘 PT는 ‘" + compact(s.muscle, 24) + "’. 지금은 " + compact(action, 54);
        }
        return "오늘 PT는 ‘" + compact(s.muscle, 30) + "’. 이 힘을 한 번 써보자.";
    }

    public static String roomSummary(Context context) {
        Snapshot s = current(context);
        if (!s.active) return "아직 진행 중인 마음 PT가 없어. 오늘 화면에서 하나를 정하면 어린 승재와 위젯도 같은 훈련을 보게 돼.";
        return modeLabel(s.mode) + "\n🌱 " + s.muscle + "\n🏋️ " + s.exercise;
    }

    public static String modeLabel(String mode) {
        if ("RECOVERY".equals(mode)) return "🌙 회복 모드";
        if ("STABILIZE".equals(mode)) return "🫧 안정 모드";
        if ("REVIEW".equals(mode)) return "🔎 복기 모드";
        if ("MAINTENANCE".equals(mode)) return "🌳 유지 모드";
        return "🏋️ 훈련 모드";
    }

    private static String compact(String s, int max) {
        if (s == null) return "";
        String clean = s.replace('\n', ' ').replace('\r', ' ').trim();
        if (clean.length() <= max) return clean;
        return clean.substring(0, Math.max(1, max - 1)).trim() + "…";
    }

    private static String safe(String s) { return s == null ? "" : s; }
}
