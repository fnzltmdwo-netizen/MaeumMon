package com.maeummon.app.clinical;

import android.content.Context;
import org.json.*;

public final class PolicySelectionEnforcementConsistencyGateRC11 {
    private PolicySelectionEnforcementConsistencyGateRC11(){}

    public enum EnforcementState {
        NONE,
        CONSISTENT,
        REBOUND_TO_HIERARCHY,
        POLICY_SUPPRESSED,
        CURRENT_ONLY
    }

    public static final class Result {
        public boolean evaluated=false;
        public boolean mismatchDetected=false;
        public boolean reboundApplied=false;
        public boolean policySuppressed=false;
        public EnforcementState state=EnforcementState.NONE;
        public String hierarchyWinner="";
        public String hierarchyPolicyKey="";
        public String retrievalPolicyKey="";
        public String effectivePolicyKey="";
        public String effectiveIntervention="";
        public String effectiveMode="";
        public String effectiveDose="";
        public String reason="";
        public String summary="";
    }

    public static Result enforce(
            Context c,
            ClinicalDecisionRC7 d,
            PolicyHierarchyArbitrationSpecificityRC11.Result hierarchy,
            PolicyMemoryRetrievalContextMatchGuardRC11.Result retrieval){

        Result r=new Result();
        if(d==null||hierarchy==null||retrieval==null){
            r.summary="NONE | MISSING_INPUT";
            return r;
        }

        r.evaluated=true;
        r.hierarchyWinner=hierarchy.winner.name();
        r.hierarchyPolicyKey=safe(hierarchy.selectedPolicyKey);
        r.retrievalPolicyKey=safe(retrieval.policyKey);

        // CURRENT_ONLY means no historical policy may influence downstream choices.
        if(hierarchy.winner
                == PolicyHierarchyArbitrationSpecificityRC11.Winner.CURRENT_ONLY){

            suppressPolicyFields(d);
            r.policySuppressed=true;
            r.state=EnforcementState.CURRENT_ONLY;
            r.reason="HIERARCHY_CURRENT_ONLY";
            persist(c,r);
            return finish(r);
        }

        // No hierarchy policy selected => suppress any accidental retrieval leak.
        if(r.hierarchyPolicyKey.isEmpty()){
            if(!r.retrievalPolicyKey.isEmpty() || retrieval.applicable){
                suppressPolicyFields(d);
                r.policySuppressed=true;
                r.mismatchDetected=true;
                r.state=EnforcementState.POLICY_SUPPRESSED;
                r.reason="NO_HIERARCHY_POLICY_BUT_RETRIEVAL_PRESENT";
            }else{
                r.state=EnforcementState.CONSISTENT;
                r.reason="NO_POLICY_ON_BOTH_PATHS";
            }
            persist(c,r);
            return finish(r);
        }

        // Hierarchy and retrieval must point to same policy.
        if(!r.hierarchyPolicyKey.equals(r.retrievalPolicyKey)){
            r.mismatchDetected=true;
            r.reboundApplied=true;
            r.state=EnforcementState.REBOUND_TO_HIERARCHY;
            r.reason="RETRIEVAL_MISMATCH_REBOUND_TO_HIERARCHY";

            d.policyRetrievalFound=true;
            d.policyRetrievalApplicable=true;
            d.policyRetrievalKey=r.hierarchyPolicyKey;
            d.policyRetrievalInterventionId=safe(hierarchy.selectedInterventionId);
            d.policyRetrievalMode=safe(hierarchy.selectedMode);
            d.policyRetrievalDose=safe(hierarchy.selectedDose);
            d.policyRetrievalReason="HIERARCHY_ENFORCED";
            d.policyRetrievalSummary="REBOUND_TO_HIERARCHY | "+r.hierarchyPolicyKey;

            r.effectivePolicyKey=r.hierarchyPolicyKey;
            r.effectiveIntervention=safe(hierarchy.selectedInterventionId);
            r.effectiveMode=safe(hierarchy.selectedMode);
            r.effectiveDose=safe(hierarchy.selectedDose);

            persist(c,r);
            return finish(r);
        }

        r.state=EnforcementState.CONSISTENT;
        r.reason="HIERARCHY_AND_RETRIEVAL_MATCH";
        r.effectivePolicyKey=r.hierarchyPolicyKey;
        r.effectiveIntervention=safe(hierarchy.selectedInterventionId);
        r.effectiveMode=safe(hierarchy.selectedMode);
        r.effectiveDose=safe(hierarchy.selectedDose);
        persist(c,r);
        return finish(r);
    }

    public static String instruction(Result r){
        if(r==null||!r.evaluated)return "";

        switch(r.state){
            case REBOUND_TO_HIERARCHY:
                return "POLICY_SELECTION_ENFORCEMENT=REBOUND. downstream retrieval이 hierarchy winner와 달라 hierarchy가 선택한 policy로 되돌린다.";
            case POLICY_SUPPRESSED:
                return "POLICY_SELECTION_ENFORCEMENT=SUPPRESSED. hierarchy가 policy를 허용하지 않았으므로 downstream policy influence를 제거한다.";
            case CURRENT_ONLY:
                return "POLICY_SELECTION_ENFORCEMENT=CURRENT_ONLY. 현재 evidence가 우선이므로 과거 policy의 intervention/mode/dose 영향은 모두 차단한다.";
            case CONSISTENT:
                return "POLICY_SELECTION_ENFORCEMENT=CONSISTENT. hierarchy winner와 downstream retrieval이 일치한다.";
            default:
                return "";
        }
    }

    public static boolean finalPolicyInfluenceAllowed(Result r){
        return r!=null
                && r.evaluated
                && !r.policySuppressed
                && r.state!=EnforcementState.CURRENT_ONLY
                && (r.state==EnforcementState.CONSISTENT
                    ||r.state==EnforcementState.REBOUND_TO_HIERARCHY)
                && !r.effectivePolicyKey.isEmpty();
    }

    private static void suppressPolicyFields(ClinicalDecisionRC7 d){
        d.policyRetrievalApplicable=false;
        d.policyRetrievalKey="";
        d.policyRetrievalInterventionId="";
        d.policyRetrievalMode="";
        d.policyRetrievalDose="";
        d.policyCanAffectIntervention=false;
        d.policyCanAffectMode=false;
        d.policyCanAffectDose=false;
    }

    private static void persist(Context c,Result r){
        if(c==null)return;
        try{
            JSONObject f=CentralTherapyProfile.loadFormulation(c);
            f.put("policy_selection_enforcement_state",r.state.name());
            f.put("policy_selection_mismatch",r.mismatchDetected);
            f.put("policy_selection_rebound",r.reboundApplied);
            f.put("policy_selection_suppressed",r.policySuppressed);
            f.put("policy_selection_hierarchy_key",r.hierarchyPolicyKey);
            f.put("policy_selection_retrieval_key",r.retrievalPolicyKey);
            f.put("policy_selection_effective_key",r.effectivePolicyKey);
            f.put("policy_selection_reason",r.reason);
            f.put("policy_selection_updated_at",System.currentTimeMillis());
            CentralTherapyProfile.replaceFormulation(c,f);
        }catch(Exception ignored){}
    }

    private static Result finish(Result r){
        r.summary=r.state.name()
                +" | mismatch="+r.mismatchDetected
                +" | rebound="+r.reboundApplied
                +" | suppressed="+r.policySuppressed
                +" | hierarchy="+r.hierarchyPolicyKey
                +" | retrieval="+r.retrievalPolicyKey
                +" | effective="+r.effectivePolicyKey
                +" | reason="+r.reason;
        return r;
    }

    private static String safe(String s){
        return s==null?"":s;
    }
}
