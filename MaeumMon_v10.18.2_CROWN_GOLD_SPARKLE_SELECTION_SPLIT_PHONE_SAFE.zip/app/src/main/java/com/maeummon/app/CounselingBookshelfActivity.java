package com.maeummon.app;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.text.format.DateFormat;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.util.List;

public class CounselingBookshelfActivity extends Activity {
    private MindTrainingStore store;
    private LinearLayout list;
    private TextView empty;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_counseling_bookshelf);
        UiInsets.apply(this, findViewById(R.id.counselingBookshelfRoot));
        store = new MindTrainingStore(this);
        list = findViewById(R.id.counselingBookshelfList);
        empty = findViewById(R.id.counselingBookshelfEmpty);
        findViewById(R.id.addCounselingFromBookshelfButton).setOnClickListener(v ->
                startActivity(new Intent(this, SharedCounselingLinkActivity.class)));
    }

    @Override
    protected void onResume() {
        super.onResume();
        render();
    }

    private void render() {
        list.removeAllViews();
        MindTrainingStore.CounselingSyncSession active = store.activeSyncSession();
        if (active != null && active.chunkCount > 0) {
            TextView syncing = new TextView(this);
            syncing.setBackgroundResource(R.drawable.bg_card);
            syncing.setTextColor(getResources().getColor(R.color.sage_dark));
            syncing.setTextSize(15);
            syncing.setPadding(dp(16), dp(14), dp(16), dp(14));
            LinearLayout.LayoutParams syncLp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            syncLp.topMargin = dp(10);
            syncing.setLayoutParams(syncLp);
            syncing.setText("🔄 상담 완전판 · 진행 중\n" + active.chunkCount + "개 말풍선 · " + active.charCount + "자\n\n눌러서 계속 이어붙이기");
            syncing.setOnClickListener(v -> startActivity(new Intent(this, CounselingImportActivity.class)));
            list.addView(syncing);
        }
        List<MindTrainingStore.CounselingEntry> entries = store.counselingHistory(30);
        empty.setVisibility(entries.isEmpty() ? View.VISIBLE : View.GONE);
        for (MindTrainingStore.CounselingEntry e : entries) {
            TextView card = new TextView(this);
            card.setBackgroundResource(R.drawable.bg_card);
            card.setTextColor(getResources().getColor(R.color.brown));
            card.setTextSize(15);
            card.setPadding(dp(16), dp(14), dp(16), dp(14));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            lp.topMargin = dp(10);
            card.setLayoutParams(lp);
            String date = DateFormat.format("M월 d일 HH:mm", e.createdAt).toString();
            String muscle = e.muscleName.isEmpty() ? "아직 구조화되지 않은 상담 기록" : e.muscleName;
            String direction = e.priorityDirection.isEmpty() ? shortText(e.formulation, 110) : shortText(e.priorityDirection, 110);
            int programCount = store.programsForCounseling(e.id).size();
            String programs = programCount > 0 ? "\n\n🏋️ 마음 PT 프로그램 " + programCount + "개" : "";
            card.setText("🧠 " + date + "\n" + e.title + "\n\n🌱 " + muscle + (direction.isEmpty() ? "" : "\n\n→ " + direction) + programs + "\n\n📖 눌러서 상담 원문 전체 보기");
            card.setOnClickListener(v -> {
                Intent i = new Intent(this, CounselingDetailActivity.class);
                i.putExtra(CounselingDetailActivity.EXTRA_ENTRY_ID, e.id);
                startActivity(i);
            });
            list.addView(card);
        }
    }

    private int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density + 0.5f); }
    private String shortText(String s, int max) {
        if (s == null) return "";
        String one = s.replace('\n', ' ').trim();
        return one.length() <= max ? one : one.substring(0, max) + "…";
    }
}
