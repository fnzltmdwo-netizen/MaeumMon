package com.maeummon.app;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class MindTrainingDbHelper extends SQLiteOpenHelper {
    public static final String DB_NAME = "maeummon_mind_pt.db";
    public static final int DB_VERSION = 7;

    public MindTrainingDbHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        createCoreTables(db);
        createCounselingTables(db);
        createCounselingSyncTables(db);
        createCounselingProgramTables(db);
        createSharedCounselingThreadTables(db);
    }

    private void createCoreTables(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE concerns (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "raw_text TEXT NOT NULL," +
                "mode TEXT NOT NULL," +
                "created_at INTEGER NOT NULL)");

        db.execSQL("CREATE TABLE mind_muscles (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "name TEXT NOT NULL UNIQUE," +
                "mechanism TEXT," +
                "status TEXT NOT NULL DEFAULT 'ACTIVE_FOCUS'," +
                "mastery_stage TEXT NOT NULL DEFAULT 'DISCOVERED'," +
                "created_at INTEGER NOT NULL," +
                "updated_at INTEGER NOT NULL)");

        db.execSQL("CREATE TABLE training_sessions (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "concern_id INTEGER NOT NULL," +
                "muscle_id INTEGER NOT NULL," +
                "mode TEXT NOT NULL," +
                "exercise_type TEXT NOT NULL," +
                "exercise_text TEXT NOT NULL," +
                "difficulty INTEGER NOT NULL DEFAULT 1," +
                "success_criterion TEXT NOT NULL," +
                "rationale TEXT," +
                "created_at INTEGER NOT NULL," +
                "completed_at INTEGER," +
                "program_step_id INTEGER," +
                "superseded_at INTEGER)");

        db.execSQL("CREATE TABLE training_outcomes (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "training_id INTEGER NOT NULL," +
                "attempt_status TEXT NOT NULL," +
                "effect TEXT NOT NULL," +
                "reflection TEXT," +
                "created_at INTEGER NOT NULL)");

        db.execSQL("CREATE INDEX idx_training_muscle ON training_sessions(muscle_id, created_at DESC)");
        db.execSQL("CREATE INDEX idx_outcome_training ON training_outcomes(training_id)");
    }

    private void createCounselingTables(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE IF NOT EXISTS counseling_entries (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "source TEXT NOT NULL DEFAULT 'GPT_FULL_COUNSELING'," +
                "title TEXT," +
                "raw_text TEXT NOT NULL," +
                "current_concern TEXT," +
                "formulation TEXT," +
                "priority_direction TEXT," +
                "muscle_name TEXT," +
                "training_text TEXT," +
                "success_criterion TEXT," +
                "caution TEXT," +
                "created_at INTEGER NOT NULL)");
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_counseling_created ON counseling_entries(created_at DESC)");
    }

    private void createCounselingSyncTables(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE IF NOT EXISTS counseling_sync_sessions (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "title TEXT NOT NULL," +
                "status TEXT NOT NULL DEFAULT 'ACTIVE'," +
                "created_at INTEGER NOT NULL," +
                "updated_at INTEGER NOT NULL," +
                "completed_at INTEGER)");
        db.execSQL("CREATE TABLE IF NOT EXISTS counseling_sync_chunks (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "session_id INTEGER NOT NULL," +
                "speaker TEXT NOT NULL," +
                "content TEXT NOT NULL," +
                "content_key TEXT NOT NULL," +
                "created_at INTEGER NOT NULL)");
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_sync_session_status ON counseling_sync_sessions(status, updated_at DESC)");
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_sync_chunks_session ON counseling_sync_chunks(session_id, id ASC)");
        db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS idx_sync_chunk_dedupe ON counseling_sync_chunks(session_id, speaker, content_key)");
    }

    private void createCounselingProgramTables(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE IF NOT EXISTS counseling_programs (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "counseling_id INTEGER NOT NULL," +
                "name TEXT NOT NULL," +
                "mechanism TEXT," +
                "muscle_name TEXT NOT NULL," +
                "priority INTEGER NOT NULL DEFAULT 50," +
                "reason TEXT," +
                "status TEXT NOT NULL DEFAULT 'PENDING'," +
                "created_at INTEGER NOT NULL)");
        db.execSQL("CREATE TABLE IF NOT EXISTS counseling_program_steps (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "program_id INTEGER NOT NULL," +
                "step_order INTEGER NOT NULL," +
                "mode TEXT NOT NULL DEFAULT 'TRAINING'," +
                "exercise_type TEXT NOT NULL," +
                "exercise_text TEXT NOT NULL," +
                "success_criterion TEXT NOT NULL," +
                "rationale TEXT," +
                "difficulty INTEGER NOT NULL DEFAULT 1," +
                "status TEXT NOT NULL DEFAULT 'PENDING'," +
                "created_at INTEGER NOT NULL)");
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_program_counseling ON counseling_programs(counseling_id, priority DESC, id ASC)");
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_program_steps ON counseling_program_steps(program_id, step_order ASC)");
    }

    private void createSharedCounselingThreadTables(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE IF NOT EXISTS shared_counseling_threads (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "share_url TEXT NOT NULL UNIQUE," +
                "title TEXT," +
                "is_complete INTEGER NOT NULL DEFAULT 0," +
                "turn_count INTEGER NOT NULL DEFAULT 0," +
                "char_count INTEGER NOT NULL DEFAULT 0," +
                "last_counseling_id INTEGER," +
                "analysis_state TEXT NOT NULL DEFAULT 'PENDING'," +
                "analysis_error TEXT," +
                "analyzed_turn_count INTEGER NOT NULL DEFAULT 0," +
                "analysis_updated_at INTEGER," +
                "first_turn_hash TEXT," +
                "last_turn_hash TEXT," +
                "first_turn_preview TEXT," +
                "last_turn_preview TEXT," +
                "last_verified_at INTEGER," +
                "last_sync_at INTEGER," +
                "created_at INTEGER NOT NULL," +
                "updated_at INTEGER NOT NULL)");
        db.execSQL("CREATE TABLE IF NOT EXISTS shared_counseling_turns (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "thread_id INTEGER NOT NULL," +
                "turn_order INTEGER NOT NULL," +
                "speaker TEXT NOT NULL," +
                "content TEXT NOT NULL," +
                "content_hash TEXT NOT NULL," +
                "created_at INTEGER NOT NULL)");
        db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS idx_shared_turn_hash ON shared_counseling_turns(thread_id, content_hash)");
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_shared_turn_order ON shared_counseling_turns(thread_id, turn_order ASC)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        if (oldVersion < 2) createCounselingTables(db);
        if (oldVersion < 3) createCounselingSyncTables(db);
        if (oldVersion < 4) {
            createCounselingProgramTables(db);
            try { db.execSQL("ALTER TABLE training_sessions ADD COLUMN program_step_id INTEGER"); } catch (Exception ignored) {}
            try { db.execSQL("ALTER TABLE training_sessions ADD COLUMN superseded_at INTEGER"); } catch (Exception ignored) {}
        }
        if (oldVersion < 5) createSharedCounselingThreadTables(db);
        if (oldVersion < 6) {
            try { db.execSQL("ALTER TABLE shared_counseling_threads ADD COLUMN analysis_state TEXT NOT NULL DEFAULT 'PENDING'"); } catch (Exception ignored) {}
            try { db.execSQL("ALTER TABLE shared_counseling_threads ADD COLUMN analysis_error TEXT"); } catch (Exception ignored) {}
            try { db.execSQL("ALTER TABLE shared_counseling_threads ADD COLUMN analyzed_turn_count INTEGER NOT NULL DEFAULT 0"); } catch (Exception ignored) {}
            try { db.execSQL("ALTER TABLE shared_counseling_threads ADD COLUMN analysis_updated_at INTEGER"); } catch (Exception ignored) {}
        }
        if (oldVersion < 7) {
            try { db.execSQL("ALTER TABLE shared_counseling_threads ADD COLUMN first_turn_hash TEXT"); } catch (Exception ignored) {}
            try { db.execSQL("ALTER TABLE shared_counseling_threads ADD COLUMN last_turn_hash TEXT"); } catch (Exception ignored) {}
            try { db.execSQL("ALTER TABLE shared_counseling_threads ADD COLUMN first_turn_preview TEXT"); } catch (Exception ignored) {}
            try { db.execSQL("ALTER TABLE shared_counseling_threads ADD COLUMN last_turn_preview TEXT"); } catch (Exception ignored) {}
            try { db.execSQL("ALTER TABLE shared_counseling_threads ADD COLUMN last_verified_at INTEGER"); } catch (Exception ignored) {}
            try { db.execSQL("ALTER TABLE shared_counseling_threads ADD COLUMN last_sync_at INTEGER"); } catch (Exception ignored) {}
        }
    }
}
