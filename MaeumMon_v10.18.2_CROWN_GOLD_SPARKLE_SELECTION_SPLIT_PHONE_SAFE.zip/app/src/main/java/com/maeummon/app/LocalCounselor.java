package com.maeummon.app;

import java.util.Locale;

public class LocalCounselor {

    public static String reply(String input) {
        String t = input.toLowerCase(Locale.KOREA);

        if (containsAny(t, "불안", "무서", "걱정", "긴장", "초조")) {
            return "승재야, 많이 불안했구나. 지금 당장 모든 걸 해결하려고 애쓰지 않아도 돼. "
                    + "우선 제일 불안한 지점을 하나만 골라보자. 그건 일이야, 사람이야, 아니면 내 마음이 버거운 거야?";
        }
        if (containsAny(t, "화나", "짜증", "열받", "억울", "빡")) {
            return "승재야, 그 상황이면 화가 나는 게 이상한 게 아니야. "
                    + "지금은 누가 맞고 틀렸는지보다, 네 마음이 어디서 다쳤는지 보는 게 먼저야. "
                    + "그 일에서 제일 억울했던 장면이 뭐였는지 말해줄래?";
        }
        if (containsAny(t, "슬퍼", "울고", "외로", "서운", "허무")) {
            return "아이고, 오늘 마음이 많이 처졌구나. 괜찮아, 여기서는 애써 단단할 필요 없어. "
                    + "승재야, 지금 제일 듣고 싶은 말이 있다면 어떤 말일까?";
        }
        if (containsAny(t, "지쳐", "피곤", "힘들", "번아웃", "귀찮")) {
            return "많이 버텼구나, 승재야. 지금 필요한 건 더 열심히 하는 게 아니라 숨 돌릴 틈일 수도 있어. "
                    + "오늘 꼭 해야 하는 일 하나하고, 미뤄도 되는 일 하나만 같이 골라보자.";
        }
        if (containsAny(t, "좋아", "행복", "기뻐", "신나", "잘됐")) {
            return "그 마음 너무 소중하다, 승재야 🌱 좋은 일은 그냥 흘려보내지 말고 꼭 붙잡아두자. "
                    + "오늘 기분 좋아진 이유를 한 문장으로 남겨볼래?";
        }

        return "응, 승재야. 내가 놀라지 않고 듣고 있어. 지금 당장 결론을 내릴 필요는 없어. "
                + "오늘 네 마음에서 제일 크게 자리 잡은 감정이 뭐였는지 한 단어로만 먼저 말해볼래?";
    }

    private static boolean containsAny(String text, String... words) {
        for (String word : words) {
            if (text.contains(word)) return true;
        }
        return false;
    }
}
