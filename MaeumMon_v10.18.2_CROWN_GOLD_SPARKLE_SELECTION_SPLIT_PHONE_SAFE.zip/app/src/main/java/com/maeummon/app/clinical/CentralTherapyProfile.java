package com.maeummon.app.clinical;

import android.content.*;
import org.json.*;
import java.util.*;

public final class CentralTherapyProfile {
    private CentralTherapyProfile(){}

    private static final String PREF="central_therapy_profile_v610";
    private static final String KEY_PROFILE="THERAPY_PROFILE";
    private static final String KEY_FORMULATION="CURRENT_FORMULATION";
    private static final String KEY_PROCESS="THERAPY_PROCESS_STATE";
    private static final String KEY_SESSION="SESSION_STATE";
    private static final int SCHEMA_VERSION=1;

    public static JSONObject loadProfile(Context c){
        return loadObject(c,KEY_PROFILE,defaultProfile());
    }

    public static JSONObject loadFormulation(Context c){
        return loadObject(c,KEY_FORMULATION,defaultFormulation());
    }

    public static JSONObject loadProcessState(Context c){
        return loadObject(c,KEY_PROCESS,defaultProcessState());
    }

    public static JSONObject loadSessionState(Context c){
        return loadObject(c,KEY_SESSION,new JSONObject());
    }

    public static synchronized void updateFromClinicalTurn(
            Context c,
            String userText,
            ClinicalDecisionRC7 decision,
            String finalReply
    ){
        if(c==null)return;
        try{
            JSONObject profile=loadProfile(c);
            JSONObject formulation=loadFormulation(c);
            JSONObject process=loadProcessState(c);

            ClinicalMemoryConsolidatorRC7.Snapshot memory=ClinicalMemoryConsolidatorRC7.load(c);
            profile.put("stable_profile",memory.stableProfile);
            profile.put("updated_at",System.currentTimeMillis());

            if(decision!=null){
                formulation.put("next_clinical_move",safe(decision.move));
                formulation.put("target_variable",safe(decision.target));
                formulation.put("selected_unit_id",safe(decision.unitId));
                if(decision.selectedInterventionId!=null && !decision.selectedInterventionId.isEmpty()){
                    formulation.put("last_intervention_id",decision.selectedInterventionId);
                    formulation.put("last_intervention_target",decision.interventionTarget);
                    formulation.put("last_intervention_time",System.currentTimeMillis());
                }
                formulation.put("confidence",safe(decision.confidence));
                formulation.put("known_variables",new JSONArray(decision.known));
                formulation.put("missing_information",new JSONArray(decision.missing));

                ClinicalSessionMemoryRC7.State sessionState =
                        ClinicalSessionMemoryRC7.load(c);
                AnswerEvidenceMapperRC8.Evidence answerEvidence =
                        AnswerEvidenceMapperRC8.map(
                                sessionState.answerTarget,
                                userText);

                JSONArray evidenceUpdated =
                        AnswerEvidenceMapperRC8.applyToHypotheses(
                                formulation.optJSONArray("alternative_hypotheses"),
                                answerEvidence);

                JSONArray competing = CompetingFormulationEngineRC8.update(
                        evidenceUpdated,
                        userText,
                        new JSONArray(decision.known),
                        formulation.optJSONArray("session_summary"));
                formulation.put("alternative_hypotheses",competing);
                formulation.put("last_answer_evidence",
                        AnswerEvidenceMapperRC8.summary(answerEvidence));
                formulation.put("leading_hypothesis",
                        CompetingFormulationEngineRC8.bestHypothesisId(competing));
                formulation.put("confidence",
                        CompetingFormulationEngineRC8.confidenceBand(competing));
                formulation.put("updated_at",System.currentTimeMillis());

                process.put("last_move",safe(decision.move));
                process.put("session_phase",safe(decision.sessionPhase));
                process.put("therapeutic_pacing",safe(decision.therapeuticPacing));
                process.put("release_integrity_summary",safe(decision.releaseIntegritySummary));
                process.put("release_integrity_pass",decision.releaseIntegrityPass);
                process.put("response_fact_guard_summary",safe(decision.responseFactGuardSummary));
                process.put("response_rewrite_required",decision.responseRewriteRequired);
                process.put("response_overreach_guard_summary",safe(decision.responseOverreachGuardSummary));
                process.put("response_overreach_rewrite_required",decision.responseOverreachRewriteRequired);
                process.put("response_relevance_guard_summary",safe(decision.responseRelevanceGuardSummary));
                process.put("response_relevance_rewrite_required",decision.responseRelevanceRewriteRequired);
                process.put("response_attunement_guard_summary",safe(decision.responseAttunementGuardSummary));
                process.put("response_attunement_rewrite_required",decision.responseAttunementRewriteRequired);
                process.put("response_precision_guard_summary",safe(decision.responsePrecisionGuardSummary));
                process.put("response_precision_rewrite_required",decision.responsePrecisionRewriteRequired);
                process.put("response_specificity_guard_summary",safe(decision.responseSpecificityGuardSummary));
                process.put("response_specificity_rewrite_required",decision.responseSpecificityRewriteRequired);
                process.put("response_evidence_anchor_used",safe(decision.responseEvidenceAnchorUsed));
                process.put("response_continuity_guard_summary",safe(decision.responseContinuityGuardSummary));
                process.put("response_continuity_rewrite_required",decision.responseContinuityRewriteRequired);
                process.put("response_timing_guard_summary",safe(decision.responseTimingGuardSummary));
                process.put("response_timing_rewrite_required",decision.responseTimingRewriteRequired);
                process.put("final_acceptance_summary",safe(decision.finalAcceptanceSummary));
                process.put("final_response_accepted",decision.finalResponseAccepted);
                process.put("final_fallback_used",decision.finalFallbackUsed);
                process.put("intervention_dose",safe(decision.interventionDose));
                process.put("intervention_max_steps",decision.interventionMaxSteps);
                process.put("intervention_homework_allowed",decision.interventionHomeworkAllowed);
                process.put("intervention_exercise_minutes",decision.interventionExerciseMinutes);
                process.put("intervention_dose_rationale",safe(decision.interventionDoseRationale));
                process.put("intervention_delivery_style",safe(decision.interventionDeliveryStyle));
                process.put("intervention_dose_blocked_reason",safe(decision.interventionDoseBlockedReason));
                process.put("intervention_fidelity_summary",safe(decision.interventionFidelitySummary));
                process.put("intervention_fidelity_rewrite_required",decision.interventionFidelityRewriteRequired);
                process.put("minimal_action_plan",safe(decision.minimalActionPlan));
                process.put("intervention_outcome",safe(decision.interventionOutcome));
                process.put("intervention_outcome_review_required",decision.interventionOutcomeReviewRequired);
                process.put("intervention_outcome_reopen_suggested",decision.interventionOutcomeReopenSuggested);
                process.put("intervention_outcome_learning",safe(decision.interventionOutcomeLearning));
                process.put("intervention_outcome_next_move_hint",safe(decision.interventionOutcomeNextMoveHint));
                process.put("intervention_adaptation_action",safe(decision.interventionAdaptationAction));
                process.put("intervention_switch_allowed",decision.interventionSwitchAllowed);
                process.put("intervention_switch_required",decision.interventionSwitchRequired);
                process.put("intervention_review_before_switch",decision.interventionReviewBeforeSwitch);
                process.put("intervention_adaptation_reopen",decision.interventionAdaptationReopen);
                process.put("intervention_switch_candidate_id",safe(decision.interventionSwitchCandidateId));
                process.put("intervention_adaptation_rationale",safe(decision.interventionAdaptationRationale));
                process.put("intervention_adaptation_summary",safe(decision.interventionAdaptationSummary));
                process.put("intervention_barrier",safe(decision.interventionBarrier));
                process.put("intervention_barrier_shrink",decision.interventionBarrierShrink);
                process.put("intervention_barrier_clarify",decision.interventionBarrierClarify);
                process.put("intervention_barrier_cue",decision.interventionBarrierCue);
                process.put("intervention_barrier_reduce_dose",decision.interventionBarrierReduceDose);
                process.put("intervention_barrier_change_context",decision.interventionBarrierChangeContext);
                process.put("intervention_barrier_adjustment",safe(decision.interventionBarrierAdjustment));
                process.put("intervention_barrier_rationale",safe(decision.interventionBarrierRationale));
                process.put("intervention_barrier_summary",safe(decision.interventionBarrierSummary));
                process.put("intervention_preference_mode",safe(decision.interventionPreferenceMode));
                process.put("intervention_preference_explicit",decision.interventionPreferenceExplicit);
                process.put("intervention_preference_inferred",decision.interventionPreferenceInferred);
                process.put("intervention_preference_modality_changed",decision.interventionPreferenceModalityChanged);
                process.put("intervention_preference_mechanism_preserved",decision.interventionPreferenceMechanismPreserved);
                process.put("intervention_preference_source",safe(decision.interventionPreferenceSource));
                process.put("intervention_preference_instruction",safe(decision.interventionPreferenceInstruction));
                process.put("intervention_preference_rationale",safe(decision.interventionPreferenceRationale));
                process.put("intervention_preference_summary",safe(decision.interventionPreferenceSummary));
                process.put("micro_experiment_ready",decision.microExperimentReady);
                process.put("micro_experiment_id",safe(decision.microExperimentId));
                process.put("micro_experiment_action",safe(decision.microExperimentAction));
                process.put("micro_experiment_review_criterion",safe(decision.microExperimentReviewCriterion));
                process.put("micro_experiment_stop_condition",safe(decision.microExperimentStopCondition));
                process.put("micro_experiment_mode",safe(decision.microExperimentMode));
                process.put("micro_experiment_dose",safe(decision.microExperimentDose));
                process.put("micro_experiment_max_minutes",decision.microExperimentMaxMinutes);
                process.put("micro_experiment_rationale",safe(decision.microExperimentRationale));
                process.put("micro_experiment_summary",safe(decision.microExperimentSummary));
                process.put("micro_experiment_active",decision.microExperimentActive);
                process.put("micro_experiment_attribution",safe(decision.microExperimentAttribution));
                process.put("micro_experiment_outcome_eligible",decision.microExperimentOutcomeEligible);
                process.put("micro_experiment_outcome_needs_clarification",decision.microExperimentOutcomeNeedsClarification);
                process.put("micro_experiment_mapped_outcome",safe(decision.microExperimentMappedOutcome));
                process.put("micro_experiment_matched_evidence",safe(decision.microExperimentMatchedEvidence));
                process.put("micro_experiment_review_mapping_summary",safe(decision.microExperimentReviewMappingSummary));
                process.put("review_attribution_clarification_needed",decision.reviewAttributionClarificationNeeded);
                process.put("review_attribution_ask_allowed",decision.reviewAttributionAskAllowed);
                process.put("review_attribution_question",safe(decision.reviewAttributionQuestion));
                process.put("review_attribution_target",safe(decision.reviewAttributionTarget));
                process.put("review_attribution_source",safe(decision.reviewAttributionSource));
                process.put("review_attribution_reason",safe(decision.reviewAttributionReason));
                process.put("review_attribution_summary",safe(decision.reviewAttributionSummary));
                process.put("outcome_commit_state",safe(decision.outcomeCommitState));
                process.put("outcome_commit_experiment_id",safe(decision.outcomeCommitExperimentId));
                process.put("outcome_commit_learning_allowed",decision.outcomeCommitLearningAllowed);
                process.put("outcome_commit_suppress_generic",decision.outcomeCommitSuppressGeneric);
                process.put("outcome_commit_value",safe(decision.outcomeCommitValue));
                process.put("outcome_commit_resolution",safe(decision.outcomeCommitResolution));
                process.put("outcome_commit_reason",safe(decision.outcomeCommitReason));
                process.put("outcome_commit_summary",safe(decision.outcomeCommitSummary));
                process.put("intervention_policy_memory_updated",decision.interventionPolicyMemoryUpdated);
                process.put("intervention_policy_mechanism",safe(decision.interventionPolicyMechanism));
                process.put("intervention_policy_intervention_id",safe(decision.interventionPolicyInterventionId));
                process.put("intervention_policy_preferred_mode",safe(decision.interventionPolicyPreferredMode));
                process.put("intervention_policy_preferred_dose",safe(decision.interventionPolicyPreferredDose));
                process.put("intervention_policy_confidence",safe(decision.interventionPolicyConfidence));
                process.put("intervention_policy_positive_commits",decision.interventionPolicyPositiveCommits);
                process.put("intervention_policy_negative_commits",decision.interventionPolicyNegativeCommits);
                process.put("intervention_policy_relevant_commits",decision.interventionPolicyRelevantCommits);
                process.put("intervention_policy_context_scope",safe(decision.interventionPolicyContextScope));
                process.put("intervention_policy_recommendation",safe(decision.interventionPolicyRecommendation));
                process.put("intervention_policy_summary",safe(decision.interventionPolicySummary));
                process.put("policy_retrieval_found",decision.policyRetrievalFound);
                process.put("policy_retrieval_applicable",decision.policyRetrievalApplicable);
                process.put("policy_mechanism_match",decision.policyMechanismMatch);
                process.put("policy_context_match",decision.policyContextMatch);
                process.put("policy_confidence_sufficient",decision.policyConfidenceSufficient);
                process.put("policy_blocked_by_current_evidence",decision.policyBlockedByCurrentEvidence);
                process.put("policy_retrieval_key",safe(decision.policyRetrievalKey));
                process.put("policy_retrieval_intervention_id",safe(decision.policyRetrievalInterventionId));
                process.put("policy_retrieval_mode",safe(decision.policyRetrievalMode));
                process.put("policy_retrieval_dose",safe(decision.policyRetrievalDose));
                process.put("policy_retrieval_confidence",safe(decision.policyRetrievalConfidence));
                process.put("policy_retrieval_reason",safe(decision.policyRetrievalReason));
                process.put("policy_retrieval_summary",safe(decision.policyRetrievalSummary));
                process.put("policy_conflict_detected",decision.policyConflictDetected);
                process.put("policy_conflict_resolution",safe(decision.policyConflictResolution));
                process.put("policy_can_affect_intervention",decision.policyCanAffectIntervention);
                process.put("policy_can_affect_mode",decision.policyCanAffectMode);
                process.put("policy_can_affect_dose",decision.policyCanAffectDose);
                process.put("policy_conflict_reason",safe(decision.policyConflictReason));
                process.put("policy_conflict_summary",safe(decision.policyConflictSummary));
                process.put("policy_decay_evaluated",decision.policyDecayEvaluated);
                process.put("policy_decay_changed",decision.policyDecayChanged);
                process.put("policy_decay_status",safe(decision.policyDecayStatus));
                process.put("policy_decay_old_confidence",safe(decision.policyDecayOldConfidence));
                process.put("policy_decay_new_confidence",safe(decision.policyDecayNewConfidence));
                process.put("policy_decay_recent_positive",decision.policyDecayRecentPositive);
                process.put("policy_decay_recent_negative",decision.policyDecayRecentNegative);
                process.put("policy_decay_age_days",decision.policyDecayAgeDays);
                process.put("policy_decay_stale",decision.policyDecayStale);
                process.put("policy_decay_contradicted",decision.policyDecayContradicted);
                process.put("policy_decay_reason",safe(decision.policyDecayReason));
                process.put("policy_decay_summary",safe(decision.policyDecaySummary));
                process.put("policy_revalidation_evaluated",decision.policyRevalidationEvaluated);
                process.put("policy_revalidation_changed",decision.policyRevalidationChanged);
                process.put("policy_revalidation_state",safe(decision.policyRevalidationState));
                process.put("policy_revalidation_old_status",safe(decision.policyRevalidationOldStatus));
                process.put("policy_revalidation_new_status",safe(decision.policyRevalidationNewStatus));
                process.put("policy_revalidation_old_confidence",safe(decision.policyRevalidationOldConfidence));
                process.put("policy_revalidation_new_confidence",safe(decision.policyRevalidationNewConfidence));
                process.put("policy_revalidation_recent_positive",decision.policyRevalidationRecentPositive);
                process.put("policy_revalidation_recent_negative",decision.policyRevalidationRecentNegative);
                process.put("policy_revalidation_reason",safe(decision.policyRevalidationReason));
                process.put("policy_revalidation_summary",safe(decision.policyRevalidationSummary));
                process.put("policy_transfer_evaluated",decision.policyTransferEvaluated);
                process.put("policy_transfer_state",safe(decision.policyTransferState));
                process.put("policy_transfer_source_context",safe(decision.policyTransferSourceContext));
                process.put("policy_transfer_target_context",safe(decision.policyTransferTargetContext));
                process.put("policy_transfer_mechanism_match",decision.policyTransferMechanismMatch);
                process.put("policy_transfer_context_similarity",decision.policyTransferContextSimilarity);
                process.put("policy_transfer_evidence_sufficient",decision.policyTransferEvidenceSufficient);
                process.put("policy_transfer_trial_only",decision.policyTransferTrialOnly);
                process.put("policy_transfer_general_eligible",decision.policyTransferGeneralEligible);
                process.put("policy_transfer_reason",safe(decision.policyTransferReason));
                process.put("policy_transfer_summary",safe(decision.policyTransferSummary));
                process.put("general_policy_promotion_evaluated",decision.generalPolicyPromotionEvaluated);
                process.put("general_policy_promotion_changed",decision.generalPolicyPromotionChanged);
                process.put("general_policy_promotion_state",safe(decision.generalPolicyPromotionState));
                process.put("general_policy_distinct_contexts",decision.generalPolicyDistinctContexts);
                process.put("general_policy_positive_commits",decision.generalPolicyPositiveCommits);
                process.put("general_policy_negative_commits",decision.generalPolicyNegativeCommits);
                process.put("general_policy_clean_across_contexts",decision.generalPolicyCleanAcrossContexts);
                process.put("general_policy_promotion_reason",safe(decision.generalPolicyPromotionReason));
                process.put("general_policy_promotion_summary",safe(decision.generalPolicyPromotionSummary));
                process.put("general_policy_boundary_evaluated",decision.generalPolicyBoundaryEvaluated);
                process.put("general_policy_boundary_changed",decision.generalPolicyBoundaryChanged);
                process.put("general_policy_boundary_state",safe(decision.generalPolicyBoundaryState));
                process.put("general_policy_boundary_context",safe(decision.generalPolicyBoundaryContext));
                process.put("general_policy_boundary_recent_positive",decision.generalPolicyBoundaryRecentPositive);
                process.put("general_policy_boundary_recent_negative",decision.generalPolicyBoundaryRecentNegative);
                process.put("general_policy_boundary_excluded",decision.generalPolicyBoundaryExcluded);
                process.put("general_policy_boundary_reason",safe(decision.generalPolicyBoundaryReason));
                process.put("general_policy_boundary_summary",safe(decision.generalPolicyBoundarySummary));
                process.put("policy_hierarchy_evaluated",decision.policyHierarchyEvaluated);
                process.put("policy_hierarchy_winner",safe(decision.policyHierarchyWinner));
                process.put("policy_hierarchy_context_found",decision.policyHierarchyContextFound);
                process.put("policy_hierarchy_general_found",decision.policyHierarchyGeneralFound);
                process.put("policy_hierarchy_both_found",decision.policyHierarchyBothFound);
                process.put("policy_hierarchy_context_key",safe(decision.policyHierarchyContextKey));
                process.put("policy_hierarchy_general_key",safe(decision.policyHierarchyGeneralKey));
                process.put("policy_hierarchy_selected_key",safe(decision.policyHierarchySelectedKey));
                process.put("policy_hierarchy_selected_intervention",safe(decision.policyHierarchySelectedIntervention));
                process.put("policy_hierarchy_selected_mode",safe(decision.policyHierarchySelectedMode));
                process.put("policy_hierarchy_selected_dose",safe(decision.policyHierarchySelectedDose));
                process.put("policy_hierarchy_reason",safe(decision.policyHierarchyReason));
                process.put("policy_hierarchy_summary",safe(decision.policyHierarchySummary));
                process.put("policy_selection_enforcement_evaluated",decision.policySelectionEnforcementEvaluated);
                process.put("policy_selection_mismatch_detected",decision.policySelectionMismatchDetected);
                process.put("policy_selection_rebound_applied",decision.policySelectionReboundApplied);
                process.put("policy_selection_suppressed",decision.policySelectionSuppressed);
                process.put("policy_selection_enforcement_state",safe(decision.policySelectionEnforcementState));
                process.put("policy_selection_hierarchy_key",safe(decision.policySelectionHierarchyKey));
                process.put("policy_selection_retrieval_key",safe(decision.policySelectionRetrievalKey));
                process.put("policy_selection_effective_key",safe(decision.policySelectionEffectiveKey));
                process.put("policy_selection_effective_intervention",safe(decision.policySelectionEffectiveIntervention));
                process.put("policy_selection_effective_mode",safe(decision.policySelectionEffectiveMode));
                process.put("policy_selection_effective_dose",safe(decision.policySelectionEffectiveDose));
                process.put("policy_selection_reason",safe(decision.policySelectionReason));
                process.put("policy_selection_summary",safe(decision.policySelectionSummary));
                process.put("adaptive_policy_release_gate_passed",decision.adaptivePolicyReleaseGatePassed);
                process.put("adaptive_policy_release_gate_repaired",decision.adaptivePolicyReleaseGateRepaired);
                process.put("adaptive_policy_release_outcome_leak_blocked",decision.adaptivePolicyReleaseOutcomeLeakBlocked);
                process.put("adaptive_policy_release_hierarchy_leak_blocked",decision.adaptivePolicyReleaseHierarchyLeakBlocked);
                process.put("adaptive_policy_release_retired_leak_blocked",decision.adaptivePolicyReleaseRetiredLeakBlocked);
                process.put("adaptive_policy_release_exception_leak_blocked",decision.adaptivePolicyReleaseExceptionLeakBlocked);
                process.put("adaptive_policy_release_bridge_override_blocked",decision.adaptivePolicyReleaseBridgeOverrideBlocked);
                process.put("adaptive_policy_release_violation_count",decision.adaptivePolicyReleaseViolationCount);
                process.put("adaptive_policy_release_violations",safe(decision.adaptivePolicyReleaseViolations));
                process.put("adaptive_policy_release_summary",safe(decision.adaptivePolicyReleaseSummary));
                process.put("outcome_commit_idempotency_evaluated",decision.outcomeCommitIdempotencyEvaluated);
                process.put("outcome_commit_learning_allowed",decision.outcomeCommitLearningAllowed);
                process.put("outcome_commit_duplicate",decision.outcomeCommitDuplicate);
                process.put("outcome_commit_conflicting_duplicate",decision.outcomeCommitConflictingDuplicate);
                process.put("outcome_commit_idempotency_state",safe(decision.outcomeCommitIdempotencyState));
                process.put("outcome_commit_idempotency_key",safe(decision.outcomeCommitIdempotencyKey));
                process.put("outcome_commit_idempotency_reason",safe(decision.outcomeCommitIdempotencyReason));
                process.put("outcome_commit_idempotency_summary",safe(decision.outcomeCommitIdempotencySummary));
                process.put("outcome_revision_evaluated",decision.outcomeRevisionEvaluated);
                process.put("outcome_revision_review_required",decision.outcomeRevisionReviewRequired);
                process.put("outcome_revision_applied",decision.outcomeRevisionApplied);
                process.put("outcome_revision_rejected",decision.outcomeRevisionRejected);
                process.put("outcome_revision_state",safe(decision.outcomeRevisionState));
                process.put("outcome_revision_experiment_id",safe(decision.outcomeRevisionExperimentId));
                process.put("outcome_revision_prior",safe(decision.outcomeRevisionPrior));
                process.put("outcome_revision_proposed",safe(decision.outcomeRevisionProposed));
                process.put("outcome_revision_final",safe(decision.outcomeRevisionFinal));
                process.put("outcome_revision_question",safe(decision.outcomeRevisionQuestion));
                process.put("outcome_revision_reason",safe(decision.outcomeRevisionReason));
                process.put("outcome_revision_summary",safe(decision.outcomeRevisionSummary));
                process.put("outcome_revision_propagation_evaluated",decision.outcomeRevisionPropagationEvaluated);
                process.put("outcome_revision_propagation_recomputed",decision.outcomeRevisionPropagationRecomputed);
                process.put("outcome_revision_propagation_state",safe(decision.outcomeRevisionPropagationState));
                process.put("outcome_revision_propagation_commit_rows",decision.outcomeRevisionPropagationCommitRows);
                process.put("outcome_revision_propagation_transfer_rows",decision.outcomeRevisionPropagationTransferRows);
                process.put("outcome_revision_propagation_policies",decision.outcomeRevisionPropagationPolicies);
                process.put("outcome_revision_propagation_generalization",decision.outcomeRevisionPropagationGeneralization);
                process.put("outcome_revision_propagation_reason",safe(decision.outcomeRevisionPropagationReason));
                process.put("outcome_revision_propagation_summary",safe(decision.outcomeRevisionPropagationSummary));
                process.put("structured_provenance_evaluated",decision.structuredProvenanceEvaluated);
                process.put("structured_provenance_enriched",decision.structuredProvenanceEnriched);
                process.put("structured_provenance_legacy_migrated",decision.structuredProvenanceLegacyMigrated);
                process.put("structured_provenance_rows_enriched",decision.structuredProvenanceRowsEnriched);
                process.put("structured_provenance_legacy_rows_migrated",decision.structuredProvenanceLegacyRowsMigrated);
                process.put("structured_provenance_canonical_key",safe(decision.structuredProvenanceCanonicalKey));
                process.put("structured_provenance_reason",safe(decision.structuredProvenanceReason));
                process.put("structured_provenance_summary",safe(decision.structuredProvenanceSummary));
                process.put("provenance_integrity_evaluated",decision.provenanceIntegrityEvaluated);
                process.put("provenance_integrity_repaired",decision.provenanceIntegrityRepaired);
                process.put("provenance_integrity_quarantined",decision.provenanceIntegrityQuarantined);
                process.put("provenance_integrity_rows_checked",decision.provenanceIntegrityRowsChecked);
                process.put("provenance_integrity_rows_repaired",decision.provenanceIntegrityRowsRepaired);
                process.put("provenance_integrity_rows_quarantined",decision.provenanceIntegrityRowsQuarantined);
                process.put("provenance_integrity_legacy_unresolved",decision.provenanceIntegrityLegacyUnresolved);
                process.put("provenance_integrity_reason",safe(decision.provenanceIntegrityReason));
                process.put("provenance_integrity_summary",safe(decision.provenanceIntegritySummary));
                process.put("provenance_lineage_evaluated",decision.provenanceLineageEvaluated);
                process.put("provenance_lineage_updated",decision.provenanceLineageUpdated);
                process.put("provenance_lineage_nodes_added",decision.provenanceLineageNodesAdded);
                process.put("provenance_lineage_edges_added",decision.provenanceLineageEdgesAdded);
                process.put("provenance_lineage_experiment_id",safe(decision.provenanceLineageExperimentId));
                process.put("provenance_lineage_policy_key",safe(decision.provenanceLineagePolicyKey));
                process.put("provenance_lineage_root_key",safe(decision.provenanceLineageRootKey));
                process.put("provenance_lineage_reason",safe(decision.provenanceLineageReason));
                process.put("provenance_lineage_summary",safe(decision.provenanceLineageSummary));
                process.put("decision_rationale_evaluated",decision.decisionRationaleEvaluated);
                process.put("decision_rationale_usable",decision.decisionRationaleUsable);
                process.put("decision_rationale_policy_referenced",decision.decisionRationalePolicyReferenced);
                process.put("decision_rationale_current_evidence_primary",decision.decisionRationaleCurrentEvidencePrimary);
                process.put("decision_rationale_text",safe(decision.decisionRationaleText));
                process.put("decision_rationale_compact",safe(decision.decisionRationaleCompact));
                process.put("decision_rationale_source_tier",safe(decision.decisionRationaleSourceTier));
                process.put("decision_rationale_reason",safe(decision.decisionRationaleReason));
                process.put("decision_rationale_summary",safe(decision.decisionRationaleSummary));
                process.put("decision_rationale_fidelity_evaluated",decision.decisionRationaleFidelityEvaluated);
                process.put("decision_rationale_fidelity_repaired",decision.decisionRationaleFidelityRepaired);
                process.put("decision_rationale_fidelity_blocked",decision.decisionRationaleFidelityBlocked);
                process.put("decision_rationale_move_mismatch",decision.decisionRationaleMoveMismatch);
                process.put("decision_rationale_policy_overclaim",decision.decisionRationalePolicyOverclaim);
                process.put("decision_rationale_unsupported_certainty",decision.decisionRationaleUnsupportedCertainty);
                process.put("decision_rationale_internal_jargon_leak",decision.decisionRationaleInternalJargonLeak);
                process.put("decision_rationale_evidence_mismatch",decision.decisionRationaleEvidenceMismatch);
                process.put("decision_rationale_fidelity_state",safe(decision.decisionRationaleFidelityState));
                process.put("decision_rationale_final",safe(decision.decisionRationaleFinal));
                process.put("decision_rationale_fidelity_reason",safe(decision.decisionRationaleFidelityReason));
                process.put("decision_rationale_fidelity_summary",safe(decision.decisionRationaleFidelitySummary));
                process.put("explainability_delivery_evaluated",decision.explainabilityDeliveryEvaluated);
                process.put("explainability_should_surface",decision.explainabilityShouldSurface);
                process.put("explainability_user_asked_why",decision.explainabilityUserAskedWhy);
                process.put("explainability_decision_needs_justification",decision.explainabilityDecisionNeedsJustification);
                process.put("explainability_recent_rationale_shown",decision.explainabilityRecentRationaleShown);
                process.put("explainability_suppressed_for_repetition",decision.explainabilitySuppressedForRepetition);
                process.put("explainability_delivery_mode",safe(decision.explainabilityDeliveryMode));
                process.put("explainability_delivery_text",safe(decision.explainabilityDeliveryText));
                process.put("explainability_placement",safe(decision.explainabilityPlacement));
                process.put("explainability_max_sentences",decision.explainabilityMaxSentences);
                process.put("explainability_delivery_reason",safe(decision.explainabilityDeliveryReason));
                process.put("explainability_delivery_summary",safe(decision.explainabilityDeliverySummary));
                process.put("decision_transition_snapshot_loaded",decision.decisionTransitionSnapshotLoaded);
                process.put("decision_transition_move_changed",decision.decisionTransitionMoveChanged);
                process.put("decision_transition_intervention_changed",decision.decisionTransitionInterventionChanged);
                process.put("decision_transition_target_changed",decision.decisionTransitionTargetChanged);
                process.put("decision_transition_summary",safe(decision.decisionTransitionSummary));
                process.put("decision_transition_cause_evaluated",decision.decisionTransitionCauseEvaluated);
                process.put("decision_transition_cause_detected",decision.decisionTransitionCauseDetected);
                process.put("decision_transition_primary_cause",safe(decision.decisionTransitionPrimaryCause));
                process.put("decision_transition_secondary_cause",safe(decision.decisionTransitionSecondaryCause));
                process.put("decision_transition_from_state",safe(decision.decisionTransitionFromState));
                process.put("decision_transition_to_state",safe(decision.decisionTransitionToState));
                process.put("decision_transition_human_reason",safe(decision.decisionTransitionHumanReason));
                process.put("decision_transition_cause_reason",safe(decision.decisionTransitionCauseReason));
                process.put("decision_transition_cause_summary",safe(decision.decisionTransitionCauseSummary));
                process.put("decision_transition_cause_fidelity_evaluated",decision.decisionTransitionCauseFidelityEvaluated);
                process.put("decision_transition_cause_fidelity_repaired",decision.decisionTransitionCauseFidelityRepaired);
                process.put("decision_transition_cause_fidelity_blocked",decision.decisionTransitionCauseFidelityBlocked);
                process.put("decision_transition_multi_cause",decision.decisionTransitionMultiCause);
                process.put("decision_transition_cause_fidelity_state",safe(decision.decisionTransitionCauseFidelityState));
                process.put("decision_transition_cause_confidence",safe(decision.decisionTransitionCauseConfidence));
                process.put("decision_transition_fidelity_primary_cause",safe(decision.decisionTransitionFidelityPrimaryCause));
                process.put("decision_transition_fidelity_secondary_cause",safe(decision.decisionTransitionFidelitySecondaryCause));
                process.put("decision_transition_fidelity_human_reason",safe(decision.decisionTransitionFidelityHumanReason));
                process.put("decision_transition_cause_fidelity_reason",safe(decision.decisionTransitionCauseFidelityReason));
                process.put("decision_transition_cause_fidelity_summary",safe(decision.decisionTransitionCauseFidelitySummary));
                process.put("transition_explanation_correction_evaluated",decision.transitionExplanationCorrectionEvaluated);
                process.put("transition_explanation_correction_detected",decision.transitionExplanationCorrectionDetected);
                process.put("transition_explanation_clarification_required",decision.transitionExplanationClarificationRequired);
                process.put("transition_explanation_correction_applied",decision.transitionExplanationCorrectionApplied);
                process.put("transition_explanation_correction_rejected",decision.transitionExplanationCorrectionRejected);
                process.put("transition_explanation_correction_state",safe(decision.transitionExplanationCorrectionState));
                process.put("transition_explanation_prior_cause",safe(decision.transitionExplanationPriorCause));
                process.put("transition_explanation_corrected_cause",safe(decision.transitionExplanationCorrectedCause));
                process.put("transition_explanation_corrected_reason",safe(decision.transitionExplanationCorrectedReason));
                process.put("transition_explanation_clarification_question",safe(decision.transitionExplanationClarificationQuestion));
                process.put("transition_explanation_correction_reason",safe(decision.transitionExplanationCorrectionReason));
                process.put("transition_explanation_correction_summary",safe(decision.transitionExplanationCorrectionSummary));
                process.put("transition_correction_memory_evaluated",decision.transitionCorrectionMemoryEvaluated);
                process.put("transition_correction_memory_reusable",decision.transitionCorrectionMemoryReusable);
                process.put("transition_correction_memory_exact",decision.transitionCorrectionMemoryExact);
                process.put("transition_correction_memory_blocked",decision.transitionCorrectionMemoryBlocked);
                process.put("transition_correction_memory_match",safe(decision.transitionCorrectionMemoryMatch));
                process.put("transition_correction_memory_cause",safe(decision.transitionCorrectionMemoryCause));
                process.put("transition_correction_memory_reason_text",safe(decision.transitionCorrectionMemoryReasonText));
                process.put("transition_correction_memory_source_context",safe(decision.transitionCorrectionMemorySourceContext));
                process.put("transition_correction_memory_current_context",safe(decision.transitionCorrectionMemoryCurrentContext));
                process.put("transition_correction_memory_reason",safe(decision.transitionCorrectionMemoryReason));
                process.put("transition_correction_memory_summary",safe(decision.transitionCorrectionMemorySummary));
                process.put("transition_correction_revalidation_evaluated",decision.transitionCorrectionRevalidationEvaluated);
                process.put("transition_correction_revalidation_pending",decision.transitionCorrectionRevalidationPending);
                process.put("transition_correction_reactivated",decision.transitionCorrectionReactivated);
                process.put("transition_correction_revalidation_state",safe(decision.transitionCorrectionRevalidationState));
                process.put("transition_correction_revalidation_key",safe(decision.transitionCorrectionRevalidationKey));
                process.put("transition_correction_revalidation_context",safe(decision.transitionCorrectionRevalidationContext));
                process.put("transition_correction_revalidation_cause",safe(decision.transitionCorrectionRevalidationCause));
                process.put("transition_correction_revalidation_confirmations",decision.transitionCorrectionRevalidationConfirmations);
                process.put("transition_correction_revalidation_contradictions",decision.transitionCorrectionRevalidationContradictions);
                process.put("transition_correction_revalidation_reason",safe(decision.transitionCorrectionRevalidationReason));
                process.put("transition_correction_revalidation_summary",safe(decision.transitionCorrectionRevalidationSummary));
                process.put("transition_correction_conflict_evaluated",decision.transitionCorrectionConflictEvaluated);
                process.put("transition_correction_conflicted",decision.transitionCorrectionConflicted);
                process.put("transition_correction_replacement_pending",decision.transitionCorrectionReplacementPending);
                process.put("transition_correction_replaced",decision.transitionCorrectionReplaced);
                process.put("transition_correction_retired",decision.transitionCorrectionRetired);
                process.put("transition_correction_conflict_state",safe(decision.transitionCorrectionConflictState));
                process.put("transition_correction_conflict_key",safe(decision.transitionCorrectionConflictKey));
                process.put("transition_correction_conflict_incumbent",safe(decision.transitionCorrectionConflictIncumbent));
                process.put("transition_correction_conflict_challenger",safe(decision.transitionCorrectionConflictChallenger));
                process.put("transition_correction_conflict_incumbent_count",decision.transitionCorrectionConflictIncumbentCount);
                process.put("transition_correction_conflict_challenger_count",decision.transitionCorrectionConflictChallengerCount);
                process.put("transition_correction_conflict_distinct_causes",decision.transitionCorrectionConflictDistinctCauses);
                process.put("transition_correction_conflict_active_cause",safe(decision.transitionCorrectionConflictActiveCause));
                process.put("transition_correction_conflict_active_reason",safe(decision.transitionCorrectionConflictActiveReason));
                process.put("transition_correction_conflict_reason",safe(decision.transitionCorrectionConflictReason));
                process.put("transition_correction_conflict_summary",safe(decision.transitionCorrectionConflictSummary));
                process.put("transition_correction_fresh_evidence_evaluated",decision.transitionCorrectionFreshEvidenceEvaluated);
                process.put("transition_correction_memory_allowed",decision.transitionCorrectionMemoryAllowed);
                process.put("transition_correction_current_turn_override",decision.transitionCorrectionCurrentTurnOverride);
                process.put("transition_correction_fresh_evidence_blocked",decision.transitionCorrectionFreshEvidenceBlocked);
                process.put("transition_correction_fresh_evidence_state",safe(decision.transitionCorrectionFreshEvidenceState));
                process.put("transition_correction_fresh_evidence_memory_cause",safe(decision.transitionCorrectionFreshEvidenceMemoryCause));
                process.put("transition_correction_fresh_evidence_current_cause",safe(decision.transitionCorrectionFreshEvidenceCurrentCause));
                process.put("transition_correction_fresh_evidence_effective_cause",safe(decision.transitionCorrectionFreshEvidenceEffectiveCause));
                process.put("transition_correction_fresh_evidence_effective_reason",safe(decision.transitionCorrectionFreshEvidenceEffectiveReason));
                process.put("transition_correction_fresh_evidence_reason",safe(decision.transitionCorrectionFreshEvidenceReason));
                process.put("transition_correction_fresh_evidence_summary",safe(decision.transitionCorrectionFreshEvidenceSummary));
                process.put("transition_correction_override_isolation_evaluated",decision.transitionCorrectionOverrideIsolationEvaluated);
                process.put("transition_correction_override_ephemeral",decision.transitionCorrectionOverrideEphemeral);
                process.put("transition_correction_commit_allowed",decision.transitionCorrectionCommitAllowed);
                process.put("transition_correction_commit_blocked",decision.transitionCorrectionCommitBlocked);
                process.put("transition_correction_duplicate_commit_suppressed",decision.transitionCorrectionDuplicateCommitSuppressed);
                process.put("transition_correction_override_isolation_state",safe(decision.transitionCorrectionOverrideIsolationState));
                process.put("transition_correction_commit_identity",safe(decision.transitionCorrectionCommitIdentity));
                process.put("transition_correction_override_isolation_reason",safe(decision.transitionCorrectionOverrideIsolationReason));
                process.put("transition_correction_override_isolation_summary",safe(decision.transitionCorrectionOverrideIsolationSummary));
                process.put("transition_correction_commit_provenance_evaluated",decision.transitionCorrectionCommitProvenanceEvaluated);
                process.put("transition_correction_commit_provenance_ready",decision.transitionCorrectionCommitProvenanceReady);
                process.put("transition_correction_commit_provenance_committed",decision.transitionCorrectionCommitProvenanceCommitted);
                process.put("transition_correction_commit_provenance_blocked",decision.transitionCorrectionCommitProvenanceBlocked);
                process.put("transition_correction_commit_provenance_duplicate",decision.transitionCorrectionCommitProvenanceDuplicate);
                process.put("transition_correction_commit_provenance_state",safe(decision.transitionCorrectionCommitProvenanceState));
                process.put("transition_correction_commit_evidence_id",safe(decision.transitionCorrectionCommitEvidenceId));
                process.put("transition_correction_canonical_commit_key",safe(decision.transitionCorrectionCanonicalCommitKey));
                process.put("transition_correction_commit_transition_key",safe(decision.transitionCorrectionCommitTransitionKey));
                process.put("transition_correction_commit_context",safe(decision.transitionCorrectionCommitContext));
                process.put("transition_correction_commit_provenance_reason",safe(decision.transitionCorrectionCommitProvenanceReason));
                process.put("transition_correction_commit_provenance_summary",safe(decision.transitionCorrectionCommitProvenanceSummary));
                process.put("correction_provenance_integrity_evaluated",decision.correctionProvenanceIntegrityEvaluated);
                process.put("correction_provenance_integrity_repaired",decision.correctionProvenanceIntegrityRepaired);
                process.put("correction_provenance_integrity_quarantined",decision.correctionProvenanceIntegrityQuarantined);
                process.put("correction_provenance_integrity_rows_checked",decision.correctionProvenanceIntegrityRowsChecked);
                process.put("correction_provenance_integrity_rows_valid",decision.correctionProvenanceIntegrityRowsValid);
                process.put("correction_provenance_integrity_rows_repaired",decision.correctionProvenanceIntegrityRowsRepaired);
                process.put("correction_provenance_integrity_rows_quarantined",decision.correctionProvenanceIntegrityRowsQuarantined);
                process.put("correction_provenance_integrity_legacy_unresolved",decision.correctionProvenanceIntegrityLegacyUnresolved);
                process.put("correction_provenance_integrity_reason",safe(decision.correctionProvenanceIntegrityReason));
                process.put("correction_provenance_integrity_summary",safe(decision.correctionProvenanceIntegritySummary));
                process.put("correction_provenance_reinstatement_evaluated",decision.correctionProvenanceReinstatementEvaluated);
                process.put("correction_provenance_reinstatement_review_required",decision.correctionProvenanceReinstatementReviewRequired);
                process.put("correction_provenance_reinstatement_ready",decision.correctionProvenanceReinstatementReady);
                process.put("correction_provenance_reinstated",decision.correctionProvenanceReinstated);
                process.put("correction_provenance_reinstatement_blocked",decision.correctionProvenanceReinstatementBlocked);
                process.put("correction_provenance_reinstatement_matching_rows",decision.correctionProvenanceReinstatementMatchingRows);
                process.put("correction_provenance_reinstated_rows",decision.correctionProvenanceReinstatedRows);
                process.put("correction_provenance_reinstatement_state",safe(decision.correctionProvenanceReinstatementState));
                process.put("correction_provenance_reinstatement_transition_key",safe(decision.correctionProvenanceReinstatementTransitionKey));
                process.put("correction_provenance_reinstatement_context",safe(decision.correctionProvenanceReinstatementContext));
                process.put("correction_provenance_reinstatement_cause",safe(decision.correctionProvenanceReinstatementCause));
                process.put("correction_provenance_reinstatement_reason",safe(decision.correctionProvenanceReinstatementReason));
                process.put("correction_provenance_reinstatement_summary",safe(decision.correctionProvenanceReinstatementSummary));
                process.put("correction_provenance_reinstatement_idempotency_evaluated",decision.correctionProvenanceReinstatementIdempotencyEvaluated);
                process.put("correction_provenance_reinstatement_idempotency_allow",decision.correctionProvenanceReinstatementIdempotencyAllow);
                process.put("correction_provenance_reinstatement_duplicate_suppressed",decision.correctionProvenanceReinstatementDuplicateSuppressed);
                process.put("correction_provenance_reinstatement_already_active",decision.correctionProvenanceReinstatementAlreadyActive);
                process.put("correction_provenance_reinstatement_idempotency_blocked",decision.correctionProvenanceReinstatementIdempotencyBlocked);
                process.put("correction_provenance_reinstatement_idempotency_state",safe(decision.correctionProvenanceReinstatementIdempotencyState));
                process.put("correction_provenance_reinstatement_identity",safe(decision.correctionProvenanceReinstatementIdentity));
                process.put("correction_provenance_reinstatement_idempotency_reason",safe(decision.correctionProvenanceReinstatementIdempotencyReason));
                process.put("correction_provenance_reinstatement_idempotency_summary",safe(decision.correctionProvenanceReinstatementIdempotencySummary));
                process.put("post_reinstatement_verification_evaluated",decision.postReinstatementVerificationEvaluated);
                process.put("post_reinstatement_verification_required",decision.postReinstatementVerificationRequired);
                process.put("post_reinstatement_verified_keep",decision.postReinstatementVerifiedKeep);
                process.put("post_reinstatement_requarantined",decision.postReinstatementRequarantined);
                process.put("post_reinstatement_verification_state",safe(decision.postReinstatementVerificationState));
                process.put("post_reinstatement_transition_key",safe(decision.postReinstatementTransitionKey));
                process.put("post_reinstatement_reinstated_cause",safe(decision.postReinstatementReinstatedCause));
                process.put("post_reinstatement_current_cause",safe(decision.postReinstatementCurrentCause));
                process.put("post_reinstatement_verification_reason",safe(decision.postReinstatementVerificationReason));
                process.put("post_reinstatement_verification_summary",safe(decision.postReinstatementVerificationSummary));
                process.put("requarantine_cooldown_evaluated",decision.requarantineCooldownEvaluated);
                process.put("requarantine_cooldown_active",decision.requarantineCooldownActive);
                process.put("requarantine_cooldown_released",decision.requarantineCooldownReleased);
                process.put("requarantine_loop_blocked",decision.requarantineLoopBlocked);
                process.put("requarantine_cooldown_state",safe(decision.requarantineCooldownState));
                process.put("requarantine_cooldown_transition_key",safe(decision.requarantineCooldownTransitionKey));
                process.put("requarantine_cooldown_quarantined_cause",safe(decision.requarantineCooldownQuarantinedCause));
                process.put("requarantine_cooldown_current_cause",safe(decision.requarantineCooldownCurrentCause));
                process.put("requarantine_cooldown_clean_confirmations",decision.requarantineCooldownCleanConfirmations);
                process.put("requarantine_cooldown_contradictions",decision.requarantineCooldownContradictions);
                process.put("requarantine_cooldown_reason",safe(decision.requarantineCooldownReason));
                process.put("requarantine_cooldown_summary",safe(decision.requarantineCooldownSummary));
                process.put("cooldown_evidence_ledger_evaluated",decision.cooldownEvidenceLedgerEvaluated);
                process.put("cooldown_evidence_ledger_committed",decision.cooldownEvidenceLedgerCommitted);
                process.put("cooldown_evidence_ledger_duplicate",decision.cooldownEvidenceLedgerDuplicate);
                process.put("cooldown_evidence_ledger_eligible",decision.cooldownEvidenceLedgerEligible);
                process.put("cooldown_evidence_ledger_contradiction",decision.cooldownEvidenceLedgerContradiction);
                process.put("cooldown_evidence_ledger_state",safe(decision.cooldownEvidenceLedgerState));
                process.put("cooldown_evidence_ledger_evidence_id",safe(decision.cooldownEvidenceLedgerEvidenceId));
                process.put("cooldown_evidence_ledger_identity",safe(decision.cooldownEvidenceLedgerIdentity));
                process.put("cooldown_evidence_ledger_transition_key",safe(decision.cooldownEvidenceLedgerTransitionKey));
                process.put("cooldown_evidence_ledger_reason",safe(decision.cooldownEvidenceLedgerReason));
                process.put("cooldown_evidence_ledger_summary",safe(decision.cooldownEvidenceLedgerSummary));
                process.put("cooldown_evidence_integrity_evaluated",decision.cooldownEvidenceIntegrityEvaluated);
                process.put("cooldown_evidence_integrity_repaired",decision.cooldownEvidenceIntegrityRepaired);
                process.put("cooldown_evidence_integrity_quarantined",decision.cooldownEvidenceIntegrityQuarantined);
                process.put("cooldown_evidence_synthetic_blocked",decision.cooldownEvidenceSyntheticBlocked);
                process.put("cooldown_evidence_integrity_rows_checked",decision.cooldownEvidenceIntegrityRowsChecked);
                process.put("cooldown_evidence_integrity_rows_valid",decision.cooldownEvidenceIntegrityRowsValid);
                process.put("cooldown_evidence_integrity_rows_repaired",decision.cooldownEvidenceIntegrityRowsRepaired);
                process.put("cooldown_evidence_integrity_rows_quarantined",decision.cooldownEvidenceIntegrityRowsQuarantined);
                process.put("cooldown_evidence_synthetic_blocked_rows",decision.cooldownEvidenceSyntheticBlockedRows);
                process.put("cooldown_evidence_integrity_reason",safe(decision.cooldownEvidenceIntegrityReason));
                process.put("cooldown_evidence_integrity_summary",safe(decision.cooldownEvidenceIntegritySummary));
                process.put("cooldown_evidence_independence_evaluated",decision.cooldownEvidenceIndependenceEvaluated);
                process.put("cooldown_evidence_independent",decision.cooldownEvidenceIndependent);
                process.put("cooldown_evidence_duplicate",decision.cooldownEvidenceDuplicate);
                process.put("cooldown_evidence_near_duplicate",decision.cooldownEvidenceNearDuplicate);
                process.put("cooldown_evidence_independence_blocked",decision.cooldownEvidenceIndependenceBlocked);
                process.put("cooldown_evidence_independence_state",safe(decision.cooldownEvidenceIndependenceState));
                process.put("cooldown_evidence_independence_matched_evidence_id",safe(decision.cooldownEvidenceIndependenceMatchedEvidenceId));
                process.put("cooldown_evidence_similarity",safe(decision.cooldownEvidenceSimilarity));
                process.put("cooldown_evidence_independence_reason",safe(decision.cooldownEvidenceIndependenceReason));
                process.put("cooldown_evidence_independence_summary",safe(decision.cooldownEvidenceIndependenceSummary));
                process.put("cooldown_evidence_temporal_independence_evaluated",decision.cooldownEvidenceTemporalIndependenceEvaluated);
                process.put("cooldown_evidence_temporally_independent",decision.cooldownEvidenceTemporallyIndependent);
                process.put("cooldown_evidence_burst_blocked",decision.cooldownEvidenceBurstBlocked);
                process.put("cooldown_evidence_temporal_waiting",decision.cooldownEvidenceTemporalWaiting);
                process.put("cooldown_evidence_temporal_independence_state",safe(decision.cooldownEvidenceTemporalIndependenceState));
                process.put("cooldown_evidence_temporal_transition_key",safe(decision.cooldownEvidenceTemporalTransitionKey));
                process.put("cooldown_evidence_temporal_current_cause",safe(decision.cooldownEvidenceTemporalCurrentCause));
                process.put("cooldown_evidence_temporal_last_eligible_at",decision.cooldownEvidenceTemporalLastEligibleAt);
                process.put("cooldown_evidence_temporal_separation_ms",decision.cooldownEvidenceTemporalSeparationMs);
                process.put("cooldown_evidence_temporal_reason",safe(decision.cooldownEvidenceTemporalReason));
                process.put("cooldown_evidence_temporal_summary",safe(decision.cooldownEvidenceTemporalSummary));
                process.put("cooldown_evidence_temporal_diversity_evaluated",decision.cooldownEvidenceTemporalDiversityEvaluated);
                process.put("cooldown_evidence_temporal_diversity_threshold_met",decision.cooldownEvidenceTemporalDiversityThresholdMet);
                process.put("cooldown_evidence_temporal_diversity_clean_evidence_count",decision.cooldownEvidenceTemporalDiversityCleanEvidenceCount);
                process.put("cooldown_evidence_temporal_diversity_distinct_days",decision.cooldownEvidenceTemporalDiversityDistinctDays);
                process.put("cooldown_evidence_temporal_diversity_state",safe(decision.cooldownEvidenceTemporalDiversityState));
                process.put("cooldown_evidence_temporal_diversity_transition_key",safe(decision.cooldownEvidenceTemporalDiversityTransitionKey));
                process.put("cooldown_evidence_temporal_diversity_cause",safe(decision.cooldownEvidenceTemporalDiversityCause));
                process.put("cooldown_evidence_temporal_diversity_reason",safe(decision.cooldownEvidenceTemporalDiversityReason));
                process.put("cooldown_evidence_temporal_diversity_summary",safe(decision.cooldownEvidenceTemporalDiversitySummary));
                process.put("transition_correction_lifecycle_ordering_integrity_evaluated",decision.transitionCorrectionLifecycleOrderingIntegrityEvaluated);
                process.put("transition_correction_lifecycle_retired",decision.transitionCorrectionLifecycleRetired);
                process.put("transition_correction_lifecycle_ordering_integrity_state",safe(decision.transitionCorrectionLifecycleOrderingIntegrityState));
                process.put("transition_correction_lifecycle_ordering_integrity_reason",safe(decision.transitionCorrectionLifecycleOrderingIntegrityReason));
                process.put("transition_correction_lifecycle_ordering_integrity_summary",safe(decision.transitionCorrectionLifecycleOrderingIntegritySummary));
                process.put("phase_rationale",safe(decision.phaseRationale));
                process.put("last_target",safe(decision.target));
                process.put("safety_override",decision.safetyOverride);
                process.put("rupture_active",decision.allianceRupture);
                process.put("updated_at",System.currentTimeMillis());
            }

            // Current session summary remains distinct from stable profile.
            formulation.put("session_summary",memory.sessionSummary);

            saveObject(c,KEY_PROFILE,profile);
            saveObject(c,KEY_FORMULATION,formulation);
            saveObject(c,KEY_PROCESS,process);
        }catch(Exception ignored){}
    }

    public static synchronized void updateResponseNeed(Context c,String need){
        if(c==null)return;
        try{
            JSONObject f=loadFormulation(c);
            f.put("response_need",safe(need));
            f.put("updated_at",System.currentTimeMillis());
            saveObject(c,KEY_FORMULATION,f);
        }catch(Exception ignored){}
    }

    public static synchronized void mergeCheckIn(
            Context c,String emotion,String note,int intensity
    ){
        if(c==null)return;
        try{
            JSONObject p=loadProfile(c);
            JSONArray history=p.optJSONArray("checkin_history");
            if(history==null)history=new JSONArray();
            JSONObject item=new JSONObject();
            item.put("emotion",safe(emotion));
            item.put("note",safe(note));
            if(intensity>=0)item.put("intensity",Math.max(0,Math.min(10,intensity)));
            item.put("time",System.currentTimeMillis());
            history.put(item);
            history=tail(history,30);
            p.put("checkin_history",history);
            p.put("updated_at",System.currentTimeMillis());
            saveObject(c,KEY_PROFILE,p);
        }catch(Exception ignored){}
    }


    public static synchronized void mergeFocusCoaching(
            Context c,String goal,String situation,String result
    ){
        if(c==null)return;
        try{
            JSONObject f=loadFormulation(c);
            f.put("focus_goal",safe(goal));
            f.put("last_focus_situation",safe(situation));
            f.put("last_focus_coaching",compact(safe(result),900));
            f.put("updated_at",System.currentTimeMillis());
            saveObject(c,KEY_FORMULATION,f);

            JSONObject p=loadProfile(c);
            JSONArray a=p.optJSONArray("coaching_history");
            if(a==null)a=new JSONArray();
            JSONObject item=new JSONObject();
            item.put("goal",safe(goal));
            item.put("situation",compact(safe(situation),500));
            item.put("result",compact(safe(result),900));
            item.put("time",System.currentTimeMillis());
            a.put(item);
            p.put("coaching_history",tail(a,20));
            p.put("updated_at",System.currentTimeMillis());
            saveObject(c,KEY_PROFILE,p);
        }catch(Exception ignored){}
    }

    public static synchronized void mergeCheckIn(
            Context c,String emotion,String note
    ){
        mergeCheckIn(c,emotion,note,-1);
    }

    public static synchronized void mergeDiaryInsight(
            Context c,String insight,String source
    ){
        if(c==null||safe(insight).trim().isEmpty())return;
        try{
            JSONObject p=loadProfile(c);
            JSONArray a=p.optJSONArray("diary_insights");
            if(a==null)a=new JSONArray();
            JSONObject item=new JSONObject();
            item.put("text",safe(insight));
            item.put("source",safe(source));
            item.put("time",System.currentTimeMillis());
            a.put(item);
            p.put("diary_insights",tail(a,30));
            p.put("updated_at",System.currentTimeMillis());
            saveObject(c,KEY_PROFILE,p);
        }catch(Exception ignored){}
    }

    public static String buildSharedContext(Context c,String surface){
        JSONObject p=loadProfile(c);
        JSONObject f=loadFormulation(c);
        JSONObject ps=loadProcessState(c);
        StringBuilder b=new StringBuilder();
        b.append("[CENTRAL_THERAPY_CONTEXT]\\n");
        b.append("surface=").append(safe(surface)).append("\\n");
        b.append("THERAPY_PROFILE=").append(p.toString()).append("\\n");
        b.append("CURRENT_FORMULATION=").append(f.toString()).append("\\n");
        b.append("THERAPY_PROCESS_STATE=").append(ps.toString()).append("\\n");
        b.append("THERAPEUTIC_PROGRESS=")
                .append(TherapeuticGoalProgressRC8.progressSummary(c)).append("\\n");
        b.append("규칙: 위 정보는 공유 상담맥락이다. 임시 가설을 확정사실처럼 말하지 말고, ");
        b.append("현재 surface의 목적에 맞는 정보만 선택해서 사용한다.\\n");
        return b.toString();
    }


    public static String reportHint(Context c,String period){
        JSONObject p=loadProfile(c);
        JSONObject f=loadFormulation(c);
        JSONArray stable=p.optJSONArray("stable_profile");
        JSONArray checkins=p.optJSONArray("checkin_history");
        String need=f.optString("response_need","");
        String move=f.optString("next_clinical_move","");

        List<String> parts=new ArrayList<>();
        if(stable!=null && stable.length()>0){
            JSONObject latest=stable.optJSONObject(0);
            if(latest!=null){
                String tx=latest.optString("text","");
                if(!tx.isEmpty())parts.add("최근 상담에서 반복해서 보인 흐름: "+compact(tx,120));
            }
        }
        if(checkins!=null && checkins.length()>0){
            JSONObject last=checkins.optJSONObject(checkins.length()-1);
            if(last!=null){
                String emotion=last.optString("emotion","");
                if(!emotion.isEmpty())parts.add("최근 체크인의 중심 감정: "+emotion);
            }
        }
        if("UNDERSTANDING".equalsIgnoreCase(need)){
            parts.add("지금은 해결책보다 마음을 정확히 이해하는 쪽이 더 중요해 보여.");
        }else if("ACTION".equalsIgnoreCase(need)){
            parts.add("지금은 이해한 내용을 실제 행동 한 단계로 옮기는 게 도움이 될 수 있어.");
        }
        if(parts.isEmpty() && !move.isEmpty()){
            parts.add("최근 상담 흐름을 이어서 이번 "+safe(period)+"의 변화를 살펴보자.");
        }
        if(parts.isEmpty())return "";
        StringBuilder b=new StringBuilder();
        for(String s:parts){
            if(b.length()>0)b.append("\n");
            b.append("• ").append(s);
        }
        return b.toString();
    }


    public static String formulationSummary(Context c){
        JSONObject f=loadFormulation(c);
        JSONArray hs=f.optJSONArray("alternative_hypotheses");
        StringBuilder b=new StringBuilder();
        b.append("leading=").append(f.optString("leading_hypothesis",""));
        b.append(", confidence=").append(f.optString("confidence","LOW"));
        if(hs!=null && hs.length()>0){
            b.append(", hypotheses=");
            for(int i=0;i<hs.length();i++){
                JSONObject h=hs.optJSONObject(i);
                if(h==null)continue;
                if(i>0)b.append(" | ");
                b.append(h.optString("id","")).append(":")
                        .append((int)Math.round(h.optDouble("confidence",0)*100)).append("%");
            }
        }
        return b.toString();
    }

    public static String compactSummary(Context c){
        JSONObject p=loadProfile(c);
        JSONObject f=loadFormulation(c);
        JSONArray stable=p.optJSONArray("stable_profile");
        JSONArray session=f.optJSONArray("session_summary");
        return "stable="+(stable==null?0:stable.length())
                +", session="+(session==null?0:session.length())
                +", move="+f.optString("next_clinical_move","")
                +", need="+f.optString("response_need","");
    }



    public static void replaceProfile(Context c,JSONObject value){
        saveObject(c,KEY_PROFILE,value==null?defaultProfile():value);
    }

    public static void replaceFormulation(Context c,JSONObject value){
        saveObject(c,KEY_FORMULATION,value==null?defaultFormulation():value);
    }

    public static void replaceProcessState(Context c,JSONObject value){
        saveObject(c,KEY_PROCESS,value==null?defaultProcessState():value);
    }

    public static void replaceSessionState(Context c,JSONObject value){
        saveObject(c,KEY_SESSION,value==null?new JSONObject():value);
    }

    public static void clearCurrentFormulation(Context c){
        if(c==null)return;
        saveObject(c,KEY_FORMULATION,defaultFormulation());
        saveObject(c,KEY_PROCESS,defaultProcessState());
    }

    private static JSONObject defaultProfile(){
        JSONObject o=new JSONObject();
        try{
            o.put("schema_version",SCHEMA_VERSION);
            o.put("stable_profile",new JSONArray());
            o.put("checkin_history",new JSONArray());
            o.put("diary_insights",new JSONArray());
            o.put("coaching_history",new JSONArray());
            o.put("active_therapy_goal","");
            o.put("goal_source","");
            o.put("goal_started_at",0);
            o.put("goal_progress_score",50);
            o.put("goal_progress_history",new JSONArray());
            o.put("goal_archive",new JSONArray());
            o.put("stable_memory_sync_summary","");
            o.put("stable_memory_sync_updated_at",0);
            o.put("current_context_scope","UNKNOWN");
            o.put("context_generalization_summary","");
            o.put("context_generalization_updated_at",0);
            o.put("last_goal_status","UNCHANGED");
            o.put("last_goal_transition_reason","");
            o.put("updated_at",0);
        }catch(Exception ignored){}
        return o;
    }

    private static JSONObject defaultFormulation(){
        JSONObject o=new JSONObject();
        try{
            o.put("schema_version",SCHEMA_VERSION);
            o.put("presenting_problem","");
            o.put("trigger","");
            o.put("observed_fact",new JSONArray());
            o.put("interpretation",new JSONArray());
            o.put("automatic_thought",new JSONArray());
            o.put("emotion",new JSONArray());
            o.put("body_response",new JSONArray());
            o.put("urge",new JSONArray());
            o.put("behavior",new JSONArray());
            o.put("core_fear",new JSONArray());
            o.put("core_belief",new JSONArray());
            o.put("conditional_rule",new JSONArray());
            o.put("coping_strategy",new JSONArray());
            o.put("maintaining_cycle",new JSONArray());
            o.put("relationship_pattern",new JSONArray());
            o.put("past_parallel",new JSONArray());
            o.put("protective_factor",new JSONArray());
            o.put("strength",new JSONArray());
            o.put("alternative_hypotheses",new JSONArray());
            o.put("leading_hypothesis","");
            o.put("last_answer_evidence","");
            o.put("formulation_reopened",false);
            o.put("formulation_reopen_reason","");
            o.put("reopen_recovery_target","");
            o.put("reopen_recovery_move","");
            o.put("reopen_recovery_ask_budget",0);
            o.put("reopen_recovery_rationale","");
            o.put("retired_hypotheses",new JSONArray());
            o.put("evidence_calibrated_at",0);
            o.put("evidence_calibration_rationale","");
            o.put("evidence_conflict_matrix",new JSONArray());
            o.put("evidence_conflict_count",0);
            o.put("unresolved_evidence_conflicts",0);
            o.put("evidence_conflict_updated_at",0);
            o.put("evidence_ledger",new JSONArray());
            o.put("evidence_provenance_summary","");
            o.put("evidence_provenance_updated_at",0);
            o.put("evidence_gate_summary","");
            o.put("evidence_gate_updated_at",0);
            o.put("central_insight","");
            o.put("central_mechanism","");
            o.put("central_evidence_anchor","");
            o.put("central_uncertainty","");
            o.put("central_insight_usable",false);
            o.put("central_insight_updated_at",0);
            o.put("central_bridge_ready",false);
            o.put("central_bridge_intervention_id","");
            o.put("central_bridge_target","");
            o.put("central_bridge_rationale","");
            o.put("central_bridge_blocked_reason","");
            o.put("central_bridge_updated_at",0);
            o.put("missing_information",new JSONArray());
            o.put("known_variables",new JSONArray());
            o.put("session_summary",new JSONArray());
            o.put("response_need","");
            o.put("next_clinical_move","");
            o.put("target_variable","");
            o.put("selected_unit_id","");
            o.put("last_intervention_id","");
            o.put("last_intervention_target","");
            o.put("last_intervention_time",0);
            o.put("last_intervention_outcome","");
            o.put("last_intervention_review_note","");
            o.put("intervention_history",new JSONArray());
            o.put("adaptive_plan_action","");
            o.put("adaptive_plan_rationale","");
            o.put("confidence","LOW");
            o.put("updated_at",0);
        }catch(Exception ignored){}
        return o;
    }

    private static JSONObject defaultProcessState(){
        JSONObject o=new JSONObject();
        try{
            o.put("schema_version",SCHEMA_VERSION);
            o.put("goal_agreement","");
            o.put("task_agreement","");
            o.put("empathic_accuracy","");
            o.put("rupture_active",false);
            o.put("rupture_type","");
            o.put("treatment_credibility","");
            o.put("last_repair_result","");
            o.put("last_intervention_outcome","");
            o.put("last_intervention_next_move","");
            o.put("adaptive_plan_action","");
            o.put("adaptive_plan_rationale","");
            o.put("session_phase","ORIENT");
            o.put("therapeutic_pacing","SLOW");
            o.put("phase_rationale","");
            o.put("release_integrity_summary","");
            o.put("release_integrity_pass",true);
            o.put("response_fact_guard_summary","");
            o.put("response_rewrite_required",false);
            o.put("response_overreach_guard_summary","");
            o.put("response_overreach_rewrite_required",false);
            o.put("response_relevance_guard_summary","");
            o.put("response_relevance_rewrite_required",false);
            o.put("response_attunement_guard_summary","");
            o.put("response_attunement_rewrite_required",false);
            o.put("response_precision_guard_summary","");
            o.put("response_precision_rewrite_required",false);
            o.put("response_specificity_guard_summary","");
            o.put("response_specificity_rewrite_required",false);
            o.put("response_evidence_anchor_used","");
            o.put("response_continuity_guard_summary","");
            o.put("response_continuity_rewrite_required",false);
            o.put("response_timing_guard_summary","");
            o.put("response_timing_rewrite_required",false);
            o.put("final_acceptance_summary","");
            o.put("final_response_accepted",true);
            o.put("final_fallback_used",false);
            o.put("intervention_dose","NONE");
            o.put("intervention_max_steps",0);
            o.put("intervention_homework_allowed",false);
            o.put("intervention_exercise_minutes",0);
            o.put("intervention_dose_rationale","");
            o.put("intervention_delivery_style","");
            o.put("intervention_dose_blocked_reason","");
            o.put("intervention_fidelity_summary","");
            o.put("intervention_fidelity_rewrite_required",false);
            o.put("minimal_action_plan","");
            o.put("intervention_outcome","UNKNOWN");
            o.put("intervention_outcome_review_required",false);
            o.put("intervention_outcome_reopen_suggested",false);
            o.put("intervention_outcome_learning","");
            o.put("intervention_outcome_next_move_hint","");
            o.put("intervention_adaptation_action","NONE");
            o.put("intervention_switch_allowed",false);
            o.put("intervention_switch_required",false);
            o.put("intervention_review_before_switch",false);
            o.put("intervention_adaptation_reopen",false);
            o.put("intervention_switch_candidate_id","");
            o.put("intervention_adaptation_rationale","");
            o.put("intervention_adaptation_summary","");
            o.put("intervention_barrier","NONE");
            o.put("intervention_barrier_shrink",false);
            o.put("intervention_barrier_clarify",false);
            o.put("intervention_barrier_cue",false);
            o.put("intervention_barrier_reduce_dose",false);
            o.put("intervention_barrier_change_context",false);
            o.put("intervention_barrier_adjustment","");
            o.put("intervention_barrier_rationale","");
            o.put("intervention_barrier_summary","");
            o.put("intervention_preference_mode","DEFAULT");
            o.put("intervention_preference_explicit",false);
            o.put("intervention_preference_inferred",false);
            o.put("intervention_preference_modality_changed",false);
            o.put("intervention_preference_mechanism_preserved",true);
            o.put("intervention_preference_source","");
            o.put("intervention_preference_instruction","");
            o.put("intervention_preference_rationale","");
            o.put("intervention_preference_summary","");
            o.put("micro_experiment_ready",false);
            o.put("micro_experiment_id","");
            o.put("micro_experiment_action","");
            o.put("micro_experiment_review_criterion","");
            o.put("micro_experiment_stop_condition","");
            o.put("micro_experiment_mode","");
            o.put("micro_experiment_dose","");
            o.put("micro_experiment_max_minutes",0);
            o.put("micro_experiment_rationale","");
            o.put("micro_experiment_summary","");
            o.put("micro_experiment_active",false);
            o.put("micro_experiment_attribution","NONE");
            o.put("micro_experiment_outcome_eligible",false);
            o.put("micro_experiment_outcome_needs_clarification",false);
            o.put("micro_experiment_mapped_outcome","UNKNOWN");
            o.put("micro_experiment_matched_evidence","");
            o.put("micro_experiment_review_mapping_summary","");
            o.put("review_attribution_clarification_needed",false);
            o.put("review_attribution_ask_allowed",false);
            o.put("review_attribution_question","");
            o.put("review_attribution_target","");
            o.put("review_attribution_source","");
            o.put("review_attribution_reason","");
            o.put("review_attribution_summary","");
            o.put("outcome_commit_state","NONE");
            o.put("outcome_commit_experiment_id","");
            o.put("outcome_commit_learning_allowed",false);
            o.put("outcome_commit_suppress_generic",false);
            o.put("outcome_commit_value","UNKNOWN");
            o.put("outcome_commit_resolution","");
            o.put("outcome_commit_reason","");
            o.put("outcome_commit_summary","");
            o.put("intervention_policy_memory_updated",false);
            o.put("intervention_policy_mechanism","");
            o.put("intervention_policy_intervention_id","");
            o.put("intervention_policy_preferred_mode","");
            o.put("intervention_policy_preferred_dose","");
            o.put("intervention_policy_confidence","NONE");
            o.put("intervention_policy_positive_commits",0);
            o.put("intervention_policy_negative_commits",0);
            o.put("intervention_policy_relevant_commits",0);
            o.put("intervention_policy_context_scope","");
            o.put("intervention_policy_recommendation","");
            o.put("intervention_policy_summary","");
            o.put("policy_retrieval_found",false);
            o.put("policy_retrieval_applicable",false);
            o.put("policy_mechanism_match",false);
            o.put("policy_context_match",false);
            o.put("policy_confidence_sufficient",false);
            o.put("policy_blocked_by_current_evidence",false);
            o.put("policy_retrieval_key","");
            o.put("policy_retrieval_intervention_id","");
            o.put("policy_retrieval_mode","");
            o.put("policy_retrieval_dose","");
            o.put("policy_retrieval_confidence","NONE");
            o.put("policy_retrieval_reason","");
            o.put("policy_retrieval_summary","");
            o.put("policy_conflict_detected",false);
            o.put("policy_conflict_resolution","NONE");
            o.put("policy_can_affect_intervention",false);
            o.put("policy_can_affect_mode",false);
            o.put("policy_can_affect_dose",false);
            o.put("policy_conflict_reason","");
            o.put("policy_conflict_summary","");
            o.put("policy_decay_evaluated",false);
            o.put("policy_decay_changed",false);
            o.put("policy_decay_status","ACTIVE");
            o.put("policy_decay_old_confidence","NONE");
            o.put("policy_decay_new_confidence","NONE");
            o.put("policy_decay_recent_positive",0);
            o.put("policy_decay_recent_negative",0);
            o.put("policy_decay_age_days",0);
            o.put("policy_decay_stale",false);
            o.put("policy_decay_contradicted",false);
            o.put("policy_decay_reason","");
            o.put("policy_decay_summary","");
            o.put("policy_revalidation_evaluated",false);
            o.put("policy_revalidation_changed",false);
            o.put("policy_revalidation_state","NONE");
            o.put("policy_revalidation_old_status","");
            o.put("policy_revalidation_new_status","");
            o.put("policy_revalidation_old_confidence","");
            o.put("policy_revalidation_new_confidence","");
            o.put("policy_revalidation_recent_positive",0);
            o.put("policy_revalidation_recent_negative",0);
            o.put("policy_revalidation_reason","");
            o.put("policy_revalidation_summary","");
            o.put("policy_transfer_evaluated",false);
            o.put("policy_transfer_state","BLOCK");
            o.put("policy_transfer_source_context","");
            o.put("policy_transfer_target_context","");
            o.put("policy_transfer_mechanism_match",false);
            o.put("policy_transfer_context_similarity",false);
            o.put("policy_transfer_evidence_sufficient",false);
            o.put("policy_transfer_trial_only",false);
            o.put("policy_transfer_general_eligible",false);
            o.put("policy_transfer_reason","");
            o.put("policy_transfer_summary","");
            o.put("general_policy_promotion_evaluated",false);
            o.put("general_policy_promotion_changed",false);
            o.put("general_policy_promotion_state","NONE");
            o.put("general_policy_distinct_contexts",0);
            o.put("general_policy_positive_commits",0);
            o.put("general_policy_negative_commits",0);
            o.put("general_policy_clean_across_contexts",false);
            o.put("general_policy_promotion_reason","");
            o.put("general_policy_promotion_summary","");
            o.put("general_policy_boundary_evaluated",false);
            o.put("general_policy_boundary_changed",false);
            o.put("general_policy_boundary_state","NONE");
            o.put("general_policy_boundary_context","");
            o.put("general_policy_boundary_recent_positive",0);
            o.put("general_policy_boundary_recent_negative",0);
            o.put("general_policy_boundary_excluded",false);
            o.put("general_policy_boundary_reason","");
            o.put("general_policy_boundary_summary","");
            o.put("policy_hierarchy_evaluated",false);
            o.put("policy_hierarchy_winner","NONE");
            o.put("policy_hierarchy_context_found",false);
            o.put("policy_hierarchy_general_found",false);
            o.put("policy_hierarchy_both_found",false);
            o.put("policy_hierarchy_context_key","");
            o.put("policy_hierarchy_general_key","");
            o.put("policy_hierarchy_selected_key","");
            o.put("policy_hierarchy_selected_intervention","");
            o.put("policy_hierarchy_selected_mode","");
            o.put("policy_hierarchy_selected_dose","");
            o.put("policy_hierarchy_reason","");
            o.put("policy_hierarchy_summary","");
            o.put("policy_selection_enforcement_evaluated",false);
            o.put("policy_selection_mismatch_detected",false);
            o.put("policy_selection_rebound_applied",false);
            o.put("policy_selection_suppressed",false);
            o.put("policy_selection_enforcement_state","NONE");
            o.put("policy_selection_hierarchy_key","");
            o.put("policy_selection_retrieval_key","");
            o.put("policy_selection_effective_key","");
            o.put("policy_selection_effective_intervention","");
            o.put("policy_selection_effective_mode","");
            o.put("policy_selection_effective_dose","");
            o.put("policy_selection_reason","");
            o.put("policy_selection_summary","");
            o.put("adaptive_policy_release_gate_passed",false);
            o.put("adaptive_policy_release_gate_repaired",false);
            o.put("adaptive_policy_release_outcome_leak_blocked",false);
            o.put("adaptive_policy_release_hierarchy_leak_blocked",false);
            o.put("adaptive_policy_release_retired_leak_blocked",false);
            o.put("adaptive_policy_release_exception_leak_blocked",false);
            o.put("adaptive_policy_release_bridge_override_blocked",false);
            o.put("adaptive_policy_release_violation_count",0);
            o.put("adaptive_policy_release_violations","");
            o.put("adaptive_policy_release_summary","");
            o.put("outcome_commit_idempotency_evaluated",false);
            o.put("outcome_commit_learning_allowed",true);
            o.put("outcome_commit_duplicate",false);
            o.put("outcome_commit_conflicting_duplicate",false);
            o.put("outcome_commit_idempotency_state","NOT_APPLICABLE");
            o.put("outcome_commit_idempotency_key","");
            o.put("outcome_commit_idempotency_reason","");
            o.put("outcome_commit_idempotency_summary","");
            o.put("outcome_revision_evaluated",false);
            o.put("outcome_revision_review_required",false);
            o.put("outcome_revision_applied",false);
            o.put("outcome_revision_rejected",false);
            o.put("outcome_revision_state","NONE");
            o.put("outcome_revision_experiment_id","");
            o.put("outcome_revision_prior","");
            o.put("outcome_revision_proposed","");
            o.put("outcome_revision_final","");
            o.put("outcome_revision_question","");
            o.put("outcome_revision_reason","");
            o.put("outcome_revision_summary","");
            o.put("outcome_revision_propagation_evaluated",false);
            o.put("outcome_revision_propagation_recomputed",false);
            o.put("outcome_revision_propagation_state","NONE");
            o.put("outcome_revision_propagation_commit_rows",0);
            o.put("outcome_revision_propagation_transfer_rows",0);
            o.put("outcome_revision_propagation_policies",0);
            o.put("outcome_revision_propagation_generalization",false);
            o.put("outcome_revision_propagation_reason","");
            o.put("outcome_revision_propagation_summary","");
            o.put("structured_provenance_evaluated",false);
            o.put("structured_provenance_enriched",false);
            o.put("structured_provenance_legacy_migrated",false);
            o.put("structured_provenance_rows_enriched",0);
            o.put("structured_provenance_legacy_rows_migrated",0);
            o.put("structured_provenance_canonical_key","");
            o.put("structured_provenance_reason","");
            o.put("structured_provenance_summary","");
            o.put("provenance_integrity_evaluated",false);
            o.put("provenance_integrity_repaired",false);
            o.put("provenance_integrity_quarantined",false);
            o.put("provenance_integrity_rows_checked",0);
            o.put("provenance_integrity_rows_repaired",0);
            o.put("provenance_integrity_rows_quarantined",0);
            o.put("provenance_integrity_legacy_unresolved",0);
            o.put("provenance_integrity_reason","");
            o.put("provenance_integrity_summary","");
            o.put("provenance_lineage_evaluated",false);
            o.put("provenance_lineage_updated",false);
            o.put("provenance_lineage_nodes_added",0);
            o.put("provenance_lineage_edges_added",0);
            o.put("provenance_lineage_experiment_id","");
            o.put("provenance_lineage_policy_key","");
            o.put("provenance_lineage_root_key","");
            o.put("provenance_lineage_reason","");
            o.put("provenance_lineage_summary","");
            o.put("decision_rationale_evaluated",false);
            o.put("decision_rationale_usable",false);
            o.put("decision_rationale_policy_referenced",false);
            o.put("decision_rationale_current_evidence_primary",true);
            o.put("decision_rationale_text","");
            o.put("decision_rationale_compact","");
            o.put("decision_rationale_source_tier","");
            o.put("decision_rationale_reason","");
            o.put("decision_rationale_summary","");
            o.put("decision_rationale_fidelity_evaluated",false);
            o.put("decision_rationale_fidelity_repaired",false);
            o.put("decision_rationale_fidelity_blocked",false);
            o.put("decision_rationale_move_mismatch",false);
            o.put("decision_rationale_policy_overclaim",false);
            o.put("decision_rationale_unsupported_certainty",false);
            o.put("decision_rationale_internal_jargon_leak",false);
            o.put("decision_rationale_evidence_mismatch",false);
            o.put("decision_rationale_fidelity_state","PASS");
            o.put("decision_rationale_final","");
            o.put("decision_rationale_fidelity_reason","");
            o.put("decision_rationale_fidelity_summary","");
            o.put("explainability_delivery_evaluated",false);
            o.put("explainability_should_surface",false);
            o.put("explainability_user_asked_why",false);
            o.put("explainability_decision_needs_justification",false);
            o.put("explainability_recent_rationale_shown",false);
            o.put("explainability_suppressed_for_repetition",false);
            o.put("explainability_delivery_mode","SILENT_INTERNAL");
            o.put("explainability_delivery_text","");
            o.put("explainability_placement","");
            o.put("explainability_max_sentences",0);
            o.put("explainability_delivery_reason","");
            o.put("explainability_delivery_summary","");
            o.put("decision_transition_snapshot_loaded",false);
            o.put("decision_transition_move_changed",false);
            o.put("decision_transition_intervention_changed",false);
            o.put("decision_transition_target_changed",false);
            o.put("decision_transition_summary","");
            o.put("decision_transition_cause_evaluated",false);
            o.put("decision_transition_cause_detected",false);
            o.put("decision_transition_primary_cause","NONE");
            o.put("decision_transition_secondary_cause","");
            o.put("decision_transition_from_state","");
            o.put("decision_transition_to_state","");
            o.put("decision_transition_human_reason","");
            o.put("decision_transition_cause_reason","");
            o.put("decision_transition_cause_summary","");
            o.put("decision_transition_cause_fidelity_evaluated",false);
            o.put("decision_transition_cause_fidelity_repaired",false);
            o.put("decision_transition_cause_fidelity_blocked",false);
            o.put("decision_transition_multi_cause",false);
            o.put("decision_transition_cause_fidelity_state","PASS");
            o.put("decision_transition_cause_confidence","NONE");
            o.put("decision_transition_fidelity_primary_cause","NONE");
            o.put("decision_transition_fidelity_secondary_cause","");
            o.put("decision_transition_fidelity_human_reason","");
            o.put("decision_transition_cause_fidelity_reason","");
            o.put("decision_transition_cause_fidelity_summary","");
            o.put("transition_explanation_correction_evaluated",false);
            o.put("transition_explanation_correction_detected",false);
            o.put("transition_explanation_clarification_required",false);
            o.put("transition_explanation_correction_applied",false);
            o.put("transition_explanation_correction_rejected",false);
            o.put("transition_explanation_correction_state","NONE");
            o.put("transition_explanation_prior_cause","");
            o.put("transition_explanation_corrected_cause","");
            o.put("transition_explanation_corrected_reason","");
            o.put("transition_explanation_clarification_question","");
            o.put("transition_explanation_correction_reason","");
            o.put("transition_explanation_correction_summary","");
            o.put("transition_correction_memory_evaluated",false);
            o.put("transition_correction_memory_reusable",false);
            o.put("transition_correction_memory_exact",false);
            o.put("transition_correction_memory_blocked",false);
            o.put("transition_correction_memory_match","NONE");
            o.put("transition_correction_memory_cause","");
            o.put("transition_correction_memory_reason_text","");
            o.put("transition_correction_memory_source_context","");
            o.put("transition_correction_memory_current_context","");
            o.put("transition_correction_memory_reason","");
            o.put("transition_correction_memory_summary","");
            o.put("transition_correction_revalidation_evaluated",false);
            o.put("transition_correction_revalidation_pending",false);
            o.put("transition_correction_reactivated",false);
            o.put("transition_correction_revalidation_state","NONE");
            o.put("transition_correction_revalidation_key","");
            o.put("transition_correction_revalidation_context","");
            o.put("transition_correction_revalidation_cause","");
            o.put("transition_correction_revalidation_confirmations",0);
            o.put("transition_correction_revalidation_contradictions",0);
            o.put("transition_correction_revalidation_reason","");
            o.put("transition_correction_revalidation_summary","");
            o.put("transition_correction_conflict_evaluated",false);
            o.put("transition_correction_conflicted",false);
            o.put("transition_correction_replacement_pending",false);
            o.put("transition_correction_replaced",false);
            o.put("transition_correction_retired",false);
            o.put("transition_correction_conflict_state","NONE");
            o.put("transition_correction_conflict_key","");
            o.put("transition_correction_conflict_incumbent","");
            o.put("transition_correction_conflict_challenger","");
            o.put("transition_correction_conflict_incumbent_count",0);
            o.put("transition_correction_conflict_challenger_count",0);
            o.put("transition_correction_conflict_distinct_causes",0);
            o.put("transition_correction_conflict_active_cause","");
            o.put("transition_correction_conflict_active_reason","");
            o.put("transition_correction_conflict_reason","");
            o.put("transition_correction_conflict_summary","");
            o.put("transition_correction_fresh_evidence_evaluated",false);
            o.put("transition_correction_memory_allowed",false);
            o.put("transition_correction_current_turn_override",false);
            o.put("transition_correction_fresh_evidence_blocked",false);
            o.put("transition_correction_fresh_evidence_state","NONE");
            o.put("transition_correction_fresh_evidence_memory_cause","");
            o.put("transition_correction_fresh_evidence_current_cause","");
            o.put("transition_correction_fresh_evidence_effective_cause","");
            o.put("transition_correction_fresh_evidence_effective_reason","");
            o.put("transition_correction_fresh_evidence_reason","");
            o.put("transition_correction_fresh_evidence_summary","");
            o.put("transition_correction_override_isolation_evaluated",false);
            o.put("transition_correction_override_ephemeral",false);
            o.put("transition_correction_commit_allowed",false);
            o.put("transition_correction_commit_blocked",false);
            o.put("transition_correction_duplicate_commit_suppressed",false);
            o.put("transition_correction_override_isolation_state","NONE");
            o.put("transition_correction_commit_identity","");
            o.put("transition_correction_override_isolation_reason","");
            o.put("transition_correction_override_isolation_summary","");
            o.put("transition_correction_commit_provenance_evaluated",false);
            o.put("transition_correction_commit_provenance_ready",false);
            o.put("transition_correction_commit_provenance_committed",false);
            o.put("transition_correction_commit_provenance_blocked",false);
            o.put("transition_correction_commit_provenance_duplicate",false);
            o.put("transition_correction_commit_provenance_state","NONE");
            o.put("transition_correction_commit_evidence_id","");
            o.put("transition_correction_canonical_commit_key","");
            o.put("transition_correction_commit_transition_key","");
            o.put("transition_correction_commit_context","");
            o.put("transition_correction_commit_provenance_reason","");
            o.put("transition_correction_commit_provenance_summary","");
            o.put("correction_provenance_integrity_evaluated",false);
            o.put("correction_provenance_integrity_repaired",false);
            o.put("correction_provenance_integrity_quarantined",false);
            o.put("correction_provenance_integrity_rows_checked",0);
            o.put("correction_provenance_integrity_rows_valid",0);
            o.put("correction_provenance_integrity_rows_repaired",0);
            o.put("correction_provenance_integrity_rows_quarantined",0);
            o.put("correction_provenance_integrity_legacy_unresolved",0);
            o.put("correction_provenance_integrity_reason","");
            o.put("correction_provenance_integrity_summary","");
            o.put("correction_provenance_reinstatement_evaluated",false);
            o.put("correction_provenance_reinstatement_review_required",false);
            o.put("correction_provenance_reinstatement_ready",false);
            o.put("correction_provenance_reinstated",false);
            o.put("correction_provenance_reinstatement_blocked",false);
            o.put("correction_provenance_reinstatement_matching_rows",0);
            o.put("correction_provenance_reinstated_rows",0);
            o.put("correction_provenance_reinstatement_state","NONE");
            o.put("correction_provenance_reinstatement_transition_key","");
            o.put("correction_provenance_reinstatement_context","");
            o.put("correction_provenance_reinstatement_cause","");
            o.put("correction_provenance_reinstatement_reason","");
            o.put("correction_provenance_reinstatement_summary","");
            o.put("correction_provenance_reinstatement_idempotency_evaluated",false);
            o.put("correction_provenance_reinstatement_idempotency_allow",false);
            o.put("correction_provenance_reinstatement_duplicate_suppressed",false);
            o.put("correction_provenance_reinstatement_already_active",false);
            o.put("correction_provenance_reinstatement_idempotency_blocked",false);
            o.put("correction_provenance_reinstatement_idempotency_state","NONE");
            o.put("correction_provenance_reinstatement_identity","");
            o.put("correction_provenance_reinstatement_idempotency_reason","");
            o.put("correction_provenance_reinstatement_idempotency_summary","");
            o.put("post_reinstatement_verification_evaluated",false);
            o.put("post_reinstatement_verification_required",false);
            o.put("post_reinstatement_verified_keep",false);
            o.put("post_reinstatement_requarantined",false);
            o.put("post_reinstatement_verification_state","NONE");
            o.put("post_reinstatement_transition_key","");
            o.put("post_reinstatement_reinstated_cause","");
            o.put("post_reinstatement_current_cause","");
            o.put("post_reinstatement_verification_reason","");
            o.put("post_reinstatement_verification_summary","");
            o.put("requarantine_cooldown_evaluated",false);
            o.put("requarantine_cooldown_active",false);
            o.put("requarantine_cooldown_released",false);
            o.put("requarantine_loop_blocked",false);
            o.put("requarantine_cooldown_state","NONE");
            o.put("requarantine_cooldown_transition_key","");
            o.put("requarantine_cooldown_quarantined_cause","");
            o.put("requarantine_cooldown_current_cause","");
            o.put("requarantine_cooldown_clean_confirmations",0);
            o.put("requarantine_cooldown_contradictions",0);
            o.put("requarantine_cooldown_reason","");
            o.put("requarantine_cooldown_summary","");
            o.put("cooldown_evidence_ledger_evaluated",false);
            o.put("cooldown_evidence_ledger_committed",false);
            o.put("cooldown_evidence_ledger_duplicate",false);
            o.put("cooldown_evidence_ledger_eligible",false);
            o.put("cooldown_evidence_ledger_contradiction",false);
            o.put("cooldown_evidence_ledger_state","NONE");
            o.put("cooldown_evidence_ledger_evidence_id","");
            o.put("cooldown_evidence_ledger_identity","");
            o.put("cooldown_evidence_ledger_transition_key","");
            o.put("cooldown_evidence_ledger_reason","");
            o.put("cooldown_evidence_ledger_summary","");
            o.put("cooldown_evidence_integrity_evaluated",false);
            o.put("cooldown_evidence_integrity_repaired",false);
            o.put("cooldown_evidence_integrity_quarantined",false);
            o.put("cooldown_evidence_synthetic_blocked",false);
            o.put("cooldown_evidence_integrity_rows_checked",0);
            o.put("cooldown_evidence_integrity_rows_valid",0);
            o.put("cooldown_evidence_integrity_rows_repaired",0);
            o.put("cooldown_evidence_integrity_rows_quarantined",0);
            o.put("cooldown_evidence_synthetic_blocked_rows",0);
            o.put("cooldown_evidence_integrity_reason","");
            o.put("cooldown_evidence_integrity_summary","");
            o.put("cooldown_evidence_independence_evaluated",false);
            o.put("cooldown_evidence_independent",false);
            o.put("cooldown_evidence_duplicate",false);
            o.put("cooldown_evidence_near_duplicate",false);
            o.put("cooldown_evidence_independence_blocked",false);
            o.put("cooldown_evidence_independence_state","NONE");
            o.put("cooldown_evidence_independence_matched_evidence_id","");
            o.put("cooldown_evidence_similarity","");
            o.put("cooldown_evidence_independence_reason","");
            o.put("cooldown_evidence_independence_summary","");
            o.put("cooldown_evidence_temporal_independence_evaluated",false);
            o.put("cooldown_evidence_temporally_independent",false);
            o.put("cooldown_evidence_burst_blocked",false);
            o.put("cooldown_evidence_temporal_waiting",false);
            o.put("cooldown_evidence_temporal_independence_state","NONE");
            o.put("cooldown_evidence_temporal_transition_key","");
            o.put("cooldown_evidence_temporal_current_cause","");
            o.put("cooldown_evidence_temporal_last_eligible_at",0L);
            o.put("cooldown_evidence_temporal_separation_ms",0L);
            o.put("cooldown_evidence_temporal_reason","");
            o.put("cooldown_evidence_temporal_summary","");
            o.put("cooldown_evidence_temporal_diversity_evaluated",false);
            o.put("cooldown_evidence_temporal_diversity_threshold_met",false);
            o.put("cooldown_evidence_temporal_diversity_clean_evidence_count",0);
            o.put("cooldown_evidence_temporal_diversity_distinct_days",0);
            o.put("cooldown_evidence_temporal_diversity_state","NONE");
            o.put("cooldown_evidence_temporal_diversity_transition_key","");
            o.put("cooldown_evidence_temporal_diversity_cause","");
            o.put("cooldown_evidence_temporal_diversity_reason","");
            o.put("cooldown_evidence_temporal_diversity_summary","");
            o.put("transition_correction_lifecycle_ordering_integrity_evaluated",false);
            o.put("transition_correction_lifecycle_retired",false);
            o.put("transition_correction_lifecycle_ordering_integrity_state","UNKNOWN");
            o.put("transition_correction_lifecycle_ordering_integrity_reason","");
            o.put("transition_correction_lifecycle_ordering_integrity_summary","");
            o.put("last_move","");
            o.put("last_target","");
            o.put("safety_override",false);
            o.put("updated_at",0);
        }catch(Exception ignored){}
        return o;
    }

    private static JSONObject loadObject(Context c,String key,JSONObject fallback){
        if(c==null)return fallback;
        try{
            String raw=c.getSharedPreferences(PREF,Context.MODE_PRIVATE)
                    .getString(key,"");
            if(raw==null||raw.isEmpty())return fallback;
            return new JSONObject(raw);
        }catch(Exception e){
            return fallback;
        }
    }

    private static void saveObject(Context c,String key,JSONObject value){
        if(c==null)return;
        c.getSharedPreferences(PREF,Context.MODE_PRIVATE).edit()
                .putString(key,value==null?"{}":value.toString()).apply();
    }

    private static JSONArray tail(JSONArray src,int max){
        JSONArray out=new JSONArray();
        int start=Math.max(0,src.length()-max);
        for(int i=start;i<src.length();i++)out.put(src.opt(i));
        return out;
    }

    private static String compact(String s,int max){
        s=safe(s).trim();
        return s.length()<=max?s:s.substring(0,max);
    }

    private static String safe(String s){return s==null?"":s;}
}
