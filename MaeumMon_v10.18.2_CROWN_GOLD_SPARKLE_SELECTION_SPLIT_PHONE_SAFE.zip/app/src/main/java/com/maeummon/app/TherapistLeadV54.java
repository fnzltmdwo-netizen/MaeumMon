package com.maeummon.app;

import android.content.Context;
import java.util.Locale;

/**
 * v5.4 Active therapist lead.
 *
 * Session continuity says "do not close too early". This layer adds the
 * missing half: choose what the counselor should actively examine next.
 */
public final class TherapistLeadV54 {
    private TherapistLeadV54() {}

    public static String buildContext(Context c, String userMessage) {
        String t = userMessage == null ? "" : userMessage.toLowerCase(Locale.KOREA);
        boolean insightAccepted = has(t, "아하", "그렇구나", "그러네", "비슷한 결", "맞는 것 같", "맞아", "이해돼");
        boolean action = has(t, "어떻게", "어케", "뭐라고", "해야", "방법", "바꾸", "고치", "해볼까");
        boolean close = has(t, "오늘은 여기", "정리해줘", "마무리", "그만", "끝낼", "이제 됐");
        boolean highEmotion = has(t, "너무 무서", "너무 불안", "숨 막", "울 것", "못 견디", "죽고 싶", "해치");

        String modeHint = close || action ? "CLOSE_OR_ACT"
                : highEmotion ? "STAY_WITH_IT"
                : "LEAD_FORWARD";

        return "[THERAPIST LEAD v5.4 / 상담의 다음 목적지를 상담사가 고른다]\n"
                + "lead_hint=" + modeHint + ", insight_accepted=" + insightAccepted
                + ", wants_action=" + action + ", explicit_close=" + close + ".\n"
                + "- SESSION_CONTINUITY가 '아직 안 끝났다'를 판단한다면, THERAPIST_LEAD는 '그럼 다음에 무엇을 볼지'를 고른다. 사용자가 다시 화제를 던져주기를 기다리지 않는다.\n"
                + "- 내부 세션 지도: SCENE/FACT → AUTOMATIC_MEANING → CORE_FEAR → CORE_NEED → PROTECTIVE_BEHAVIOR → LONG_TERM_COST → CHANGE_TARGET. 모든 칸을 억지로 채우지 않지만, 현재 개입을 바꿀 가장 중요한 빈칸 하나를 therapist_next_focus로 선택한다.\n"
                + "- LEAD_FORWARD: 정서가 감당 가능한 상태이고 핵심 빈칸이 남아 있으면, 지금까지의 이해를 1~2문장으로 연결한 뒤 그 한 칸을 가르는 질문 1개를 상담사가 먼저 연다.\n"
                + "- STAY_WITH_IT: 감정이 높거나 방금 중요한 상처를 말한 순간에는 바로 다음 분석 질문을 던지지 않는다. 정확한 공감/반영으로 잠시 머문 뒤, 안정되면 다음 층으로 간다.\n"
                + "- CLOSE_OR_ACT: 사용자가 행동·결정·문장을 원하거나 세션 마무리를 원하고 구조가 충분하면 탐색을 끝내고 CHANGE/INTEGRATE로 간다.\n"
                + "- '아하', '비슷한 결이구나', '그렇구나'는 보통 insight acceptance이지 topic close가 아니다. 그 뒤 보호행동/비용/두려움 등 핵심 빈칸이 남았다면 상담사가 다음 단계로 이끈다.\n"
                + "- 질문 금지 규칙과 충돌하지 않는다. 질문 자체가 목적이 아니라, formulation 또는 intervention을 실제로 바꾸는 한 질문만 허용한다.\n"
                + "- 좋은 리드 예: '응, 두 상황 모두 상대 반응을 빨리 네 문제로 가져오는 건 비슷해. 그런데 그 다음에 네가 뭘 하는지를 봐야 이 패턴이 왜 계속되는지 알 수 있을 것 같아. 보통 사과를 빨리 하거나, 눈치를 더 보거나, 혼자 오래 곱씹는 쪽이야?'\n"
                + "- 나쁜 리드 예: '또 궁금한 거 있어?', '더 이야기해볼까?', '어떻게 느껴?'처럼 세션을 사용자가 다시 끌게 만드는 막연한 질문.\n"
                + "현재 ACTIVE_SESSION_MEMORY를 보고 이미 확인된 칸은 다시 묻지 않는다.";
    }

    public static String prompt() {
        return "[THERAPIST LEAD v5.4] 상담사가 세션의 다음 목적지를 능동적으로 선택한다. "
                + "SCENE→MEANING→CORE_FEAR→CORE_NEED→PROTECTIVE_BEHAVIOR→LONG_TERM_COST→CHANGE_TARGET 중 다음 개입을 바꿀 가장 중요한 빈칸 하나를 therapist_next_focus로 고른다. "
                + "사용자가 통찰을 받아들인 말('아하/그렇구나/비슷한 결')을 했다고 자동 종료하지 않는다. 핵심 빈칸이 남으면 LEAD_FORWARD + CONTINUATION_ENDING으로 이해를 연결한 뒤 판별 질문 하나를 먼저 연다. "
                + "감정이 높으면 STAY_WITH_IT, 행동/마무리 요청이면 CLOSE_OR_ACT. 막연한 '더 말해볼래?' 질문은 금지한다.";
    }

    private static boolean has(String t, String... xs) {
        for (String x : xs) if (t.contains(x.toLowerCase(Locale.KOREA))) return true;
        return false;
    }
}
