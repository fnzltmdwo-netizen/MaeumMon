package com.maeummon.app.clinical;

import android.content.Context;
import org.json.*;
import java.util.*;

public final class OutcomeRevisionPropagationLearningRecomputeRC12 {
    private OutcomeRevisionPropagationLearningRecomputeRC12(){}

    public enum State {
        NONE,
        REVISION_FOUND,
        RECOMPUTED,
        NO_EFFECT_FOUND
    }

    public static final class Result {
        public boolean evaluated=false;
        public boolean recomputed=false;
        public State state=State.NONE;
        public String experimentId="";
        public String priorOutcome="";
        public String finalOutcome="";
        public int commitRowsUpdated=0;
        public int transferRowsUpdated=0;
        public int policiesRecomputed=0;
        public boolean generalizationRecomputed=false;
        public String reason="";
        public String summary="";
    }

    public static Result propagate(
            Context c,
            ClinicalDecisionRC7 d,
            ConflictingOutcomeReconciliationRevisionGateRC12.Result revision){

        Result r=new Result();

        if(c==null||d==null||revision==null){
            r.summary="NONE | MISSING_INPUT";
            return r;
        }

        if(!revision.revisionApplied
                || revision.state
                    != ConflictingOutcomeReconciliationRevisionGateRC12.State.REVISION_APPLIED){

            r.summary="NONE | NO_APPLIED_REVISION";
            return r;
        }

        r.evaluated=true;
        r.state=State.REVISION_FOUND;
        r.experimentId=safe(revision.experimentId);
        r.priorOutcome=safe(revision.priorOutcome);
        r.finalOutcome=safe(revision.finalOutcome);

        try{
            JSONObject p=CentralTherapyProfile.loadProfile(c);

            // 1) Rewrite semantic outcome in commit history, preserving audit metadata.
            JSONArray commits=p.optJSONArray("micro_experiment_outcome_commit_history");
            if(commits!=null){
                for(int i=0;i<commits.length();i++){
                    JSONObject x=commits.optJSONObject(i);
                    if(x==null)continue;

                    if(!r.experimentId.equals(x.optString("experiment_id","")))
                        continue;

                    String old=x.optString("outcome","UNKNOWN");
                    x.put("original_outcome_before_revision",old);
                    x.put("outcome",r.finalOutcome);
                    x.put("outcome_revised",true);
                    x.put("outcome_revision_time",System.currentTimeMillis());
                    r.commitRowsUpdated++;
                }
            }

            // 2) Rewrite cross-context learning row for the same experiment when present.
            JSONArray transfers=p.optJSONArray("cross_context_transfer_history");
            if(transfers!=null){
                for(int i=0;i<transfers.length();i++){
                    JSONObject x=transfers.optJSONObject(i);
                    if(x==null)continue;

                    String exp=x.optString("experiment_id","");
                    if(!r.experimentId.isEmpty() && r.experimentId.equals(exp)){
                        String old=x.optString("outcome","UNKNOWN");
                        x.put("original_outcome_before_revision",old);
                        x.put("outcome",r.finalOutcome);
                        x.put("outcome_revised",true);
                        x.put("outcome_revision_time",System.currentTimeMillis());
                        r.transferRowsUpdated++;
                    }
                }
            }

            // 3) Recompute every policy from canonical committed history.
            JSONArray policies=p.optJSONArray("intervention_policy_memory");
            if(policies!=null){
                for(int i=0;i<policies.length();i++){
                    JSONObject policy=policies.optJSONObject(i);
                    if(policy==null)continue;

                    String intervention=policy.optString("intervention_id","");
                    if(intervention.isEmpty())continue;

                    int positive=0;
                    int negative=0;
                    int relevant=0;

                    if(commits!=null){
                        for(int j=0;j<commits.length();j++){
                            JSONObject item=commits.optJSONObject(j);
                            if(item==null)continue;
                            if(!"COMMIT".equals(item.optString("commit_state","")))
                                continue;

                            if(!StructuredOutcomeProvenanceCanonicalIdentityRC12
                                    .exactInterventionMatch(item,intervention))
                                continue;

                            relevant++;
                            String outcome=item.optString("outcome","UNKNOWN");
                            if("HELPED".equals(outcome)
                                    ||"PARTIAL".equals(outcome))
                                positive++;
                            else if("NO_CHANGE".equals(outcome)
                                    ||"WORSE".equals(outcome))
                                negative++;
                        }
                    }

                    String confidence;
                    if(relevant<2){
                        confidence="LOW";
                    }else if(positive>=3 && negative==0){
                        confidence="HIGH";
                    }else if(positive>=2 && positive>negative){
                        confidence="MEDIUM";
                    }else{
                        confidence="LOW";
                    }

                    policy.put("positive_commits",positive);
                    policy.put("negative_commits",negative);
                    policy.put("total_relevant_commits",relevant);
                    policy.put("confidence",confidence);
                    policy.put("recomputed_after_outcome_revision",true);
                    policy.put("last_revision_recompute_experiment_id",
                            r.experimentId);
                    policy.put("last_revision_recompute_at",
                            System.currentTimeMillis());

                    // A revised negative invalidates optimistic active status.
                    if(("NO_CHANGE".equals(r.finalOutcome)
                            ||"WORSE".equals(r.finalOutcome))
                            && interventionMatchesExperiment(
                                    intervention,r.experimentId)){

                        if("HIGH".equals(confidence)
                                ||"MEDIUM".equals(confidence)){
                            // confidence itself came from all canonical rows;
                            // status remains ACTIVE if enough other evidence survives.
                            policy.put("policy_status","ACTIVE");
                        }else{
                            policy.put("policy_status","DEMOTED");
                        }
                    }

                    r.policiesRecomputed++;
                }
            }

            // 4) Recompute generalization candidate from revised transfer history.
            recomputeGeneralizationCandidate(p,transfers);
            r.generalizationRecomputed=true;

            // 5) Preserve immutable revision propagation audit trail.
            JSONArray audit=p.optJSONArray("outcome_revision_propagation_history");
            if(audit==null)audit=new JSONArray();

            JSONObject item=new JSONObject();
            item.put("experiment_id",r.experimentId);
            item.put("prior_outcome",r.priorOutcome);
            item.put("final_outcome",r.finalOutcome);
            item.put("commit_rows_updated",r.commitRowsUpdated);
            item.put("transfer_rows_updated",r.transferRowsUpdated);
            item.put("policies_recomputed",r.policiesRecomputed);
            item.put("time",System.currentTimeMillis());
            audit.put(item);

            JSONArray trimmed=new JSONArray();
            int start=Math.max(0,audit.length()-30);
            for(int i=start;i<audit.length();i++)
                trimmed.put(audit.opt(i));

            p.put("outcome_revision_propagation_history",trimmed);
            p.put("last_outcome_revision_propagated_experiment",
                    r.experimentId);
            p.put("last_outcome_revision_propagated_at",
                    System.currentTimeMillis());

            CentralTherapyProfile.replaceProfile(c,p);

            if(r.commitRowsUpdated==0
                    && r.transferRowsUpdated==0
                    && r.policiesRecomputed==0){
                r.state=State.NO_EFFECT_FOUND;
                r.reason="NO_PRIOR_LEARNING_ROWS_FOUND";
            }else{
                r.state=State.RECOMPUTED;
                r.recomputed=true;
                r.reason="REVISION_PROPAGATED_TO_DERIVED_LEARNING";
            }

            return finish(r);
        }catch(Exception e){
            r.state=State.NO_EFFECT_FOUND;
            r.recomputed=false;
            r.reason="REVISION_PROPAGATION_PERSIST_FAILED";
            return finish(r);
        }
    }

    public static String instruction(Result r){
        if(r==null||!r.evaluated)return "";

        if(r.state==State.RECOMPUTED){
            return "OUTCOME_REVISION_PROPAGATION=RECOMPUTED. 수정된 outcome을 기준으로 commit history, policy memory, cross-context/generalization 파생 학습을 다시 계산했다.";
        }

        if(r.state==State.NO_EFFECT_FOUND){
            return "OUTCOME_REVISION_PROPAGATION=NO_EFFECT_FOUND. revision은 보존했지만 수정할 기존 파생 학습 기록을 찾지 못했다.";
        }

        return "";
    }

    private static void recomputeGeneralizationCandidate(
            JSONObject p,
            JSONArray transfers){

        try{
            if(transfers==null){
                p.put("generalization_candidate_ready",false);
                return;
            }

            HashMap<String,HashSet<String>> contextsByKey=new HashMap<>();
            HashMap<String,Integer> positiveByKey=new HashMap<>();
            HashMap<String,Integer> negativeByKey=new HashMap<>();

            for(int i=0;i<transfers.length();i++){
                JSONObject x=transfers.optJSONObject(i);
                if(x==null)continue;

                String mechanism=x.optString("mechanism","");
                String intervention=x.optString("intervention_id","");
                String context=x.optString("target_context","UNKNOWN");
                String outcome=x.optString("outcome","UNKNOWN");
                String key=mechanism+"__"+intervention;

                if(!contextsByKey.containsKey(key))
                    contextsByKey.put(key,new HashSet<String>());

                if("HELPED".equals(outcome)
                        ||"PARTIAL".equals(outcome)){
                    contextsByKey.get(key).add(context);
                    positiveByKey.put(
                            key,
                            positiveByKey.containsKey(key)
                                    ?positiveByKey.get(key)+1:1);
                }else if("NO_CHANGE".equals(outcome)
                        ||"WORSE".equals(outcome)){
                    negativeByKey.put(
                            key,
                            negativeByKey.containsKey(key)
                                    ?negativeByKey.get(key)+1:1);
                }
            }

            boolean ready=false;
            String bestKey="";
            int bestPositive=0;
            int bestContexts=0;

            for(String key:contextsByKey.keySet()){
                int pos=positiveByKey.containsKey(key)
                        ?positiveByKey.get(key):0;
                int neg=negativeByKey.containsKey(key)
                        ?negativeByKey.get(key):0;
                int ctx=contextsByKey.get(key).size();

                if(ctx>=3 && pos>=4 && neg==0){
                    if(pos>bestPositive){
                        ready=true;
                        bestKey=key;
                        bestPositive=pos;
                        bestContexts=ctx;
                    }
                }
            }

            p.put("generalization_candidate_ready",ready);

            if(ready){
                String[] parts=bestKey.split("__",2);
                p.put("generalization_candidate_mechanism",
                        parts.length>0?parts[0]:"");
                p.put("generalization_candidate_intervention",
                        parts.length>1?parts[1]:"");
                p.put("generalization_candidate_context_count",
                        bestContexts);
                p.put("generalization_candidate_positive_count",
                        bestPositive);
            }else{
                p.remove("generalization_candidate_mechanism");
                p.remove("generalization_candidate_intervention");
                p.put("generalization_candidate_context_count",0);
                p.put("generalization_candidate_positive_count",0);
            }
        }catch(Exception ignored){}
    }

    private static boolean interventionMatchesExperiment(
            String intervention,String experimentId){
        return intervention!=null
                && experimentId!=null
                && !intervention.isEmpty()
                && experimentId.contains(intervention);
    }

    private static Result finish(Result r){
        r.summary=r.state.name()
                +" | experiment="+r.experimentId
                +" | "+r.priorOutcome+"->"+r.finalOutcome
                +" | commits="+r.commitRowsUpdated
                +" | transfers="+r.transferRowsUpdated
                +" | policies="+r.policiesRecomputed
                +" | generalization="+r.generalizationRecomputed
                +" | reason="+r.reason;
        return r;
    }

    private static String safe(String s){
        return s==null?"":s;
    }
}
