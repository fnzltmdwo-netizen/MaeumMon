package com.maeummon.app.clinical;

import android.content.Context;
import org.json.*;

public final class CrossContextTransferGeneralizationGuardRC11 {
    private CrossContextTransferGeneralizationGuardRC11(){}

    public enum Transfer {
        BLOCK,
        SAME_CONTEXT,
        NEAR_CONTEXT_TRIAL,
        GENERALIZABLE
    }

    public static final class Result {
        public boolean evaluated=false;
        public Transfer transfer=Transfer.BLOCK;
        public String sourceContext="";
        public String targetContext="";
        public boolean mechanismMatch=false;
        public boolean contextSimilarity=false;
        public boolean evidenceSufficient=false;
        public boolean trialOnly=false;
        public boolean generalPolicyEligible=false;
        public String reason="";
        public String summary="";
    }

    public static Result evaluate(
            Context c,ClinicalDecisionRC7 d,
            PolicyMemoryRetrievalContextMatchGuardRC11.Result retrieval){

        Result r=new Result();
        if(c==null||d==null){
            r.summary="BLOCK | NO_CONTEXT_OR_DECISION";
            return r;
        }

        JSONObject f=CentralTherapyProfile.loadFormulation(c);
        JSONObject p=CentralTherapyProfile.loadProfile(c);

        String target=f.optString("current_context_scope","UNKNOWN");
        r.targetContext=target;

        JSONObject source=findPolicyCandidate(p,d);
        if(source==null){
            r.summary="BLOCK | NO_POLICY_CANDIDATE";
            return r;
        }

        r.evaluated=true;
        r.sourceContext=source.optString("context_scope","UNKNOWN");
        r.mechanismMatch=safe(d.centralMechanism).equals(
                source.optString("mechanism",""));

        String conf=source.optString("confidence","LOW");
        int positives=source.optInt("positive_commits",0);
        int negatives=source.optInt("negative_commits",0);

        r.contextSimilarity=isNearContext(r.sourceContext,target);
        r.evidenceSufficient=
                "HIGH".equals(conf)
                && positives>=3
                && negatives==0;

        // Exact context: normal use, not transfer.
        if(target.equals(r.sourceContext)){
            r.transfer=Transfer.SAME_CONTEXT;
            r.trialOnly=false;
            r.generalPolicyEligible=false;
            r.reason="EXACT_CONTEXT_MATCH";
            return finish(r);
        }

        // Already GENERAL policy.
        if("GENERAL".equals(r.sourceContext)
                && r.mechanismMatch
                && ("MEDIUM".equals(conf)||"HIGH".equals(conf))){
            r.transfer=Transfer.GENERALIZABLE;
            r.trialOnly=false;
            r.generalPolicyEligible=true;
            r.reason="EXISTING_GENERAL_POLICY";
            return finish(r);
        }

        // Different mechanism always blocks transfer.
        if(!r.mechanismMatch){
            r.transfer=Transfer.BLOCK;
            r.reason="MECHANISM_MISMATCH";
            return finish(r);
        }

        // Far context blocks transfer, regardless of confidence.
        if(!r.contextSimilarity){
            r.transfer=Transfer.BLOCK;
            r.reason="CONTEXT_TOO_DIFFERENT";
            return finish(r);
        }

        // Near-context transfer is trial-only, never stable immediately.
        if(r.contextSimilarity && r.evidenceSufficient){
            r.transfer=Transfer.NEAR_CONTEXT_TRIAL;
            r.trialOnly=true;
            r.generalPolicyEligible=false;
            r.reason="HIGH_CONFIDENCE_NEAR_CONTEXT_TRIAL_ONLY";
            persistTrial(c,p,source,target,r);
            return finish(r);
        }

        r.transfer=Transfer.BLOCK;
        r.reason="INSUFFICIENT_TRANSFER_EVIDENCE";
        return finish(r);
    }

    public static String instruction(Result r){
        if(r==null||!r.evaluated)return "";

        switch(r.transfer){
            case SAME_CONTEXT:
                return "";
            case NEAR_CONTEXT_TRIAL:
                return "POLICY_TRANSFER=NEAR_CONTEXT_TRIAL. 과거 policy를 새 context의 정답으로 일반화하지 말고, 현재 formulation과 bridge가 동일한 방향일 때만 작은 trial로 시험한다.";
            case GENERALIZABLE:
                return "POLICY_TRANSFER=GENERALIZABLE. 이미 여러 context에서 검증된 GENERAL policy이지만 현재 evidence를 계속 우선한다.";
            case BLOCK:
            default:
                return "POLICY_TRANSFER=BLOCKED. 다른 context의 과거 policy를 현재 상황에 일반화하지 않는다.";
        }
    }

    public static boolean mayUseAsTrial(Result r){
        return r!=null
                && r.transfer==Transfer.NEAR_CONTEXT_TRIAL
                && r.trialOnly;
    }

    public static void registerTransferredOutcome(
            Context c,ClinicalDecisionRC7 d){

        if(c==null||d==null)return;
        if(!"COMMIT".equals(d.outcomeCommitState))return;

        try{
            JSONObject p=CentralTherapyProfile.loadProfile(c);
            JSONObject f=CentralTherapyProfile.loadFormulation(c);

            String target=f.optString("current_context_scope","UNKNOWN");
            String mechanism=safe(d.centralMechanism);
            String intervention=safe(d.selectedInterventionId);
            String outcome=safe(d.outcomeCommitValue);

            JSONArray h=p.optJSONArray("cross_context_transfer_history");
            if(h==null)h=new JSONArray();

            JSONObject item=new JSONObject();
            item.put("target_context",target);
            item.put("mechanism",mechanism);
            item.put("intervention_id",intervention);
            item.put("experiment_id",safe(d.outcomeCommitExperimentId).isEmpty()?safe(d.microExperimentId):safe(d.outcomeCommitExperimentId));
            item.put("context_scope",target);
            item.put("mode",safe(d.preferenceMode));
            item.put("dose",safe(d.interventionDose));
            item.put("canonical_learning_key",mechanism+"::"+intervention+"::"+target+"::"+safe(d.outcomeCommitExperimentId));
            item.put("provenance_schema_version","6.7.4");
            item.put("outcome",outcome);
            item.put("time",System.currentTimeMillis());
            h.put(item);

            JSONArray trimmed=new JSONArray();
            int start=Math.max(0,h.length()-24);
            for(int i=start;i<h.length();i++)trimmed.put(h.opt(i));
            p.put("cross_context_transfer_history",trimmed);

            // Promotion to GENERAL requires clean positive evidence in >=3 distinct contexts.
            JSONArray contexts=new JSONArray();
            int positiveCount=0;
            for(int i=0;i<trimmed.length();i++){
                JSONObject x=trimmed.optJSONObject(i);
                if(x==null)continue;
                if(!mechanism.equals(x.optString("mechanism","")))continue;
                if(!intervention.equals(x.optString("intervention_id","")))continue;

                String o=x.optString("outcome","UNKNOWN");
                if(!"HELPED".equals(o)&&!"PARTIAL".equals(o))continue;

                positiveCount++;
                addUnique(contexts,x.optString("target_context","UNKNOWN"));
            }

            if(contexts.length()>=3 && positiveCount>=4){
                p.put("generalization_candidate_mechanism",mechanism);
                p.put("generalization_candidate_intervention",intervention);
                p.put("generalization_candidate_context_count",contexts.length());
                p.put("generalization_candidate_positive_count",positiveCount);
                p.put("generalization_candidate_ready",true);
            }

            CentralTherapyProfile.replaceProfile(c,p);
        }catch(Exception ignored){}
    }

    private static JSONObject findPolicyCandidate(
            JSONObject p,ClinicalDecisionRC7 d){

        JSONArray policies=p.optJSONArray("intervention_policy_memory");
        if(policies==null)return null;

        String mechanism=safe(d.centralMechanism);
        String intervention=safe(d.selectedInterventionId);

        JSONObject best=null;
        int bestRank=-1;

        for(int i=0;i<policies.length();i++){
            JSONObject x=policies.optJSONObject(i);
            if(x==null)continue;
            if(!mechanism.equals(x.optString("mechanism","")))continue;
            if(!intervention.isEmpty()
                    && !intervention.equals(x.optString("intervention_id","")))
                continue;
            if(!PolicyMemoryDecayContradictionDemotionRC11.isPolicyUsable(x))
                continue;

            String conf=x.optString("confidence","LOW");
            int rank="HIGH".equals(conf)?2:"MEDIUM".equals(conf)?1:0;
            if(rank>bestRank){
                best=x;
                bestRank=rank;
            }
        }
        return best;
    }

    private static boolean isNearContext(String a,String b){
        if(a==null||b==null)return false;
        if(a.equals(b))return true;

        return pair(a,b,"RELATIONSHIP","FRIENDSHIP")
                ||pair(a,b,"RELATIONSHIP","ROMANTIC")
                ||pair(a,b,"RELATIONSHIP","FAMILY")
                ||pair(a,b,"WORK","EVALUATION")
                ||pair(a,b,"WORK","INTERPERSONAL")
                ||pair(a,b,"WORK","LOAD")
                ||pair(a,b,"SOCIAL","FRIENDSHIP")
                ||pair(a,b,"SOCIAL","RELATIONSHIP");
    }

    private static boolean pair(
            String a,String b,String x,String y){
        return (x.equals(a)&&y.equals(b))
                ||(y.equals(a)&&x.equals(b));
    }

    private static void persistTrial(
            Context c,JSONObject p,JSONObject source,
            String target,Result r){
        try{
            JSONObject marker=new JSONObject();
            marker.put("source_policy_key",source.optString("key",""));
            marker.put("source_context",r.sourceContext);
            marker.put("target_context",target);
            marker.put("status","TRIAL_ONLY");
            marker.put("started_at",System.currentTimeMillis());
            p.put("active_cross_context_policy_trial",marker);
            CentralTherapyProfile.replaceProfile(c,p);
        }catch(Exception ignored){}
    }

    private static void addUnique(JSONArray a,String value)
            throws JSONException{
        for(int i=0;i<a.length();i++)
            if(value.equals(a.optString(i)))return;
        a.put(value);
    }

    private static Result finish(Result r){
        r.summary=r.transfer.name()
                +" | source="+r.sourceContext
                +" | target="+r.targetContext
                +" | mechanismMatch="+r.mechanismMatch
                +" | near="+r.contextSimilarity
                +" | evidence="+r.evidenceSufficient
                +" | trialOnly="+r.trialOnly
                +" | reason="+r.reason;
        return r;
    }

    private static String safe(String s){
        return s==null?"":s;
    }
}
