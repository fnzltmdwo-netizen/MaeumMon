package com.maeummon.app;

import android.accessibilityservice.AccessibilityService;
import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.text.TextUtils;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.accessibility.AccessibilityWindowInfo;

import java.util.List;

public class LauncherSurfaceAccessibilityService extends AccessibilityService {
    public static final String PREF_MODE = "launcher_surface_mode";
    public static final String PREF_MODE_AT = "launcher_surface_mode_at";
    public static final String MODE_HOME = "home";
    public static final String MODE_BLOCKED = "blocked";
    public static final String MODE_UNKNOWN = "unknown";

    private String launcherPackage = "";
    private Handler handler;

    private final Runnable surfacePoll = new Runnable() {
        @Override public void run() {
            classifyCurrentSurface();
            if (handler != null) handler.postDelayed(this, 250L);
        }
    };

    private final Runnable recheckAfterWindowTransition = new Runnable() {
        @Override public void run() {
            classifyCurrentSurface();
        }
    };

    @Override
    public void onServiceConnected() {
        super.onServiceConnected();
        launcherPackage = resolveLauncherPackage();
        handler = new Handler(Looper.getMainLooper());
        handler.removeCallbacks(surfacePoll);
        handler.post(surfacePoll);
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event == null) {
            classifyCurrentSurface();
            return;
        }

        // 핵심: One UI의 Finder/앱서랍/검색으로 전환되는 순간에는
        // 새 window tree가 완전히 준비되기 전에 잠깐 이전 HOME tree가 반환될 수 있다.
        // 그래서 런처의 window 전환 이벤트가 오면 먼저 BLOCKED로 숨기고,
        // 잠시 뒤 실제 tree를 다시 읽어서 순수 HOME일 때만 복구한다.
        int type = event.getEventType();
        String eventPkg = event.getPackageName() == null ? "" : event.getPackageName().toString();
        boolean launcherWindowTransition = eventPkg.equals(launcherPackage)
                && (type == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED
                || type == AccessibilityEvent.TYPE_WINDOWS_CHANGED);

        if (launcherWindowTransition) {
            saveMode(MODE_BLOCKED);
            if (handler != null) {
                handler.removeCallbacks(recheckAfterWindowTransition);
                handler.postDelayed(recheckAfterWindowTransition, 420L);
            }
            return;
        }

        // 키보드/검색 관련 콘텐츠 변화도 HOME으로 재노출하기 전에 먼저 숨긴다.
        if (eventPkg.equals(launcherPackage)
                && (type == AccessibilityEvent.TYPE_VIEW_FOCUSED
                || type == AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED)) {
            saveMode(MODE_BLOCKED);
        }

        classifyCurrentSurface();
    }

    private void classifyCurrentSurface() {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) {
            // 전환 중 root가 잠깐 null인 경우 이전 HOME 상태를 유지하면
            // Finder/앱서랍에서 다마고치가 순간적으로 보일 수 있다.
            saveMode(MODE_BLOCKED);
            return;
        }

        CharSequence packageCs = root.getPackageName();
        String pkg = packageCs == null ? "" : packageCs.toString();
        String cls = root.getClassName() == null ? "" : root.getClassName().toString().toLowerCase();
        SurfaceInfo info = inspect(root);
        boolean inputMethodVisible = isInputMethodWindowVisible();

        if (pkg.equals(launcherPackage)) {
            boolean blocked = false;

            // 최근 앱/오버뷰 계열
            if (cls.contains("recents") || cls.contains("overview")) blocked = true;
            if (info.hasRecentKeyword) blocked = true;

            // One UI 앱 목록/Finder/폴더 계열. 실제 바탕화면 외 런처 표면은 모두 숨긴다.
            if (cls.contains("allapps") || cls.contains("drawer") || cls.contains("appslist") || cls.contains("finder")
                    || cls.contains("folder") || cls.contains("folderview") || cls.contains("openfolder")) {
                blocked = true;
            }
            // 런처에서 키보드가 떠 있다는 건 Finder/검색/폴더 이름 입력 등
            // 순수 홈 바탕화면이 아니라는 뜻이므로 즉시 숨긴다.
            if (inputMethodVisible) blocked = true;

            // 검색창이 실제로 포커스되었거나 편집 가능한 노드가 포커스된 경우도 차단.
            // 기존 nodeCount 조건 때문에 Samsung Finder가 홈으로 오인되던 문제를 제거한다.
            if (info.hasAppDrawerSearch || info.hasFocusedEditableSearch) blocked = true;
            if (info.hasFolderSurface) blocked = true;

            saveMode(blocked ? MODE_BLOCKED : MODE_HOME);
            return;
        }

        // Samsung/Android 최근 앱은 SystemUI window로 뜨는 경우가 있다.
        String lowerPkg = pkg.toLowerCase();
        if (lowerPkg.contains("systemui")) {
            if (cls.contains("recents") || cls.contains("overview") || info.hasRecentKeyword) {
                saveMode(MODE_BLOCKED);
            }
            // 단순 상태바/알림 아이콘 이벤트는 이전 판정을 유지한다.
            return;
        }

        // 다른 실제 앱이 active window이면 숨김.
        // 우리 오버레이는 NOT_FOCUSABLE이라 active root가 되지 않는다.
        if (!pkg.isEmpty()) saveMode(MODE_BLOCKED);
    }

    @Override public void onInterrupt() {}

    @Override
    public void onDestroy() {
        if (handler != null) handler.removeCallbacksAndMessages(null);
        super.onDestroy();
    }

    private SurfaceInfo inspect(AccessibilityNodeInfo root) {
        SurfaceInfo out = new SurfaceInfo();
        walk(root, out);
        return out;
    }

    private void walk(AccessibilityNodeInfo n, SurfaceInfo out) {
        if (n == null || out.nodeCount > 260) return;
        out.nodeCount++;

        CharSequence t = n.getText();
        CharSequence d = n.getContentDescription();
        CharSequence cls = n.getClassName();

        if (n.isEditable() && (n.isFocused() || n.isAccessibilityFocused())) {
            out.hasFocusedEditableSearch = true;
        }

        if (t != null && !TextUtils.isEmpty(t)) {
            out.textCount++;
            check(t.toString(), out);
        }
        if (d != null && !TextUtils.isEmpty(d)) {
            out.textCount++;
            check(d.toString(), out);
        }
        if (cls != null) {
            String c = cls.toString().toLowerCase();
            if (c.contains("searchview") || c.contains("searchbar")) out.hasSearchWidget = true;
            if (c.contains("folder") || c.contains("openfolder") || c.contains("folderview")) {
                out.hasFolderSurface = true;
            }
        }

        for (int i = 0; i < n.getChildCount(); i++) walk(n.getChild(i), out);
    }

    private void check(String raw, SurfaceInfo out) {
        String s = raw.trim().toLowerCase();

        if (s.contains("모두 닫기")
                || s.contains("실행 중인 앱")
                || s.contains("최근 앱")
                || s.contains("close all")
                || s.contains("recent apps")) {
            out.hasRecentKeyword = true;
        }

        if (s.equals("검색")
                || s.contains("앱 검색")
                || s.contains("finder 검색")
                || s.equals("search apps")
                || s.contains("search apps")
                || s.equals("finder")) {
            out.hasAppDrawerSearch = true;
        }

        // Samsung One UI에서 홈 폴더를 열면 launcher package는 그대로라서
        // 폴더 관련 노드/설명 문구를 별도로 감지해야 한다.
        if (s.equals("폴더")
                || s.contains("폴더 열기")
                || s.contains("폴더 닫기")
                || s.contains("폴더 이름")
                || s.contains("폴더에 앱 추가")
                || s.contains("폴더에 추가")
                || s.contains("folder opened")
                || s.contains("open folder")
                || s.contains("close folder")
                || s.contains("folder name")
                || s.contains("add apps to folder")) {
            out.hasFolderSurface = true;
        }
    }

    private boolean isInputMethodWindowVisible() {
        try {
            List<AccessibilityWindowInfo> windows = getWindows();
            if (windows == null) return false;
            for (AccessibilityWindowInfo w : windows) {
                if (w != null && w.getType() == AccessibilityWindowInfo.TYPE_INPUT_METHOD) {
                    return true;
                }
            }
        } catch (Throwable ignored) {
            // 일부 제조사에서 windows 조회가 제한되어도 기존 node 판정은 계속 사용한다.
        }
        return false;
    }

    private void saveMode(String mode) {
        String old = getSharedPreferences(AppPrefs.PREFS, MODE_PRIVATE)
                .getString(PREF_MODE, MODE_UNKNOWN);
        if (!mode.equals(old)) {
            getSharedPreferences(AppPrefs.PREFS, MODE_PRIVATE)
                    .edit()
                    .putString(PREF_MODE, mode)
                    .putLong(PREF_MODE_AT, System.currentTimeMillis())
                    .apply();
        } else {
            // timestamp 갱신은 주기적으로 하지 않아도 된다. mode 자체가 안정 판정값이다.
        }
    }

    private String resolveLauncherPackage() {
        Intent i = new Intent(Intent.ACTION_MAIN);
        i.addCategory(Intent.CATEGORY_HOME);
        android.content.pm.ResolveInfo r = getPackageManager().resolveActivity(
                i, android.content.pm.PackageManager.MATCH_DEFAULT_ONLY);
        return r != null && r.activityInfo != null ? r.activityInfo.packageName : "";
    }

    private static class SurfaceInfo {
        int nodeCount = 0;
        int textCount = 0;
        boolean hasRecentKeyword = false;
        boolean hasAppDrawerSearch = false;
        boolean hasSearchWidget = false;
        boolean hasFocusedEditableSearch = false;
        boolean hasFolderSurface = false;
    }

    public static boolean isEnabled(Context c) {
        String enabled = Settings.Secure.getString(
                c.getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        if (enabled == null) return false;
        String target = c.getPackageName() + "/" + LauncherSurfaceAccessibilityService.class.getName();
        for (String s : enabled.split(":")) {
            if (s.equalsIgnoreCase(target)
                    || s.endsWith("/" + LauncherSurfaceAccessibilityService.class.getSimpleName())) {
                return true;
            }
        }
        return false;
    }
}
