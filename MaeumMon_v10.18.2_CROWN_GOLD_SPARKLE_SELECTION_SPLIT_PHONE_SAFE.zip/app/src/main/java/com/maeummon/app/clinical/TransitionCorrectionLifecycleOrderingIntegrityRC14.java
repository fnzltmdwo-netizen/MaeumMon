package com.maeummon.app.clinical;

import android.content.Context;
import org.json.*;

public final class TransitionCorrectionLifecycleOrderingIntegrityRC14 {
    private TransitionCorrectionLifecycleOrderingIntegrityRC14(){}

    public enum State {
        PASS,
        RETIREMENT_REACHED,
        CONFLICT_ACTIVE,
        REPLACEMENT_PENDING,
        STABLE,
        UNKNOWN
    }

    public static final class Result {
        public boolean evaluated=false;
        public boolean persistentConflict=false;
        public boolean retirementExpected=false;
        public boolean retired=false;
        public State state=State.UNKNOWN;
        public String conflictLifecycleState="";
        public String reason="";
        public String summary="";
    }

    public static Result evaluate(ClinicalDecisionRC7 d){
        Result r=new Result();
        if(d==null){
            r.reason="NO_DECISION";
            return finish(r);
        }

        r.evaluated=true;
        r.conflictLifecycleState=safe(
                d.transitionCorrectionConflictState);

        if("RETIRED".equals(r.conflictLifecycleState)){
            r.persistentConflict=true;
            r.retirementExpected=true;
            r.retired=true;
            r.state=State.RETIREMENT_REACHED;
            r.reason="PERSISTENT_CONFLICT_REACHED_RETIRED";
            return finish(r);
        }

        if("CONFLICTED".equals(r.conflictLifecycleState)){
            r.state=State.CONFLICT_ACTIVE;
            r.reason="SHORT_OR_UNRESOLVED_CONFLICT";
            return finish(r);
        }

        if("REPLACEMENT_PENDING".equals(r.conflictLifecycleState)){
            r.state=State.REPLACEMENT_PENDING;
            r.reason="CHALLENGER_NOT_YET_STRONG_ENOUGH";
            return finish(r);
        }

        if("STABLE".equals(r.conflictLifecycleState)
                ||"REPLACED".equals(r.conflictLifecycleState)){
            r.state=State.STABLE;
            r.reason="ACTIVE_CAUSE_AVAILABLE";
            return finish(r);
        }

        r.state=State.PASS;
        r.reason="NO_CONFLICT_LIFECYCLE_ACTION";
        return finish(r);
    }

    public static String instruction(Result r){
        if(r==null||!r.evaluated)return "";

        if(r.state==State.RETIREMENT_REACHED)
            return "CORRECTION_LIFECYCLE_INTEGRITY=RETIRED. 장기적으로 해결되지 않은 near-tie correction conflict는 더 이상 active WHY memory로 사용하지 않는다.";

        if(r.state==State.CONFLICT_ACTIVE)
            return "CORRECTION_LIFECYCLE_INTEGRITY=CONFLICTED. 아직 짧거나 해결 중인 충돌이라 active correction memory 사용을 보류한다.";

        return "";
    }

    private static Result finish(Result r){
        r.summary=r.state.name()
                +" | lifecycle="+r.conflictLifecycleState
                +" | persistentConflict="+r.persistentConflict
                +" | retirementExpected="+r.retirementExpected
                +" | retired="+r.retired
                +" | reason="+r.reason;
        return r;
    }

    private static String safe(String s){
        return s==null?"":s;
    }
}
