package com.maeummon.app;

import android.content.Context;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.os.Handler;
import android.os.Looper;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class TypecastClient {

    public static class Voice {
        public final String id;
        public final String name;
        public final String gender;
        public final String age;
        public Voice(String id, String name, String gender, String age) {
            this.id = id; this.name = name; this.gender = gender; this.age = age;
        }
        @Override public String toString() {
            String extra = "";
            if (!gender.isEmpty()) extra += " · " + gender;
            if (!age.isEmpty()) extra += " · " + age;
            return name + extra + "\n" + id;
        }
    }

    public interface Listener {
        void onStarted();
        void onSuccess();
        void onError(String message);
    }

    public interface VoicesListener {
        void onSuccess(List<Voice> voices);
        void onError(String message);
    }

    private static final ExecutorService EXECUTOR = Executors.newSingleThreadExecutor();
    private static final Handler MAIN = new Handler(Looper.getMainLooper());
    private static MediaPlayer player;
    private static HttpURLConnection activeConnection;

    public static synchronized void stop() {
        try { if (activeConnection != null) activeConnection.disconnect(); } catch (Exception ignored) {}
        activeConnection = null;
        try {
            if (player != null) { player.stop(); player.release(); }
        } catch (Exception ignored) {}
        player = null;
    }

    public static void speak(Context context, String apiKey, String voiceId, String modelId,
                             boolean smartEmotion, String emotionPreset, float emotionIntensity,
                             int volume, int pitch, float tempo, String text, Listener listener) {
        if (text == null || text.trim().isEmpty()) return;
        if (apiKey == null || apiKey.trim().isEmpty() || voiceId == null || voiceId.trim().isEmpty()) {
            if (listener != null) listener.onError("Typecast API Key 또는 Voice ID가 비어 있어.");
            return;
        }
        final Context appContext = context.getApplicationContext();
        final String model = "ssfm-v30"; // Studio-match mode: always use latest Typecast model
        final String cleanText = text.replace("\n", " ").trim();
        final String safePreset = (emotionPreset == null || emotionPreset.trim().isEmpty()) ? "normal" : emotionPreset.trim();
        final float safeIntensity = Math.max(0f, Math.min(2f, emotionIntensity));
        final int safeVolume = Math.max(0, Math.min(200, volume));
        final int safePitch = Math.max(-12, Math.min(12, pitch));
        final float safeTempo = Math.max(0.5f, Math.min(2.0f, tempo));

        EXECUTOR.execute(() -> {
            HttpURLConnection conn = null;
            File audioFile = null;
            try {
                stop();
                if (listener != null) MAIN.post(listener::onStarted);
                conn = (HttpURLConnection) new URL("https://api.typecast.ai/v1/text-to-speech").openConnection();
                activeConnection = conn;
                conn.setRequestMethod("POST");
                conn.setConnectTimeout(15000);
                conn.setReadTimeout(50000);
                conn.setDoOutput(true);
                conn.setRequestProperty("Content-Type", "application/json");
                conn.setRequestProperty("Accept", "audio/wav");
                conn.setRequestProperty("X-API-KEY", apiKey.trim());

                JSONObject body = new JSONObject();
                body.put("voice_id", voiceId.trim());
                body.put("text", cleanText);
                body.put("model", model);
                body.put("language", "kor");

                JSONObject prompt = new JSONObject();
                if (smartEmotion) {
                    prompt.put("emotion_type", "smart");
                } else {
                    prompt.put("emotion_type", "preset");
                    prompt.put("emotion_preset", safePreset);
                    prompt.put("emotion_intensity", safeIntensity);
                }
                body.put("prompt", prompt);

                JSONObject output = new JSONObject();
                output.put("volume", safeVolume);
                output.put("audio_pitch", safePitch);
                output.put("audio_tempo", safeTempo);
                output.put("audio_format", "wav");
                body.put("output", output);

                byte[] request = body.toString().getBytes(StandardCharsets.UTF_8);
                try (OutputStream os = new BufferedOutputStream(conn.getOutputStream())) {
                    os.write(request); os.flush();
                }

                int status = conn.getResponseCode();
                if (status < 200 || status >= 300) {
                    InputStream err = conn.getErrorStream();
                    String detail = err == null ? "HTTP " + status : readUtf8(err);
                    throw new Exception("Typecast 오류 " + status + ": " + detail);
                }

                audioFile = File.createTempFile("maeummon_typecast_", ".wav", appContext.getCacheDir());
                try (InputStream in = new BufferedInputStream(conn.getInputStream());
                     FileOutputStream fos = new FileOutputStream(audioFile)) {
                    byte[] buffer = new byte[8192];
                    int len;
                    while ((len = in.read(buffer)) != -1) fos.write(buffer, 0, len);
                }
                final File finalFile = audioFile;
                MAIN.post(() -> playFile(finalFile, listener));
            } catch (Exception e) {
                if (audioFile != null) try { audioFile.delete(); } catch (Exception ignored) {}
                final String msg = e.getMessage() == null ? "Typecast 음성 생성에 실패했어." : e.getMessage();
                if (listener != null) MAIN.post(() -> listener.onError(msg));
            } finally {
                try { if (conn != null) conn.disconnect(); } catch (Exception ignored) {}
                if (activeConnection == conn) activeConnection = null;
            }
        });
    }

    public static void listChildMaleVoices(String apiKey, VoicesListener listener) {
        if (apiKey == null || apiKey.trim().isEmpty()) {
            if (listener != null) listener.onError("먼저 Typecast API Key를 입력해줘.");
            return;
        }
        EXECUTOR.execute(() -> {
            HttpURLConnection conn = null;
            try {
                String endpoint = "https://api.typecast.ai/v2/voices?model=ssfm-v30&age=child&gender=male";
                conn = (HttpURLConnection) new URL(endpoint).openConnection();
                conn.setRequestMethod("GET");
                conn.setConnectTimeout(15000);
                conn.setReadTimeout(30000);
                conn.setRequestProperty("Accept", "application/json");
                conn.setRequestProperty("X-API-KEY", apiKey.trim());
                int status = conn.getResponseCode();
                if (status < 200 || status >= 300) {
                    InputStream err = conn.getErrorStream();
                    String detail = err == null ? "HTTP " + status : readUtf8(err);
                    throw new Exception("목소리 목록 오류 " + status + ": " + detail);
                }
                String json = readUtf8Unlimited(conn.getInputStream());
                List<Voice> voices = parseVoices(json);
                if (listener != null) MAIN.post(() -> listener.onSuccess(voices));
            } catch (Exception e) {
                String msg = e.getMessage() == null ? "어린이 목소리 목록을 불러오지 못했어." : e.getMessage();
                if (listener != null) MAIN.post(() -> listener.onError(msg));
            } finally {
                if (conn != null) try { conn.disconnect(); } catch (Exception ignored) {}
            }
        });
    }

    private static List<Voice> parseVoices(String json) throws Exception {
        List<Voice> result = new ArrayList<>();
        String trimmed = json == null ? "" : json.trim();
        JSONArray arr = null;
        if (trimmed.startsWith("[")) {
            arr = new JSONArray(trimmed);
        } else {
            JSONObject root = new JSONObject(trimmed);
            String[] keys = {"voices", "items", "data", "results"};
            for (String key : keys) {
                Object v = root.opt(key);
                if (v instanceof JSONArray) { arr = (JSONArray) v; break; }
                if (v instanceof JSONObject) {
                    JSONObject obj = (JSONObject) v;
                    if (obj.optJSONArray("voices") != null) { arr = obj.optJSONArray("voices"); break; }
                    if (obj.optJSONArray("items") != null) { arr = obj.optJSONArray("items"); break; }
                }
            }
        }
        if (arr == null) return result;
        for (int i = 0; i < arr.length(); i++) {
            JSONObject o = arr.optJSONObject(i);
            if (o == null) continue;
            String id = first(o, "voice_id", "id");
            if (id.isEmpty()) continue;
            String name = first(o, "voice_name", "name", "display_name", "actor_name");
            if (name.isEmpty()) name = "Typecast 어린이 목소리 " + (result.size() + 1);
            String gender = first(o, "gender", "sex");
            String age = first(o, "age", "age_group");
            result.add(new Voice(id, name, gender, age));
        }
        return result;
    }

    private static String first(JSONObject o, String... keys) {
        for (String k : keys) {
            String v = o.optString(k, "").trim();
            if (!v.isEmpty() && !"null".equalsIgnoreCase(v)) return v;
        }
        return "";
    }

    private static synchronized void playFile(File file, Listener listener) {
        try {
            if (player != null) {
                try { player.stop(); } catch (Exception ignored) {}
                try { player.release(); } catch (Exception ignored) {}
            }
            player = new MediaPlayer();
            player.setAudioAttributes(new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build());
            player.setDataSource(file.getAbsolutePath());
            player.setOnPreparedListener(mp -> {
                // Keep Typecast's original WAV dynamics. No Android-side loudness enhancer.
                mp.setVolume(1.0f, 1.0f);
                mp.start();
            });
            player.setOnCompletionListener(mp -> {
                try { mp.release(); } catch (Exception ignored) {}
                player = null;
                try { file.delete(); } catch (Exception ignored) {}
                if (listener != null) listener.onSuccess();
            });
            player.setOnErrorListener((mp, what, extra) -> {
                try { mp.release(); } catch (Exception ignored) {}
                player = null;
                try { file.delete(); } catch (Exception ignored) {}
                if (listener != null) listener.onError("Typecast 음성 재생에 실패했어.");
                return true;
            });
            player.prepareAsync();
        } catch (Exception e) {
            try { file.delete(); } catch (Exception ignored) {}
            if (listener != null) listener.onError("Typecast 음성 재생에 실패했어.");
        }
    }

    private static String readUtf8(InputStream in) throws Exception {
        String text = readUtf8Unlimited(in);
        return text.length() > 500 ? text.substring(0, 500) : text;
    }

    private static String readUtf8Unlimited(InputStream in) throws Exception {
        try (InputStream input = in; ByteArrayOutputStream bos = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[4096];
            int len;
            while ((len = input.read(buffer)) != -1) bos.write(buffer, 0, len);
            return bos.toString("UTF-8");
        }
    }
}
