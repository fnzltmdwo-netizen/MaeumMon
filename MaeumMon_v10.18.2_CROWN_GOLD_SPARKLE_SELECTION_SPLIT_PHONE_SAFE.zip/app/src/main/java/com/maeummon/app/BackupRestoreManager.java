package com.maeummon.app;

import android.content.ContentValues;
import android.content.Context;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.Map;
import java.util.Set;

/**
 * Portable MaeumMon backup.
 *
 * v2 backs up both SharedPreferences and the complete Mind PT SQLite database,
 * so reinstalling the app does not lose accumulated counseling threads,
 * PTs, crown priority, training progress, or outcomes.
 *
 * API keys and diary PIN hashes are deliberately excluded.
 */
public final class BackupRestoreManager {
    private BackupRestoreManager() {}

    private static final int BACKUP_VERSION = 2;

    private static final String[] PREF_NAMES = {
            AppPrefs.PREFS,
            "maeummon_pet_state",
            "maeummon_widget_prefs",
            "maeummon_therapy_memory",
            TherapyThreadManager.PREF,
            "maeummon_change_map",
            "maeummon_shared_counseling_cache"
    };

    /** Explicit allow-list prevents accidentally exporting unrelated SQLite internals. */
    private static final String[] DB_TABLES = {
            "concerns",
            "mind_muscles",
            "training_sessions",
            "training_outcomes",
            "counseling_entries",
            "counseling_sync_sessions",
            "counseling_sync_chunks",
            "counseling_programs",
            "counseling_program_steps",
            "shared_counseling_threads",
            "shared_counseling_turns"
    };

    // Delete child/history tables first. No FK is currently declared, but this order is future-safe.
    private static final String[] DB_DELETE_ORDER = {
            "training_outcomes",
            "training_sessions",
            "counseling_program_steps",
            "counseling_programs",
            "counseling_sync_chunks",
            "counseling_sync_sessions",
            "shared_counseling_turns",
            "shared_counseling_threads",
            "counseling_entries",
            "mind_muscles",
            "concerns"
    };

    private static boolean isSensitiveKey(String key) {
        if (key == null) return false;
        String k = key.toLowerCase();
        return k.contains("api_key") || k.contains("pin_hash");
    }

    public static void exportToUri(Context context, Uri uri) throws Exception {
        JSONObject root = new JSONObject();
        root.put("format", "maeummon-backup");
        root.put("version", BACKUP_VERSION);
        root.put("exportedAt", System.currentTimeMillis());
        root.put("mindPtDbVersion", MindTrainingDbHelper.DB_VERSION);

        root.put("preferences", exportPreferences(context));
        root.put("mindPtDatabase", exportMindPtDatabase(context));

        OutputStream os = context.getContentResolver().openOutputStream(uri, "w");
        if (os == null) throw new IllegalStateException("백업 파일을 열 수 없습니다.");
        try {
            os.write(root.toString(2).getBytes(StandardCharsets.UTF_8));
            os.flush();
        } finally {
            os.close();
        }
    }

    private static JSONObject exportPreferences(Context context) throws Exception {
        JSONObject prefsRoot = new JSONObject();
        for (String prefName : PREF_NAMES) {
            SharedPreferences sp = context.getSharedPreferences(prefName, Context.MODE_PRIVATE);
            JSONObject out = new JSONObject();
            for (Map.Entry<String, ?> entry : sp.getAll().entrySet()) {
                if (isSensitiveKey(entry.getKey())) continue;
                Object value = entry.getValue();
                JSONObject item = new JSONObject();
                if (value instanceof String) {
                    item.put("t", "s"); item.put("v", value);
                } else if (value instanceof Integer) {
                    item.put("t", "i"); item.put("v", value);
                } else if (value instanceof Long) {
                    item.put("t", "l"); item.put("v", value);
                } else if (value instanceof Float) {
                    item.put("t", "f"); item.put("v", ((Float) value).doubleValue());
                } else if (value instanceof Boolean) {
                    item.put("t", "b"); item.put("v", value);
                } else if (value instanceof Set) {
                    item.put("t", "ss");
                    JSONArray arr = new JSONArray();
                    for (Object o : (Set<?>) value) if (o != null) arr.put(String.valueOf(o));
                    item.put("v", arr);
                } else {
                    continue;
                }
                out.put(entry.getKey(), item);
            }
            prefsRoot.put(prefName, out);
        }
        return prefsRoot;
    }

    private static JSONObject exportMindPtDatabase(Context context) throws Exception {
        JSONObject dbRoot = new JSONObject();
        MindTrainingDbHelper helper = new MindTrainingDbHelper(context.getApplicationContext());
        SQLiteDatabase db = helper.getReadableDatabase();
        try {
            for (String table : DB_TABLES) {
                JSONArray rows = new JSONArray();
                Cursor c = db.rawQuery("SELECT * FROM " + table + " ORDER BY id ASC", null);
                try {
                    String[] columns = c.getColumnNames();
                    while (c.moveToNext()) {
                        JSONObject row = new JSONObject();
                        for (int i = 0; i < columns.length; i++) {
                            if (c.isNull(i)) {
                                row.put(columns[i], JSONObject.NULL);
                                continue;
                            }
                            switch (c.getType(i)) {
                                case Cursor.FIELD_TYPE_INTEGER:
                                    row.put(columns[i], c.getLong(i));
                                    break;
                                case Cursor.FIELD_TYPE_FLOAT:
                                    row.put(columns[i], c.getDouble(i));
                                    break;
                                case Cursor.FIELD_TYPE_BLOB:
                                    // Current PT DB has no blob columns. Keep a safe textual fallback.
                                    row.put(columns[i], android.util.Base64.encodeToString(c.getBlob(i), android.util.Base64.NO_WRAP));
                                    break;
                                case Cursor.FIELD_TYPE_STRING:
                                default:
                                    row.put(columns[i], c.getString(i));
                                    break;
                            }
                        }
                        rows.put(row);
                    }
                } finally {
                    c.close();
                }
                dbRoot.put(table, rows);
            }
        } finally {
            helper.close();
        }
        return dbRoot;
    }

    public static void restoreFromUri(Context context, Uri uri) throws Exception {
        JSONObject root = readRoot(context, uri);
        if (!"maeummon-backup".equals(root.optString("format"))) {
            throw new IllegalArgumentException("마음몬 백업 파일이 아닙니다.");
        }

        int version = root.optInt("version", 1);
        if (version > BACKUP_VERSION) {
            throw new IllegalArgumentException("더 최신 마음몬에서 만든 백업이야. 앱을 먼저 업데이트해줘.");
        }

        // v2+: restore the complete Mind PT DB first, then prefs/UI state.
        JSONObject dbRoot = root.optJSONObject("mindPtDatabase");
        if (dbRoot != null) restoreMindPtDatabase(context, dbRoot);

        JSONObject prefsRoot = root.optJSONObject("preferences");
        if (prefsRoot != null) restorePreferences(context, prefsRoot);
    }

    private static JSONObject readRoot(Context context, Uri uri) throws Exception {
        InputStream is = context.getContentResolver().openInputStream(uri);
        if (is == null) throw new IllegalStateException("백업 파일을 읽을 수 없습니다.");
        StringBuilder sb = new StringBuilder();
        try (BufferedReader br = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8))) {
            String line;
            while ((line = br.readLine()) != null) sb.append(line).append('\n');
        }
        return new JSONObject(sb.toString());
    }

    private static void restorePreferences(Context context, JSONObject prefsRoot) throws Exception {
        for (String prefName : PREF_NAMES) {
            JSONObject in = prefsRoot.optJSONObject(prefName);
            if (in == null) continue;
            SharedPreferences.Editor ed = context.getSharedPreferences(prefName, Context.MODE_PRIVATE).edit();
            // Sensitive values are intentionally not in the backup; keep any API key/PIN already on this install.
            JSONArray names = in.names();
            if (names != null) {
                for (int i = 0; i < names.length(); i++) {
                    String key = names.getString(i);
                    if (isSensitiveKey(key)) continue;
                    JSONObject item = in.optJSONObject(key);
                    if (item == null) continue;
                    String type = item.optString("t");
                    switch (type) {
                        case "s": ed.putString(key, item.optString("v", "")); break;
                        case "i": ed.putInt(key, item.optInt("v")); break;
                        case "l": ed.putLong(key, item.optLong("v")); break;
                        case "f": ed.putFloat(key, (float) item.optDouble("v")); break;
                        case "b": ed.putBoolean(key, item.optBoolean("v")); break;
                        case "ss":
                            java.util.HashSet<String> set = new java.util.HashSet<>();
                            JSONArray arr = item.optJSONArray("v");
                            if (arr != null) for (int j = 0; j < arr.length(); j++) set.add(arr.optString(j));
                            ed.putStringSet(key, set);
                            break;
                    }
                }
            }
            if (!ed.commit()) throw new IllegalStateException("설정 복원에 실패했습니다: " + prefName);
        }
    }

    private static void restoreMindPtDatabase(Context context, JSONObject dbRoot) throws Exception {
        MindTrainingDbHelper helper = new MindTrainingDbHelper(context.getApplicationContext());
        SQLiteDatabase db = helper.getWritableDatabase();
        db.beginTransaction();
        try {
            for (String table : DB_DELETE_ORDER) db.delete(table, null, null);

            for (String table : DB_TABLES) {
                JSONArray rows = dbRoot.optJSONArray(table);
                if (rows == null) continue;
                for (int i = 0; i < rows.length(); i++) {
                    JSONObject row = rows.optJSONObject(i);
                    if (row == null) continue;
                    ContentValues values = jsonToContentValues(row);
                    long result = db.insertOrThrow(table, null, values);
                    if (result == -1L) throw new IllegalStateException("DB 복원 실패: " + table);
                }
            }
            db.setTransactionSuccessful();
        } finally {
            db.endTransaction();
            helper.close();
        }
    }

    private static ContentValues jsonToContentValues(JSONObject row) throws Exception {
        ContentValues values = new ContentValues();
        JSONArray names = row.names();
        if (names == null) return values;
        for (int i = 0; i < names.length(); i++) {
            String key = names.getString(i);
            Object value = row.opt(key);
            if (value == null || value == JSONObject.NULL) {
                values.putNull(key);
            } else if (value instanceof Boolean) {
                values.put(key, ((Boolean) value) ? 1 : 0);
            } else if (value instanceof Integer) {
                values.put(key, (Integer) value);
            } else if (value instanceof Long) {
                values.put(key, (Long) value);
            } else if (value instanceof Number) {
                Number n = (Number) value;
                double d = n.doubleValue();
                long l = n.longValue();
                if (Math.abs(d - l) < 0.0000001d) values.put(key, l);
                else values.put(key, d);
            } else {
                values.put(key, String.valueOf(value));
            }
        }
        return values;
    }
}
