package com.maeummon.app.clinical;

import android.content.Context;
import org.json.*;

public final class TransitionExplanationCorrectionReconciliationRC13 {
    private TransitionExplanationCorrectionReconciliationRC13(){}

    public enum State {
        NONE,
        CORRECTION_DETECTED,
        CLARIFICATION_REQUIRED,
        CORRECTION_APPLIED,
        CORRECTION_REJECTED
    }

    public static final class Result {
        public boolean evaluated=false;
        public boolean correctionDetected=false;
        public boolean clarificationRequired=false;
        public boolean correctionApplied=false;
        public boolean correctionRejected=false;
        public State state=State.NONE;
        public String priorCause="";
        public String correctedCause="";
        public String correctedReason="";
        public String clarificationQuestion="";
        public String userCorrectionText="";
        public String reason="";
        public String summary="";
    }

    public static Result reconcile(
            Context c,
            ClinicalDecisionRC7 d,
            String userText){

        Result r=new Result();
        if(c==null||d==null){
            r.summary="NONE | MISSING_INPUT";
            return r;
        }

        r.evaluated=true;

        JSONObject session=
                CentralTherapyProfile.loadSessionState(c);

        if(session.optBoolean(
                "pending_transition_explanation_correction",
                false)){
            return resolvePending(c,d,userText,session);
        }

        if(!detectCorrection(userText)){
            r.reason="NO_USER_CORRECTION";
            return finish(r);
        }

        r.correctionDetected=true;
        r.state=State.CORRECTION_DETECTED;
        r.userCorrectionText=compact(userText,300);
        r.priorCause=safe(
                d.decisionTransitionFidelityPrimaryCause);

        String explicitCause=
                inferExplicitCause(userText);

        if(!explicitCause.isEmpty()){
            r.correctedCause=explicitCause;
            r.correctedReason=
                    naturalReason(explicitCause);
            r.correctionApplied=true;
            r.state=State.CORRECTION_APPLIED;
            r.reason="EXPLICIT_USER_CAUSE_CORRECTION";
            persistCorrection(c,d,r,session);
            return finish(r);
        }

        r.clarificationRequired=true;
        r.state=State.CLARIFICATION_REQUIRED;
        r.clarificationQuestion=
                buildClarificationQuestion(
                        r.priorCause);
        r.reason="CORRECTION_WITHOUT_CLEAR_REPLACEMENT";

        try{
            session.put(
                    "pending_transition_explanation_correction",
                    true);
            session.put(
                    "pending_transition_correction_prior_cause",
                    r.priorCause);
            session.put(
                    "pending_transition_correction_user_text",
                    r.userCorrectionText);
            session.put(
                    "pending_transition_correction_question",
                    r.clarificationQuestion);
            session.put(
                    "pending_transition_correction_started_at",
                    System.currentTimeMillis());
            CentralTherapyProfile.replaceSessionState(
                    c,session);
        }catch(Exception ignored){}

        return finish(r);
    }

    public static String instruction(Result r){
        if(r==null||!r.evaluated)return "";

        if(r.state==State.CLARIFICATION_REQUIRED){
            return "TRANSITION_EXPLANATION_CORRECTION=CLARIFY. 사용자가 이전 WHY 설명을 부정했으므로 방어하지 말고 다음 확인 질문 1개만 자연스럽게 한다: "
                    +r.clarificationQuestion;
        }

        if(r.state==State.CORRECTION_APPLIED){
            return "TRANSITION_EXPLANATION_CORRECTION=APPLIED. 이전 전환 원인 설명을 사용자 수정으로 교체하고, 다음 답변에서는 짧게 인정한 뒤 수정된 이유를 사용한다: "
                    +r.correctedReason;
        }

        if(r.state==State.CORRECTION_REJECTED){
            return "TRANSITION_EXPLANATION_CORRECTION=REJECTED. 기존 원인 설명을 유지하되 사용자 부정을 다시 사실처럼 해석하지 않는다.";
        }

        return "";
    }

    public static boolean shouldForceClarification(
            Result r){

        return r!=null
                &&r.clarificationRequired
                &&r.state==State.CLARIFICATION_REQUIRED;
    }

    private static Result resolvePending(
            Context c,
            ClinicalDecisionRC7 d,
            String userText,
            JSONObject session){

        Result r=new Result();
        r.evaluated=true;
        r.correctionDetected=true;
        r.priorCause=session.optString(
                "pending_transition_correction_prior_cause",
                "UNKNOWN");
        r.userCorrectionText=
                compact(userText,300);

        String explicit=inferExplicitCause(userText);

        if(!explicit.isEmpty()){
            r.correctedCause=explicit;
            r.correctedReason=
                    naturalReason(explicit);
            r.correctionApplied=true;
            r.state=State.CORRECTION_APPLIED;
            r.reason="PENDING_CORRECTION_RESOLVED";
            clearPending(session);
            persistCorrection(c,d,r,session);
            return finish(r);
        }

        if(isRejectingCorrection(userText)){
            r.correctionRejected=true;
            r.state=State.CORRECTION_REJECTED;
            r.reason="USER_REJECTED_CAUSE_CHANGE";
            clearPending(session);
            CentralTherapyProfile.replaceSessionState(
                    c,session);
            return finish(r);
        }

        r.clarificationRequired=true;
        r.state=State.CLARIFICATION_REQUIRED;
        r.clarificationQuestion=
                buildClarificationQuestion(
                        r.priorCause);
        r.reason="CORRECTION_STILL_AMBIGUOUS";
        return finish(r);
    }

    private static void persistCorrection(
            Context c,
            ClinicalDecisionRC7 d,
            Result r,
            JSONObject session){

        JSONObject profile=
                CentralTherapyProfile.loadProfile(c);

        try{
            JSONArray history=
                    profile.optJSONArray(
                            "transition_explanation_correction_history");
            if(history==null)history=new JSONArray();

            JSONObject item=new JSONObject();
            item.put("prior_cause",r.priorCause);
            item.put("corrected_cause",
                    r.correctedCause);
            item.put("corrected_reason",
                    r.correctedReason);
            item.put("user_text",
                    r.userCorrectionText);
            item.put("decision_transition_from",
                    safe(d.decisionTransitionFromState));
            item.put("decision_transition_to",
                    safe(d.decisionTransitionToState));
            JSONObject formulation=
                    CentralTherapyProfile.loadFormulation(c);
            item.put("context_scope",
                    formulation.optString("current_context_scope","UNKNOWN"));
            item.put("mechanism",safe(d.centralMechanism));
            item.put("intervention_id",safe(d.selectedInterventionId));
            item.put("correction_context_bound",true);
            item.put("correction_boundary_schema","6.8.4");
            item.put("time",
                    System.currentTimeMillis());

            history.put(item);

            JSONArray trimmed=new JSONArray();
            int start=Math.max(
                    0,history.length()-30);

            for(int i=start;
                    i<history.length();i++)
                trimmed.put(history.opt(i));

            profile.put(
                    "transition_explanation_correction_history",
                    trimmed);
            profile.put(
                    "last_transition_explanation_corrected_cause",
                    r.correctedCause);
            profile.put(
                    "last_transition_explanation_corrected_reason",
                    r.correctedReason);
            profile.put(
                    "last_transition_explanation_correction_at",
                    System.currentTimeMillis());

            CentralTherapyProfile.replaceProfile(
                    c,profile);

            session.put(
                    "last_transition_explanation_corrected_cause",
                    r.correctedCause);
            session.put(
                    "last_transition_explanation_corrected_reason",
                    r.correctedReason);
            session.put(
                    "last_transition_explanation_correction_at",
                    System.currentTimeMillis());

            clearPending(session);
            CentralTherapyProfile.replaceSessionState(
                    c,session);

        }catch(Exception ignored){}
    }

    private static boolean detectCorrection(
            String text){

        String u=text==null?"":text.trim();

        return containsAny(u,
                "아니 그 이유",
                "그게 이유가 아니",
                "그거 때문 아니",
                "내가 말한 건 그게 아니",
                "그렇게 판단한 거 아니",
                "그 뜻이 아니",
                "아니 내가",
                "그렇게 생각한 게 아니",
                "원인은 그게 아니",
                "이유는 그게 아니");
    }

    private static String inferExplicitCause(
            String text){

        String u=text==null?"":text.trim();

        if(containsAny(u,
                "안전","무서워서","위험해서"))
            return "SAFETY_OVERRIDE";

        if(containsAny(u,
                "네가 내 말을 잘못 이해",
                "이해가 안 맞",
                "내 말 제대로 이해"))
            return "ALLIANCE_REPAIR";

        if(containsAny(u,
                "새로 말한 거",
                "방금 말한 내용",
                "새 정보",
                "내가 방금 알려준"))
            return "NEW_USER_EVIDENCE";

        if(containsAny(u,
                "질문 초점",
                "그 질문보다",
                "확인해야 할 게 달라"))
            return "TARGET_INFORMATION_GAIN";

        if(containsAny(u,
                "생각해보니 결과가 달라",
                "아까 결과 수정",
                "결과를 바꿔"))
            return "OUTCOME_REVISION";

        if(containsAny(u,
                "해본 결과",
                "해보니까",
                "효과가 없",
                "오히려 더"))
            return "INTERVENTION_OUTCOME_ADAPTATION";

        if(containsAny(u,
                "기존 생각이 틀",
                "가설이 안 맞",
                "다시 봐야"))
            return "FORMULATION_REOPEN";

        return "";
    }

    private static boolean isRejectingCorrection(
            String text){

        String u=text==null?"":text.trim();

        return containsAny(u,
                "그냥 됐어",
                "아니 원래대로",
                "기존 설명이 맞",
                "바꾸지 마",
                "수정 안 해도 돼");
    }

    private static String buildClarificationQuestion(
            String priorCause){

        if("NEW_USER_EVIDENCE".equals(priorCause))
            return "그럼 방향이 바뀐 핵심 이유는 방금 새로 말한 내용 때문이 아니라, 다른 어떤 점 때문이었어?";

        if("POLICY_MEMORY_SUPPORT".equals(priorCause))
            return "그럼 예전 비슷한 경험 때문이 아니라, 지금 상황에서 어떤 점이 방향을 바꾸게 했다고 느껴?";

        if("OUTCOME_REVIEW".equals(priorCause))
            return "그럼 방금 해본 방법의 결과 때문이 아니라, 어떤 점 때문에 지금 방향이 달라졌다고 보는 게 맞아?";

        return "내 설명에서 틀린 핵심이 뭐였어? 방향이 바뀐 이유를 한 가지만 말해줄래?";
    }

    private static String naturalReason(
            String cause){

        if("SAFETY_OVERRIDE".equals(cause))
            return "지금은 안전과 안정화를 우선해야 해서 방향이 바뀐 거야.";

        if("ALLIANCE_REPAIR".equals(cause))
            return "내가 네 말을 정확히 이해했는지 다시 맞추는 게 먼저라서 방향을 조정한 거야.";

        if("NEW_USER_EVIDENCE".equals(cause))
            return "방금 새로 나온 정보가 이전 판단의 우선순위를 바꿔서 방향이 달라진 거야.";

        if("TARGET_INFORMATION_GAIN".equals(cause))
            return "상담 방향을 더 크게 가를 정보가 보여서 확인할 초점을 바꾼 거야.";

        if("OUTCOME_REVISION".equals(cause))
            return "직전 시도의 결과를 새롭게 수정했기 때문에 이전 판단을 다시 조정한 거야.";

        if("INTERVENTION_OUTCOME_ADAPTATION".equals(cause))
            return "직전 방법을 실제로 해본 결과를 반영해서 다음 개입을 조정한 거야.";

        if("FORMULATION_REOPEN".equals(cause))
            return "새 정보가 기존 해석과 잘 맞지 않아서 이전 결론을 다시 열어본 거야.";

        return "네가 바로잡아준 내용을 기준으로 전환 이유를 다시 잡았어.";
    }

    private static void clearPending(
            JSONObject session){

        try{
            session.put(
                    "pending_transition_explanation_correction",
                    false);
            session.remove(
                    "pending_transition_correction_prior_cause");
            session.remove(
                    "pending_transition_correction_user_text");
            session.remove(
                    "pending_transition_correction_question");
        }catch(Exception ignored){}
    }

    private static boolean containsAny(
            String s,String... xs){

        if(s==null)return false;

        for(String x:xs)
            if(x!=null&&!x.isEmpty()
                    &&s.contains(x))
                return true;

        return false;
    }

    private static String compact(
            String s,int max){

        s=s==null?"":s.trim();

        return s.length()<=max
                ?s
                :s.substring(0,max);
    }

    private static Result finish(Result r){
        r.summary=r.state.name()
                +" | detected="+r.correctionDetected
                +" | clarification="+r.clarificationRequired
                +" | applied="+r.correctionApplied
                +" | rejected="+r.correctionRejected
                +" | prior="+r.priorCause
                +" | corrected="+r.correctedCause
                +" | reason="+r.reason;

        return r;
    }

    private static String safe(String s){
        return s==null?"":s;
    }
}
