package com.maeummon.app.clinical;

import android.content.Context;
import org.json.*;

public final class CorrectionProvenanceRequarantineCooldownRC14 {
    private CorrectionProvenanceRequarantineCooldownRC14(){}

    public enum State {
        NONE,
        COOLDOWN_ACTIVE,
        REVALIDATION_ACCUMULATING,
        COOLDOWN_RELEASED,
        LOOP_BLOCKED
    }

    public static final class Result {
        public boolean evaluated=false;
        public boolean cooldownActive=false;
        public boolean released=false;
        public boolean loopBlocked=false;
        public State state=State.NONE;
        public String transitionKey="";
        public String quarantinedCause="";
        public String currentCause="";
        public int cleanConfirmations=0;
        public int contradictions=0;
        public long lastRequarantinedAt=0L;
        public String reason="";
        public String summary="";
    }

    public static Result evaluate(
            Context c,
            ClinicalDecisionRC7 d){

        Result r=new Result();

        if(c==null||d==null){
            r.summary="NONE | MISSING_INPUT";
            return r;
        }

        r.evaluated=true;

        JSONObject p=
                CentralTherapyProfile.loadProfile(c);

        JSONArray provenance=
                p.optJSONArray(
                        "transition_correction_commit_provenance_history");

        if(provenance==null||provenance.length()==0){
            r.reason="NO_PROVENANCE_HISTORY";
            return finish(r);
        }

        JSONObject f=
                CentralTherapyProfile.loadFormulation(c);

        String context=
                f.optString(
                        "current_context_scope",
                        "UNKNOWN");

        r.transitionKey=
                safe(d.decisionTransitionFromState)
                +"->"
                +safe(d.decisionTransitionToState)
                +"::"
                +context;

        JSONObject newestRequarantined=null;

        for(int i=provenance.length()-1;i>=0;i--){
            JSONObject row=provenance.optJSONObject(i);
            if(row==null)continue;

            if(!r.transitionKey.equals(
                    row.optString("transition_key","")))
                continue;

            long at=
                    row.optLong(
                            "correction_provenance_requarantined_at",
                            0L);

            if(at<=0L)continue;

            newestRequarantined=row;
            r.lastRequarantinedAt=at;
            r.quarantinedCause=
                    row.optString(
                            "corrected_cause",
                            "");
            break;
        }

        if(newestRequarantined==null){
            r.reason="NO_MATCHING_REQUARANTINE";
            return finish(r);
        }

        long now=System.currentTimeMillis();
        long minimumCooldown=
                14L*24L*60L*60L*1000L;

        r.currentCause=
                safe(
                    d.transitionExplanationCorrectedCause);

        r.cleanConfirmations=
                CooldownCleanConfirmationEvidenceLedgerRC14.countClean(
                        c,r.transitionKey,r.quarantinedCause);

        r.contradictions=
                CooldownCleanConfirmationEvidenceLedgerRC14.countContradictions(
                        c,r.transitionKey,r.quarantinedCause);

        boolean timeReleased=
                (now-r.lastRequarantinedAt)
                >=minimumCooldown;

        CooldownEvidenceTemporalDiversityMultiDayRC14.Result temporalDiversity =
                CooldownEvidenceTemporalDiversityMultiDayRC14.evaluate(
                        c,r.transitionKey,r.quarantinedCause);

        boolean evidenceReleased=
                r.cleanConfirmations>=3
                &&r.contradictions==0
                &&CooldownEvidenceTemporalDiversityMultiDayRC14
                    .releaseEligible(temporalDiversity);

        if(r.contradictions>0){
            r.cooldownActive=true;
            r.loopBlocked=true;
            r.state=State.LOOP_BLOCKED;
            r.reason="CONTRADICTION_DURING_COOLDOWN";

        }else if(timeReleased&&evidenceReleased){
            r.released=true;
            r.state=State.COOLDOWN_RELEASED;
            r.reason="TIME_AND_CLEAN_CONFIRMATION_THRESHOLD_MET";

        }else if(r.cleanConfirmations>0){
            r.cooldownActive=true;
            r.state=State.REVALIDATION_ACCUMULATING;
            r.reason="WAITING_FOR_COOLDOWN_RELEASE_THRESHOLD";

        }else{
            r.cooldownActive=true;
            r.state=State.COOLDOWN_ACTIVE;
            r.reason="REQUARANTINE_COOLDOWN_ACTIVE";
        }

        try{
            p.put(
                "last_requarantine_cooldown_state",
                r.state.name());

            p.put(
                "last_requarantine_cooldown_transition",
                r.transitionKey);

            p.put(
                "last_requarantine_cooldown_confirmations",
                r.cleanConfirmations);

            p.put(
                "last_requarantine_cooldown_contradictions",
                r.contradictions);

            p.put(
                "last_requarantine_cooldown_at",
                now);

            CentralTherapyProfile.replaceProfile(c,p);
        }catch(Exception ignored){}

        return finish(r);
    }

    public static boolean blocksReinstatement(
            Result r){

        return r!=null
                &&(r.state==State.COOLDOWN_ACTIVE
                    ||r.state==State.REVALIDATION_ACCUMULATING
                    ||r.state==State.LOOP_BLOCKED);
    }

    public static String instruction(Result r){
        if(r==null||!r.evaluated)return "";

        if(r.state==State.COOLDOWN_ACTIVE)
            return "REQUARANTINE_COOLDOWN=ACTIVE. 최근 다시 격리된 correction provenance는 즉시 재복구하지 않는다.";

        if(r.state==State.REVALIDATION_ACCUMULATING)
            return "REQUARANTINE_COOLDOWN=ACCUMULATING. 같은 사용자 교정이 다시 확인되고 있지만 시간/반복 기준이 모두 충족될 때까지 재복구를 막는다.";

        if(r.state==State.LOOP_BLOCKED)
            return "REQUARANTINE_COOLDOWN=LOOP_BLOCKED. cooldown 중 다시 모순이 생겨 격리↔복구 반복을 차단한다.";

        if(r.state==State.COOLDOWN_RELEASED)
            return "REQUARANTINE_COOLDOWN=RELEASED. 최소 cooldown과 깨끗한 반복 확인 기준을 모두 충족해 재검토 가능하다.";

        return "";
    }

    private static Result finish(Result r){
        r.summary=
                r.state.name()
                +" | transition="+r.transitionKey
                +" | quarantinedCause="+r.quarantinedCause
                +" | currentCause="+r.currentCause
                +" | confirmations="+r.cleanConfirmations
                +" | contradictions="+r.contradictions
                +" | cooldownActive="+r.cooldownActive
                +" | released="+r.released
                +" | loopBlocked="+r.loopBlocked
                +" | reason="+r.reason;

        return r;
    }

    private static String safe(String s){
        return s==null?"":s;
    }
}
