package com.maeummon.app;

import android.content.Context;
import java.util.Locale;

/**
 * v5.2 Session Continuity layer.
 *
 * Distinguishes finishing one response from finishing the counseling topic.
 * A good insight is not automatically a session close. When the user reveals
 * a new high-impact fear/meaning or an important formulation gap remains, the
 * counselor stays with the same thread and follows it one layer deeper.
 */
public final class SessionContinuityV52 {
    private SessionContinuityV52() {}

    public static String buildContext(Context c, String userMessage) {
        String t = userMessage == null ? "" : userMessage.toLowerCase(Locale.KOREA);
        boolean action = has(t, "어떻게 해", "어케해", "그래서 뭐", "뭐라고", "하면 돼", "해야 해", "방법", "말해볼까");
        boolean newFear = has(t, "무서", "두려", "불안", "싫어할", "미워할", "멀어질", "버려", "화낼", "표정", "반응");
        boolean insightSignal = has(t, "아하", "아 그렇", "맞아", "그런 것 같", "그게", "그러네");
        boolean close = has(t, "오늘은 여기", "그만", "정리해줘", "마무리", "이제 됐", "고마워 끝");

        StringBuilder b = new StringBuilder();
        b.append("[SESSION CONTINUITY v5.2]\n");
        b.append("이번 메시지 힌트: new_fear_or_reaction=").append(newFear)
         .append(", wants_action=").append(action)
         .append(", insight_signal=").append(insightSignal)
         .append(", explicit_close=").append(close).append(".\n");
        b.append("- 가장 중요한 구분: RESPONSE_END(이번 답변의 마침표)와 TOPIC_CLOSE(이 상담 주제 종료)는 다르다. 좋은 핵심문장을 말했다고 상담주제를 자동 종료하지 않는다.\n");
        b.append("- 사용자가 직전 답변 뒤 새 두려움/의미/상대반응을 말하면 NEW MATERIAL로 취급한다. 특히 그 정보가 왜 행동을 못 하는지 설명력을 높이면 TURNING_POINT 또는 FORMULATION_GAP 후보이며 같은 주제를 계속 붙든다.\n");
        b.append("- TOPIC_OPEN 조건: 핵심 두려움/의미가 아직 불명확, 새 정보가 기존 가설을 바꿈, 답에 따라 개입이 달라지는 빈칸이 남음, 사용자가 더 말하고 있음. 이때는 해석 한 문장으로 닫지 말고 공감→업데이트된 이해→고가치 질문 1개까지 자연스럽게 이어갈 수 있다.\n");
        b.append("- TOPIC_CLOSE 조건: 사용자가 명시적으로 마무리/정리를 원함, 핵심 구조가 충분히 확인됨 + 사용자가 행동/결정을 원함, 같은 질문이 반복되고 새 정보가 없음, 안전/안정화 때문에 탐색을 멈춰야 함.\n");
        b.append("- 질문은 '상담을 계속하기 위해 아무 질문이나'가 아니다. 답에 따라 formulation/개입이 달라지는 질문만 1개. 저가치면 질문 없이 따뜻한 마침표로 둔다.\n");
        b.append("- FORMULATE와 CONTINUE는 함께 가능하다. 실제 상담처럼 '내가 지금 듣기엔 X에 가까워 보여. 그런데 Y가 가장 무섭다고 했잖아. 그 순간 제일 먼저 떠오르는 건 A야, B야?'처럼 이미 잡은 이해를 발판으로 한 층 더 간다.\n");
        b.append("- INTERVENE 단계에서는 이미 충분히 탐색된 주제를 다시 캐묻지 않는다. 행동을 해본 뒤에는 다음 턴 REVIEW로 이어간다.\n");
        b.append("- 같은 주제의 연결어를 사용한다: '아까 말한...', '방금 말한 그 부분이...', '여기서 하나 더 보이는 건...'. 단 억지로 매번 쓰지 않는다.\n");
        return b.toString();
    }

    public static String prompt() {
        return "[SESSION CONTINUITY v5.2] 한 답변을 끝내는 것과 상담 주제를 끝내는 것을 구분한다. "
                + "새로운 핵심 두려움/의미/상대반응이 나오거나 답에 따라 formulation/개입이 바뀌는 빈칸이 남으면 TOPIC_OPEN으로 같은 줄기를 이어간다. "
                + "이때 FORMULATE 뒤에도 고가치 질문 하나를 자연스럽게 붙일 수 있다. 반대로 구조가 충분하고 사용자가 행동/결정/마무리를 원하면 TOPIC_CLOSE로 질문을 만들지 않는다. "
                + "상담 지속을 위한 질문 자체가 목적이 아니며, 질문은 반드시 방향을 바꾸는 정보만 묻는다.";
    }

    private static boolean has(String t, String... xs) {
        for (String x : xs) if (t.contains(x.toLowerCase(Locale.KOREA))) return true;
        return false;
    }
}
