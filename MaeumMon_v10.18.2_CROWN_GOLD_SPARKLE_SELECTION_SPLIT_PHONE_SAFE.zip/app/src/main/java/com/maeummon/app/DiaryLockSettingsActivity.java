package com.maeummon.app;

import android.app.Activity;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class DiaryLockSettingsActivity extends Activity {

    private EditText pinInput;
    private TextView status;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_diary_lock_settings);
        UiInsets.apply(this, findViewById(R.id.lockSettingsRoot));

        pinInput = findViewById(R.id.newPinInput);
        status = findViewById(R.id.lockStatusText);

        findViewById(R.id.savePinButton).setOnClickListener(v -> savePin());
        findViewById(R.id.removePinButton).setOnClickListener(v -> {
            DiarySecurity.clearPin(this);
            refresh();
            Toast.makeText(this, "마음일기 잠금을 해제했어.", Toast.LENGTH_SHORT).show();
        });
        findViewById(R.id.lockNowButton).setOnClickListener(v -> {
            DiarySecurity.lockNow(this);
            Toast.makeText(this, "마음일기를 지금 잠갔어.", Toast.LENGTH_SHORT).show();
        });

        refresh();
    }

    private void savePin() {
        String pin = pinInput.getText().toString().trim();
        if (!pin.matches("\\d{4}")) {
            Toast.makeText(this, "숫자 4자리로 입력해줘.", Toast.LENGTH_SHORT).show();
            return;
        }

        DiarySecurity.setPin(this, pin);
        pinInput.setText("");
        refresh();
        Toast.makeText(this, "마음일기 PIN을 저장했어 🔐", Toast.LENGTH_SHORT).show();
    }

    private void refresh() {
        status.setText(DiarySecurity.isEnabled(this)
                ? "현재 잠금: 켜짐 🔒"
                : "현재 잠금: 꺼짐 🔓");
    }
}
