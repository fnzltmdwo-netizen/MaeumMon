package com.maeummon.app;

import android.content.Context;
import android.content.SharedPreferences;

public class PetStateManager {
    private static final String PREF = "maeummon_pet_state";
    private static final String K_MOOD = "mood";
    private static final String K_ENERGY = "energy";
    private static final String K_CALM = "calm";
    private static final String K_LONELY = "lonely";
    private static final String K_LAST = "last_tick";
    private static final String K_LAST_SEEN = "last_seen";

    public static class State {
        public final int mood;
        public final int energy;
        public final int calm;
        public final int lonely;
        State(int mood, int energy, int calm, int lonely) {
            this.mood = mood; this.energy = energy; this.calm = calm; this.lonely = lonely;
        }
    }

    private static SharedPreferences p(Context c) {
        return c.getSharedPreferences(PREF, Context.MODE_PRIVATE);
    }

    public static synchronized State get(Context c) {
        tick(c);
        SharedPreferences sp=p(c);
        return new State(sp.getInt(K_MOOD,72), sp.getInt(K_ENERGY,68), sp.getInt(K_CALM,70), sp.getInt(K_LONELY,25));
    }

    public static synchronized void tick(Context c) {
        SharedPreferences sp=p(c);
        long now=System.currentTimeMillis();
        long last=sp.getLong(K_LAST, now);
        if (!sp.contains(K_LAST)) {
            sp.edit().putLong(K_LAST, now).putLong(K_LAST_SEEN, now).apply();
            return;
        }
        long hours=Math.max(0L,(now-last)/(60L*60L*1000L));
        if (hours < 1) return;
        int steps=(int)Math.min(24,hours);
        int mood=sp.getInt(K_MOOD,72);
        int energy=sp.getInt(K_ENERGY,68);
        int calm=sp.getInt(K_CALM,70);
        int lonely=sp.getInt(K_LONELY,25);
        java.util.Calendar cal=java.util.Calendar.getInstance();
        int hour=cal.get(java.util.Calendar.HOUR_OF_DAY);
        if (hour>=23 || hour<7) energy=clamp(energy+steps*2); else energy=clamp(energy-steps);
        calm=clamp(calm + (hour>=22 || hour<8 ? steps : 0));
        lonely=clamp(lonely + steps);
        mood=clamp(mood - Math.max(0,steps/3));
        sp.edit().putInt(K_MOOD,mood).putInt(K_ENERGY,energy).putInt(K_CALM,calm).putInt(K_LONELY,lonely).putLong(K_LAST,now).apply();
    }

    public static synchronized void markSeen(Context c) {
        State s=get(c);
        p(c).edit().putInt(K_LONELY,clamp(s.lonely-5)).putInt(K_MOOD,clamp(s.mood+1)).putLong(K_LAST_SEEN,System.currentTimeMillis()).apply();
    }

    public static synchronized void onCheckIn(Context c, int score) {
        State s=get(c);
        int mood=s.mood + (score-3)*6;
        int calm=s.calm + (score>=3 ? 3 : -3);
        p(c).edit().putInt(K_MOOD,clamp(mood)).putInt(K_CALM,clamp(calm)).putInt(K_LONELY,clamp(s.lonely-7)).apply();
    }

    public static synchronized void onDiarySaved(Context c, String label) {
        State s=get(c);
        int calm=s.calm+5, mood=s.mood+2;
        if ("불안".equals(label)) calm-=7;
        if ("슬픔".equals(label)) mood-=7;
        if ("지침".equals(label) || "잠옴".equals(label)) {
            p(c).edit().putInt(K_ENERGY,clamp(s.energy-8)).putInt(K_CALM,clamp(calm)).putInt(K_MOOD,clamp(mood)).putInt(K_LONELY,clamp(s.lonely-6)).apply();
            return;
        }
        if ("좋음".equals(label)) mood+=7;
        p(c).edit().putInt(K_CALM,clamp(calm)).putInt(K_MOOD,clamp(mood)).putInt(K_LONELY,clamp(s.lonely-6)).apply();
    }

    public static synchronized void setFromContext(Context c, int mood, int energy, int calm, int lonely) {
        p(c).edit()
                .putInt(K_MOOD, clamp(mood))
                .putInt(K_ENERGY, clamp(energy))
                .putInt(K_CALM, clamp(calm))
                .putInt(K_LONELY, clamp(lonely))
                .putLong(K_LAST, System.currentTimeMillis())
                .apply();
    }

    public static synchronized void onTodoSaved(Context c, boolean allDone) {
        State s=get(c);
        p(c).edit().putInt(K_MOOD,clamp(s.mood+(allDone?5:1))).putInt(K_CALM,clamp(s.calm+(allDone?4:1))).apply();
    }

    public static String summary(Context c) {
        State s=get(c);
        return "기분 " + iconMood(s.mood) + " " + s.mood + "   ·   에너지 ⚡ " + s.energy + "\n"
                + "안정감 🌿 " + s.calm + "   ·   외로움 🫧 " + s.lonely;
    }

    public static String dominantNeed(Context c) {
        State s=get(c);
        if (s.energy<=32) return "rest";
        if (s.calm<=38) return "calm";
        if (s.lonely>=68) return "company";
        if (s.mood<=38) return "comfort";
        return "okay";
    }

    public static String proactiveLine(Context c) {
        String ptLine = CentralMindPtState.mascotLine(c);
        if (ptLine != null && !ptLine.trim().isEmpty()) return ptLine;
        State s=get(c);
        int hour=java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY);
        String need=dominantNeed(c);
        if (hour>=0 && hour<6) return "승재야, 이 시간엔 마음이 더 크게 흔들릴 수 있어. 지금 결론 내리지 말고, 잠드는 쪽으로 가도 돼.";
        if (hour>=6 && hour<11) {
            if (s.energy<45) return "좋은 아침이야. 아직 몸이 덜 깼다면, 오늘은 속도를 조금 낮춰도 괜찮아.";
            return "좋은 아침이야, 승재야. 오늘은 잘하려고 애쓰기보다 한 가지씩만 해보자.";
        }
        if (hour>=11 && hour<14) return "승재야, 점심은 챙겼어? 마음 보기 전에 몸부터 조금 채워주자.";
        if (hour>=18 && hour<23) {
            if ("calm".equals(need)) return "오늘 마음이 팽팽했지? 지금은 답 찾기보다 먼저 풀어주는 쪽으로 가도 돼.";
            return "오늘도 여기까지 오느라 애썼어. 남은 시간만큼은 조금 덜 빡빡하게 보내자.";
        }
        if ("rest".equals(need)) return "승재야, 지금은 힘을 더 짜내기보다 잠깐 쉬는 게 더 도움 될 것 같아.";
        if ("company".equals(need)) return "승재야, 오늘은 내가 먼저 와봤어. 혼자 있는 느낌이 들면 한마디만 해도 돼.";
        if ("comfort".equals(need)) return "오늘 마음이 가라앉아 있구나. 이유를 다 찾지 않아도 돼. 내가 옆에 있을게.";
        return "승재야, 잠깐 들렀어 :) 오늘은 지금까지 어땠어?";
    }

    public static AnimatedYoungSeungjaeView.State recommendedAnimation(Context c) {
        State s=get(c);
        int h=java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY);
        if (h>=23 || h<6 || s.energy<25) return AnimatedYoungSeungjaeView.State.SLEEP;
        if (s.calm<35) return AnimatedYoungSeungjaeView.State.SIT;
        if (s.lonely>70) return AnimatedYoungSeungjaeView.State.WAVE;
        if (s.mood>82 && s.energy>55) return AnimatedYoungSeungjaeView.State.JUMP;
        if (s.energy<42) return AnimatedYoungSeungjaeView.State.SIT;
        return AnimatedYoungSeungjaeView.State.IDLE;
    }

    private static String iconMood(int v) { if(v>=75)return "😊"; if(v>=50)return "🙂"; if(v>=30)return "😮‍💨"; return "🥺"; }
    private static int clamp(int v){return Math.max(0,Math.min(100,v));}
}
