package com.maeummon.app.clinical;

import java.util.*;
import org.json.JSONArray;
import org.json.JSONObject;

/** v6.0.4: deterministic counseling response quality gate for QA diagnostics. */
public final class ClinicalResponseQualityRC7 {
    private ClinicalResponseQualityRC7(){}

    public static final class Result {
        public final int score;
        public final String grade;
        public final List<String> issues;
        public final List<String> strengths;
        public Result(int score,String grade,List<String> issues,List<String> strengths){
            this.score=score; this.grade=grade; this.issues=issues; this.strengths=strengths;
        }
        public JSONObject toJson(){
            JSONObject o=new JSONObject();
            try{
                o.put("score",score); o.put("grade",grade);
                o.put("issues",new JSONArray(issues)); o.put("strengths",new JSONArray(strengths));
            }catch(Exception ignored){}
            return o;
        }
    }

    public static Result evaluate(String userText,String reply,ClinicalDecisionRC7 d){
        String u=safe(userText).trim();
        String r=safe(reply).trim();
        List<String> issues=new ArrayList<>();
        List<String> strengths=new ArrayList<>();
        int score=100;

        if(r.isEmpty()){
            return new Result(0,"FAIL",Arrays.asList("EMPTY_REPLY"),Collections.<String>emptyList());
        }

        int questions=countChar(r,'?') + countKoreanQuestionEndings(r);
        int sentences=sentenceCount(r);
        int len=r.length();

        // Global quality checks.
        if(len>900){ score-=16; issues.add("TOO_LONG"); }
        else if(len>650){ score-=8; issues.add("LONG_REPLY"); }
        else strengths.add("CONCISE_ENOUGH");

        if(hasRepetitiveMeaning(r)){ score-=14; issues.add("REPETITIVE_MEANING"); }
        if(hasGenericValidationStack(r)){ score-=14; issues.add("GENERIC_VALIDATION_STACK"); }
        if(hasDiagnosticOverclaim(r)){ score-=22; issues.add("DIAGNOSIS_OVERCLAIM"); }
        if(hasIntentOverclaim(r)){ score-=16; issues.add("OTHER_INTENT_OVERCLAIM"); }
        if(hasCharacterJudgment(r)){ score-=18; issues.add("CHARACTER_LABELING"); }

        if(d!=null){
            String move=safe(d.move);
            if("ASK".equals(move)){
                if(questions!=1){ score-=Math.min(35,12+Math.abs(questions-1)*8); issues.add("ASK_NOT_EXACTLY_ONE_QUESTION"); }
                else strengths.add("ONE_QUESTION_ONLY");
                if(sentences>3 || len>280){ score-=14; issues.add("ASK_HAS_EXTRA_ANALYSIS"); }
                if(containsAdvice(r)){ score-=18; issues.add("ASK_CONTAINS_ADVICE"); }
            } else if("FORMULATE".equals(move)){
                if(questions>1){ score-=12; issues.add("FORMULATE_QUESTION_OVERLOAD"); }
                if(sentences>6){ score-=10; issues.add("FORMULATE_TOO_LONG"); }
                if(hasPrematureCertainty(r)){ score-=15; issues.add("FORMULATE_OVERCONFIDENT"); }
                else strengths.add("HYPOTHESIS_LANGUAGE");
            } else if("INTERVENE".equals(move)){
                int advice=countAdviceMarkers(r);
                if(advice>3){ score-=16; issues.add("TOO_MANY_ACTIONS"); }
                if(questions>1){ score-=10; issues.add("INTERVENE_QUESTION_OVERLOAD"); }
                if(sentences>6){ score-=10; issues.add("INTERVENE_TOO_LONG"); }
                if(advice>=1) strengths.add("ACTIONABLE");
            } else if("ALLIANCE_REPAIR".equals(move)){
                if(containsDefensiveTherapistLanguage(r)){ score-=30; issues.add("THERAPIST_DEFENSIVENESS"); }
                if(questions>1){ score-=12; issues.add("REPAIR_QUESTION_OVERLOAD"); }
                if(len>360){ score-=10; issues.add("REPAIR_TOO_LONG"); }
                if(containsRepairLanguage(r)) strengths.add("REPAIR_ORIENTED");
            } else if("STABILIZE".equals(move)){
                if(hasDeepAnalysisLanguage(r)){ score-=22; issues.add("SAFETY_TURN_OVERANALYZED"); }
                if(len>420){ score-=12; issues.add("SAFETY_REPLY_TOO_LONG"); }
                if(questions>2){ score-=12; issues.add("SAFETY_QUESTION_OVERLOAD"); }
                strengths.add("SAFETY_PRIORITY");
            }
        }

        // Fact vs interpretation discipline: warn when assistant states speculative intent as fact.
        if(mentionsUserInterpretationAsFact(u,r)){ score-=14; issues.add("FACT_INTERPRETATION_MERGE"); }

        score=Math.max(0,Math.min(100,score));
        String grade=score>=90?"PASS":(score>=75?"WARN":"FAIL");
        return new Result(score,grade,issues,strengths);
    }

    private static boolean containsAdvice(String s){
        return countAdviceMarkers(s)>0;
    }
    private static int countAdviceMarkers(String s){
        String[] xs={"해봐","해보자","하는 게 좋아","해야 해","하지 마","적어봐","말해봐","보내봐","연습해","시도해"};
        int n=0; for(String x:xs) if(s.contains(x)) n++; return n;
    }
    private static boolean hasGenericValidationStack(String s){
        String[] xs={"힘들었겠다","속상했겠다","많이 힘들","그랬구나","이해돼","충분히 그럴 수"};
        int n=0; for(String x:xs) if(s.contains(x)) n++; return n>=3;
    }
    private static boolean hasDiagnosticOverclaim(String s){
        String[] xs={"너는 우울증이야","공황장애야","애착장애야","성격장애야","ADHD라서 그래","진단은"};
        for(String x:xs) if(s.contains(x)) return true; return false;
    }
    private static boolean hasIntentOverclaim(String s){
        String[] xs={"상대가 널 무시한 거야","널 싫어해서","일부러 그런 거야","마음이 식은 거야","널 버리려는"};
        for(String x:xs) if(s.contains(x)) return true; return false;
    }
    private static boolean hasCharacterJudgment(String s){
        String[] xs={"넌 원래 이기적","너는 집착형","너는 의존적","넌 약한 사람","성격이 문제"};
        for(String x:xs) if(s.contains(x)) return true; return false;
    }
    private static boolean hasPrematureCertainty(String s){
        String[] xs={"분명히","확실히","틀림없이","100%","무조건"};
        for(String x:xs) if(s.contains(x)) return true; return false;
    }
    private static boolean containsDefensiveTherapistLanguage(String s){
        String[] xs={"내 의도는 그게 아니었어","내가 맞게 말한 거야","네가 오해한 거야","나는 잘못한 게 없어"};
        for(String x:xs) if(s.contains(x)) return true; return false;
    }
    private static boolean containsRepairLanguage(String s){
        String[] xs={"어긋","답답","맞출게","어떤 부분","방향","질문 방식","원하는"};
        for(String x:xs) if(s.contains(x)) return true; return false;
    }
    private static boolean hasDeepAnalysisLanguage(String s){
        String[] xs={"핵심신념","애착","스키마","인지왜곡","유지요인","과거 경험 때문에"};
        for(String x:xs) if(s.contains(x)) return true; return false;
    }
    private static boolean hasRepetitiveMeaning(String s){
        String[] parts=s.split("[.!?\\n]+");
        List<String> clean=new ArrayList<>();
        for(String p:parts){ String q=normalize(p); if(q.length()>=8) clean.add(q); }
        for(int i=0;i<clean.size();i++) for(int j=i+1;j<clean.size();j++){
            String a=clean.get(i),b=clean.get(j);
            if(a.equals(b)) return true;
            if(a.length()>12&&b.length()>12){
                String shortA=a.length()>20?a.substring(0,20):a;
                String shortB=b.length()>20?b.substring(0,20):b;
                if(shortA.equals(shortB)) return true;
            }
        }
        return false;
    }
    private static boolean mentionsUserInterpretationAsFact(String user,String reply){
        boolean ambiguous=user.contains("것 같")||user.contains("싶어")||user.contains("모르겠")||user.contains("혹시");
        if(!ambiguous) return false;
        String[] asserted={"그래서 널 싫어하는 거야","그래서 무시하는 거야","상대가 일부러","마음이 식은 게 맞아"};
        for(String x:asserted) if(reply.contains(x)) return true;
        return false;
    }
    private static int countKoreanQuestionEndings(String s){
        int n=0; String[] xs={"야?","어?","까?","니?","지?"};
        for(String x:xs){ int from=0; while((from=s.indexOf(x,from))>=0){n++;from+=x.length();} }
        // '?' already counted globally; avoid excessive double-counting.
        return Math.max(0,n-countChar(s,'?'));
    }
    private static int countChar(String s,char c){int n=0;for(int i=0;i<s.length();i++)if(s.charAt(i)==c)n++;return n;}
    private static int sentenceCount(String s){
        String[] p=s.split("[.!?\\n]+"); int n=0; for(String x:p)if(!x.trim().isEmpty())n++; return Math.max(1,n);
    }
    private static String normalize(String s){return safe(s).replaceAll("\\s+","").replace("정말","").replace("너무","");}
    private static String safe(String s){return s==null?"":s;}
}
