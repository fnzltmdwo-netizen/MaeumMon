package com.maeummon.app.clinical;

import android.content.Context;
import org.json.*;

public final class ProvenanceIntegrityValidationBackfillGateRC12 {
    private ProvenanceIntegrityValidationBackfillGateRC12(){}

    public enum RowState {
        VALID,
        REPAIRED,
        QUARANTINED,
        LEGACY_UNRESOLVED
    }

    public static final class Result {
        public boolean evaluated=false;
        public boolean repaired=false;
        public boolean quarantined=false;
        public int rowsChecked=0;
        public int rowsRepaired=0;
        public int rowsQuarantined=0;
        public int legacyUnresolved=0;
        public String reason="";
        public String summary="";
    }

    public static Result validateAndBackfill(Context c,ClinicalDecisionRC7 d){
        Result r=new Result();
        if(c==null||d==null){
            r.summary="NO_EVALUATION | NO_CONTEXT_OR_DECISION";
            return r;
        }

        JSONObject p=CentralTherapyProfile.loadProfile(c);
        JSONObject f=CentralTherapyProfile.loadFormulation(c);

        r.evaluated=true;

        validateArray(
                p.optJSONArray("micro_experiment_outcome_commit_history"),
                p,f,d,r);

        validateArray(
                p.optJSONArray("outcome_commit_idempotency_history"),
                p,f,d,r);

        validateArray(
                p.optJSONArray("cross_context_transfer_history"),
                p,f,d,r);

        try{
            p.put("last_provenance_integrity_rows_checked",r.rowsChecked);
            p.put("last_provenance_integrity_rows_repaired",r.rowsRepaired);
            p.put("last_provenance_integrity_rows_quarantined",r.rowsQuarantined);
            p.put("last_provenance_integrity_legacy_unresolved",r.legacyUnresolved);
            p.put("last_provenance_integrity_at",System.currentTimeMillis());

            CentralTherapyProfile.replaceProfile(c,p);
        }catch(Exception e){
            r.quarantined=true;
            r.reason="PROVENANCE_INTEGRITY_SUMMARY_PERSIST_FAILED";
        }

        r.repaired=r.rowsRepaired>0;
        r.quarantined=r.rowsQuarantined>0;

        if(r.quarantined)
            r.reason="INCONSISTENT_ROWS_QUARANTINED";
        else if(r.repaired)
            r.reason="PROVENANCE_BACKFILL_REPAIRED";
        else if(r.legacyUnresolved>0)
            r.reason="LEGACY_ROWS_UNRESOLVED";
        else
            r.reason="ALL_ROWS_VALID";

        r.summary="checked="+r.rowsChecked
                +" | repaired="+r.rowsRepaired
                +" | quarantined="+r.rowsQuarantined
                +" | legacyUnresolved="+r.legacyUnresolved
                +" | reason="+r.reason;

        return r;
    }

    public static boolean rowEligibleForLearning(JSONObject row){
        if(row==null)return false;
        if(row.optBoolean("provenance_quarantined",false))
            return false;
        if("LEGACY_UNRESOLVED".equals(
                row.optString("provenance_integrity_state","")))
            return false;
        return true;
    }

    public static String instruction(Result r){
        if(r==null||!r.evaluated)return "";

        if(r.quarantined){
            return "PROVENANCE_INTEGRITY=QUARANTINED. structured provenance가 서로 모순되는 학습 행은 policy 계산에서 제외하고 감사 정보만 보존한다.";
        }

        if(r.repaired){
            return "PROVENANCE_INTEGRITY=REPAIRED. 누락되거나 오래된 canonical provenance를 현재 구조에 맞게 backfill하고 key를 재계산했다.";
        }

        if(r.legacyUnresolved>0){
            return "PROVENANCE_INTEGRITY=LEGACY_UNRESOLVED. 정확히 매칭할 수 없는 legacy 행은 자동 학습에 사용하지 않고 보존만 한다.";
        }

        return "";
    }

    private static void validateArray(
            JSONArray a,
            JSONObject profile,
            JSONObject formulation,
            ClinicalDecisionRC7 d,
            Result r){

        if(a==null)return;

        try{
            for(int i=0;i<a.length();i++){
                JSONObject x=a.optJSONObject(i);
                if(x==null)continue;

                r.rowsChecked++;

                String exp=x.optString("experiment_id","");
                String mechanism=x.optString("mechanism","");
                String intervention=x.optString("intervention_id","");
                String context=x.optString("context_scope","");
                String key=x.optString("canonical_learning_key","");
                String schema=x.optString("provenance_schema_version","");

                // Legacy unresolved row: no structured identity and cannot safely infer.
                if(intervention.isEmpty()
                        && mechanism.isEmpty()
                        && context.isEmpty()){

                    String activeIntervention=safe(d.selectedInterventionId);

                    if(!activeIntervention.isEmpty()
                            && exp.contains(activeIntervention)){

                        intervention=activeIntervention;
                        mechanism=safe(d.centralMechanism);
                        context=formulation.optString(
                                "current_context_scope","UNKNOWN");

                        x.put("intervention_id",intervention);
                        x.put("mechanism",mechanism);
                        x.put("context_scope",context);
                        x.put("provenance_schema_version","6.7.5");
                        r.rowsRepaired++;
                    }else{
                        x.put("provenance_integrity_state",
                                RowState.LEGACY_UNRESOLVED.name());
                        x.put("provenance_quarantined",true);
                        x.put("provenance_integrity_reason",
                                "LEGACY_IDENTITY_CANNOT_BE_RESOLVED");
                        r.legacyUnresolved++;
                        r.rowsQuarantined++;
                        continue;
                    }
                }

                // Partial structured rows: fill only safe missing fields.
                if(intervention.isEmpty()
                        && !safe(d.selectedInterventionId).isEmpty()
                        && exp.contains(safe(d.selectedInterventionId))){

                    intervention=safe(d.selectedInterventionId);
                    x.put("intervention_id",intervention);
                    r.rowsRepaired++;
                }

                if(mechanism.isEmpty()
                        && intervention.equals(
                                safe(d.selectedInterventionId))){

                    mechanism=safe(d.centralMechanism);
                    x.put("mechanism",mechanism);
                    r.rowsRepaired++;
                }

                if(context.isEmpty()
                        && intervention.equals(
                                safe(d.selectedInterventionId))){

                    context=formulation.optString(
                            "current_context_scope","UNKNOWN");
                    x.put("context_scope",context);
                    r.rowsRepaired++;
                }

                mechanism=x.optString("mechanism","");
                intervention=x.optString("intervention_id","");
                context=x.optString("context_scope","");

                // Impossible/ambiguous partial identity is quarantined.
                if(intervention.isEmpty()
                        || mechanism.isEmpty()
                        || context.isEmpty()){

                    x.put("provenance_integrity_state",
                            RowState.QUARANTINED.name());
                    x.put("provenance_quarantined",true);
                    x.put("provenance_integrity_reason",
                            "INCOMPLETE_STRUCTURED_IDENTITY");
                    r.rowsQuarantined++;
                    continue;
                }

                String expectedKey=buildKey(
                        mechanism,intervention,context,exp);

                // Canonical key is derived data; safely repair mismatch.
                if(key.isEmpty() || !expectedKey.equals(key)){
                    if(!key.isEmpty())
                        x.put("canonical_learning_key_before_repair",key);

                    x.put("canonical_learning_key",expectedKey);
                    x.put("provenance_schema_version","6.7.5");
                    x.put("provenance_key_repaired",true);
                    r.rowsRepaired++;
                }

                // Structured identity contradiction vs same row metadata:
                // GENERAL rows are allowed only when context explicitly says GENERAL.
                if("GENERAL".equals(x.optString("policy_scope",""))
                        && !"GENERAL".equals(context)){

                    x.put("provenance_integrity_state",
                            RowState.QUARANTINED.name());
                    x.put("provenance_quarantined",true);
                    x.put("provenance_integrity_reason",
                            "GENERAL_SCOPE_CONTEXT_CONTRADICTION");
                    r.rowsQuarantined++;
                    continue;
                }

                x.put("provenance_integrity_state",
                        r.rowsRepaired>0
                                ?RowState.REPAIRED.name()
                                :RowState.VALID.name());
                x.put("provenance_quarantined",false);
                x.put("provenance_integrity_checked_at",
                        System.currentTimeMillis());

                if(schema.isEmpty())
                    x.put("provenance_schema_version","6.7.5");
            }
        }catch(Exception e){
            r.rowsQuarantined++;
            r.quarantined=true;
            r.reason="PROVENANCE_ROW_VALIDATION_FAILED";
        }
    }

    private static String buildKey(
            String mechanism,
            String intervention,
            String context,
            String experiment){

        return safe(mechanism)+"::"
                +safe(intervention)+"::"
                +safe(context)+"::"
                +safe(experiment);
    }

    private static String safe(String s){
        return s==null?"":s;
    }
}
