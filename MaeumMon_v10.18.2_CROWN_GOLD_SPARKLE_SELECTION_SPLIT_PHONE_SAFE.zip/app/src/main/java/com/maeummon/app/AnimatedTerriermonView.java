package com.maeummon.app;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.view.View;
import android.view.animation.LinearInterpolator;

public class AnimatedTerriermonView extends View {

    public enum State {
        IDLE, WALK, HAPPY, TALK, SLEEP, SAD, JUMP
    }

    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);

    private float phase = 0f;
    private State state = State.IDLE;
    private boolean facingRight = true;
    private ValueAnimator animator;

    private final int cream = Color.rgb(255, 253, 235);
    private final int creamShadow = Color.rgb(232, 228, 201);
    private final int green = Color.rgb(167, 198, 101);
    private final int greenDark = Color.rgb(112, 143, 62);
    private final int outline = Color.rgb(66, 62, 50);
    private final int cheek = Color.rgb(246, 176, 171);

    public AnimatedTerriermonView(Context context) {
        super(context);
        setLayerType(View.LAYER_TYPE_SOFTWARE, null);

        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeWidth(dp(2.1f));
        stroke.setStrokeCap(Paint.Cap.ROUND);
        stroke.setStrokeJoin(Paint.Join.ROUND);
        stroke.setColor(outline);

        animator = ValueAnimator.ofFloat(0f, 1f);
        animator.setDuration(1000);
        animator.setRepeatCount(ValueAnimator.INFINITE);
        animator.setInterpolator(new LinearInterpolator());
        animator.addUpdateListener(a -> {
            phase = (float) a.getAnimatedValue();
            invalidate();
        });
        animator.start();
    }

    public void setState(State newState) {
        state = newState;
        invalidate();
    }

    public State getState() {
        return state;
    }

    public void setFacingRight(boolean right) {
        facingRight = right;
        invalidate();
    }

    private float dp(float v) {
        return v * getResources().getDisplayMetrics().density;
    }

    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        if (animator != null) animator.cancel();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        float w = getWidth();
        float h = getHeight();
        if (w <= 0 || h <= 0) return;

        canvas.save();

        // Mirror the entire character, not just a raster image.
        if (!facingRight) {
            canvas.scale(-1f, 1f, w / 2f, h / 2f);
        }

        float cycle = (float) (Math.sin(phase * Math.PI * 2));
        float cycle2 = (float) (Math.cos(phase * Math.PI * 2));

        float bob = 0f;
        float bodySquash = 1f;
        float jump = 0f;

        switch (state) {
            case WALK:
                bob = cycle2 * h * 0.018f;
                break;
            case IDLE:
            case TALK:
                bob = cycle * h * 0.007f;
                bodySquash = 1f + cycle2 * 0.01f;
                break;
            case HAPPY:
                bob = Math.abs(cycle) * -h * 0.025f;
                break;
            case JUMP:
                jump = -Math.abs(cycle) * h * 0.16f;
                bodySquash = 1f - Math.abs(cycle2) * 0.035f;
                break;
            case SLEEP:
                bob = cycle * h * 0.003f;
                break;
            case SAD:
                bob = cycle * h * 0.003f;
                break;
        }

        canvas.translate(0, bob + jump);

        float cx = w * 0.5f;
        float headCy = h * 0.37f;
        float bodyCy = h * 0.69f;

        float earSwing = 0f;
        if (state == State.WALK) earSwing = cycle * 8f;
        else if (state == State.HAPPY) earSwing = cycle * 13f;
        else earSwing = cycle * 2.5f;

        drawShadow(canvas, cx, h * 0.91f, w * 0.45f, h * 0.07f, jump);

        // ears behind body
        drawEar(canvas, cx - w * 0.23f, headCy + h * 0.05f, true, earSwing);
        drawEar(canvas, cx + w * 0.23f, headCy + h * 0.05f, false, -earSwing);

        // body
        canvas.save();
        canvas.scale(1f, bodySquash, cx, bodyCy);
        drawBody(canvas, cx, bodyCy, w * 0.25f, h * 0.24f);
        drawArmsAndLegs(canvas, cx, bodyCy, cycle);
        canvas.restore();

        drawHead(canvas, cx, headCy, w * 0.28f, h * 0.245f);
        drawFace(canvas, cx, headCy, w * 0.28f, h * 0.245f, cycle);

        if (state == State.SLEEP) {
            drawSleepZ(canvas, w * 0.73f, h * 0.18f);
        }

        canvas.restore();
    }

    private void drawShadow(Canvas c, float cx, float cy, float ww, float hh, float jump) {
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(Color.argb(jump < -dp(5) ? 40 : 70, 60, 55, 45));
        RectF r = new RectF(cx - ww/2, cy - hh/2, cx + ww/2, cy + hh/2);
        c.drawOval(r, paint);
    }

    private void drawEar(Canvas c, float x, float y, boolean left, float swingDeg) {
        c.save();
        c.rotate(swingDeg, x, y);

        float sign = left ? -1f : 1f;

        Path ear = new Path();
        ear.moveTo(x, y - getHeight() * 0.16f);
        ear.cubicTo(
                x + sign * getWidth() * 0.09f, y - getHeight() * 0.11f,
                x + sign * getWidth() * 0.22f, y + getHeight() * 0.10f,
                x + sign * getWidth() * 0.23f, y + getHeight() * 0.27f
        );
        ear.cubicTo(
                x + sign * getWidth() * 0.14f, y + getHeight() * 0.25f,
                x + sign * getWidth() * 0.08f, y + getHeight() * 0.10f,
                x, y - getHeight() * 0.16f
        );

        paint.setStyle(Paint.Style.FILL);
        paint.setColor(cream);
        c.drawPath(ear, paint);
        c.drawPath(ear, stroke);

        // green ear patches
        paint.setColor(green);
        float px = x + sign * getWidth() * 0.14f;
        RectF p1 = new RectF(px - dp(12), y + getHeight()*0.02f,
                px + dp(12), y + getHeight()*0.10f);
        c.drawOval(p1, paint);

        RectF p2 = new RectF(x + sign*getWidth()*0.20f - dp(15), y + getHeight()*0.15f,
                x + sign*getWidth()*0.20f + dp(15), y + getHeight()*0.24f);
        c.drawOval(p2, paint);

        c.restore();
    }

    private void drawBody(Canvas c, float cx, float cy, float rx, float ry) {
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(cream);
        RectF body = new RectF(cx-rx, cy-ry, cx+rx, cy+ry);
        c.drawOval(body, paint);
        c.drawOval(body, stroke);

        // green neck triangle/bib
        Path bib = new Path();
        bib.moveTo(cx - rx*0.70f, cy - ry*0.56f);
        bib.lineTo(cx + rx*0.70f, cy - ry*0.56f);
        bib.lineTo(cx, cy + ry*0.05f);
        bib.close();
        paint.setColor(green);
        c.drawPath(bib, paint);
        c.drawPath(bib, stroke);
    }

    private void drawArmsAndLegs(Canvas c, float cx, float cy, float cycle) {
        float armSwing = 0f;
        float legSwing = 0f;

        if (state == State.WALK) {
            armSwing = cycle * 15f;
            legSwing = cycle * 12f;
        } else if (state == State.HAPPY) {
            armSwing = 22f + Math.abs(cycle) * 20f;
        } else if (state == State.TALK) {
            armSwing = 8f + cycle * 8f;
        } else if (state == State.SAD) {
            armSwing = -8f;
        }

        drawLimb(c, cx - getWidth()*0.19f, cy - getHeight()*0.02f, true, armSwing, true);
        drawLimb(c, cx + getWidth()*0.19f, cy - getHeight()*0.02f, false, -armSwing, true);

        drawLimb(c, cx - getWidth()*0.11f, cy + getHeight()*0.18f, true, legSwing, false);
        drawLimb(c, cx + getWidth()*0.11f, cy + getHeight()*0.18f, false, -legSwing, false);
    }

    private void drawLimb(Canvas c, float x, float y, boolean left, float angle, boolean arm) {
        c.save();
        c.rotate(angle, x, y);

        float ww = getWidth() * (arm ? 0.085f : 0.10f);
        float hh = getHeight() * (arm ? 0.16f : 0.11f);

        paint.setColor(cream);
        paint.setStyle(Paint.Style.FILL);
        RectF r = new RectF(x - ww/2, y, x + ww/2, y + hh);
        c.drawRoundRect(r, ww/2, ww/2, paint);
        c.drawRoundRect(r, ww/2, ww/2, stroke);

        paint.setColor(green);
        RectF tip = new RectF(x - ww/2, y + hh*0.72f, x + ww/2, y + hh);
        c.drawRoundRect(tip, ww/2, ww/2, paint);

        c.restore();
    }

    private void drawHead(Canvas c, float cx, float cy, float rx, float ry) {
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(cream);

        RectF head = new RectF(cx-rx, cy-ry, cx+rx, cy+ry);
        c.drawOval(head, paint);
        c.drawOval(head, stroke);

        // horn
        Path horn = new Path();
        horn.moveTo(cx - dp(12), cy - ry*0.88f);
        horn.lineTo(cx, cy - ry*1.47f);
        horn.lineTo(cx + dp(13), cy - ry*0.86f);
        horn.close();
        paint.setColor(creamShadow);
        c.drawPath(horn, paint);
        c.drawPath(horn, stroke);
    }

    private void drawFace(Canvas c, float cx, float cy, float rx, float ry, float cycle) {
        boolean blink = false;

        // natural periodic blink
        float p = phase;
        if (state == State.SLEEP) blink = true;
        else if (state == State.HAPPY && cycle > 0.55f) blink = true;
        else if (p > 0.92f && p < 0.97f) blink = true;

        float eyeY = cy - ry*0.05f;
        float eyeDX = rx*0.42f;

        if (blink) {
            stroke.setStrokeWidth(dp(3));
            c.drawLine(cx-eyeDX-dp(8), eyeY, cx-eyeDX+dp(8), eyeY, stroke);
            c.drawLine(cx+eyeDX-dp(8), eyeY, cx+eyeDX+dp(8), eyeY, stroke);
            stroke.setStrokeWidth(dp(2.1f));
        } else {
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(Color.rgb(24,25,24));
            c.drawOval(new RectF(cx-eyeDX-dp(10), eyeY-dp(14), cx-eyeDX+dp(10), eyeY+dp(14)), paint);
            c.drawOval(new RectF(cx+eyeDX-dp(10), eyeY-dp(14), cx+eyeDX+dp(10), eyeY+dp(14)), paint);

            paint.setColor(Color.WHITE);
            c.drawCircle(cx-eyeDX-dp(3), eyeY-dp(5), dp(3.4f), paint);
            c.drawCircle(cx+eyeDX-dp(3), eyeY-dp(5), dp(3.4f), paint);
        }

        // cheeks
        paint.setColor(cheek);
        paint.setAlpha(state == State.SAD ? 80 : 125);
        c.drawOval(new RectF(cx-rx*0.76f, cy+ry*0.20f, cx-rx*0.42f, cy+ry*0.40f), paint);
        c.drawOval(new RectF(cx+rx*0.42f, cy+ry*0.20f, cx+rx*0.76f, cy+ry*0.40f), paint);
        paint.setAlpha(255);

        // nose
        paint.setColor(outline);
        c.drawOval(new RectF(cx-dp(5), cy+ry*0.18f, cx+dp(5), cy+ry*0.26f), paint);

        // mouth
        Path mouth = new Path();
        if (state == State.SAD) {
            mouth.moveTo(cx-dp(8), cy+ry*0.44f);
            mouth.quadTo(cx, cy+ry*0.34f, cx+dp(8), cy+ry*0.44f);
            c.drawPath(mouth, stroke);
        } else if (state == State.TALK) {
            float open = dp(5 + 5*Math.abs(cycle));
            paint.setColor(Color.rgb(74,45,40));
            c.drawOval(new RectF(cx-dp(8), cy+ry*0.36f, cx+dp(8), cy+ry*0.36f+open), paint);
        } else if (state == State.HAPPY || state == State.JUMP) {
            paint.setColor(Color.rgb(74,45,40));
            c.drawOval(new RectF(cx-dp(11), cy+ry*0.34f, cx+dp(11), cy+ry*0.52f), paint);
            paint.setColor(Color.rgb(246,130,136));
            c.drawOval(new RectF(cx-dp(7), cy+ry*0.43f, cx+dp(7), cy+ry*0.51f), paint);
        } else if (state != State.SLEEP) {
            mouth.moveTo(cx-dp(8), cy+ry*0.37f);
            mouth.quadTo(cx, cy+ry*0.48f, cx+dp(8), cy+ry*0.37f);
            c.drawPath(mouth, stroke);
        }
    }

    private void drawSleepZ(Canvas c, float x, float y) {
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(greenDark);
        paint.setTextSize(dp(16));
        paint.setFakeBoldText(true);
        c.drawText("Z", x, y, paint);
        paint.setTextSize(dp(11));
        c.drawText("z", x+dp(17), y-dp(12), paint);
        paint.setFakeBoldText(false);
    }
}
