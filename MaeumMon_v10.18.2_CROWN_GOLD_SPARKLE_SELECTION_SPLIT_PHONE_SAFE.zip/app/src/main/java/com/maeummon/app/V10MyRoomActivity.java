package com.maeummon.app;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class V10MyRoomActivity extends Activity {
    private TextView currentPtRoomText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_v10_my_room);
        UiInsets.apply(this, findViewById(R.id.v10MyRoomRoot));
        currentPtRoomText = findViewById(R.id.currentPtRoomText);
        findViewById(R.id.openCurrentPtButton).setOnClickListener(v -> startActivity(new Intent(this, MindPtActivity.class)));
        findViewById(R.id.openDailyLetterRoomButton).setOnClickListener(v -> startActivity(new Intent(this, DailyLetterActivity.class)));
        findViewById(R.id.openWordsRoomButton).setOnClickListener(v -> startActivity(new Intent(this, WordsForSeungjaeActivity.class)));
        findViewById(R.id.openDiaryRoomButton).setOnClickListener(v -> startActivity(new Intent(this, MoodCalendarActivity.class)));
        findViewById(R.id.openCoachRoomButton).setOnClickListener(v -> startActivity(new Intent(this, DesiredSelfCoachActivity.class)));
        findViewById(R.id.openLegacySettingsButton).setOnClickListener(v -> startActivity(new Intent(this, MainActivity.class)));
    }

    @Override
    protected void onResume() {
        super.onResume();
        currentPtRoomText.setText(CentralMindPtState.roomSummary(this));
        PetStateManager.markSeen(this);
    }
}
