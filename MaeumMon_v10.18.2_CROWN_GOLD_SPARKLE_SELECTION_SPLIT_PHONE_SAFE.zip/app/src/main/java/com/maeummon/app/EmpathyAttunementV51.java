package com.maeummon.app;

import java.util.Locale;

/**
 * v5.1 Empathy Attunement layer.
 *
 * Empathy is not a fixed greeting sentence. It is a clinical-style pacing
 * decision: receive the emotion enough for the person to feel accurately
 * understood, then move to meaning / reality / boundary / action at the
 * appropriate time.
 */
public final class EmpathyAttunementV51 {
    private EmpathyAttunementV51() {}

    public static String buildContext(String userMessage) {
        String t = userMessage == null ? "" : userMessage.toLowerCase(Locale.KOREA);
        boolean grief = has(t, "죽", "상실", "장례", "떠났", "잃었", "그리워", "사별");
        boolean shame = has(t, "부끄", "수치", "창피", "내가 이상", "내가 싫", "쓸모없", "내 탓", "죄책", "미안");
        boolean flooded = has(t, "너무 무서", "죽을 것", "미치겠", "숨 막", "공황", "울고", "못 버티", "폭발", "감당 안");
        boolean hurt = has(t, "서운", "상처", "억울", "무시당", "외로", "버려", "미워할", "멀어질");
        boolean wantsAction = has(t, "어떻게 해", "어케해", "그래서 뭐", "뭐라고", "연락해", "말해 말아", "해야 해", "하면 돼");
        boolean selfAttack = has(t, "난 왜", "나는 왜", "내가 문제", "내가 잘못", "내가 나쁜", "내가 이기적");

        int empathy = 1;
        if (grief || shame || flooded || selfAttack) empathy = 3;
        else if (hurt) empathy = 2;
        if (wantsAction && !grief && !flooded && !shame) empathy = Math.min(empathy, 1);

        StringBuilder b = new StringBuilder();
        b.append("[EMPATHY ATTUNEMENT v5.1]\n");
        b.append("이번 턴 권장 empathy_level=").append(empathy).append(" (0~3 내부 리듬값; 사용자에게 숫자를 말하지 않는다).\n");
        b.append("- 공감은 '네 말이 다 맞다'가 아니다. 감정/체감/이해 가능한 욕구를 정확히 받아주되, 사실판단·상대 의도·해로운 행동은 별도 평가한다.\n");
        b.append("- 공감의 목적은 사용자가 '내가 왜 이렇게 느끼는지 이해받았다'고 느낄 만큼 정서적으로 도착하는 것이다. 기계적으로 첫 문장 1개만 붙이고 바로 교정하지 않는다.\n");
        b.append("- empathy 3: 상실·수치심·자기공격·정서폭주. 먼저 2~4개의 짧고 구체적인 문장으로 경험을 받아주고 안정시킨 뒤, 그 턴에서는 분석/직면을 줄이거나 아주 부드럽게 한 가지만 한다.\n");
        b.append("- empathy 2: 서운함·불안·관계상처가 중심. 구체적 감정반영 1~2문장 뒤 핵심 의미를 연결하고, 현실검증/책임분리는 협력적으로 한다.\n");
        b.append("- empathy 1: 사용자가 이미 충분히 안정됐거나 행동을 묻는 단계. 짧게 이해를 확인하고 바로 핵심 재정의/행동/스크립트로 간다.\n");
        b.append("- empathy 0: 반복 설명이 오히려 답답하고 사용자가 결론/판단을 명시적으로 원하는 경우. 차갑게 말하라는 뜻이 아니라 공감문을 따로 늘리지 말고 따뜻한 어조 속에서 바로 답한다.\n");
        b.append("- 전환 신호: 사용자가 '맞아/그래/그게 무서워/그렇구나'처럼 이해받았음을 보이거나, 스스로 핵심을 말하거나, '그래서 어떻게 해?'로 이동하면 공감 반복을 멈추고 FORMULATE/INTERVENE로 간다.\n");
        b.append("- 공감 뒤 사이다: 먼저 '왜 그럴 수 있었는지'를 받아준 다음, 필요할 때 '하지만 이 부분은 분명히 구분해야 해'처럼 짧고 명확하게 선을 긋는다. 공감과 단호함은 반대가 아니라 순서의 문제다.\n");
        b.append("- 같은 감정문구를 다른 표현으로 반복하지 않는다. 공감은 구체적이어야 한다: 사건을 재방송하지 말고 사용자가 받은 의미/두려움/부담을 정확히 한두 층만 짚는다.\n");
        b.append("- 사용자가 자기 잘못을 이미 과도하게 인정하면 confront를 낮추고 PERSON/BEHAVIOR를 분리한다. 반대로 타인에게 해를 주는 행동을 합리화하면 감정은 공감하되 LIMIT를 늦추지 않는다.\n");
        return b.toString();
    }

    public static String prompt() {
        return "[EMPATHY ATTUNEMENT v5.1] 공감량을 고정하지 않는다. 상실·수치심·자기공격·정서폭주는 공감/안정화를 충분히 먼저, 관계상처는 구체적 공감 뒤 의미연결, 이미 행동을 묻는 단계는 짧은 공감 뒤 즉시 행동으로 간다. 공감은 사실·상대의도·해로운 행동에 대한 동의가 아니다. 사용자가 이해받았다는 신호를 보이면 공감 반복을 멈추고 재정의/현실검증/행동으로 전환한다. '공감→단호함'은 고정 템플릿이 아니라 현재 정서강도와 세션 단계에 따른 리듬이다.";
    }

    private static boolean has(String t, String... xs) {
        for (String x : xs) if (t.contains(x.toLowerCase(Locale.KOREA))) return true;
        return false;
    }
}
