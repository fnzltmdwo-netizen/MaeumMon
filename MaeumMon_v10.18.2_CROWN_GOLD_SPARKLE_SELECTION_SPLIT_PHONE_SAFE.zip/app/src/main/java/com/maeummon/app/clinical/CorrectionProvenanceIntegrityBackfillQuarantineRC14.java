package com.maeummon.app.clinical;

import android.content.Context;
import org.json.*;
import java.security.MessageDigest;

public final class CorrectionProvenanceIntegrityBackfillQuarantineRC14 {
    private CorrectionProvenanceIntegrityBackfillQuarantineRC14(){}

    public enum RowState {
        VALID,
        REPAIRED,
        QUARANTINED,
        LEGACY_UNRESOLVED
    }

    public static final class Result {
        public boolean evaluated=false;
        public boolean repaired=false;
        public boolean quarantined=false;
        public int rowsChecked=0;
        public int rowsValid=0;
        public int rowsRepaired=0;
        public int rowsQuarantined=0;
        public int rowsLegacyUnresolved=0;
        public String reason="";
        public String summary="";
    }

    public static Result validateAndBackfill(Context c){
        Result r=new Result();

        if(c==null){
            r.summary="NO_EVALUATION | NO_CONTEXT";
            return r;
        }

        r.evaluated=true;

        try{
            JSONObject p=CentralTherapyProfile.loadProfile(c);

            JSONArray provenance=
                    p.optJSONArray(
                            "transition_correction_commit_provenance_history");

            if(provenance==null)
                provenance=new JSONArray();

            JSONArray corrections=
                    p.optJSONArray(
                            "transition_explanation_correction_history");

            if(corrections==null)
                corrections=new JSONArray();

            for(int i=0;i<provenance.length();i++){
                JSONObject row=provenance.optJSONObject(i);
                if(row==null)continue;

                r.rowsChecked++;
                boolean rowRepaired=false;

                String source=row.optString("source_type","");
                String evidenceText=row.optString("user_evidence_text","");
                String evidenceId=row.optString("user_evidence_id","");
                String transitionKey=row.optString("transition_key","");
                String cause=row.optString("corrected_cause","");
                String context=row.optString("context_scope","");
                String canonical=row.optString("canonical_commit_key","");

                if(source.isEmpty()
                        &&!evidenceText.isEmpty()
                        &&!cause.isEmpty()){
                    row.put("source_type","EXPLICIT_USER_CORRECTION");
                    source="EXPLICIT_USER_CORRECTION";
                    rowRepaired=true;
                }

                if(evidenceId.isEmpty()
                        &&!evidenceText.isEmpty()){
                    evidenceId=sha256(normalize(evidenceText));
                    row.put("user_evidence_id",evidenceId);
                    rowRepaired=true;
                }

                if(transitionKey.isEmpty()){
                    String from=row.optString("decision_transition_from","");
                    String to=row.optString("decision_transition_to","");

                    if(!from.isEmpty()
                            &&!to.isEmpty()
                            &&!context.isEmpty()){
                        transitionKey=
                                from+"->"+to+"::"+context;
                        row.put("transition_key",transitionKey);
                        rowRepaired=true;
                    }
                }

                if(context.isEmpty()
                        &&!transitionKey.isEmpty()){
                    int split=transitionKey.lastIndexOf("::");
                    if(split>0 && split+2<transitionKey.length()){
                        context=transitionKey.substring(split+2);
                        row.put("context_scope",context);
                        rowRepaired=true;
                    }
                }

                if(!transitionKey.isEmpty()
                        &&!cause.isEmpty()
                        &&!evidenceId.isEmpty()){
                    String expected=sha256(
                            transitionKey
                            +"::"
                            +cause
                            +"::"
                            +evidenceId);

                    if(!canonical.isEmpty()
                            &&!canonical.equals(expected)){
                        row.put(
                                "canonical_commit_key_before_repair",
                                canonical);
                        rowRepaired=true;
                    }

                    if(!expected.equals(canonical)){
                        row.put(
                                "canonical_commit_key",
                                expected);
                        canonical=expected;
                        rowRepaired=true;
                    }
                }

                boolean explicit=
                        "EXPLICIT_USER_CORRECTION".equals(source);

                boolean complete=
                        explicit
                        &&!evidenceId.isEmpty()
                        &&!transitionKey.isEmpty()
                        &&!cause.isEmpty()
                        &&!canonical.isEmpty();

                if(!complete){
                    boolean legacy=
                            evidenceText.isEmpty()
                            &&evidenceId.isEmpty()
                            &&canonical.isEmpty();

                    if(legacy){
                        row.put(
                                "correction_provenance_integrity_state",
                                RowState.LEGACY_UNRESOLVED.name());
                        row.put(
                                "correction_provenance_quarantined",
                                true);
                        row.put(
                                "correction_provenance_integrity_reason",
                                "LEGACY_CORRECTION_IDENTITY_UNRESOLVED");

                        r.rowsLegacyUnresolved++;
                        r.rowsQuarantined++;
                        r.quarantined=true;
                        continue;
                    }

                    row.put(
                            "correction_provenance_integrity_state",
                            RowState.QUARANTINED.name());
                    row.put(
                            "correction_provenance_quarantined",
                            true);
                    row.put(
                            "correction_provenance_integrity_reason",
                            "INCOMPLETE_EXPLICIT_CORRECTION_PROVENANCE");

                    r.rowsQuarantined++;
                    r.quarantined=true;
                    continue;
                }

                if(rowRepaired){
                    row.put(
                            "correction_provenance_integrity_state",
                            RowState.REPAIRED.name());
                    row.put(
                            "correction_provenance_quarantined",
                            false);
                    row.put(
                            "correction_provenance_integrity_reason",
                            "SAFE_BACKFILL_OR_CANONICAL_REPAIR");
                    row.put(
                            "correction_provenance_integrity_schema",
                            "6.9.0");

                    r.rowsRepaired++;
                    r.repaired=true;
                }else{
                    row.put(
                            "correction_provenance_integrity_state",
                            RowState.VALID.name());
                    row.put(
                            "correction_provenance_quarantined",
                            false);
                    row.put(
                            "correction_provenance_integrity_reason",
                            "VALID_EXPLICIT_CORRECTION_PROVENANCE");
                    row.put(
                            "correction_provenance_integrity_schema",
                            "6.9.0");

                    r.rowsValid++;
                }
            }

            p.put(
                    "transition_correction_commit_provenance_history",
                    provenance);

            p.put(
                    "last_correction_provenance_integrity_checked_at",
                    System.currentTimeMillis());

            p.put(
                    "last_correction_provenance_integrity_rows_checked",
                    r.rowsChecked);

            p.put(
                    "last_correction_provenance_integrity_rows_repaired",
                    r.rowsRepaired);

            p.put(
                    "last_correction_provenance_integrity_rows_quarantined",
                    r.rowsQuarantined);

            p.put(
                    "last_correction_provenance_integrity_legacy_unresolved",
                    r.rowsLegacyUnresolved);

            CentralTherapyProfile.replaceProfile(c,p);

            if(r.rowsQuarantined>0)
                r.reason="QUARANTINED_INVALID_CORRECTION_PROVENANCE";
            else if(r.rowsRepaired>0)
                r.reason="CORRECTION_PROVENANCE_REPAIRED";
            else
                r.reason="CORRECTION_PROVENANCE_VALID";

            r.summary="checked="+r.rowsChecked
                    +" | valid="+r.rowsValid
                    +" | repaired="+r.rowsRepaired
                    +" | quarantined="+r.rowsQuarantined
                    +" | legacyUnresolved="+r.rowsLegacyUnresolved
                    +" | reason="+r.reason;

            return r;
        }catch(Exception e){
            r.quarantined=true;
            r.reason="CORRECTION_PROVENANCE_INTEGRITY_WRITE_FAILED";
            r.summary="ERROR | "+r.reason;
            return r;
        }
    }

    public static boolean rowEligibleForCorrectionMemory(
            JSONObject row){

        if(row==null)return false;

        if(row.optBoolean(
                "correction_provenance_quarantined",
                false))
            return false;

        String state=row.optString(
                "correction_provenance_integrity_state",
                "");

        if(RowState.QUARANTINED.name().equals(state)
                ||RowState.LEGACY_UNRESOLVED.name().equals(state))
            return false;

        return ExplicitCorrectionCommitProvenanceIdentityRC13
                .rowHasValidExplicitProvenance(row);
    }

    public static String instruction(Result r){
        if(r==null||!r.evaluated)return "";

        if(r.rowsQuarantined>0)
            return "CORRECTION_PROVENANCE_INTEGRITY=QUARANTINE_ACTIVE. 출처가 불완전하거나 모순된 correction provenance는 WHY memory에서 제외한다.";

        if(r.rowsRepaired>0)
            return "CORRECTION_PROVENANCE_INTEGRITY=REPAIRED. 안전하게 재구성 가능한 correction provenance만 canonical identity로 복구했다.";

        return "CORRECTION_PROVENANCE_INTEGRITY=VALID.";
    }

    private static String normalize(String s){
        if(s==null)return "";
        return s.trim()
                .replaceAll("\\s+"," ")
                .toLowerCase();
    }

    private static String sha256(String s){
        try{
            MessageDigest md=
                    MessageDigest.getInstance("SHA-256");

            byte[] b=md.digest(
                    (s==null?"":s).getBytes("UTF-8"));

            StringBuilder out=
                    new StringBuilder();

            for(byte x:b)
                out.append(String.format("%02x",x));

            return out.toString();

        }catch(Exception e){
            return Integer.toHexString(
                    (s==null?"":s).hashCode());
        }
    }
}
