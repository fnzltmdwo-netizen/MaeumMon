package com.maeummon.app;

import android.app.Activity;
import android.os.Bundle;
import android.text.format.DateFormat;
import android.widget.TextView;

public class CounselingDetailActivity extends Activity {
    public static final String EXTRA_ENTRY_ID = "entry_id";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_counseling_detail);
        UiInsets.apply(this, findViewById(R.id.counselingDetailRoot));

        long id = getIntent().getLongExtra(EXTRA_ENTRY_ID, -1L);
        MindTrainingStore store = new MindTrainingStore(this);
        MindTrainingStore.CounselingEntry e = store.counselingById(id);
        if (e == null) {
            finish();
            return;
        }

        ((TextView) findViewById(R.id.counselingDetailTitle)).setText(e.title.isEmpty() ? "상담 완전판 기록" : e.title);
        ((TextView) findViewById(R.id.counselingDetailDate)).setText(DateFormat.format("yyyy년 M월 d일 HH:mm", e.createdAt));

        TextView extracted = findViewById(R.id.counselingDetailExtracted);
        StringBuilder info = new StringBuilder();
        if (!e.currentConcern.isEmpty()) info.append("최근 사용자 발화\n").append(e.currentConcern).append("\n\n");
        if (!e.priorityDirection.isEmpty()) info.append("상담에서 명시된 우선 방향\n").append(e.priorityDirection).append("\n\n");
        if (!e.muscleName.isEmpty()) info.append("연결된 마음근육\n").append(e.muscleName).append("\n\n");
        if (!e.trainingText.isEmpty()) info.append("상담에서 명시된 훈련\n").append(e.trainingText).append("\n\n");
        if (info.length() == 0 && !e.formulation.isEmpty()) {
            info.append("최근 ChatGPT 답변 참고\n").append(e.formulation);
        }
        extracted.setText(info.length() == 0 ? "별도 요약 없이 원문 그대로 보관된 상담이야." : info.toString().trim());

        ((TextView) findViewById(R.id.counselingDetailRawText)).setText(e.rawText);
        findViewById(R.id.counselingDetailClose).setOnClickListener(v -> finish());
    }
}
