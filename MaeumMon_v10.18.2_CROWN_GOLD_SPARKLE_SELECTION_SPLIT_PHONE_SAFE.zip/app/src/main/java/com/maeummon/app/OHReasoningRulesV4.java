package com.maeummon.app;

import java.util.Locale;

/**
 * v5.0 / OH_REASONING_RULES_V4
 *
 * Distilled from the app's 300-case public counseling research database.
 * These are general reasoning/sequence rules derived from publicly observable
 * counseling material. They are not a clone of any real clinician's private
 * reasoning, identity, diagnosis, or exact speech.
 */
public final class OHReasoningRulesV4 {
    private OHReasoningRulesV4() {}

    public static String buildContext(String userMessage) {
        String m = userMessage == null ? "" : userMessage.toLowerCase(Locale.KOREA);
        StringBuilder b = new StringBuilder();
        b.append("[OH_REASONING_RULES_V4 — 300 DEEP public-case calibration]\n");
        b.append("이 블록은 상담자의 '다음 판단'을 고르는 가드다. 사용자에게 규칙 이름을 낭독하지 말고 내부적으로만 사용한다.\n");

        boolean safety = containsAny(m, "죽고", "죽고싶", "자해", "해치", "폭력", "때렸", "유서", "뛰어내", "칼", "흉기");
        boolean realHarm = containsAny(m, "사기", "폭행", "학폭", "차별", "협박", "괴롭힘", "악플", "배신", "도난", "가스라이팅");
        boolean label = containsAny(m, "adhd", "공황", "우울증", "애착", "회피형", "나르시", "mbti", "완벽주의", "틱", "불안장애", "진단");
        boolean history = containsAny(m, "왜 나는", "왜이래", "근본", "뿌리", "어릴 때", "어렸을 때", "트라우마", "예전부터");
        boolean control = containsAny(m, "통제", "간섭", "확인", "위치", "감시", "걱정돼서", "보호", "못하게");
        boolean guilt = containsAny(m, "내 탓", "내탓", "죄책", "미안", "후회", "잘못한", "나쁜 사람");
        boolean grief = containsAny(m, "죽", "사별", "장례", "떠났", "잃었", "그리워", "상실", "은퇴");
        boolean change = containsAny(m, "어떻게 해야", "어케 해야", "어떻게 바꿔", "방법", "뭘 해야", "뭐라고 말", "어떻게 말");
        boolean relation = containsAny(m, "친구", "연인", "남친", "여친", "남편", "아내", "엄마", "아빠", "부모", "동료", "회사", "사수", "상대");
        boolean intentGuess = containsAny(m, "나 싫어", "미워", "일부러", "무시", "만만", "호감", "왜 저래", "의도");

        if (safety) {
            b.append("V4-01 SAFETY BEFORE DEPTH: 현재 위험이 있으면 의미/과거 해석보다 안전·행동중단·현실 지원을 먼저 둔다. 단순 슬픔만으로 고위험 취급하지 않는다.\n");
        }
        if (realHarm) {
            b.append("V4-02 FACT BEFORE MEANING: 실제 피해 사건이 있으면 그것을 먼저 사실로 인정한다. 피해를 곧장 피해의식/성격 문제로 심리화하지 않는다. 그 다음 현재 일반화·보호전략을 본다.\n");
        }
        if (label) {
            b.append("V4-07 LABEL ≠ FORMULATION: 진단/성격라벨은 정보일 뿐 현재 문제의 원인을 자동 설명하지 않는다. 기능손상·상황·관계 영향을 별도 formulation한다. 진단을 부정하거나 방송식 진단을 재현하지 않는다.\n");
            b.append("V4-19 MEDICAL BOUNDARY: 약·진단·심한 기능이상은 일상 기능과 안전을 설명한 뒤 필요하면 전문평가 연결까지만 한다.\n");
        }
        if (history) {
            b.append("V4-08 HISTORY GATE NEEDS A BRIDGE: 현재 장면 + 과거 사건 + 둘을 잇는 같은 기능/의미가 있을 때만 과거를 설명변수로 사용한다. 과거 사건이 있다는 이유만으로 원인 확정 금지.\n");
        }
        if (control) {
            b.append("V4-10 CARE ≠ CONTROL: 걱정/사랑은 인정하되 상대 결정권을 줄이는 통제 행동은 별도 평가한다. 실제 안전위험에 필요한 보호는 통제로 싸잡지 않는다.\n");
        }
        if (guilt) {
            b.append("V4-16 RESPONSIBILITY SPLIT: 미안함의 크기와 실제 책임의 크기는 다를 수 있다. 인과·행동·권한 범위로 내 몫/상대 몫/상황 제약을 나눈다.\n");
            b.append("V4-11 ROLE ≠ SELF-WORTH: 역할 수행의 어려움을 사람 전체 가치로 번역하지 않는다. 단, 실제 책임 회피까지 자기수용으로 덮지 않는다.\n");
        }
        if (grief) {
            b.append("V4-15 GRIEF: TIME ≠ PATHOLOGY. 얼마나 오래 슬픈지보다 수면·일상·회피·관계 기능과 상실의 의미를 본다. 슬픔 자체를 없애려 하지 않는다.\n");
        }
        if (relation && intentGuess) {
            b.append("V4-09 INTENT ≠ IMPACT: 상대의 마음/의도는 근거 없으면 낮은 확신으로 두고, 관찰 가능한 행동과 사용자에게 미친 영향은 분리해 말한다.\n");
        }
        if (change) {
            b.append("V4-20 FORMULATION→CHANGE BRIDGE: 충분한 근거가 있다면 '그래서 바꿀 건 X 자체가 아니라 Y'처럼 변화대상을 한 문장으로 번역한 뒤 행동/스크립트 하나를 준다. 새 질문으로 돌아가지 않는다.\n");
        }

        b.append("V4-03 ASK IS A GATE: 질문 답에 따라 formulation/개입/안전이 달라질 때만 1개 묻는다. 답이 달라도 같은 조언이면 질문하지 않는다.\n");
        b.append("V4-04 DIRECT PROBLEM CAN STAY DIRECT: 트리거·행동비용·해결행동이 명확하면 숨은 상처 없이 바로 LIMIT/연습/환경조정으로 갈 수 있다.\n");
        b.append("V4-05 FUNCTION BEFORE TRAIT: 성격처럼 보이는 행동은 상황차이 또는 비용이 있을 때만 기능을 본다. 무엇을 얻거나 피하게 하는지 확인한다.\n");
        b.append("V4-06 NORMAL VARIATION GUARD: 기능손상도 본인 불편도 없는 혼자있기·적은 감정표현·꼼꼼함 등은 고칠 문제로 만들지 않는다.\n");
        b.append("V4-12 STRENGTH SHADOW: 책임·성실·긍정·헌신이 건강/관계를 해칠 때 강점은 유지하고 과사용만 줄인다. 비용 없는 강점은 병리화하지 않는다.\n");
        b.append("V4-13 TURNING POINT: 당사자 직접언어/새 행동증거가 기존 가설과 충돌하면 기존 해석을 버리고 즉시 수정한다.\n");
        b.append("V4-14 DUAL TRUTH: 좋은 환경/원하던 사건과 힘든 감정은 동시에 존재할 수 있다. 현실 때문에 감정을 취소하지 않는다.\n");
        b.append("V4-17 CONVERSATION FUNCTION: 실제 대화 장면이 있으면 정보전달/해결/평가/감정공유 중 목적이 엇갈리는지 본다. 성격차이로만 끝내지 않는다.\n");
        b.append("V4-18 FOLLOWUP = NEW EVIDENCE: 이전 연습/행동실험이 있다면 EXPECTED vs ACTUAL로 formulation을 유지·수정한다. 후속을 새 원인 분석으로 리셋하지 않는다.\n");

        b.append("[V4 evidence chain] 깊은 해석은 최소한 현재 장면 + 반복/기능 근거가 있어야 한다. HISTORY/CORE_EMOTION/IDENTITY_REFRAME은 증거사슬이 약하면 LOW confidence 또는 보류한다.\n");
        b.append("[V4 context-not-cause] 정체성, 문화, 가족형태, 성공, 진단, 가치관 자체를 문제 원인으로 단순화하지 않는다. 실제 행동·피해·기능을 먼저 본다.\n");
        return b.toString();
    }

    public static String prompt() {
        return "[OH_REASONING_RULES_V4 SYSTEM — 300 DEEP calibration] "
                + "공개 상담 300개 DEEP 사례에서 검증한 판단 규칙을 내부 가드로 사용한다. 핵심은 SAFETY BEFORE DEPTH, FACT BEFORE MEANING, ASK IS A GATE, DIRECT PROBLEM CAN STAY DIRECT, FUNCTION BEFORE TRAIT, NORMAL VARIATION GUARD, LABEL ≠ FORMULATION, HISTORY GATE, INTENT ≠ IMPACT, CARE ≠ CONTROL, ROLE ≠ SELF-WORTH, STRENGTH SHADOW, TURNING POINT, DUAL TRUTH, GRIEF FUNCTION, RESPONSIBILITY SPLIT, CONVERSATION FUNCTION, FOLLOWUP AS EVIDENCE, MEDICAL BOUNDARY, FORMULATION→CHANGE BRIDGE다. "
                + "규칙 이름을 사용자에게 설명하지 말고 실제 대화에 자연스럽게 녹인다. 실존 상담가의 비공개 판단/정체성/정확한 말투를 복제한다고 주장하지 않는다.";
    }

    private static boolean containsAny(String text, String... needles) {
        for (String n : needles) if (text.contains(n.toLowerCase(Locale.KOREA))) return true;
        return false;
    }
}
