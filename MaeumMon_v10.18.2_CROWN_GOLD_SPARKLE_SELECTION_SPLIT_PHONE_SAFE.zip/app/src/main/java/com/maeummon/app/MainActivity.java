package com.maeummon.app;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.EditText;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {

    private static final int REQ_BACKUP_SAVE = 6101;
    private static final int REQ_BACKUP_RESTORE = 6102;

    private SharedPreferences prefs;
    private Switch overlaySwitch;
    private Switch bootSwitch;
    private TextView recordsText;
    private EditText apiKeyInput;
    private TextView keyStatusText;
    private Spinner contextModelSpinner;
    private Spinner counselingModelSpinner;
    private TextView usageStatusText;
    private TextView accessibilityStatusText;
    private ProgressBar affectionProgress;
    private TextView affectionLevelText;
    private TextView affectionPointText;
    private TextView checkInStatusText;
    private TextView checkInReplyText;
    private TextView diaryPreviewText;
    private TextView reportPreviewText;
    private TextView letterPreviewSummaryText;
    private TextView petStateSummaryText;
    private TextView petStateHintText;
    private TextView wordsPreviewText;
    private ImageView mainMascotPreview;
    private boolean waitingForOverlayPermission = false;
    private View homeFriendContent;
    private TextView homeFriendArrow;
    private View apiKeyContent;
    private TextView apiKeyArrow;
    private static final String KEY_HOME_FRIEND_EXPANDED = "main_home_friend_expanded";
    private static final String KEY_API_KEY_EXPANDED = "main_api_key_expanded";
    private volatile boolean liveAiRefreshing = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        UiInsets.apply(this, findViewById(R.id.mainRoot));

        prefs = getSharedPreferences(AppPrefs.PREFS, MODE_PRIVATE);

        overlaySwitch = findViewById(R.id.overlaySwitch);
        bootSwitch = findViewById(R.id.bootSwitch);
        recordsText = findViewById(R.id.recordsText);
        apiKeyInput = findViewById(R.id.apiKeyInput);
        keyStatusText = findViewById(R.id.keyStatusText);
        contextModelSpinner = findViewById(R.id.contextModelSpinner);
        counselingModelSpinner = findViewById(R.id.counselingModelSpinner);
        usageStatusText = findViewById(R.id.usageStatusText);
        accessibilityStatusText = findViewById(R.id.accessibilityStatusText);
        affectionProgress = findViewById(R.id.affectionProgress);
        affectionLevelText = findViewById(R.id.affectionLevelText);
        affectionPointText = findViewById(R.id.affectionPointText);
        checkInStatusText = findViewById(R.id.checkInStatusText);
        checkInReplyText = findViewById(R.id.checkInReplyText);
        diaryPreviewText = findViewById(R.id.diaryPreviewText);
        reportPreviewText = findViewById(R.id.reportPreviewText);
        letterPreviewSummaryText = findViewById(R.id.letterPreviewSummaryText);
        petStateSummaryText = findViewById(R.id.petStateSummaryText);
        petStateHintText = findViewById(R.id.petStateHintText);
        wordsPreviewText = findViewById(R.id.wordsPreviewText);
        mainMascotPreview = findViewById(R.id.mainMascotPreview);
        homeFriendContent = findViewById(R.id.homeFriendContent);
        homeFriendArrow = findViewById(R.id.homeFriendArrow);
        apiKeyContent = findViewById(R.id.apiKeyContent);
        apiKeyArrow = findViewById(R.id.apiKeyArrow);
        initHomeFriendFold();
        initApiKeyFold();
        initAiModelSettings();

        findViewById(R.id.openUsageAccessButton).setOnClickListener(v ->
                startActivity(new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
        );
        findViewById(R.id.openAccessibilityButton).setOnClickListener(v ->
                startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        );

        overlaySwitch.setChecked(prefs.getBoolean(AppPrefs.KEY_OVERLAY, false));
        bootSwitch.setChecked(prefs.getBoolean(AppPrefs.KEY_BOOT, false));
        apiKeyInput.setText(prefs.getString(AppPrefs.KEY_API_KEY, ""));

        findViewById(R.id.saveApiKeyButton).setOnClickListener(v -> saveApiKey());
        findViewById(R.id.saveAiModelButton).setOnClickListener(v -> saveAiModels());
        findViewById(R.id.openChatButton).setOnClickListener(v ->
                startActivity(new Intent(this, ChatActivity.class))
        );
        findViewById(R.id.openCasualChatButton).setOnClickListener(v ->
                startActivity(new Intent(this, CasualChatActivity.class))
        );
        findViewById(R.id.openDesiredSelfCoachButton).setOnClickListener(v ->
                startActivity(new Intent(this, DesiredSelfCoachActivity.class))
        );
        findViewById(R.id.openCalendarButton).setOnClickListener(v ->
                startActivity(new Intent(this, MoodCalendarActivity.class))
        );
        findViewById(R.id.openDiaryButton).setOnClickListener(v ->
                startActivity(new Intent(this, MoodCalendarActivity.class))
        );
        findViewById(R.id.openCalendarButton2).setOnClickListener(v ->
                startActivity(new Intent(this, MoodCalendarActivity.class))
        );
        findViewById(R.id.openWeeklyReportButton).setOnClickListener(v ->
                startActivity(new Intent(this, WeeklyReportActivity.class))
        );
        findViewById(R.id.openMonthlyStatsButton).setOnClickListener(v ->
                startActivity(new Intent(this, MonthlyStatsActivity.class))
        );
        findViewById(R.id.shareBackupButton).setOnClickListener(v ->
                shareText("마음몬 전체 기록 내보내기", EmotionDiaryStorage.exportAllText(this))
        );
        findViewById(R.id.saveBackupFileButton).setOnClickListener(v -> openBackupCreateDocument());
        findViewById(R.id.restoreBackupFileButton).setOnClickListener(v -> openBackupRestoreDocument());
        findViewById(R.id.openDailyLetterButton).setOnClickListener(v ->
                startActivity(new Intent(this, DailyLetterActivity.class))
        );
        findViewById(R.id.openWordsForSeungjaeButton).setOnClickListener(v ->
                startActivity(new Intent(this, WordsForSeungjaeActivity.class))
        );
        overlaySwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
            prefs.edit().putBoolean(AppPrefs.KEY_OVERLAY, isChecked).apply();
            if (isChecked) {
                ensureOverlayPermissionAndStart();
            } else {
                stopService(new Intent(this, OverlayService.class));
            }
        });

        bootSwitch.setOnCheckedChangeListener((buttonView, isChecked) ->
                prefs.edit().putBoolean(AppPrefs.KEY_BOOT, isChecked).apply()
        );

        setupCheckInButton(R.id.check1, 1);
        setupCheckInButton(R.id.check2, 2);
        setupCheckInButton(R.id.check3, 3);
        setupCheckInButton(R.id.check4, 4);
        setupCheckInButton(R.id.check5, 5);

        requestNotificationsIfNeeded();
        requestLocationIfNeeded();
        refreshAll();
    }

    private void initHomeFriendFold() {
        boolean expanded = prefs.getBoolean(KEY_HOME_FRIEND_EXPANDED, false);
        setHomeFriendExpanded(expanded);
        findViewById(R.id.homeFriendHeader).setOnClickListener(v -> {
            boolean next = homeFriendContent.getVisibility() != View.VISIBLE;
            setHomeFriendExpanded(next);
            prefs.edit().putBoolean(KEY_HOME_FRIEND_EXPANDED, next).apply();
        });
    }

    private void setHomeFriendExpanded(boolean expanded) {
        homeFriendContent.setVisibility(expanded ? View.VISIBLE : View.GONE);
        homeFriendArrow.setText(expanded ? "▾" : "▸");
    }

    private void initApiKeyFold() {
        View header = findViewById(R.id.apiKeyHeader);
        if (header == null || apiKeyContent == null || apiKeyArrow == null) return;
        boolean expanded = prefs.getBoolean(KEY_API_KEY_EXPANDED, false);
        apiKeyContent.setVisibility(expanded ? View.VISIBLE : View.GONE);
        apiKeyArrow.setText(expanded ? "▾" : "▸");
        header.setOnClickListener(v -> {
            boolean show = apiKeyContent.getVisibility() != View.VISIBLE;
            apiKeyContent.setVisibility(show ? View.VISIBLE : View.GONE);
            apiKeyArrow.setText(show ? "▾" : "▸");
            prefs.edit().putBoolean(KEY_API_KEY_EXPANDED, show).apply();
        });
    }


    private static final String[] MODEL_LABELS = {
            "GPT-5.6 Terra · 추천",
            "GPT-5.6 Sol · 최고성능",
            "GPT-5.6 Luna · 비용절약",
            "GPT-4.1 mini · 기존"
    };

    private static final String[] MODEL_IDS = {
            "gpt-5.6-terra",
            "gpt-5.6-sol",
            "gpt-5.6-luna",
            "gpt-4.1-mini"
    };

    private void initAiModelSettings() {
        if (contextModelSpinner == null || counselingModelSpinner == null) return;
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, MODEL_LABELS);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        contextModelSpinner.setAdapter(adapter);
        counselingModelSpinner.setAdapter(adapter);

        String contextModel = prefs.getString(AppPrefs.KEY_CONTEXT_MODEL, "gpt-5.6-terra");
        String counselingModel = prefs.getString(AppPrefs.KEY_COUNSELING_MODEL, "gpt-5.6-terra");
        contextModelSpinner.setSelection(modelIndex(contextModel));
        counselingModelSpinner.setSelection(modelIndex(counselingModel));
    }

    private int modelIndex(String id) {
        for (int i = 0; i < MODEL_IDS.length; i++) {
            if (MODEL_IDS[i].equals(id)) return i;
        }
        return 0;
    }

    private void saveAiModels() {
        int ci = contextModelSpinner == null ? 0 : contextModelSpinner.getSelectedItemPosition();
        int ti = counselingModelSpinner == null ? 0 : counselingModelSpinner.getSelectedItemPosition();
        if (ci < 0 || ci >= MODEL_IDS.length) ci = 0;
        if (ti < 0 || ti >= MODEL_IDS.length) ti = 0;
        prefs.edit()
                .putString(AppPrefs.KEY_CONTEXT_MODEL, MODEL_IDS[ci])
                .putString(AppPrefs.KEY_COUNSELING_MODEL, MODEL_IDS[ti])
                .apply();
        Toast.makeText(this, "AI 모델 설정 저장 완료", Toast.LENGTH_SHORT).show();
    }

    private void saveApiKey() {
        String key = apiKeyInput.getText().toString().trim();
        prefs.edit().putString(AppPrefs.KEY_API_KEY, key).apply();
        updateKeyStatus();
        Toast.makeText(this, "API Key 저장 완료", Toast.LENGTH_SHORT).show();
    }

    private void updateKeyStatus() {
        String key = prefs.getString(AppPrefs.KEY_API_KEY, "");
        if (key.isEmpty()) {
            keyStatusText.setText("API Key 없이도 기본 상담은 가능해.");
        } else {
            keyStatusText.setText("API Key가 저장되어 있어. 이제 어린 승재와 더 자연스럽게 대화할 수 있어.");
        }
    }

    private void updateUsageStatus() {
        if (UsageAccessHelper.hasPermission(this)) {
            usageStatusText.setText("홈화면 감지 권한이 켜져 있어. 어린 승재가 홈에서만 잘 나타날 거야.");
        } else {
            usageStatusText.setText("홈화면 감지 권한이 아직 없어. 버튼을 눌러 허용해줘야 다른 앱에선 숨고 홈에서만 나타나.");
        }
    }

    private void updateAccessibilityStatus() {
        if (LauncherSurfaceAccessibilityService.isEnabled(this)) {
            accessibilityStatusText.setText("최근 앱·앱 목록 숨김 감지: 켜짐 ✓");
        } else {
            accessibilityStatusText.setText("최근 앱·앱 목록에서도 숨기려면 이 감지를 한 번 켜줘.");
        }
    }

    private void refreshRecords() {
        String chat = ChatStorage.getRecentDiaryPreview(this);
        String diary = EmotionDiaryStorage.recentPreview(this);
        StringBuilder sb = new StringBuilder();
        if (!chat.startsWith("아직 기록이 없어")) {
            sb.append("💬 최근 상담에서 말한 내용\n").append(chat);
        }
        if (!diary.startsWith("아직 적은 속마음 일기가 없어")) {
            if (sb.length() > 0) sb.append("\n\n────────────\n\n");
            sb.append("📘 최근 감정 일기\n").append(diary);
        }
        recordsText.setText(sb.length() == 0 ? "아직 마음 기록이 없어. 상담하거나 일기를 적으면 여기에 같이 쌓여." : sb.toString());
    }

    private void ensureOverlayPermissionAndStart() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            waitingForOverlayPermission = true;
            Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
            startActivity(intent);
            Toast.makeText(this, "‘다른 앱 위에 표시’를 허용해줘 🌿", Toast.LENGTH_LONG).show();
            return;
        }
        startOverlayService();
    }

    private void startOverlayService() {
        Intent serviceIntent = new Intent(this, OverlayService.class);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(serviceIntent);
        } else {
            startService(serviceIntent);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshAll();

        if (waitingForOverlayPermission) {
            waitingForOverlayPermission = false;
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.canDrawOverlays(this)) {
                overlaySwitch.setChecked(true);
                prefs.edit().putBoolean(AppPrefs.KEY_OVERLAY, true).apply();
                startOverlayService();
            } else {
                overlaySwitch.setChecked(false);
                prefs.edit().putBoolean(AppPrefs.KEY_OVERLAY, false).apply();
            }
        }

        // 앱 업데이트/프로세스 종료 뒤에도 설정이 켜져 있으면 홈 다마고치 서비스를 다시 살린다.
        if (!waitingForOverlayPermission
                && prefs.getBoolean(AppPrefs.KEY_OVERLAY, false)
                && (Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.canDrawOverlays(this))) {
            startOverlayService();
        }
    }

    private void refreshAll() {
        updateKeyStatus();
        refreshRecords();
        updateUsageStatus();
        updateAccessibilityStatus();
        updateAffectionUi();
        updateCheckInUi();
        updateDiaryPreview();
        updateReportPreview();
        LiveMindManager.recalculatePetState(this);
        updateLetterPreview();
        updateWordsPreview();
        updatePetStateUi();
        refreshLiveAiContentIfNeeded();
        mainMascotPreview.setImageResource(YoungSeungjaeHome.getOutfitPreviewRes(this));

        if (Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1001);
        }
    }

    private void setupCheckInButton(int id, int score) {
        findViewById(id).setOnClickListener(v -> {
            if (CompanionProfile.checkedInToday(this)) {
                Toast.makeText(this, "오늘 마음 체크인은 이미 했어 🌱", Toast.LENGTH_SHORT).show();
                return;
            }

            CompanionProfile.saveCheckIn(this, score);
            PetStateManager.onCheckIn(this, score);
            checkInReplyText.setText(UnifiedTherapyProfile.checkInReply(this, score));
            updateAffectionUi();
            updateCheckInUi();
            refreshRecords();
            updateReportPreview();
                updateLetterPreview();
        });
    }

    private void updateAffectionUi() {
        int affection = CompanionProfile.getAffection(this);
        affectionProgress.setProgress(affection);
        affectionLevelText.setText(
                "Lv." + CompanionProfile.level(affection)
                        + " · " + CompanionProfile.levelName(affection)
        );
        affectionPointText.setText(affection + " / 100");
    }

    private void updateCheckInUi() {
        boolean done = CompanionProfile.checkedInToday(this);
        int[] ids = {R.id.check1, R.id.check2, R.id.check3, R.id.check4, R.id.check5};
        for (int id : ids) {
            View v = findViewById(id);
            v.setEnabled(!done);
            v.setAlpha(done ? 0.45f : 1f);
        }

        if (done) {
            checkInStatusText.setText("오늘 마음 확인했어 💚 내일 또 물어볼게.");
        } else {
            checkInStatusText.setText("승재야, 오늘 마음은 1~5점 중 몇 점이야?");
        }
    }

    private void updateDiaryPreview() {
        String today = EmotionDiaryStorage.today();
        org.json.JSONObject obj = EmotionDiaryStorage.getEntryByDate(this, today);
        if (obj != null) {
            String sticker = obj.optString("sticker", "🙂");
            String label = obj.optString("label", "잔잔");
            String text = obj.optString("text", "");
            if (text.length() > 32) text = text.substring(0, 32) + "...";
            diaryPreviewText.setText("오늘 일기 있음 · " + sticker + " " + label + "\n" + text);
        } else {
            diaryPreviewText.setText("오늘 기분 스티커 하나 붙이고, 마음 한 줄만 남겨보자.");
        }
    }

    private void updateReportPreview() {
        reportPreviewText.setText(EmotionDiaryStorage.weeklyPatternSummary(this) + "\n" + UnifiedTherapyProfile.reportFocus(this));
    }


    private void updateLetterPreview() {
        String text = LiveMindManager.getLiveLetter(this);
        if (text.length() > 90) text = text.substring(0, 90) + "...";
        letterPreviewSummaryText.setText(text);
    }

    private void updatePetStateUi() {
        if (petStateSummaryText == null) return;
        petStateSummaryText.setText(PetStateManager.summary(this));
        String need = PetStateManager.dominantNeed(this);
        if ("rest".equals(need)) petStateHintText.setText("지금은 힘이 조금 떨어져 있어. 쉬는 쪽 행동이 더 자주 나올 거야.");
        else if ("calm".equals(need)) petStateHintText.setText("마음이 팽팽해서 어린 승재가 조금 더 차분하게 옆에 있어줄 거야.");
        else if ("company".equals(need)) petStateHintText.setText("혼자 있는 느낌이 커져서 어린 승재가 먼저 말을 걸 가능성이 높아졌어.");
        else if ("comfort".equals(need)) petStateHintText.setText("마음이 가라앉아 있어서 다독여주는 행동이 조금 더 자주 나올 거야.");
        else petStateHintText.setText("상태가 비교적 편안해. 어린 승재가 자유롭게 돌아다닐 거야.");
        String therapyTheme = UnifiedTherapyProfile.compactTheme(this);
        if (!therapyTheme.isEmpty()) {
            petStateHintText.append("\n요즘 같이 보고 있는 마음: " + therapyTheme);
        }
    }

    private void requestLocationIfNeeded() {
        if (Build.VERSION.SDK_INT >= 23
                && checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.ACCESS_COARSE_LOCATION}, 1002);
        }
    }


    private void updateWordsPreview() {
        if (wordsPreviewText == null) return;
        String words = LiveMindManager.getLiveWords(this);
        if (words.isEmpty()) words = LiveMindManager.localWords(this);
        String oneLine = words.replace("\r", "").replace("\n", "  ·  ");
        if (oneLine.length() > 110) oneLine = oneLine.substring(0, 110) + "...";
        wordsPreviewText.setText(oneLine);
    }

    private void refreshLiveAiContentIfNeeded() {
        if (liveAiRefreshing || !LiveMindManager.aiRefreshNeeded(this)) return;
        String apiKey = prefs.getString(AppPrefs.KEY_API_KEY, "").trim();
        if (apiKey.isEmpty()) return;
        liveAiRefreshing = true;
        final String recent = LiveMindManager.recentContext(this) + "\n\n" + UnifiedTherapyProfile.buildSharedContext(this);
        final String state = PetStateManager.summary(this);
        new Thread(() -> {
            String letter = "";
            String words = "";
            try {
                letter = OpenAiClient.getLiveDailyLetter(apiKey, recent, state, System.nanoTime());
                words = OpenAiClient.getFiveLineComfort(apiKey, recent, System.nanoTime());
                LiveMindManager.saveAiContent(this, letter, words);
            } catch (Exception ignored) {
                LiveMindManager.saveAiLetter(this, YoungSeungjaeHome.regenerateDailyLetter(this));
                LiveMindManager.saveAiWords(this, LiveMindManager.localWords(this));
            }
            runOnUiThread(() -> {
                liveAiRefreshing = false;
                updateLetterPreview();
                updateWordsPreview();
                updatePetStateUi();
                mainMascotPreview.setImageResource(YoungSeungjaeHome.getOutfitPreviewRes(this));
            });
        }).start();
    }

    private void requestNotificationsIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1001);
        }
    }

    private void shareText(String title, String text) {
        Intent intent = new Intent(Intent.ACTION_SEND);
        intent.setType("text/plain");
        intent.putExtra(Intent.EXTRA_SUBJECT, title);
        intent.putExtra(Intent.EXTRA_TEXT, text);
        startActivity(Intent.createChooser(intent, title));
    }
    private void openBackupCreateDocument() {
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("application/json");
        String name = "MaeumMon_backup_" + new java.text.SimpleDateFormat("yyyyMMdd_HHmm", java.util.Locale.KOREA).format(new java.util.Date()) + ".json";
        intent.putExtra(Intent.EXTRA_TITLE, name);
        startActivityForResult(intent, REQ_BACKUP_SAVE);
    }

    private void openBackupRestoreDocument() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("application/json");
        startActivityForResult(intent, REQ_BACKUP_RESTORE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        try {
            if (requestCode == REQ_BACKUP_SAVE) {
                BackupRestoreManager.exportToUri(this, uri);
                Toast.makeText(this, "마음몬 백업 저장 완료 ☁️", Toast.LENGTH_LONG).show();
            } else if (requestCode == REQ_BACKUP_RESTORE) {
                BackupRestoreManager.restoreFromUri(this, uri);
                Toast.makeText(this, "백업 복원 완료! 화면을 새로 반영했어 🌙", Toast.LENGTH_LONG).show();
                refreshAll();
                if (prefs.getBoolean(AppPrefs.KEY_OVERLAY, false)) {
                    stopService(new Intent(this, OverlayService.class));
                    startOverlayService();
                }
            }
        } catch (Exception e) {
            Toast.makeText(this, "백업 처리 실패: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

}
