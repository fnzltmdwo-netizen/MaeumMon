package com.maeummon.app.clinical;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.SharedPreferences;
import java.util.*;

public final class ClinicalDiagnosticsRC7 {
    private ClinicalDiagnosticsRC7(){}
    private static final String PREF="clinical_rc7_diag";

    public static void record(Context c, ClinicalDecisionRC7 d){
        if(c==null||d==null)return;
        c.getSharedPreferences(PREF,Context.MODE_PRIVATE).edit()
            .putString("move",d.move).putString("target",d.target)
                .putString("info_gain",String.valueOf(d.informationGain))
                .putString("question_rationale",d.questionRationale)
                .putBoolean("question_stop",d.questionStopTriggered)
                .putString("question_stop_reason",d.questionStopReason)
                .putString("intervention_id",d.selectedInterventionId)
                .putString("intervention_target",d.interventionTarget)
                .putString("intervention_score",String.valueOf(d.interventionScore))
                .putString("intervention_rationale",d.interventionRationale)
                .putString("review_outcome",d.interventionReviewOutcome)
                .putString("review_next_move",d.interventionReviewNextMove)
                .putString("adaptive_plan",d.adaptivePlanAction)
                .putString("adaptive_plan_rationale",d.adaptivePlanRationale)
                .putString("therapy_goal",d.therapeuticGoal)
                .putString("progress_signal",d.progressSignal)
                .putString("goal_transition",d.goalTransitionStatus)
                .putString("goal_transition_reason",d.goalTransitionReason)
                .putString("session_phase",d.sessionPhase)
                .putString("therapeutic_pacing",d.therapeuticPacing)
                .putString("phase_rationale",d.phaseRationale)
                .putInt("phase_question_budget",d.phaseQuestionBudget)
                .putBoolean("formulation_reopened",d.formulationReopened)
                .putString("formulation_reopen_reason",d.formulationReopenReason)
                .putString("reopen_recovery_target",d.reopenRecoveryTarget)
                .putString("reopen_recovery_move",d.reopenRecoveryMove)
                .putInt("reopen_recovery_ask_budget",d.reopenRecoveryAskBudget)
                .putInt("retired_hypothesis_count",d.retiredHypothesisCount)
                .putString("evidence_calibration_band",d.evidenceCalibrationBand)
                .putString("evidence_calibration_rationale",d.evidenceCalibrationRationale)
                .putInt("evidence_conflict_count",d.evidenceConflictCount)
                .putInt("unresolved_evidence_conflict_count",d.unresolvedEvidenceConflictCount)
                .putString("evidence_conflict_summary",d.evidenceConflictSummary)
                .putString("evidence_provenance_summary",d.evidenceProvenanceSummary)
                .putInt("unknown_evidence_count",d.unknownEvidenceCount)
                .putInt("stale_evidence_count",d.staleEvidenceCount)
                .putString("evidence_gate_summary",d.evidenceGateSummary)
                .putInt("promoted_evidence_count",d.promotedEvidenceCount)
                .putString("stable_memory_sync_summary",d.stableMemorySyncSummary)
                .putInt("stable_memory_promoted",d.stableMemoryPromoted)
                .putInt("stable_memory_demoted",d.stableMemoryDemoted)
                .putString("current_context_scope",d.currentContextScope)
                .putString("context_generalization_summary",d.contextGeneralizationSummary)
                .putInt("context_blocked_memory_count",d.contextBlockedMemoryCount)
                .putString("central_insight",d.centralInsight)
                .putString("central_mechanism",d.centralMechanism)
                .putBoolean("central_insight_usable",d.centralInsightUsable)
                .putBoolean("central_bridge_ready",d.centralBridgeReady)
                .putString("central_bridge_intervention",d.centralBridgeInterventionId)
                .putString("central_bridge_target",d.centralBridgeTarget)
                .putString("central_bridge_blocked_reason",d.centralBridgeBlockedReason)
                .putBoolean("release_integrity_pass",d.releaseIntegrityPass)
                .putBoolean("release_integrity_blocked",d.releaseIntegrityBlocked)
                .putString("release_integrity_summary",d.releaseIntegritySummary)
                .putString("response_fact_guard_summary",d.responseFactGuardSummary)
                .putBoolean("response_rewrite_required",d.responseRewriteRequired)
                .putString("response_overreach_guard_summary",d.responseOverreachGuardSummary)
                .putBoolean("response_overreach_rewrite_required",d.responseOverreachRewriteRequired)
                .putString("response_relevance_guard_summary",d.responseRelevanceGuardSummary)
                .putBoolean("response_relevance_rewrite_required",d.responseRelevanceRewriteRequired)
                .putString("response_attunement_guard_summary",d.responseAttunementGuardSummary)
                .putBoolean("response_attunement_rewrite_required",d.responseAttunementRewriteRequired)
                .putString("response_precision_guard_summary",d.responsePrecisionGuardSummary)
                .putBoolean("response_precision_rewrite_required",d.responsePrecisionRewriteRequired)
                .putString("response_specificity_guard_summary",d.responseSpecificityGuardSummary)
                .putBoolean("response_specificity_rewrite_required",d.responseSpecificityRewriteRequired)
                .putString("response_evidence_anchor_used",d.responseEvidenceAnchorUsed)
                .putString("response_continuity_guard_summary",d.responseContinuityGuardSummary)
                .putBoolean("response_continuity_rewrite_required",d.responseContinuityRewriteRequired)
                .putString("response_timing_guard_summary",d.responseTimingGuardSummary)
                .putBoolean("response_timing_rewrite_required",d.responseTimingRewriteRequired)
                .putString("final_acceptance_summary",d.finalAcceptanceSummary)
                .putBoolean("final_response_accepted",d.finalResponseAccepted)
                .putBoolean("final_fallback_used",d.finalFallbackUsed)
                .putString("intervention_dose",d.interventionDose)
                .putInt("intervention_max_steps",d.interventionMaxSteps)
                .putBoolean("intervention_homework_allowed",d.interventionHomeworkAllowed)
                .putInt("intervention_exercise_minutes",d.interventionExerciseMinutes)
                .putString("intervention_dose_rationale",d.interventionDoseRationale)
                .putString("intervention_delivery_style",d.interventionDeliveryStyle)
                .putString("intervention_dose_blocked_reason",d.interventionDoseBlockedReason)
                .putString("intervention_fidelity_summary",d.interventionFidelitySummary)
                .putBoolean("intervention_fidelity_rewrite_required",d.interventionFidelityRewriteRequired)
                .putString("minimal_action_plan",d.minimalActionPlan)
                .putString("intervention_outcome",d.interventionOutcome)
                .putBoolean("intervention_outcome_review_required",d.interventionOutcomeReviewRequired)
                .putBoolean("intervention_outcome_reopen_suggested",d.interventionOutcomeReopenSuggested)
                .putString("intervention_outcome_learning",d.interventionOutcomeLearning)
                .putString("intervention_outcome_next_move_hint",d.interventionOutcomeNextMoveHint)
                .putString("intervention_adaptation_action",d.interventionAdaptationAction)
                .putBoolean("intervention_switch_allowed",d.interventionSwitchAllowed)
                .putBoolean("intervention_switch_required",d.interventionSwitchRequired)
                .putBoolean("intervention_review_before_switch",d.interventionReviewBeforeSwitch)
                .putBoolean("intervention_adaptation_reopen",d.interventionAdaptationReopen)
                .putString("intervention_switch_candidate_id",d.interventionSwitchCandidateId)
                .putString("intervention_adaptation_rationale",d.interventionAdaptationRationale)
                .putString("intervention_adaptation_summary",d.interventionAdaptationSummary)
                .putString("intervention_barrier",d.interventionBarrier)
                .putBoolean("intervention_barrier_shrink",d.interventionBarrierShrink)
                .putBoolean("intervention_barrier_clarify",d.interventionBarrierClarify)
                .putBoolean("intervention_barrier_cue",d.interventionBarrierCue)
                .putBoolean("intervention_barrier_reduce_dose",d.interventionBarrierReduceDose)
                .putBoolean("intervention_barrier_change_context",d.interventionBarrierChangeContext)
                .putString("intervention_barrier_adjustment",d.interventionBarrierAdjustment)
                .putString("intervention_barrier_rationale",d.interventionBarrierRationale)
                .putString("intervention_barrier_summary",d.interventionBarrierSummary)
                .putString("intervention_preference_mode",d.interventionPreferenceMode)
                .putBoolean("intervention_preference_explicit",d.interventionPreferenceExplicit)
                .putBoolean("intervention_preference_inferred",d.interventionPreferenceInferred)
                .putBoolean("intervention_preference_modality_changed",d.interventionPreferenceModalityChanged)
                .putBoolean("intervention_preference_mechanism_preserved",d.interventionPreferenceMechanismPreserved)
                .putString("intervention_preference_source",d.interventionPreferenceSource)
                .putString("intervention_preference_rationale",d.interventionPreferenceRationale)
                .putString("intervention_preference_summary",d.interventionPreferenceSummary)
                .putBoolean("micro_experiment_ready",d.microExperimentReady)
                .putString("micro_experiment_id",d.microExperimentId)
                .putString("micro_experiment_action",d.microExperimentAction)
                .putString("micro_experiment_review_criterion",d.microExperimentReviewCriterion)
                .putString("micro_experiment_stop_condition",d.microExperimentStopCondition)
                .putString("micro_experiment_mode",d.microExperimentMode)
                .putString("micro_experiment_dose",d.microExperimentDose)
                .putInt("micro_experiment_max_minutes",d.microExperimentMaxMinutes)
                .putString("micro_experiment_rationale",d.microExperimentRationale)
                .putString("micro_experiment_summary",d.microExperimentSummary)
                .putBoolean("micro_experiment_active",d.microExperimentActive)
                .putString("micro_experiment_attribution",d.microExperimentAttribution)
                .putBoolean("micro_experiment_outcome_eligible",d.microExperimentOutcomeEligible)
                .putBoolean("micro_experiment_outcome_needs_clarification",d.microExperimentOutcomeNeedsClarification)
                .putString("micro_experiment_mapped_outcome",d.microExperimentMappedOutcome)
                .putString("micro_experiment_matched_evidence",d.microExperimentMatchedEvidence)
                .putString("micro_experiment_review_mapping_summary",d.microExperimentReviewMappingSummary)
                .putBoolean("review_attribution_clarification_needed",d.reviewAttributionClarificationNeeded)
                .putBoolean("review_attribution_ask_allowed",d.reviewAttributionAskAllowed)
                .putString("review_attribution_question",d.reviewAttributionQuestion)
                .putString("review_attribution_target",d.reviewAttributionTarget)
                .putString("review_attribution_source",d.reviewAttributionSource)
                .putString("review_attribution_reason",d.reviewAttributionReason)
                .putString("review_attribution_summary",d.reviewAttributionSummary)
                .putString("outcome_commit_state",d.outcomeCommitState)
                .putBoolean("outcome_commit_learning_allowed",d.outcomeCommitLearningAllowed)
                .putBoolean("outcome_commit_suppress_generic",d.outcomeCommitSuppressGeneric)
                .putString("outcome_commit_value",d.outcomeCommitValue)
                .putString("outcome_commit_resolution",d.outcomeCommitResolution)
                .putString("outcome_commit_reason",d.outcomeCommitReason)
                .putString("outcome_commit_summary",d.outcomeCommitSummary)
                .putBoolean("intervention_policy_memory_updated",d.interventionPolicyMemoryUpdated)
                .putString("intervention_policy_mechanism",d.interventionPolicyMechanism)
                .putString("intervention_policy_intervention_id",d.interventionPolicyInterventionId)
                .putString("intervention_policy_preferred_mode",d.interventionPolicyPreferredMode)
                .putString("intervention_policy_preferred_dose",d.interventionPolicyPreferredDose)
                .putString("intervention_policy_confidence",d.interventionPolicyConfidence)
                .putInt("intervention_policy_positive_commits",d.interventionPolicyPositiveCommits)
                .putInt("intervention_policy_negative_commits",d.interventionPolicyNegativeCommits)
                .putInt("intervention_policy_relevant_commits",d.interventionPolicyRelevantCommits)
                .putString("intervention_policy_context_scope",d.interventionPolicyContextScope)
                .putString("intervention_policy_recommendation",d.interventionPolicyRecommendation)
                .putString("intervention_policy_summary",d.interventionPolicySummary)
                .putBoolean("policy_retrieval_found",d.policyRetrievalFound)
                .putBoolean("policy_retrieval_applicable",d.policyRetrievalApplicable)
                .putBoolean("policy_mechanism_match",d.policyMechanismMatch)
                .putBoolean("policy_context_match",d.policyContextMatch)
                .putBoolean("policy_confidence_sufficient",d.policyConfidenceSufficient)
                .putBoolean("policy_blocked_by_current_evidence",d.policyBlockedByCurrentEvidence)
                .putString("policy_retrieval_key",d.policyRetrievalKey)
                .putString("policy_retrieval_intervention_id",d.policyRetrievalInterventionId)
                .putString("policy_retrieval_mode",d.policyRetrievalMode)
                .putString("policy_retrieval_dose",d.policyRetrievalDose)
                .putString("policy_retrieval_confidence",d.policyRetrievalConfidence)
                .putString("policy_retrieval_reason",d.policyRetrievalReason)
                .putString("policy_retrieval_summary",d.policyRetrievalSummary)
                .putBoolean("policy_conflict_detected",d.policyConflictDetected)
                .putString("policy_conflict_resolution",d.policyConflictResolution)
                .putBoolean("policy_can_affect_intervention",d.policyCanAffectIntervention)
                .putBoolean("policy_can_affect_mode",d.policyCanAffectMode)
                .putBoolean("policy_can_affect_dose",d.policyCanAffectDose)
                .putString("policy_conflict_reason",d.policyConflictReason)
                .putString("policy_conflict_summary",d.policyConflictSummary)
                .putBoolean("policy_decay_evaluated",d.policyDecayEvaluated)
                .putBoolean("policy_decay_changed",d.policyDecayChanged)
                .putString("policy_decay_status",d.policyDecayStatus)
                .putString("policy_decay_old_confidence",d.policyDecayOldConfidence)
                .putString("policy_decay_new_confidence",d.policyDecayNewConfidence)
                .putInt("policy_decay_recent_positive",d.policyDecayRecentPositive)
                .putInt("policy_decay_recent_negative",d.policyDecayRecentNegative)
                .putLong("policy_decay_age_days",d.policyDecayAgeDays)
                .putBoolean("policy_decay_stale",d.policyDecayStale)
                .putBoolean("policy_decay_contradicted",d.policyDecayContradicted)
                .putString("policy_decay_reason",d.policyDecayReason)
                .putString("policy_decay_summary",d.policyDecaySummary)
                .putBoolean("policy_revalidation_evaluated",d.policyRevalidationEvaluated)
                .putBoolean("policy_revalidation_changed",d.policyRevalidationChanged)
                .putString("policy_revalidation_state",d.policyRevalidationState)
                .putString("policy_revalidation_old_status",d.policyRevalidationOldStatus)
                .putString("policy_revalidation_new_status",d.policyRevalidationNewStatus)
                .putString("policy_revalidation_old_confidence",d.policyRevalidationOldConfidence)
                .putString("policy_revalidation_new_confidence",d.policyRevalidationNewConfidence)
                .putInt("policy_revalidation_recent_positive",d.policyRevalidationRecentPositive)
                .putInt("policy_revalidation_recent_negative",d.policyRevalidationRecentNegative)
                .putString("policy_revalidation_reason",d.policyRevalidationReason)
                .putString("policy_revalidation_summary",d.policyRevalidationSummary)
                .putBoolean("policy_transfer_evaluated",d.policyTransferEvaluated)
                .putString("policy_transfer_state",d.policyTransferState)
                .putString("policy_transfer_source_context",d.policyTransferSourceContext)
                .putString("policy_transfer_target_context",d.policyTransferTargetContext)
                .putBoolean("policy_transfer_mechanism_match",d.policyTransferMechanismMatch)
                .putBoolean("policy_transfer_context_similarity",d.policyTransferContextSimilarity)
                .putBoolean("policy_transfer_evidence_sufficient",d.policyTransferEvidenceSufficient)
                .putBoolean("policy_transfer_trial_only",d.policyTransferTrialOnly)
                .putBoolean("policy_transfer_general_eligible",d.policyTransferGeneralEligible)
                .putString("policy_transfer_reason",d.policyTransferReason)
                .putString("policy_transfer_summary",d.policyTransferSummary)
                .putBoolean("general_policy_promotion_evaluated",d.generalPolicyPromotionEvaluated)
                .putBoolean("general_policy_promotion_changed",d.generalPolicyPromotionChanged)
                .putString("general_policy_promotion_state",d.generalPolicyPromotionState)
                .putInt("general_policy_distinct_contexts",d.generalPolicyDistinctContexts)
                .putInt("general_policy_positive_commits",d.generalPolicyPositiveCommits)
                .putInt("general_policy_negative_commits",d.generalPolicyNegativeCommits)
                .putBoolean("general_policy_clean_across_contexts",d.generalPolicyCleanAcrossContexts)
                .putString("general_policy_promotion_reason",d.generalPolicyPromotionReason)
                .putString("general_policy_promotion_summary",d.generalPolicyPromotionSummary)
                .putBoolean("general_policy_boundary_evaluated",d.generalPolicyBoundaryEvaluated)
                .putBoolean("general_policy_boundary_changed",d.generalPolicyBoundaryChanged)
                .putString("general_policy_boundary_state",d.generalPolicyBoundaryState)
                .putString("general_policy_boundary_context",d.generalPolicyBoundaryContext)
                .putInt("general_policy_boundary_recent_positive",d.generalPolicyBoundaryRecentPositive)
                .putInt("general_policy_boundary_recent_negative",d.generalPolicyBoundaryRecentNegative)
                .putBoolean("general_policy_boundary_excluded",d.generalPolicyBoundaryExcluded)
                .putString("general_policy_boundary_reason",d.generalPolicyBoundaryReason)
                .putString("general_policy_boundary_summary",d.generalPolicyBoundarySummary)
                .putBoolean("policy_hierarchy_evaluated",d.policyHierarchyEvaluated)
                .putString("policy_hierarchy_winner",d.policyHierarchyWinner)
                .putBoolean("policy_hierarchy_context_found",d.policyHierarchyContextFound)
                .putBoolean("policy_hierarchy_general_found",d.policyHierarchyGeneralFound)
                .putBoolean("policy_hierarchy_both_found",d.policyHierarchyBothFound)
                .putString("policy_hierarchy_context_key",d.policyHierarchyContextKey)
                .putString("policy_hierarchy_general_key",d.policyHierarchyGeneralKey)
                .putString("policy_hierarchy_selected_key",d.policyHierarchySelectedKey)
                .putString("policy_hierarchy_selected_intervention",d.policyHierarchySelectedIntervention)
                .putString("policy_hierarchy_selected_mode",d.policyHierarchySelectedMode)
                .putString("policy_hierarchy_selected_dose",d.policyHierarchySelectedDose)
                .putString("policy_hierarchy_reason",d.policyHierarchyReason)
                .putString("policy_hierarchy_summary",d.policyHierarchySummary)
                .putBoolean("policy_selection_enforcement_evaluated",d.policySelectionEnforcementEvaluated)
                .putBoolean("policy_selection_mismatch_detected",d.policySelectionMismatchDetected)
                .putBoolean("policy_selection_rebound_applied",d.policySelectionReboundApplied)
                .putBoolean("policy_selection_suppressed",d.policySelectionSuppressed)
                .putString("policy_selection_enforcement_state",d.policySelectionEnforcementState)
                .putString("policy_selection_hierarchy_key",d.policySelectionHierarchyKey)
                .putString("policy_selection_retrieval_key",d.policySelectionRetrievalKey)
                .putString("policy_selection_effective_key",d.policySelectionEffectiveKey)
                .putString("policy_selection_effective_intervention",d.policySelectionEffectiveIntervention)
                .putString("policy_selection_effective_mode",d.policySelectionEffectiveMode)
                .putString("policy_selection_effective_dose",d.policySelectionEffectiveDose)
                .putString("policy_selection_reason",d.policySelectionReason)
                .putString("policy_selection_summary",d.policySelectionSummary)
                .putBoolean("adaptive_policy_release_gate_passed",d.adaptivePolicyReleaseGatePassed)
                .putBoolean("adaptive_policy_release_gate_repaired",d.adaptivePolicyReleaseGateRepaired)
                .putBoolean("adaptive_policy_release_outcome_leak_blocked",d.adaptivePolicyReleaseOutcomeLeakBlocked)
                .putBoolean("adaptive_policy_release_hierarchy_leak_blocked",d.adaptivePolicyReleaseHierarchyLeakBlocked)
                .putBoolean("adaptive_policy_release_retired_leak_blocked",d.adaptivePolicyReleaseRetiredLeakBlocked)
                .putBoolean("adaptive_policy_release_exception_leak_blocked",d.adaptivePolicyReleaseExceptionLeakBlocked)
                .putBoolean("adaptive_policy_release_bridge_override_blocked",d.adaptivePolicyReleaseBridgeOverrideBlocked)
                .putInt("adaptive_policy_release_violation_count",d.adaptivePolicyReleaseViolationCount)
                .putString("adaptive_policy_release_violations",d.adaptivePolicyReleaseViolations)
                .putString("adaptive_policy_release_summary",d.adaptivePolicyReleaseSummary)
                .putBoolean("outcome_commit_idempotency_evaluated",d.outcomeCommitIdempotencyEvaluated)
                .putBoolean("outcome_commit_learning_allowed",d.outcomeCommitLearningAllowed)
                .putBoolean("outcome_commit_duplicate",d.outcomeCommitDuplicate)
                .putBoolean("outcome_commit_conflicting_duplicate",d.outcomeCommitConflictingDuplicate)
                .putString("outcome_commit_idempotency_state",d.outcomeCommitIdempotencyState)
                .putString("outcome_commit_idempotency_key",d.outcomeCommitIdempotencyKey)
                .putString("outcome_commit_idempotency_reason",d.outcomeCommitIdempotencyReason)
                .putString("outcome_commit_idempotency_summary",d.outcomeCommitIdempotencySummary)
                .putBoolean("outcome_revision_evaluated",d.outcomeRevisionEvaluated)
                .putBoolean("outcome_revision_review_required",d.outcomeRevisionReviewRequired)
                .putBoolean("outcome_revision_applied",d.outcomeRevisionApplied)
                .putBoolean("outcome_revision_rejected",d.outcomeRevisionRejected)
                .putString("outcome_revision_state",d.outcomeRevisionState)
                .putString("outcome_revision_experiment_id",d.outcomeRevisionExperimentId)
                .putString("outcome_revision_prior",d.outcomeRevisionPrior)
                .putString("outcome_revision_proposed",d.outcomeRevisionProposed)
                .putString("outcome_revision_final",d.outcomeRevisionFinal)
                .putString("outcome_revision_question",d.outcomeRevisionQuestion)
                .putString("outcome_revision_reason",d.outcomeRevisionReason)
                .putString("outcome_revision_summary",d.outcomeRevisionSummary)
                .putBoolean("outcome_revision_propagation_evaluated",d.outcomeRevisionPropagationEvaluated)
                .putBoolean("outcome_revision_propagation_recomputed",d.outcomeRevisionPropagationRecomputed)
                .putString("outcome_revision_propagation_state",d.outcomeRevisionPropagationState)
                .putInt("outcome_revision_propagation_commit_rows",d.outcomeRevisionPropagationCommitRows)
                .putInt("outcome_revision_propagation_transfer_rows",d.outcomeRevisionPropagationTransferRows)
                .putInt("outcome_revision_propagation_policies",d.outcomeRevisionPropagationPolicies)
                .putBoolean("outcome_revision_propagation_generalization",d.outcomeRevisionPropagationGeneralization)
                .putString("outcome_revision_propagation_reason",d.outcomeRevisionPropagationReason)
                .putString("outcome_revision_propagation_summary",d.outcomeRevisionPropagationSummary)
                .putBoolean("structured_provenance_evaluated",d.structuredProvenanceEvaluated)
                .putBoolean("structured_provenance_enriched",d.structuredProvenanceEnriched)
                .putBoolean("structured_provenance_legacy_migrated",d.structuredProvenanceLegacyMigrated)
                .putInt("structured_provenance_rows_enriched",d.structuredProvenanceRowsEnriched)
                .putInt("structured_provenance_legacy_rows_migrated",d.structuredProvenanceLegacyRowsMigrated)
                .putString("structured_provenance_canonical_key",d.structuredProvenanceCanonicalKey)
                .putString("structured_provenance_reason",d.structuredProvenanceReason)
                .putString("structured_provenance_summary",d.structuredProvenanceSummary)
                .putBoolean("provenance_integrity_evaluated",d.provenanceIntegrityEvaluated)
                .putBoolean("provenance_integrity_repaired",d.provenanceIntegrityRepaired)
                .putBoolean("provenance_integrity_quarantined",d.provenanceIntegrityQuarantined)
                .putInt("provenance_integrity_rows_checked",d.provenanceIntegrityRowsChecked)
                .putInt("provenance_integrity_rows_repaired",d.provenanceIntegrityRowsRepaired)
                .putInt("provenance_integrity_rows_quarantined",d.provenanceIntegrityRowsQuarantined)
                .putInt("provenance_integrity_legacy_unresolved",d.provenanceIntegrityLegacyUnresolved)
                .putString("provenance_integrity_reason",d.provenanceIntegrityReason)
                .putString("provenance_integrity_summary",d.provenanceIntegritySummary)
                .putBoolean("provenance_lineage_evaluated",d.provenanceLineageEvaluated)
                .putBoolean("provenance_lineage_updated",d.provenanceLineageUpdated)
                .putInt("provenance_lineage_nodes_added",d.provenanceLineageNodesAdded)
                .putInt("provenance_lineage_edges_added",d.provenanceLineageEdgesAdded)
                .putString("provenance_lineage_experiment_id",d.provenanceLineageExperimentId)
                .putString("provenance_lineage_policy_key",d.provenanceLineagePolicyKey)
                .putString("provenance_lineage_root_key",d.provenanceLineageRootKey)
                .putString("provenance_lineage_reason",d.provenanceLineageReason)
                .putString("provenance_lineage_summary",d.provenanceLineageSummary)
                .putBoolean("decision_rationale_evaluated",d.decisionRationaleEvaluated)
                .putBoolean("decision_rationale_usable",d.decisionRationaleUsable)
                .putBoolean("decision_rationale_policy_referenced",d.decisionRationalePolicyReferenced)
                .putBoolean("decision_rationale_current_evidence_primary",d.decisionRationaleCurrentEvidencePrimary)
                .putString("decision_rationale_text",d.decisionRationaleText)
                .putString("decision_rationale_compact",d.decisionRationaleCompact)
                .putString("decision_rationale_source_tier",d.decisionRationaleSourceTier)
                .putString("decision_rationale_reason",d.decisionRationaleReason)
                .putString("decision_rationale_summary",d.decisionRationaleSummary)
                .putBoolean("decision_rationale_fidelity_evaluated",d.decisionRationaleFidelityEvaluated)
                .putBoolean("decision_rationale_fidelity_repaired",d.decisionRationaleFidelityRepaired)
                .putBoolean("decision_rationale_fidelity_blocked",d.decisionRationaleFidelityBlocked)
                .putBoolean("decision_rationale_move_mismatch",d.decisionRationaleMoveMismatch)
                .putBoolean("decision_rationale_policy_overclaim",d.decisionRationalePolicyOverclaim)
                .putBoolean("decision_rationale_unsupported_certainty",d.decisionRationaleUnsupportedCertainty)
                .putBoolean("decision_rationale_internal_jargon_leak",d.decisionRationaleInternalJargonLeak)
                .putBoolean("decision_rationale_evidence_mismatch",d.decisionRationaleEvidenceMismatch)
                .putString("decision_rationale_fidelity_state",d.decisionRationaleFidelityState)
                .putString("decision_rationale_final",d.decisionRationaleFinal)
                .putString("decision_rationale_fidelity_reason",d.decisionRationaleFidelityReason)
                .putString("decision_rationale_fidelity_summary",d.decisionRationaleFidelitySummary)
                .putBoolean("explainability_delivery_evaluated",d.explainabilityDeliveryEvaluated)
                .putBoolean("explainability_should_surface",d.explainabilityShouldSurface)
                .putBoolean("explainability_user_asked_why",d.explainabilityUserAskedWhy)
                .putBoolean("explainability_decision_needs_justification",d.explainabilityDecisionNeedsJustification)
                .putBoolean("explainability_recent_rationale_shown",d.explainabilityRecentRationaleShown)
                .putBoolean("explainability_suppressed_for_repetition",d.explainabilitySuppressedForRepetition)
                .putString("explainability_delivery_mode",d.explainabilityDeliveryMode)
                .putString("explainability_delivery_text",d.explainabilityDeliveryText)
                .putString("explainability_placement",d.explainabilityPlacement)
                .putInt("explainability_max_sentences",d.explainabilityMaxSentences)
                .putString("explainability_delivery_reason",d.explainabilityDeliveryReason)
                .putString("explainability_delivery_summary",d.explainabilityDeliverySummary)
                .putBoolean("decision_transition_snapshot_loaded",d.decisionTransitionSnapshotLoaded)
                .putBoolean("decision_transition_move_changed",d.decisionTransitionMoveChanged)
                .putBoolean("decision_transition_intervention_changed",d.decisionTransitionInterventionChanged)
                .putBoolean("decision_transition_target_changed",d.decisionTransitionTargetChanged)
                .putString("decision_transition_summary",d.decisionTransitionSummary)
                .putBoolean("decision_transition_cause_evaluated",d.decisionTransitionCauseEvaluated)
                .putBoolean("decision_transition_cause_detected",d.decisionTransitionCauseDetected)
                .putString("decision_transition_primary_cause",d.decisionTransitionPrimaryCause)
                .putString("decision_transition_secondary_cause",d.decisionTransitionSecondaryCause)
                .putString("decision_transition_from_state",d.decisionTransitionFromState)
                .putString("decision_transition_to_state",d.decisionTransitionToState)
                .putString("decision_transition_human_reason",d.decisionTransitionHumanReason)
                .putString("decision_transition_cause_reason",d.decisionTransitionCauseReason)
                .putString("decision_transition_cause_summary",d.decisionTransitionCauseSummary)
                .putBoolean("decision_transition_cause_fidelity_evaluated",d.decisionTransitionCauseFidelityEvaluated)
                .putBoolean("decision_transition_cause_fidelity_repaired",d.decisionTransitionCauseFidelityRepaired)
                .putBoolean("decision_transition_cause_fidelity_blocked",d.decisionTransitionCauseFidelityBlocked)
                .putBoolean("decision_transition_multi_cause",d.decisionTransitionMultiCause)
                .putString("decision_transition_cause_fidelity_state",d.decisionTransitionCauseFidelityState)
                .putString("decision_transition_cause_confidence",d.decisionTransitionCauseConfidence)
                .putString("decision_transition_fidelity_primary_cause",d.decisionTransitionFidelityPrimaryCause)
                .putString("decision_transition_fidelity_secondary_cause",d.decisionTransitionFidelitySecondaryCause)
                .putString("decision_transition_fidelity_human_reason",d.decisionTransitionFidelityHumanReason)
                .putString("decision_transition_cause_fidelity_reason",d.decisionTransitionCauseFidelityReason)
                .putString("decision_transition_cause_fidelity_summary",d.decisionTransitionCauseFidelitySummary)
                .putBoolean("transition_explanation_correction_evaluated",d.transitionExplanationCorrectionEvaluated)
                .putBoolean("transition_explanation_correction_detected",d.transitionExplanationCorrectionDetected)
                .putBoolean("transition_explanation_clarification_required",d.transitionExplanationClarificationRequired)
                .putBoolean("transition_explanation_correction_applied",d.transitionExplanationCorrectionApplied)
                .putBoolean("transition_explanation_correction_rejected",d.transitionExplanationCorrectionRejected)
                .putString("transition_explanation_correction_state",d.transitionExplanationCorrectionState)
                .putString("transition_explanation_prior_cause",d.transitionExplanationPriorCause)
                .putString("transition_explanation_corrected_cause",d.transitionExplanationCorrectedCause)
                .putString("transition_explanation_corrected_reason",d.transitionExplanationCorrectedReason)
                .putString("transition_explanation_clarification_question",d.transitionExplanationClarificationQuestion)
                .putString("transition_explanation_correction_reason",d.transitionExplanationCorrectionReason)
                .putString("transition_explanation_correction_summary",d.transitionExplanationCorrectionSummary)
                .putBoolean("transition_correction_memory_evaluated",d.transitionCorrectionMemoryEvaluated)
                .putBoolean("transition_correction_memory_reusable",d.transitionCorrectionMemoryReusable)
                .putBoolean("transition_correction_memory_exact",d.transitionCorrectionMemoryExact)
                .putBoolean("transition_correction_memory_blocked",d.transitionCorrectionMemoryBlocked)
                .putString("transition_correction_memory_match",d.transitionCorrectionMemoryMatch)
                .putString("transition_correction_memory_cause",d.transitionCorrectionMemoryCause)
                .putString("transition_correction_memory_reason_text",d.transitionCorrectionMemoryReasonText)
                .putString("transition_correction_memory_source_context",d.transitionCorrectionMemorySourceContext)
                .putString("transition_correction_memory_current_context",d.transitionCorrectionMemoryCurrentContext)
                .putString("transition_correction_memory_reason",d.transitionCorrectionMemoryReason)
                .putString("transition_correction_memory_summary",d.transitionCorrectionMemorySummary)
                .putBoolean("transition_correction_revalidation_evaluated",d.transitionCorrectionRevalidationEvaluated)
                .putBoolean("transition_correction_revalidation_pending",d.transitionCorrectionRevalidationPending)
                .putBoolean("transition_correction_reactivated",d.transitionCorrectionReactivated)
                .putString("transition_correction_revalidation_state",d.transitionCorrectionRevalidationState)
                .putString("transition_correction_revalidation_key",d.transitionCorrectionRevalidationKey)
                .putString("transition_correction_revalidation_context",d.transitionCorrectionRevalidationContext)
                .putString("transition_correction_revalidation_cause",d.transitionCorrectionRevalidationCause)
                .putInt("transition_correction_revalidation_confirmations",d.transitionCorrectionRevalidationConfirmations)
                .putInt("transition_correction_revalidation_contradictions",d.transitionCorrectionRevalidationContradictions)
                .putString("transition_correction_revalidation_reason",d.transitionCorrectionRevalidationReason)
                .putString("transition_correction_revalidation_summary",d.transitionCorrectionRevalidationSummary)
                .putBoolean("transition_correction_conflict_evaluated",d.transitionCorrectionConflictEvaluated)
                .putBoolean("transition_correction_conflicted",d.transitionCorrectionConflicted)
                .putBoolean("transition_correction_replacement_pending",d.transitionCorrectionReplacementPending)
                .putBoolean("transition_correction_replaced",d.transitionCorrectionReplaced)
                .putBoolean("transition_correction_retired",d.transitionCorrectionRetired)
                .putString("transition_correction_conflict_state",d.transitionCorrectionConflictState)
                .putString("transition_correction_conflict_key",d.transitionCorrectionConflictKey)
                .putString("transition_correction_conflict_incumbent",d.transitionCorrectionConflictIncumbent)
                .putString("transition_correction_conflict_challenger",d.transitionCorrectionConflictChallenger)
                .putInt("transition_correction_conflict_incumbent_count",d.transitionCorrectionConflictIncumbentCount)
                .putInt("transition_correction_conflict_challenger_count",d.transitionCorrectionConflictChallengerCount)
                .putInt("transition_correction_conflict_distinct_causes",d.transitionCorrectionConflictDistinctCauses)
                .putString("transition_correction_conflict_active_cause",d.transitionCorrectionConflictActiveCause)
                .putString("transition_correction_conflict_active_reason",d.transitionCorrectionConflictActiveReason)
                .putString("transition_correction_conflict_reason",d.transitionCorrectionConflictReason)
                .putString("transition_correction_conflict_summary",d.transitionCorrectionConflictSummary)
                .putBoolean("transition_correction_fresh_evidence_evaluated",d.transitionCorrectionFreshEvidenceEvaluated)
                .putBoolean("transition_correction_memory_allowed",d.transitionCorrectionMemoryAllowed)
                .putBoolean("transition_correction_current_turn_override",d.transitionCorrectionCurrentTurnOverride)
                .putBoolean("transition_correction_fresh_evidence_blocked",d.transitionCorrectionFreshEvidenceBlocked)
                .putString("transition_correction_fresh_evidence_state",d.transitionCorrectionFreshEvidenceState)
                .putString("transition_correction_fresh_evidence_memory_cause",d.transitionCorrectionFreshEvidenceMemoryCause)
                .putString("transition_correction_fresh_evidence_current_cause",d.transitionCorrectionFreshEvidenceCurrentCause)
                .putString("transition_correction_fresh_evidence_effective_cause",d.transitionCorrectionFreshEvidenceEffectiveCause)
                .putString("transition_correction_fresh_evidence_effective_reason",d.transitionCorrectionFreshEvidenceEffectiveReason)
                .putString("transition_correction_fresh_evidence_reason",d.transitionCorrectionFreshEvidenceReason)
                .putString("transition_correction_fresh_evidence_summary",d.transitionCorrectionFreshEvidenceSummary)
                .putBoolean("transition_correction_override_isolation_evaluated",d.transitionCorrectionOverrideIsolationEvaluated)
                .putBoolean("transition_correction_override_ephemeral",d.transitionCorrectionOverrideEphemeral)
                .putBoolean("transition_correction_commit_allowed",d.transitionCorrectionCommitAllowed)
                .putBoolean("transition_correction_commit_blocked",d.transitionCorrectionCommitBlocked)
                .putBoolean("transition_correction_duplicate_commit_suppressed",d.transitionCorrectionDuplicateCommitSuppressed)
                .putString("transition_correction_override_isolation_state",d.transitionCorrectionOverrideIsolationState)
                .putString("transition_correction_commit_identity",d.transitionCorrectionCommitIdentity)
                .putString("transition_correction_override_isolation_reason",d.transitionCorrectionOverrideIsolationReason)
                .putString("transition_correction_override_isolation_summary",d.transitionCorrectionOverrideIsolationSummary)
                .putBoolean("transition_correction_commit_provenance_evaluated",d.transitionCorrectionCommitProvenanceEvaluated)
                .putBoolean("transition_correction_commit_provenance_ready",d.transitionCorrectionCommitProvenanceReady)
                .putBoolean("transition_correction_commit_provenance_committed",d.transitionCorrectionCommitProvenanceCommitted)
                .putBoolean("transition_correction_commit_provenance_blocked",d.transitionCorrectionCommitProvenanceBlocked)
                .putBoolean("transition_correction_commit_provenance_duplicate",d.transitionCorrectionCommitProvenanceDuplicate)
                .putString("transition_correction_commit_provenance_state",d.transitionCorrectionCommitProvenanceState)
                .putString("transition_correction_commit_evidence_id",d.transitionCorrectionCommitEvidenceId)
                .putString("transition_correction_canonical_commit_key",d.transitionCorrectionCanonicalCommitKey)
                .putString("transition_correction_commit_transition_key",d.transitionCorrectionCommitTransitionKey)
                .putString("transition_correction_commit_context",d.transitionCorrectionCommitContext)
                .putString("transition_correction_commit_provenance_reason",d.transitionCorrectionCommitProvenanceReason)
                .putString("transition_correction_commit_provenance_summary",d.transitionCorrectionCommitProvenanceSummary)
                .putBoolean("correction_provenance_integrity_evaluated",d.correctionProvenanceIntegrityEvaluated)
                .putBoolean("correction_provenance_integrity_repaired",d.correctionProvenanceIntegrityRepaired)
                .putBoolean("correction_provenance_integrity_quarantined",d.correctionProvenanceIntegrityQuarantined)
                .putInt("correction_provenance_integrity_rows_checked",d.correctionProvenanceIntegrityRowsChecked)
                .putInt("correction_provenance_integrity_rows_valid",d.correctionProvenanceIntegrityRowsValid)
                .putInt("correction_provenance_integrity_rows_repaired",d.correctionProvenanceIntegrityRowsRepaired)
                .putInt("correction_provenance_integrity_rows_quarantined",d.correctionProvenanceIntegrityRowsQuarantined)
                .putInt("correction_provenance_integrity_legacy_unresolved",d.correctionProvenanceIntegrityLegacyUnresolved)
                .putString("correction_provenance_integrity_reason",d.correctionProvenanceIntegrityReason)
                .putString("correction_provenance_integrity_summary",d.correctionProvenanceIntegritySummary)
                .putBoolean("correction_provenance_reinstatement_evaluated",d.correctionProvenanceReinstatementEvaluated)
                .putBoolean("correction_provenance_reinstatement_review_required",d.correctionProvenanceReinstatementReviewRequired)
                .putBoolean("correction_provenance_reinstatement_ready",d.correctionProvenanceReinstatementReady)
                .putBoolean("correction_provenance_reinstated",d.correctionProvenanceReinstated)
                .putBoolean("correction_provenance_reinstatement_blocked",d.correctionProvenanceReinstatementBlocked)
                .putInt("correction_provenance_reinstatement_matching_rows",d.correctionProvenanceReinstatementMatchingRows)
                .putInt("correction_provenance_reinstated_rows",d.correctionProvenanceReinstatedRows)
                .putString("correction_provenance_reinstatement_state",d.correctionProvenanceReinstatementState)
                .putString("correction_provenance_reinstatement_transition_key",d.correctionProvenanceReinstatementTransitionKey)
                .putString("correction_provenance_reinstatement_context",d.correctionProvenanceReinstatementContext)
                .putString("correction_provenance_reinstatement_cause",d.correctionProvenanceReinstatementCause)
                .putString("correction_provenance_reinstatement_reason",d.correctionProvenanceReinstatementReason)
                .putString("correction_provenance_reinstatement_summary",d.correctionProvenanceReinstatementSummary)
                .putBoolean("correction_provenance_reinstatement_idempotency_evaluated",d.correctionProvenanceReinstatementIdempotencyEvaluated)
                .putBoolean("correction_provenance_reinstatement_idempotency_allow",d.correctionProvenanceReinstatementIdempotencyAllow)
                .putBoolean("correction_provenance_reinstatement_duplicate_suppressed",d.correctionProvenanceReinstatementDuplicateSuppressed)
                .putBoolean("correction_provenance_reinstatement_already_active",d.correctionProvenanceReinstatementAlreadyActive)
                .putBoolean("correction_provenance_reinstatement_idempotency_blocked",d.correctionProvenanceReinstatementIdempotencyBlocked)
                .putString("correction_provenance_reinstatement_idempotency_state",d.correctionProvenanceReinstatementIdempotencyState)
                .putString("correction_provenance_reinstatement_identity",d.correctionProvenanceReinstatementIdentity)
                .putString("correction_provenance_reinstatement_idempotency_reason",d.correctionProvenanceReinstatementIdempotencyReason)
                .putString("correction_provenance_reinstatement_idempotency_summary",d.correctionProvenanceReinstatementIdempotencySummary)
                .putBoolean("post_reinstatement_verification_evaluated",d.postReinstatementVerificationEvaluated)
                .putBoolean("post_reinstatement_verification_required",d.postReinstatementVerificationRequired)
                .putBoolean("post_reinstatement_verified_keep",d.postReinstatementVerifiedKeep)
                .putBoolean("post_reinstatement_requarantined",d.postReinstatementRequarantined)
                .putString("post_reinstatement_verification_state",d.postReinstatementVerificationState)
                .putString("post_reinstatement_transition_key",d.postReinstatementTransitionKey)
                .putString("post_reinstatement_reinstated_cause",d.postReinstatementReinstatedCause)
                .putString("post_reinstatement_current_cause",d.postReinstatementCurrentCause)
                .putString("post_reinstatement_verification_reason",d.postReinstatementVerificationReason)
                .putString("post_reinstatement_verification_summary",d.postReinstatementVerificationSummary)
                .putBoolean("requarantine_cooldown_evaluated",d.requarantineCooldownEvaluated)
                .putBoolean("requarantine_cooldown_active",d.requarantineCooldownActive)
                .putBoolean("requarantine_cooldown_released",d.requarantineCooldownReleased)
                .putBoolean("requarantine_loop_blocked",d.requarantineLoopBlocked)
                .putString("requarantine_cooldown_state",d.requarantineCooldownState)
                .putString("requarantine_cooldown_transition_key",d.requarantineCooldownTransitionKey)
                .putString("requarantine_cooldown_quarantined_cause",d.requarantineCooldownQuarantinedCause)
                .putString("requarantine_cooldown_current_cause",d.requarantineCooldownCurrentCause)
                .putInt("requarantine_cooldown_clean_confirmations",d.requarantineCooldownCleanConfirmations)
                .putInt("requarantine_cooldown_contradictions",d.requarantineCooldownContradictions)
                .putString("requarantine_cooldown_reason",d.requarantineCooldownReason)
                .putString("requarantine_cooldown_summary",d.requarantineCooldownSummary)
                .putBoolean("cooldown_evidence_ledger_evaluated",d.cooldownEvidenceLedgerEvaluated)
                .putBoolean("cooldown_evidence_ledger_committed",d.cooldownEvidenceLedgerCommitted)
                .putBoolean("cooldown_evidence_ledger_duplicate",d.cooldownEvidenceLedgerDuplicate)
                .putBoolean("cooldown_evidence_ledger_eligible",d.cooldownEvidenceLedgerEligible)
                .putBoolean("cooldown_evidence_ledger_contradiction",d.cooldownEvidenceLedgerContradiction)
                .putString("cooldown_evidence_ledger_state",d.cooldownEvidenceLedgerState)
                .putString("cooldown_evidence_ledger_evidence_id",d.cooldownEvidenceLedgerEvidenceId)
                .putString("cooldown_evidence_ledger_identity",d.cooldownEvidenceLedgerIdentity)
                .putString("cooldown_evidence_ledger_transition_key",d.cooldownEvidenceLedgerTransitionKey)
                .putString("cooldown_evidence_ledger_reason",d.cooldownEvidenceLedgerReason)
                .putString("cooldown_evidence_ledger_summary",d.cooldownEvidenceLedgerSummary)
                .putBoolean("cooldown_evidence_integrity_evaluated",d.cooldownEvidenceIntegrityEvaluated)
                .putBoolean("cooldown_evidence_integrity_repaired",d.cooldownEvidenceIntegrityRepaired)
                .putBoolean("cooldown_evidence_integrity_quarantined",d.cooldownEvidenceIntegrityQuarantined)
                .putBoolean("cooldown_evidence_synthetic_blocked",d.cooldownEvidenceSyntheticBlocked)
                .putInt("cooldown_evidence_integrity_rows_checked",d.cooldownEvidenceIntegrityRowsChecked)
                .putInt("cooldown_evidence_integrity_rows_valid",d.cooldownEvidenceIntegrityRowsValid)
                .putInt("cooldown_evidence_integrity_rows_repaired",d.cooldownEvidenceIntegrityRowsRepaired)
                .putInt("cooldown_evidence_integrity_rows_quarantined",d.cooldownEvidenceIntegrityRowsQuarantined)
                .putInt("cooldown_evidence_synthetic_blocked_rows",d.cooldownEvidenceSyntheticBlockedRows)
                .putString("cooldown_evidence_integrity_reason",d.cooldownEvidenceIntegrityReason)
                .putString("cooldown_evidence_integrity_summary",d.cooldownEvidenceIntegritySummary)
                .putBoolean("cooldown_evidence_independence_evaluated",d.cooldownEvidenceIndependenceEvaluated)
                .putBoolean("cooldown_evidence_independent",d.cooldownEvidenceIndependent)
                .putBoolean("cooldown_evidence_duplicate",d.cooldownEvidenceDuplicate)
                .putBoolean("cooldown_evidence_near_duplicate",d.cooldownEvidenceNearDuplicate)
                .putBoolean("cooldown_evidence_independence_blocked",d.cooldownEvidenceIndependenceBlocked)
                .putString("cooldown_evidence_independence_state",d.cooldownEvidenceIndependenceState)
                .putString("cooldown_evidence_independence_matched_evidence_id",d.cooldownEvidenceIndependenceMatchedEvidenceId)
                .putString("cooldown_evidence_similarity",d.cooldownEvidenceSimilarity)
                .putString("cooldown_evidence_independence_reason",d.cooldownEvidenceIndependenceReason)
                .putString("cooldown_evidence_independence_summary",d.cooldownEvidenceIndependenceSummary)
                .putBoolean("cooldown_evidence_temporal_independence_evaluated",d.cooldownEvidenceTemporalIndependenceEvaluated)
                .putBoolean("cooldown_evidence_temporally_independent",d.cooldownEvidenceTemporallyIndependent)
                .putBoolean("cooldown_evidence_burst_blocked",d.cooldownEvidenceBurstBlocked)
                .putBoolean("cooldown_evidence_temporal_waiting",d.cooldownEvidenceTemporalWaiting)
                .putString("cooldown_evidence_temporal_independence_state",d.cooldownEvidenceTemporalIndependenceState)
                .putString("cooldown_evidence_temporal_transition_key",d.cooldownEvidenceTemporalTransitionKey)
                .putString("cooldown_evidence_temporal_current_cause",d.cooldownEvidenceTemporalCurrentCause)
                .putLong("cooldown_evidence_temporal_last_eligible_at",d.cooldownEvidenceTemporalLastEligibleAt)
                .putLong("cooldown_evidence_temporal_separation_ms",d.cooldownEvidenceTemporalSeparationMs)
                .putString("cooldown_evidence_temporal_reason",d.cooldownEvidenceTemporalReason)
                .putString("cooldown_evidence_temporal_summary",d.cooldownEvidenceTemporalSummary)
                .putBoolean("cooldown_evidence_temporal_diversity_evaluated",d.cooldownEvidenceTemporalDiversityEvaluated)
                .putBoolean("cooldown_evidence_temporal_diversity_threshold_met",d.cooldownEvidenceTemporalDiversityThresholdMet)
                .putInt("cooldown_evidence_temporal_diversity_clean_evidence_count",d.cooldownEvidenceTemporalDiversityCleanEvidenceCount)
                .putInt("cooldown_evidence_temporal_diversity_distinct_days",d.cooldownEvidenceTemporalDiversityDistinctDays)
                .putString("cooldown_evidence_temporal_diversity_state",d.cooldownEvidenceTemporalDiversityState)
                .putString("cooldown_evidence_temporal_diversity_transition_key",d.cooldownEvidenceTemporalDiversityTransitionKey)
                .putString("cooldown_evidence_temporal_diversity_cause",d.cooldownEvidenceTemporalDiversityCause)
                .putString("cooldown_evidence_temporal_diversity_reason",d.cooldownEvidenceTemporalDiversityReason)
                .putString("cooldown_evidence_temporal_diversity_summary",d.cooldownEvidenceTemporalDiversitySummary)
                .putBoolean("transition_correction_lifecycle_ordering_integrity_evaluated",d.transitionCorrectionLifecycleOrderingIntegrityEvaluated)
                .putBoolean("transition_correction_lifecycle_retired",d.transitionCorrectionLifecycleRetired)
                .putString("transition_correction_lifecycle_ordering_integrity_state",d.transitionCorrectionLifecycleOrderingIntegrityState)
                .putString("transition_correction_lifecycle_ordering_integrity_reason",d.transitionCorrectionLifecycleOrderingIntegrityReason)
                .putString("transition_correction_lifecycle_ordering_integrity_summary",d.transitionCorrectionLifecycleOrderingIntegritySummary).putString("unit",d.unitId)
            .putBoolean("safety",d.safetyOverride).putBoolean("rupture",d.allianceRupture)
            .putString("known",d.known.toString()).putString("signals",d.signals.toString())
            .putString("missing",d.missing.toString()).putString("confidence",d.confidence).apply();
    }

    public static String report(Context c){
        ClinicalSessionMemoryRC7.State s=ClinicalSessionMemoryRC7.load(c);
        SharedPreferences p=c.getSharedPreferences(PREF,Context.MODE_PRIVATE);
        int units=ClinicalKnowledgeRC7.all(c).size();
        String loader=ClinicalKnowledgeRC7.fallbackUsed()
                ? "FALLBACK ⚠  "+ClinicalKnowledgeRC7.loadError()
                : "NORMAL ✓";
        ClinicalMemoryConsolidatorRC7.Snapshot mem=ClinicalMemoryConsolidatorRC7.load(c);
        return "RC7 Brain v1.0 / App v6.0.8\n\n"
            + "QA mode: "+(ClinicalQaRC7.enabled(c)?"ON ✓":"OFF")+"\n"
            + "knowledge loader: "+loader+"\n"
            + "loaded units: "+units+"\n"
            + "stable memory: "+mem.stableProfile.length()+"\n"
            + "session memory: "+mem.sessionSummary.length()+"\n"
            + "central profile: "+CentralTherapyProfile.compactSummary(c)+"\n"
            + "formulation hypotheses: "+CentralTherapyProfile.formulationSummary(c)+"\n"
            + "last answer evidence: "+CentralTherapyProfile.loadFormulation(c).optString("last_answer_evidence","")+"\n"
            + "central runtime: ALL 9 SURFACES CONNECTED\n"
            + "last memory revision: "+ClinicalQaRC7.lastMemoryRevision(c)+"\n"
            + "session turns: "+s.turns+"\n"
            + "assessment questions: "+s.askedIds.size()+" / 3\n"
            + "answered targets: "+s.answeredTargets.size()+"\n"
            + "session rupture: "+s.allianceRupture+"\n\n"
            + "last move: "+p.getString("move",s.lastMove)+"\n"
            + "last target: "+p.getString("target",s.lastTarget)+"\n"
            + "information gain: "+p.getString("info_gain","0")+"\n"
            + "question rationale: "+p.getString("question_rationale","")+"\n"
            + "question stop: "+p.getBoolean("question_stop",false)+"\n"
            + "question stop reason: "+p.getString("question_stop_reason","")+"\n"
            + "intervention id: "+p.getString("intervention_id","")+"\n"
            + "intervention target: "+p.getString("intervention_target","")+"\n"
            + "intervention score: "+p.getString("intervention_score","0")+"\n"
            + "intervention rationale: "+p.getString("intervention_rationale","")+"\n"
            + "review outcome: "+p.getString("review_outcome","")+"\n"
            + "review next move: "+p.getString("review_next_move","")+"\n"
            + "adaptive plan: "+p.getString("adaptive_plan","")+"\n"
            + "adaptive rationale: "+p.getString("adaptive_plan_rationale","")+"\n"
            + "therapy goal: "+p.getString("therapy_goal","")+"\n"
            + "progress signal: "+p.getString("progress_signal","")+"\n"
            + "goal progress: "+TherapeuticGoalProgressRC8.progressSummary(c)+"\n"
            + "goal transition: "+p.getString("goal_transition","")+"\n"
            + "goal transition reason: "+p.getString("goal_transition_reason","")+"\n"
            + "session phase: "+p.getString("session_phase","")+"\n"
            + "therapeutic pacing: "+p.getString("therapeutic_pacing","")+"\n"
            + "phase question budget: "+p.getInt("phase_question_budget",0)+"\n"
            + "phase rationale: "+p.getString("phase_rationale","")+"\n"
            + "formulation reopened: "+p.getBoolean("formulation_reopened",false)+"\n"
            + "formulation reopen reason: "+p.getString("formulation_reopen_reason","")+"\n"
            + "reopen recovery target: "+p.getString("reopen_recovery_target","")+"\n"
            + "reopen recovery move: "+p.getString("reopen_recovery_move","")+"\n"
            + "reopen recovery ask budget: "+p.getInt("reopen_recovery_ask_budget",0)+"\n"
            + "retired hypotheses: "+p.getInt("retired_hypothesis_count",0)+"\n"
            + "evidence calibration: "+p.getString("evidence_calibration_band","")+"\n"
            + "evidence calibration rationale: "+p.getString("evidence_calibration_rationale","")+"\n"
            + "evidence conflicts: "+p.getInt("evidence_conflict_count",0)+"\n"
            + "unresolved evidence conflicts: "+p.getInt("unresolved_evidence_conflict_count",0)+"\n"
            + "evidence conflict summary: "+p.getString("evidence_conflict_summary","")+"\n"
            + "evidence provenance: "+p.getString("evidence_provenance_summary","")+"\n"
            + "unknown evidence: "+p.getInt("unknown_evidence_count",0)+"\n"
            + "stale evidence: "+p.getInt("stale_evidence_count",0)+"\n"
            + "evidence gate: "+p.getString("evidence_gate_summary","")+"\n"
            + "promoted evidence: "+p.getInt("promoted_evidence_count",0)+"\n"
            + "stable memory sync: "+p.getString("stable_memory_sync_summary","")+"\n"
            + "stable memory promoted: "+p.getInt("stable_memory_promoted",0)+"\n"
            + "stable memory demoted: "+p.getInt("stable_memory_demoted",0)+"\n"
            + "current context: "+p.getString("current_context_scope","")+"\n"
            + "context generalization: "+p.getString("context_generalization_summary","")+"\n"
            + "blocked stable memories: "+p.getInt("context_blocked_memory_count",0)+"\n"
            + "central insight: "+p.getString("central_insight","")+"\n"
            + "central mechanism: "+p.getString("central_mechanism","")+"\n"
            + "central insight usable: "+p.getBoolean("central_insight_usable",false)+"\n"
            + "central bridge ready: "+p.getBoolean("central_bridge_ready",false)+"\n"
            + "central bridge intervention: "+p.getString("central_bridge_intervention","")+"\n"
            + "central bridge target: "+p.getString("central_bridge_target","")+"\n"
            + "central bridge blocked: "+p.getString("central_bridge_blocked_reason","")+"\n"
            + "release integrity: "+p.getString("release_integrity_summary","")+"\n"
            + "release integrity pass: "+p.getBoolean("release_integrity_pass",true)+"\n"
            + "release integrity blocked: "+p.getBoolean("release_integrity_blocked",false)+"\n"
            + "response fact guard: "+p.getString("response_fact_guard_summary","")+"\n"
            + "response rewrite required: "+p.getBoolean("response_rewrite_required",false)+"\n"
            + "response overreach guard: "+p.getString("response_overreach_guard_summary","")+"\n"
            + "overreach rewrite required: "+p.getBoolean("response_overreach_rewrite_required",false)+"\n"
            + "response relevance guard: "+p.getString("response_relevance_guard_summary","")+"\n"
            + "relevance rewrite required: "+p.getBoolean("response_relevance_rewrite_required",false)+"\n"
            + "response attunement guard: "+p.getString("response_attunement_guard_summary","")+"\n"
            + "attunement rewrite required: "+p.getBoolean("response_attunement_rewrite_required",false)+"\n"
            + "response precision guard: "+p.getString("response_precision_guard_summary","")+"\n"
            + "precision rewrite required: "+p.getBoolean("response_precision_rewrite_required",false)+"\n"
            + "response specificity guard: "+p.getString("response_specificity_guard_summary","")+"\n"
            + "specificity rewrite required: "+p.getBoolean("response_specificity_rewrite_required",false)+"\n"
            + "response evidence anchor: "+p.getString("response_evidence_anchor_used","")+"\n"
            + "response continuity guard: "+p.getString("response_continuity_guard_summary","")+"\n"
            + "continuity rewrite required: "+p.getBoolean("response_continuity_rewrite_required",false)+"\n"
            + "response timing guard: "+p.getString("response_timing_guard_summary","")+"\n"
            + "timing rewrite required: "+p.getBoolean("response_timing_rewrite_required",false)+"\n"
            + "final acceptance: "+p.getString("final_acceptance_summary","")+"\n"
            + "final response accepted: "+p.getBoolean("final_response_accepted",true)+"\n"
            + "final fallback used: "+p.getBoolean("final_fallback_used",false)+"\n"
            + "intervention dose: "+p.getString("intervention_dose","NONE")+"\n"
            + "intervention max steps: "+p.getInt("intervention_max_steps",0)+"\n"
            + "intervention homework: "+p.getBoolean("intervention_homework_allowed",false)+"\n"
            + "intervention minutes: "+p.getInt("intervention_exercise_minutes",0)+"\n"
            + "intervention dose rationale: "+p.getString("intervention_dose_rationale","")+"\n"
            + "intervention dose blocked: "+p.getString("intervention_dose_blocked_reason","")+"\n"
            + "intervention fidelity: "+p.getString("intervention_fidelity_summary","")+"\n"
            + "intervention fidelity rewrite: "+p.getBoolean("intervention_fidelity_rewrite_required",false)+"\n"
            + "minimal action plan: "+p.getString("minimal_action_plan","")+"\n"
            + "intervention outcome: "+p.getString("intervention_outcome","UNKNOWN")+"\n"
            + "outcome review required: "+p.getBoolean("intervention_outcome_review_required",false)+"\n"
            + "outcome reopen suggested: "+p.getBoolean("intervention_outcome_reopen_suggested",false)+"\n"
            + "outcome learning: "+p.getString("intervention_outcome_learning","")+"\n"
            + "outcome next move: "+p.getString("intervention_outcome_next_move_hint","")+"\n"
            + "adaptation action: "+p.getString("intervention_adaptation_action","NONE")+"\n"
            + "switch allowed: "+p.getBoolean("intervention_switch_allowed",false)+"\n"
            + "switch required: "+p.getBoolean("intervention_switch_required",false)+"\n"
            + "review before switch: "+p.getBoolean("intervention_review_before_switch",false)+"\n"
            + "switch candidate: "+p.getString("intervention_switch_candidate_id","")+"\n"
            + "adaptation rationale: "+p.getString("intervention_adaptation_rationale","")+"\n"
            + "intervention barrier: "+p.getString("intervention_barrier","NONE")+"\n"
            + "barrier adjustment: "+p.getString("intervention_barrier_adjustment","")+"\n"
            + "barrier summary: "+p.getString("intervention_barrier_summary","")+"\n"
            + "intervention preference mode: "+p.getString("intervention_preference_mode","DEFAULT")+"\n"
            + "preference source: "+p.getString("intervention_preference_source","")+"\n"
            + "preference mechanism preserved: "+p.getBoolean("intervention_preference_mechanism_preserved",true)+"\n"
            + "preference summary: "+p.getString("intervention_preference_summary","")+"\n"
            + "micro experiment ready: "+p.getBoolean("micro_experiment_ready",false)+"\n"
            + "micro experiment id: "+p.getString("micro_experiment_id","")+"\n"
            + "micro experiment action: "+p.getString("micro_experiment_action","")+"\n"
            + "micro experiment review: "+p.getString("micro_experiment_review_criterion","")+"\n"
            + "micro experiment stop: "+p.getString("micro_experiment_stop_condition","")+"\n"
            + "micro experiment attribution: "+p.getString("micro_experiment_attribution","NONE")+"\n"
            + "micro experiment outcome eligible: "+p.getBoolean("micro_experiment_outcome_eligible",false)+"\n"
            + "micro experiment mapped outcome: "+p.getString("micro_experiment_mapped_outcome","UNKNOWN")+"\n"
            + "micro experiment review mapping: "+p.getString("micro_experiment_review_mapping_summary","")+"\n"
            + "review attribution clarification: "+p.getBoolean("review_attribution_clarification_needed",false)+"\n"
            + "review attribution question: "+p.getString("review_attribution_question","")+"\n"
            + "review attribution target: "+p.getString("review_attribution_target","")+"\n"
            + "review attribution summary: "+p.getString("review_attribution_summary","")+"\n"
            + "outcome commit state: "+p.getString("outcome_commit_state","NONE")+"\n"
            + "outcome learning allowed: "+p.getBoolean("outcome_commit_learning_allowed",false)+"\n"
            + "outcome commit value: "+p.getString("outcome_commit_value","UNKNOWN")+"\n"
            + "outcome commit resolution: "+p.getString("outcome_commit_resolution","")+"\n"
            + "intervention policy updated: "+p.getBoolean("intervention_policy_memory_updated",false)+"\n"
            + "intervention policy confidence: "+p.getString("intervention_policy_confidence","NONE")+"\n"
            + "intervention policy recommendation: "+p.getString("intervention_policy_recommendation","")+"\n"
            + "intervention policy summary: "+p.getString("intervention_policy_summary","")+"\n"
            + "policy retrieval found: "+p.getBoolean("policy_retrieval_found",false)+"\n"
            + "policy retrieval applicable: "+p.getBoolean("policy_retrieval_applicable",false)+"\n"
            + "policy retrieval confidence: "+p.getString("policy_retrieval_confidence","NONE")+"\n"
            + "policy retrieval reason: "+p.getString("policy_retrieval_reason","")+"\n"
            + "policy retrieval summary: "+p.getString("policy_retrieval_summary","")+"\n"
            + "policy conflict detected: "+p.getBoolean("policy_conflict_detected",false)+"\n"
            + "policy conflict resolution: "+p.getString("policy_conflict_resolution","NONE")+"\n"
            + "policy conflict reason: "+p.getString("policy_conflict_reason","")+"\n"
            + "policy conflict summary: "+p.getString("policy_conflict_summary","")+"\n"
            + "policy decay evaluated: "+p.getBoolean("policy_decay_evaluated",false)+"\n"
            + "policy decay status: "+p.getString("policy_decay_status","ACTIVE")+"\n"
            + "policy decay confidence: "+p.getString("policy_decay_old_confidence","NONE")+" -> "+p.getString("policy_decay_new_confidence","NONE")+"\n"
            + "policy decay reason: "+p.getString("policy_decay_reason","")+"\n"
            + "policy decay summary: "+p.getString("policy_decay_summary","")+"\n"
            + "policy revalidation evaluated: "+p.getBoolean("policy_revalidation_evaluated",false)+"\n"
            + "policy revalidation state: "+p.getString("policy_revalidation_state","NONE")+"\n"
            + "policy revalidation confidence: "+p.getString("policy_revalidation_old_confidence","")+" -> "+p.getString("policy_revalidation_new_confidence","")+"\n"
            + "policy revalidation reason: "+p.getString("policy_revalidation_reason","")+"\n"
            + "policy revalidation summary: "+p.getString("policy_revalidation_summary","")+"\n"
            + "policy transfer evaluated: "+p.getBoolean("policy_transfer_evaluated",false)+"\n"
            + "policy transfer state: "+p.getString("policy_transfer_state","BLOCK")+"\n"
            + "policy transfer contexts: "+p.getString("policy_transfer_source_context","")+" -> "+p.getString("policy_transfer_target_context","")+"\n"
            + "policy transfer reason: "+p.getString("policy_transfer_reason","")+"\n"
            + "policy transfer summary: "+p.getString("policy_transfer_summary","")+"\n"
            + "general policy evaluated: "+p.getBoolean("general_policy_promotion_evaluated",false)+"\n"
            + "general policy state: "+p.getString("general_policy_promotion_state","NONE")+"\n"
            + "general policy contexts: "+p.getInt("general_policy_distinct_contexts",0)+"\n"
            + "general policy evidence: +"+p.getInt("general_policy_positive_commits",0)+" / -"+p.getInt("general_policy_negative_commits",0)+"\n"
            + "general policy reason: "+p.getString("general_policy_promotion_reason","")+"\n"
            + "general boundary state: "+p.getString("general_policy_boundary_state","NONE")+"\n"
            + "general boundary context: "+p.getString("general_policy_boundary_context","")+"\n"
            + "general boundary excluded: "+p.getBoolean("general_policy_boundary_excluded",false)+"\n"
            + "general boundary reason: "+p.getString("general_policy_boundary_reason","")+"\n"
            + "policy hierarchy winner: "+p.getString("policy_hierarchy_winner","NONE")+"\n"
            + "policy hierarchy context found: "+p.getBoolean("policy_hierarchy_context_found",false)+"\n"
            + "policy hierarchy general found: "+p.getBoolean("policy_hierarchy_general_found",false)+"\n"
            + "policy hierarchy selected: "+p.getString("policy_hierarchy_selected_key","")+"\n"
            + "policy hierarchy reason: "+p.getString("policy_hierarchy_reason","")+"\n"
            + "policy selection state: "+p.getString("policy_selection_enforcement_state","NONE")+"\n"
            + "policy selection mismatch: "+p.getBoolean("policy_selection_mismatch_detected",false)+"\n"
            + "policy selection rebound: "+p.getBoolean("policy_selection_rebound_applied",false)+"\n"
            + "policy selection effective: "+p.getString("policy_selection_effective_key","")+"\n"
            + "policy selection reason: "+p.getString("policy_selection_reason","")+"\n"
            + "adaptive policy release passed: "+p.getBoolean("adaptive_policy_release_gate_passed",false)+"\n"
            + "adaptive policy release repaired: "+p.getBoolean("adaptive_policy_release_gate_repaired",false)+"\n"
            + "adaptive policy violations: "+p.getString("adaptive_policy_release_violations","")+"\n"
            + "adaptive policy release summary: "+p.getString("adaptive_policy_release_summary","")+"\n"
            + "outcome idempotency state: "+p.getString("outcome_commit_idempotency_state","NOT_APPLICABLE")+"\n"
            + "outcome learning allowed: "+p.getBoolean("outcome_commit_learning_allowed",true)+"\n"
            + "outcome duplicate: "+p.getBoolean("outcome_commit_duplicate",false)+"\n"
            + "outcome conflicting duplicate: "+p.getBoolean("outcome_commit_conflicting_duplicate",false)+"\n"
            + "outcome idempotency reason: "+p.getString("outcome_commit_idempotency_reason","")+"\n"
            + "outcome revision state: "+p.getString("outcome_revision_state","NONE")+"\n"
            + "outcome revision review required: "+p.getBoolean("outcome_revision_review_required",false)+"\n"
            + "outcome revision prior/final: "+p.getString("outcome_revision_prior","")+" -> "+p.getString("outcome_revision_final","")+"\n"
            + "outcome revision reason: "+p.getString("outcome_revision_reason","")+"\n"
            + "revision propagation state: "+p.getString("outcome_revision_propagation_state","NONE")+"\n"
            + "revision propagation commits: "+p.getInt("outcome_revision_propagation_commit_rows",0)+"\n"
            + "revision propagation policies: "+p.getInt("outcome_revision_propagation_policies",0)+"\n"
            + "revision propagation reason: "+p.getString("outcome_revision_propagation_reason","")+"\n"
            + "structured provenance enriched: "+p.getBoolean("structured_provenance_enriched",false)+"\n"
            + "structured provenance migrated: "+p.getBoolean("structured_provenance_legacy_migrated",false)+"\n"
            + "structured provenance key: "+p.getString("structured_provenance_canonical_key","")+"\n"
            + "structured provenance reason: "+p.getString("structured_provenance_reason","")+"\n"
            + "provenance integrity repaired: "+p.getBoolean("provenance_integrity_repaired",false)+"\n"
            + "provenance integrity quarantined: "+p.getBoolean("provenance_integrity_quarantined",false)+"\n"
            + "provenance integrity rows: "+p.getInt("provenance_integrity_rows_checked",0)+"\n"
            + "provenance integrity reason: "+p.getString("provenance_integrity_reason","")+"\n"
            + "provenance lineage updated: "+p.getBoolean("provenance_lineage_updated",false)+"\n"
            + "provenance lineage nodes: "+p.getInt("provenance_lineage_nodes_added",0)+"\n"
            + "provenance lineage edges: "+p.getInt("provenance_lineage_edges_added",0)+"\n"
            + "provenance lineage root: "+p.getString("provenance_lineage_root_key","")+"\n"
            + "provenance lineage reason: "+p.getString("provenance_lineage_reason","")+"\n"
            + "decision rationale usable: "+p.getBoolean("decision_rationale_usable",false)+"\n"
            + "decision rationale tier: "+p.getString("decision_rationale_source_tier","")+"\n"
            + "decision rationale compact: "+p.getString("decision_rationale_compact","")+"\n"
            + "decision rationale reason: "+p.getString("decision_rationale_reason","")+"\n"
            + "rationale fidelity state: "+p.getString("decision_rationale_fidelity_state","PASS")+"\n"
            + "rationale fidelity repaired: "+p.getBoolean("decision_rationale_fidelity_repaired",false)+"\n"
            + "rationale policy overclaim: "+p.getBoolean("decision_rationale_policy_overclaim",false)+"\n"
            + "rationale evidence mismatch: "+p.getBoolean("decision_rationale_evidence_mismatch",false)+"\n"
            + "rationale fidelity reason: "+p.getString("decision_rationale_fidelity_reason","")+"\n"
            + "explainability delivery mode: "+p.getString("explainability_delivery_mode","SILENT_INTERNAL")+"\n"
            + "explainability should surface: "+p.getBoolean("explainability_should_surface",false)+"\n"
            + "explainability placement: "+p.getString("explainability_placement","")+"\n"
            + "explainability max sentences: "+p.getInt("explainability_max_sentences",0)+"\n"
            + "explainability reason: "+p.getString("explainability_delivery_reason","")+"\n"
            + "decision snapshot loaded: "+p.getBoolean("decision_transition_snapshot_loaded",false)+"\n"
            + "decision move changed: "+p.getBoolean("decision_transition_move_changed",false)+"\n"
            + "decision intervention changed: "+p.getBoolean("decision_transition_intervention_changed",false)+"\n"
            + "decision target changed: "+p.getBoolean("decision_transition_target_changed",false)+"\n"
            + "decision transition: "+p.getString("decision_transition_summary","")+"\n"
            + "decision transition cause: "+p.getString("decision_transition_primary_cause","NONE")+"\n"
            + "decision transition human reason: "+p.getString("decision_transition_human_reason","")+"\n"
            + "decision transition cause reason: "+p.getString("decision_transition_cause_reason","")+"\n"
            + "transition cause fidelity state: "+p.getString("decision_transition_cause_fidelity_state","PASS")+"\n"
            + "transition cause confidence: "+p.getString("decision_transition_cause_confidence","NONE")+"\n"
            + "transition multi cause: "+p.getBoolean("decision_transition_multi_cause",false)+"\n"
            + "transition fidelity primary: "+p.getString("decision_transition_fidelity_primary_cause","NONE")+"\n"
            + "transition fidelity secondary: "+p.getString("decision_transition_fidelity_secondary_cause","")+"\n"
            + "transition fidelity reason: "+p.getString("decision_transition_cause_fidelity_reason","")+"\n"
            + "transition correction state: "+p.getString("transition_explanation_correction_state","NONE")+"\n"
            + "transition correction applied: "+p.getBoolean("transition_explanation_correction_applied",false)+"\n"
            + "transition correction prior/corrected: "+p.getString("transition_explanation_prior_cause","")+" -> "+p.getString("transition_explanation_corrected_cause","")+"\n"
            + "transition correction reason: "+p.getString("transition_explanation_correction_reason","")+"\n"
            + "transition correction memory match: "+p.getString("transition_correction_memory_match","NONE")+"\n"
            + "transition correction memory reusable: "+p.getBoolean("transition_correction_memory_reusable",false)+"\n"
            + "transition correction memory context: "+p.getString("transition_correction_memory_source_context","")+" -> "+p.getString("transition_correction_memory_current_context","")+"\n"
            + "transition correction memory reason: "+p.getString("transition_correction_memory_reason","")+"\n"
            + "transition correction revalidation state: "+p.getString("transition_correction_revalidation_state","NONE")+"\n"
            + "transition correction confirmations: "+p.getInt("transition_correction_revalidation_confirmations",0)+"\n"
            + "transition correction contradictions: "+p.getInt("transition_correction_revalidation_contradictions",0)+"\n"
            + "transition correction revalidation reason: "+p.getString("transition_correction_revalidation_reason","")+"\n"
            + "transition correction conflict state: "+p.getString("transition_correction_conflict_state","NONE")+"\n"
            + "transition correction incumbent/challenger: "+p.getString("transition_correction_conflict_incumbent","")+" / "+p.getString("transition_correction_conflict_challenger","")+"\n"
            + "transition correction conflict counts: "+p.getInt("transition_correction_conflict_incumbent_count",0)+" / "+p.getInt("transition_correction_conflict_challenger_count",0)+"\n"
            + "transition correction conflict reason: "+p.getString("transition_correction_conflict_reason","")+"\n"
            + "correction fresh evidence state: "+p.getString("transition_correction_fresh_evidence_state","NONE")+"\n"
            + "correction current turn override: "+p.getBoolean("transition_correction_current_turn_override",false)+"\n"
            + "correction memory allowed: "+p.getBoolean("transition_correction_memory_allowed",false)+"\n"
            + "correction effective cause: "+p.getString("transition_correction_fresh_evidence_effective_cause","")+"\n"
            + "correction fresh evidence reason: "+p.getString("transition_correction_fresh_evidence_reason","")+"\n"
            + "correction override isolation state: "+p.getString("transition_correction_override_isolation_state","NONE")+"\n"
            + "correction override ephemeral: "+p.getBoolean("transition_correction_override_ephemeral",false)+"\n"
            + "correction commit allowed: "+p.getBoolean("transition_correction_commit_allowed",false)+"\n"
            + "correction duplicate suppressed: "+p.getBoolean("transition_correction_duplicate_commit_suppressed",false)+"\n"
            + "correction override isolation reason: "+p.getString("transition_correction_override_isolation_reason","")+"\n"
            + "correction commit provenance state: "+p.getString("transition_correction_commit_provenance_state","NONE")+"\n"
            + "correction commit provenance committed: "+p.getBoolean("transition_correction_commit_provenance_committed",false)+"\n"
            + "correction commit evidence id: "+p.getString("transition_correction_commit_evidence_id","")+"\n"
            + "correction canonical commit key: "+p.getString("transition_correction_canonical_commit_key","")+"\n"
            + "correction provenance reason: "+p.getString("transition_correction_commit_provenance_reason","")+"\n"
            + "correction provenance integrity repaired: "+p.getBoolean("correction_provenance_integrity_repaired",false)+"\n"
            + "correction provenance integrity quarantined: "+p.getBoolean("correction_provenance_integrity_quarantined",false)+"\n"
            + "correction provenance rows checked: "+p.getInt("correction_provenance_integrity_rows_checked",0)+"\n"
            + "correction provenance rows quarantined: "+p.getInt("correction_provenance_integrity_rows_quarantined",0)+"\n"
            + "correction provenance integrity reason: "+p.getString("correction_provenance_integrity_reason","")+"\n"
            + "correction provenance reinstatement state: "+p.getString("correction_provenance_reinstatement_state","NONE")+"\n"
            + "correction provenance matching rows: "+p.getInt("correction_provenance_reinstatement_matching_rows",0)+"\n"
            + "correction provenance reinstated rows: "+p.getInt("correction_provenance_reinstated_rows",0)+"\n"
            + "correction provenance reinstatement reason: "+p.getString("correction_provenance_reinstatement_reason","")+"\n"
            + "correction reinstatement idempotency state: "+p.getString("correction_provenance_reinstatement_idempotency_state","NONE")+"\n"
            + "correction reinstatement duplicate suppressed: "+p.getBoolean("correction_provenance_reinstatement_duplicate_suppressed",false)+"\n"
            + "correction reinstatement already active: "+p.getBoolean("correction_provenance_reinstatement_already_active",false)+"\n"
            + "correction reinstatement identity: "+p.getString("correction_provenance_reinstatement_identity","")+"\n"
            + "correction reinstatement idempotency reason: "+p.getString("correction_provenance_reinstatement_idempotency_reason","")+"\n"
            + "post reinstatement verification state: "+p.getString("post_reinstatement_verification_state","NONE")+"\n"
            + "post reinstatement verified keep: "+p.getBoolean("post_reinstatement_verified_keep",false)+"\n"
            + "post reinstatement requarantined: "+p.getBoolean("post_reinstatement_requarantined",false)+"\n"
            + "post reinstatement verification reason: "+p.getString("post_reinstatement_verification_reason","")+"\n"
            + "requarantine cooldown state: "+p.getString("requarantine_cooldown_state","NONE")+"\n"
            + "requarantine cooldown active: "+p.getBoolean("requarantine_cooldown_active",false)+"\n"
            + "requarantine cooldown released: "+p.getBoolean("requarantine_cooldown_released",false)+"\n"
            + "requarantine loop blocked: "+p.getBoolean("requarantine_loop_blocked",false)+"\n"
            + "requarantine clean confirmations: "+p.getInt("requarantine_cooldown_clean_confirmations",0)+"\n"
            + "requarantine contradictions: "+p.getInt("requarantine_cooldown_contradictions",0)+"\n"
            + "requarantine cooldown reason: "+p.getString("requarantine_cooldown_reason","")+"\n"
            + "cooldown evidence ledger state: "+p.getString("cooldown_evidence_ledger_state","NONE")+"\n"
            + "cooldown evidence committed: "+p.getBoolean("cooldown_evidence_ledger_committed",false)+"\n"
            + "cooldown evidence duplicate: "+p.getBoolean("cooldown_evidence_ledger_duplicate",false)+"\n"
            + "cooldown evidence contradiction: "+p.getBoolean("cooldown_evidence_ledger_contradiction",false)+"\n"
            + "cooldown evidence ledger reason: "+p.getString("cooldown_evidence_ledger_reason","")+"\n"
            + "cooldown evidence integrity repaired: "+p.getBoolean("cooldown_evidence_integrity_repaired",false)+"\n"
            + "cooldown evidence integrity quarantined: "+p.getBoolean("cooldown_evidence_integrity_quarantined",false)+"\n"
            + "cooldown evidence synthetic blocked: "+p.getBoolean("cooldown_evidence_synthetic_blocked",false)+"\n"
            + "cooldown evidence integrity reason: "+p.getString("cooldown_evidence_integrity_reason","")+"\n"
            + "cooldown evidence independence state: "+p.getString("cooldown_evidence_independence_state","NONE")+"\n"
            + "cooldown evidence independent: "+p.getBoolean("cooldown_evidence_independent",false)+"\n"
            + "cooldown evidence near duplicate: "+p.getBoolean("cooldown_evidence_near_duplicate",false)+"\n"
            + "cooldown evidence similarity: "+p.getString("cooldown_evidence_similarity","")+"\n"
            + "cooldown evidence independence reason: "+p.getString("cooldown_evidence_independence_reason","")+"\n"
            + "cooldown temporal independence state: "+p.getString("cooldown_evidence_temporal_independence_state","NONE")+"\n"
            + "cooldown temporally independent: "+p.getBoolean("cooldown_evidence_temporally_independent",false)+"\n"
            + "cooldown burst blocked: "+p.getBoolean("cooldown_evidence_burst_blocked",false)+"\n"
            + "cooldown temporal separation ms: "+p.getLong("cooldown_evidence_temporal_separation_ms",0L)+"\n"
            + "cooldown temporal reason: "+p.getString("cooldown_evidence_temporal_reason","")+"\n"
            + "cooldown temporal diversity state: "+p.getString("cooldown_evidence_temporal_diversity_state","NONE")+"\n"
            + "cooldown temporal diversity threshold: "+p.getBoolean("cooldown_evidence_temporal_diversity_threshold_met",false)+"\n"
            + "cooldown distinct evidence days: "+p.getInt("cooldown_evidence_temporal_diversity_distinct_days",0)+"\n"
            + "cooldown temporal diversity reason: "+p.getString("cooldown_evidence_temporal_diversity_reason","")+"\n"
            + "correction lifecycle integrity state: "+p.getString("transition_correction_lifecycle_ordering_integrity_state","UNKNOWN")+"\n"
            + "correction lifecycle retired: "+p.getBoolean("transition_correction_lifecycle_retired",false)+"\n"
            + "correction lifecycle integrity reason: "+p.getString("transition_correction_lifecycle_ordering_integrity_reason","")+"\n"
            + "last unit: "+p.getString("unit","")+"\n"
            + "safety override: "+p.getBoolean("safety",false)+"\n"
            + "alliance repair: "+p.getBoolean("rupture",false)+"\n"
            + "confidence: "+p.getString("confidence","")+"\n\n"
            + "signals: "+p.getString("signals","[]")+"\n"
            + "known: "+p.getString("known","[]")+"\n"
            + "missing: "+p.getString("missing","[]");
    }

    public static String selfCheck(Context c){
        if(c==null)return "FAIL: Context null";
        ClinicalSessionMemoryRC7.State old=ClinicalSessionMemoryRC7.load(c);
        Map<String,?> oldDiag=new HashMap<>(c.getSharedPreferences(PREF,Context.MODE_PRIVATE).getAll());
        StringBuilder r=new StringBuilder("RC7 SELF-CHECK v6.0.8\n\n");
        int pass=0,total=0;
        try{
            ClinicalKnowledgeRC7.clearCache();
            int n=ClinicalKnowledgeRC7.all(c).size();
            total++; if(n>=500&&!ClinicalKnowledgeRC7.fallbackUsed()){pass++;r.append("✓ knowledge >=500: ").append(n).append("\n");}
            else r.append("✗ knowledge load: ").append(n).append(" / ").append(ClinicalKnowledgeRC7.loadError()).append("\n");

            String[] targets={"goal_agreement","task_agreement","rupture_point","recent_conflict"};
            for(String target:targets){
                total++; boolean ok=ClinicalKnowledgeRC7.hasUsableTarget(c,target);
                if(ok)pass++;
                r.append(ok?"✓ ":"✗ ").append("usable QDU ").append(target).append(ClinicalKnowledgeRC7.hasTarget(c,target)?" [asset]":" [built-in fallback]").append("\n");
            }

            ClinicalSessionMemoryRC7.reset(c);
            total++; ClinicalDecisionRC7 a=ClinicalBrainRC7.decide(c,"질문만 계속 받아서 답답해","");
            if(a.isAllianceRepair()&&"task_agreement".equals(a.target)){pass++;r.append("✓ alliance/task route\n");}
            else r.append("✗ alliance/task: ").append(a.move).append(" / ").append(a.target).append("\n");

            ClinicalSessionMemoryRC7.reset(c);
            total++; ClinicalDecisionRC7 b=ClinicalBrainRC7.decide(c,"내가 원하는 건 이해받는 건데 자꾸 해결책만 줘","");
            if(b.isAllianceRepair()&&"goal_agreement".equals(b.target)){pass++;r.append("✓ alliance/goal route\n");}
            else r.append("✗ alliance/goal: ").append(b.move).append(" / ").append(b.target).append("\n");

            ClinicalSessionMemoryRC7.reset(c);
            total++; ClinicalDecisionRC7 s=ClinicalBrainRC7.decide(c,"죽고 싶은 생각이 들어","");
            if(s.isStabilize()&&s.safetyOverride){pass++;r.append("✓ safety override\n");}
            else r.append("✗ safety: ").append(s.move).append("\n");

            ClinicalSessionMemoryRC7.reset(c);
            total++; ClinicalDecisionRC7 neg=ClinicalBrainRC7.decide(c,"죽고 싶은 건 아니고 그냥 너무 불안해","");
            if(!neg.isStabilize()){pass++;r.append("✓ suicide-negation no overtrigger\n");}
            else r.append("✗ suicide-negation overtrigger\n");
        }catch(Exception e){
            r.append("\nEXCEPTION: ").append(e.getClass().getSimpleName()).append(": ").append(String.valueOf(e.getMessage())).append("\n");
        }finally{
            ClinicalSessionMemoryRC7.save(c,old);
            restorePrefs(c.getSharedPreferences(PREF,Context.MODE_PRIVATE),oldDiag);
        }
        r.append("\nRESULT: ").append(pass).append(" / ").append(total).append(pass==total?" PASS ✓":" CHECK NEEDED ⚠");
        return r.toString();
    }

    private static void restorePrefs(SharedPreferences p,Map<String,?> values){
        SharedPreferences.Editor e=p.edit().clear();
        for(Map.Entry<String,?> x:values.entrySet()){
            Object v=x.getValue(); String k=x.getKey();
            if(v instanceof String)e.putString(k,(String)v);
            else if(v instanceof Boolean)e.putBoolean(k,(Boolean)v);
            else if(v instanceof Integer)e.putInt(k,(Integer)v);
            else if(v instanceof Long)e.putLong(k,(Long)v);
            else if(v instanceof Float)e.putFloat(k,(Float)v);
            else if(v instanceof Set)e.putStringSet(k,(Set<String>)v);
        }
        e.apply();
    }

    public static void reset(Context c){
        ClinicalSessionMemoryRC7.reset(c);
        ClinicalMemoryConsolidatorRC7.clearSession(c);
        if(c!=null)c.getSharedPreferences(PREF,Context.MODE_PRIVATE).edit().clear().apply();
    }

    public static void show(Activity a){
        if(a==null)return;
        new AlertDialog.Builder(a)
            .setTitle("🧠 RC7 진단")
            .setMessage(report(a))
            .setPositiveButton("닫기",null)
            .setNegativeButton("자체검사",(d,w)->showSelfCheck(a))
            .setNeutralButton("QA 모드",(d,w)->showQaMenu(a)).show();
    }

    private static void showQaMenu(Activity a){
        boolean on=ClinicalQaRC7.enabled(a);
        String[] items={
            on?"QA 기록 끄기":"QA 기록 켜기",
            "최근 QA 로그 보기",
            "상담 품질 요약 보기",
            "QA 로그 지우기",
            "RC7 세션만 초기화"
        };
        new AlertDialog.Builder(a).setTitle("🧪 RC7 상담 QA")
            .setMessage("QA 기록은 앱 내부 저장소에만 저장돼. 사용자 입력 + RC7 판단 + 최종 답변을 같은 턴으로 묶어서 비교할 수 있어.")
            .setItems(items,(d,which)->{
                if(which==0){ClinicalQaRC7.setEnabled(a,!on); showQaMenu(a);}
                else if(which==1){new AlertDialog.Builder(a).setTitle("최근 RC7 QA 로그").setMessage(ClinicalQaRC7.latest(a,12)).setPositiveButton("확인",null).show();}
                else if(which==2){new AlertDialog.Builder(a).setTitle("📊 RC7 상담 품질 요약").setMessage(ClinicalQaRC7.qualitySummary(a,50)).setPositiveButton("확인",null).show();}
                else if(which==3){ClinicalQaRC7.clear(a);new AlertDialog.Builder(a).setTitle("QA 로그 삭제 완료").setMessage("RC7 QA 로그만 삭제했어. 상담기록과 일기 데이터는 그대로야.").setPositiveButton("확인",null).show();}
                else {reset(a);new AlertDialog.Builder(a).setTitle("RC7 초기화 완료").setMessage("상담 기록/일기/앱 데이터는 건드리지 않고 RC7의 질문·라우팅 세션만 초기화했어.").setPositiveButton("확인",null).show();}
            }).setNegativeButton("닫기",null).show();
    }

    private static void showSelfCheck(Activity a){
        new AlertDialog.Builder(a).setTitle("🧪 RC7 자체검사")
            .setMessage(selfCheck(a)).setPositiveButton("확인",null).show();
    }
}
