package com.maeummon.app.clinical;

import android.content.Context;
import java.util.*;

public final class RepairVerificationFinalAcceptanceGateRC9 {
    private RepairVerificationFinalAcceptanceGateRC9(){}

    public static final class Result {
        public boolean accepted=true;
        public boolean fallbackRequired=false;
        public String finalText="";
        public String summary="PASS";
        public final List<String> remainingFailures=new ArrayList<>();
    }

    public static Result verify(
            Context c,String userText,String repairedText,ClinicalDecisionRC7 d){

        Result out=new Result();
        String text=repairedText==null?"":repairedText.trim();
        out.finalText=text;

        ResponseContradictionHallucinationGuardRC9.Check fact =
                ResponseContradictionHallucinationGuardRC9.inspect(c,userText,text);
        ResponseSafetyOverreachGuardRC9.Check overreach =
                ResponseSafetyOverreachGuardRC9.inspect(c,userText,text,d);
        ResponseRelevanceGenericnessGuardRC9.Check relevance =
                ResponseRelevanceGenericnessGuardRC9.inspect(c,userText,text,d);
        ResponseAttunementValidationCalibrationGuardRC9.Check attunement =
                ResponseAttunementValidationCalibrationGuardRC9.inspect(c,userText,text,d);
        ResponsePrecisionDirectnessGuardRC9.Check precision =
                ResponsePrecisionDirectnessGuardRC9.inspect(c,userText,text,d);
        ResponseSpecificityEvidenceAnchoringGuardRC9.Check specificity =
                ResponseSpecificityEvidenceAnchoringGuardRC9.inspect(c,userText,text,d);
        ResponseContinuityTurnCoherenceGuardRC9.Check continuity =
                ResponseContinuityTurnCoherenceGuardRC9.inspect(c,userText,text,d);
        ResponseTimingStopRuleGuardRC9.Check timing =
                ResponseTimingStopRuleGuardRC9.inspect(c,userText,text,d);

        collect(out,"FACT",fact.pass,fact.failures);
        collect(out,"OVERREACH",overreach.pass,overreach.failures);
        collect(out,"RELEVANCE",relevance.pass,relevance.failures);
        collect(out,"ATTUNEMENT",attunement.pass,attunement.failures);
        collect(out,"PRECISION",precision.pass,precision.failures);
        collect(out,"SPECIFICITY",specificity.pass,specificity.failures);
        collect(out,"CONTINUITY",continuity.pass,continuity.failures);
        collect(out,"TIMING",timing.pass,timing.failures);

        if(out.remainingFailures.isEmpty()){
            out.accepted=true;
            out.fallbackRequired=false;
            out.summary="PASS";
            return out;
        }

        out.accepted=false;
        out.fallbackRequired=true;
        out.finalText=buildSafeFallback(c,userText,d);
        out.summary="FAIL -> SAFE_FALLBACK "+out.remainingFailures;
        return out;
    }

    private static void collect(
            Result out,String layer,boolean pass,List<String> failures){
        if(pass)return;
        if(failures==null||failures.isEmpty()){
            out.remainingFailures.add(layer+":UNKNOWN");
            return;
        }
        for(String f:failures)out.remainingFailures.add(layer+":"+f);
    }

    public static String buildSafeFallback(
            Context c,String userText,ClinicalDecisionRC7 d){

        String move=d==null?"":safe(d.move);
        String target=d==null?"":safe(d.target);

        if(d!=null&&d.safetyOverride){
            return "지금은 해석을 더 밀어붙이기보다 안전과 안정부터 확인하는 게 우선이야. "
                    +"현재 위험이 커지거나 스스로를 해칠 생각이 있다면 혼자 버티지 말고 바로 주변 사람이나 전문 도움과 연결해야 해.";
        }

        if(d!=null&&d.allianceRupture){
            return "내가 방금 네가 원한 방향보다 너무 앞서갔거나 다르게 이해한 것 같아. "
                    +"지금은 해결책을 더 얹기보다 네가 실제로 말한 내용 기준으로 다시 맞춰서 볼게.";
        }

        if("ASK".equals(move)){
            if(target.contains("baseline"))
                return "이걸 가르려면 한 가지만 확인하면 돼. 그 반응은 원래부터 그랬어, 아니면 최근에 달라진 거야?";
            if(target.contains("conflict"))
                return "한 가지만 확인할게. 최근에 실제로 싸우거나 갈등이 있었어?";
            if(target.contains("evaluation"))
                return "한 가지만 확인할게. 실제로 평가받거나 실수했다고 볼 만한 일이 있었어?";
            return "지금 방향을 가르기 위해 한 가지만 확인할게. 가장 최근의 구체적인 상황은 뭐였어?";
        }

        if("FORMULATE".equals(move)){
            return "지금 정보만으로는 한 가지 결론을 세게 밀기보다, 네가 직접 말한 사실과 그 사실에 붙은 해석을 나눠보는 게 맞아. "
                    +"확실한 부분부터 기준을 잡아서 이어가자.";
        }

        if("INTERVENE".equals(move)){
            return "지금은 여러 방법을 한꺼번에 쓰기보다 한 가지 작은 행동만 고르는 게 좋아. "
                    +"네가 말한 실제 상황에 맞는 한 단계부터 해보자.";
        }

        if("REVIEW".equals(move)){
            return "새로운 방법을 더 얹기 전에, 방금까지 해본 게 실제로 도움이 됐는지부터 확인하는 게 맞아.";
        }

        return "지금은 말을 더 복잡하게 만들기보다, 네가 직접 말한 사실부터 기준을 잡고 차근차근 이어갈게.";
    }

    public static String instruction(Result r){
        if(r==null||r.accepted)return "";
        return "FINAL_ACCEPTANCE_FAIL=true. one-shot repair 후에도 guard 위반이 남았다. "
                +"추가 무한 재생성은 하지 않고 deterministic safe fallback을 사용한다. remaining="
                +r.remainingFailures;
    }

    private static String safe(String s){return s==null?"":s;}
}
