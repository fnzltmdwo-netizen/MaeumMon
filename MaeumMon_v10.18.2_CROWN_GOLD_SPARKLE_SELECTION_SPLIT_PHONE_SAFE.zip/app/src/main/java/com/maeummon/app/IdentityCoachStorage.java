package com.maeummon.app;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public final class IdentityCoachStorage {
    private IdentityCoachStorage() {}

    private static SharedPreferences p(Context c) {
        return c.getSharedPreferences(AppPrefs.PREFS, Context.MODE_PRIVATE);
    }

    public static String getDesiredSelf(Context c) {
        return p(c).getString(AppPrefs.KEY_DESIRED_SELF, "").trim();
    }

    public static void saveDesiredSelf(Context c, String text) {
        p(c).edit().putString(AppPrefs.KEY_DESIRED_SELF, clean(text)).apply();
    }

    public static String getLastCoaching(Context c) {
        return p(c).getString(AppPrefs.KEY_LAST_IDENTITY_COACHING, "").trim();
    }

    public static String getLastSituation(Context c) {
        return p(c).getString(AppPrefs.KEY_LAST_IDENTITY_SITUATION, "").trim();
    }

    public static void saveCoaching(Context c, String situation, String coaching) {
        try {
            JSONArray history = history(c);
            JSONObject item = new JSONObject();
            item.put("time", new SimpleDateFormat("yyyy.MM.dd HH:mm", Locale.KOREA).format(new Date()));
            item.put("situation", clean(situation));
            item.put("coaching", clean(coaching));
            history.put(item);

            JSONArray trimmed = new JSONArray();
            int start = Math.max(0, history.length() - 8);
            for (int i = start; i < history.length(); i++) {
                JSONObject itemToKeep = history.optJSONObject(i);
                if (itemToKeep != null) trimmed.put(itemToKeep);
            }

            p(c).edit()
                    .putString(AppPrefs.KEY_IDENTITY_COACH_HISTORY, trimmed.toString())
                    .putString(AppPrefs.KEY_LAST_IDENTITY_COACHING, clean(coaching))
                    .putString(AppPrefs.KEY_LAST_IDENTITY_SITUATION, clean(situation))
                    .apply();
        } catch (Exception ignored) {}
    }

    public static String compactHistory(Context c) {
        JSONArray arr = history(c);
        if (arr.length() == 0) return "아직 집중 코칭 기록 없음";

        StringBuilder sb = new StringBuilder();
        int start = Math.max(0, arr.length() - 5);
        for (int i = start; i < arr.length(); i++) {
            JSONObject obj = arr.optJSONObject(i);
            if (obj == null) continue;

            sb.append("[")
                    .append(obj.optString("time", ""))
                    .append("]\n");

            String situation = obj.optString("situation", "").trim();
            if (!situation.isEmpty()) {
                sb.append("상황: ")
                        .append(shorten(situation, 300))
                        .append("\n");
            }

            String coaching = obj.optString("coaching", "").trim();
            if (!coaching.isEmpty()) {
                sb.append("코칭: ")
                        .append(shorten(coaching, 700))
                        .append("\n\n");
            }
        }
        return sb.toString().trim();
    }

    private static JSONArray history(Context c) {
        try {
            return new JSONArray(p(c).getString(AppPrefs.KEY_IDENTITY_COACH_HISTORY, "[]"));
        } catch (Exception e) {
            return new JSONArray();
        }
    }

    private static String clean(String s) {
        return s == null ? "" : s.trim();
    }

    private static String shorten(String s, int n) {
        if (s == null) return "";
        return s.length() <= n ? s : s.substring(0, n) + "…";
    }
}
