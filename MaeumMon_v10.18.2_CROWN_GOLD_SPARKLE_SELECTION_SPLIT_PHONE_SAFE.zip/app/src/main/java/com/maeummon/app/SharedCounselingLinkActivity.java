package com.maeummon.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.CookieManager;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.HashSet;
import java.util.LinkedHashSet;

/** Imports a ChatGPT shared conversation snapshot and converts it into Mind PT programs. */
public class SharedCounselingLinkActivity extends Activity {
    private static final String COLLECTOR_VERSION = "v3";
    private static final int CROWN_POLICY_VERSION = 9;
    private static final String CROWN_POLICY_PREF_PREFIX = "crown_policy_version_counseling_";
    private EditText linkInput;
    private TextView statusText, verificationText, previewText, programsText, importButton;
    private WebView webView;
    private MindTrainingStore store;
    private final Handler main = new Handler(Looper.getMainLooper());
    private boolean extracting = false;
    private int extractionAttempt = 0;
    private static final int MAX_EXTRACTION_ATTEMPTS = 14;

    // Full-conversation collection state. Do not analyze the first hydrated chunk immediately:
    // ChatGPT shared pages can initially expose only a partial DOM (~1-2K chars).
    private final LinkedHashSet<String> collectedMessageBlocks = new LinkedHashSet<>();
    private String bestBodySnapshot = "";
    private int lastCollectedLength = 0;
    private int stableCollectionPasses = 0;
    private long collectionStartedAt = 0L;
    private boolean collectionStarted = false;
    private static final long COLLECTION_HARD_TIMEOUT_MS = 300000L; // 최초 전체수집은 오래 걸려도 끝까지 시도
    private static final int COLLECTION_STABLE_PASSES_AT_BOTTOM = 4;
    private double lastScrollTop = -1d;
    private double lastScrollMax = -1d;
    private int noScrollableRootPasses = 0;
    // v10.14: initial full import is verified with a 3-leg sweep.
    // 0 = top→bottom discovery, 1 = bottom→top verification, 2 = top→bottom final verification.
    // We only mark COMPLETE after the final bottom is stable and no new turns appeared during the verification sweep.
    private int initialSweepPhase = 0;
    private int sweepNewTurnBaseline = 0;
    private double lastObservedScrollHeight = -1d;
    private int stableScrollHeightPasses = 0;
    private long phaseStartedAt = 0L;
    private static final int COLLECTION_FINAL_STABLE_PASSES = 6;
    private static final long COLLECTION_MIN_PHASE_MS = 1800L;
    // v10.10: one shared-link thread grows over time. First sync scans top→bottom; later sync starts at bottom and stops at the known boundary.
    private String currentShareUrl = "";
    private boolean incrementalSyncMode = false;
    private final Set<String> knownTurnHashes = new HashSet<>();
    private boolean incrementalNewSeen = false;
    private int incrementalKnownBoundaryPasses = 0;

    // v10.14.1: DOM diagnostics. If ChatGPT changes its shared-page markup,
    // show whether the WebView itself only received a short page or our selector missed turns.
    private int diagBodyChars = 0;
    private int diagRoleNodes = 0;
    private int diagTurnNodes = 0;
    private int diagArticleNodes = 0;
    private int diagUserNodes = 0;
    private int diagAssistantNodes = 0;
    private int diagStructuredBlocks = 0;
    private String diagFirstVisible = "";
    private String diagLastVisible = "";
    // v10.14.2: inspect data that React/Next.js keeps outside the visible DOM.
    private int diagScriptCount = 0;
    private int diagScriptChars = 0;
    private int diagJsonScriptCount = 0;
    private int diagRscChunkCount = 0;
    private int diagHiddenCandidateTurns = 0;
    private String diagHiddenFirst = "";
    private String diagHiddenLast = "";

    // Keep the last successfully collected shared transcript locally so a temporary
    // API/DNS failure does not force the user to scrape the whole ChatGPT page again.
    private static final String CACHE_PREFS = "maeummon_shared_counseling_cache";
    private static final String CACHE_URL = "last_share_url";
    private static final String CACHE_TEXT = "last_share_transcript";
    private static final String CACHE_TS = "last_share_saved_at";

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shared_counseling_link);
        UiInsets.apply(this, findViewById(R.id.sharedCounselingLinkRoot));
        store = new MindTrainingStore(this);
        linkInput = findViewById(R.id.sharedCounselingLinkInput);
        statusText = findViewById(R.id.sharedCounselingStatus);
        verificationText = findViewById(R.id.sharedCounselingVerification);
        previewText = findViewById(R.id.sharedCounselingPreview);
        programsText = findViewById(R.id.sharedCounselingPrograms);
        importButton = findViewById(R.id.sharedCounselingImportButton);
        webView = findViewById(R.id.sharedCounselingWebView);
        configureWebView();
        statusText.setText("🔬 수집 엔진 " + COLLECTOR_VERSION + " · DOM + 숨은 원본 진단 준비됨");

        String incoming = getIntent().getStringExtra(Intent.EXTRA_TEXT);
        if (incoming != null) {
            String url = extractShareUrl(incoming);
            if (!url.isEmpty()) linkInput.setText(url);
        }
        importButton.setOnClickListener(v -> startImport());
        findViewById(R.id.sharedCounselingManualFallback).setOnClickListener(v -> {
            Intent i = new Intent(this, CounselingImportActivity.class);
            startActivity(i);
        });
        findViewById(R.id.sharedCounselingClose).setOnClickListener(v -> finish());
    }

    private void configureWebView() {
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        // Keep the stock Android WebView user-agent. ChatGPT can serve a reduced shell
        // to unusual/custom user agents, which makes us read only login/cookie text.
        CookieManager cm = CookieManager.getInstance();
        cm.setAcceptCookie(true);
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.LOLLIPOP) {
            cm.setAcceptThirdPartyCookies(webView, true);
        }
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new Bridge(), "MaeumMonBridge");
        webView.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                if (!extracting) return;
                statusText.setText("대화 화면을 연 뒤 전체 상담을 모을 준비 중이야…");
                main.postDelayed(() -> beginFullCollection(), 1400);
            }
        });
    }

    private void startImport() {
        if (extracting) return;
        String url = extractShareUrl(linkInput.getText().toString());
        if (url.isEmpty()) {
            Toast.makeText(this, "https://chatgpt.com/share/ 로 시작하는 공유 링크를 넣어줘.", Toast.LENGTH_LONG).show();
            return;
        }
        MindTrainingStore.SharedThreadState thread = store.sharedThreadByUrl(url);
        showSyncVerification(thread, false);
        if (thread != null && thread.complete) {
            boolean needsAnalysis = !"COMPLETE".equals(thread.analysisState) || thread.analyzedTurnCount < thread.turnCount;
            if (needsAnalysis) {
                statusText.setText("기존 상담 " + thread.turnCount + "턴 · " + thread.charCount + "자가 저장돼 있어. 미완료 분석도 이어서 복구하고 새 대화도 확인할게…");
            } else {
                statusText.setText("기존 상담 " + thread.turnCount + "턴 · " + thread.charCount + "자가 저장돼 있어. 새로 생긴 대화만 찾을게…");
            }
            beginImportFromUrl(url, true);
        } else {
            if (thread != null && !thread.complete) {
                statusText.setText("최초 전체수집이 아직 끝나지 않았어. 저장된 중간 지점과 중복은 제외하고 끝까지 다시 이어서 모을게…");
            }
            beginImportFromUrl(url, false);
        }
    }

    private void beginImportFromUrl(String url) { beginImportFromUrl(url, false); }

    private void beginImportFromUrl(String url, boolean incremental) {
        currentShareUrl = url;
        incrementalSyncMode = incremental;
        knownTurnHashes.clear();
        if (incremental) knownTurnHashes.addAll(store.sharedTurnHashes(url));
        incrementalNewSeen = false;
        incrementalKnownBoundaryPasses = 0;
        extracting = true;
        extractionAttempt = 0;
        resetCollectionState();
        importButton.setEnabled(false);
        programsText.setVisibility(View.GONE);
        previewText.setVisibility(View.GONE);
        statusText.setText("상담 완전판 공유 링크를 여는 중이야…");
        webView.loadUrl(url);
    }

    private final class Bridge {
        @JavascriptInterface public void receive(String text) {
            // Backward-compatible entry point for older WebView callbacks.
            main.post(() -> handleCollectionFrame(text, 0d, 0d, 0d, 0d, false, "bridge"));
        }

        @JavascriptInterface public void receiveFrame(String text, double top, double max, boolean messageMode) {
            main.post(() -> handleCollectionFrame(text, top, max, 0d, 0d, messageMode, "legacy"));
        }

        @JavascriptInterface public void receiveFrameV2(String text, double top, double max, double client, double scroll, boolean messageMode, String rootName) {
            main.post(() -> handleCollectionFrame(text, top, max, client, scroll, messageMode, rootName));
        }

        @JavascriptInterface public void receiveDiagV1(int bodyChars, int roleNodes, int turnNodes, int articleNodes,
                                                       int userNodes, int assistantNodes, int structuredBlocks,
                                                       String firstVisible, String lastVisible) {
            main.post(() -> {
                diagBodyChars = Math.max(diagBodyChars, bodyChars);
                diagRoleNodes = Math.max(diagRoleNodes, roleNodes);
                diagTurnNodes = Math.max(diagTurnNodes, turnNodes);
                diagArticleNodes = Math.max(diagArticleNodes, articleNodes);
                diagUserNodes = Math.max(diagUserNodes, userNodes);
                diagAssistantNodes = Math.max(diagAssistantNodes, assistantNodes);
                diagStructuredBlocks = Math.max(diagStructuredBlocks, structuredBlocks);
                if (firstVisible != null && !firstVisible.trim().isEmpty()) diagFirstVisible = firstVisible.trim();
                if (lastVisible != null && !lastVisible.trim().isEmpty()) diagLastVisible = lastVisible.trim();
            });
        }

        @JavascriptInterface public void receiveHiddenDiagV1(int scriptCount, int scriptChars, int jsonScriptCount,
                                                              int rscChunkCount, int hiddenCandidateTurns,
                                                              String firstHidden, String lastHidden) {
            main.post(() -> {
                diagScriptCount = Math.max(diagScriptCount, scriptCount);
                diagScriptChars = Math.max(diagScriptChars, scriptChars);
                diagJsonScriptCount = Math.max(diagJsonScriptCount, jsonScriptCount);
                diagRscChunkCount = Math.max(diagRscChunkCount, rscChunkCount);
                diagHiddenCandidateTurns = Math.max(diagHiddenCandidateTurns, hiddenCandidateTurns);
                if (firstHidden != null && !firstHidden.trim().isEmpty()) diagHiddenFirst = firstHidden.trim();
                if (lastHidden != null && !lastHidden.trim().isEmpty()) diagHiddenLast = lastHidden.trim();
            });
        }
    }

    private void resetCollectionState() {
        collectedMessageBlocks.clear();
        bestBodySnapshot = "";
        lastCollectedLength = 0;
        stableCollectionPasses = 0;
        collectionStartedAt = 0L;
        collectionStarted = false;
        lastScrollTop = -1d;
        lastScrollMax = -1d;
        noScrollableRootPasses = 0;
        initialSweepPhase = 0;
        sweepNewTurnBaseline = 0;
        lastObservedScrollHeight = -1d;
        stableScrollHeightPasses = 0;
        phaseStartedAt = 0L;
        incrementalNewSeen = false;
        incrementalKnownBoundaryPasses = 0;
        diagBodyChars = 0;
        diagRoleNodes = 0;
        diagTurnNodes = 0;
        diagArticleNodes = 0;
        diagUserNodes = 0;
        diagAssistantNodes = 0;
        diagStructuredBlocks = 0;
        diagFirstVisible = "";
        diagLastVisible = "";
        diagScriptCount = 0;
        diagScriptChars = 0;
        diagJsonScriptCount = 0;
        diagRscChunkCount = 0;
        diagHiddenCandidateTurns = 0;
        diagHiddenFirst = "";
        diagHiddenLast = "";
    }

    private void beginFullCollection() {
        if (!extracting || collectionStarted) return;
        collectionStarted = true;
        collectionStartedAt = System.currentTimeMillis();
        phaseStartedAt = collectionStartedAt;
        initialSweepPhase = 0;
        sweepNewTurnBaseline = collectedMessageBlocks.size();
        stableCollectionPasses = 0;
        lastCollectedLength = 0;
        statusText.setText("상담 원문 전체를 모으는 중이야…");
        // ChatGPT share pages may scroll inside a nested container rather than window.
        // Find the real scroll root once, move it to the beginning, then collect message blocks while advancing it.
        String initJs = "(function(){try{"
                + "function pick(){var c=[];try{if(document.scrollingElement)c.push(document.scrollingElement);}catch(e){}"
                + "try{var a=document.querySelectorAll('main,section,div');for(var i=0;i<a.length;i++)c.push(a[i]);}catch(e){}"
                + "var best=null,score=-1;for(var j=0;j<c.length;j++){var e=c[j];if(!e)continue;"
                + "var ch=e.clientHeight||0,sh=e.scrollHeight||0,cw=e.clientWidth||0;if(ch<220||cw<240||sh-ch<180)continue;"
                + "var st='';try{st=getComputedStyle(e).overflowY||'';}catch(x){}"
                + "var bonus=/(auto|scroll|overlay)/i.test(st)?1000000:0;var sc=bonus+(sh-ch)*10+sh;"
                + "if(sc>score){score=sc;best=e;}}return best||document.scrollingElement||document.documentElement||document.body;}"
                + "window.__maeummonScrollRoot=pick();var r=window.__maeummonScrollRoot;if(r){r.scrollTop=" + (incrementalSyncMode ? "Math.max(0,(r.scrollHeight||0)-(r.clientHeight||0))" : "0") + ";}try{window.scrollTo(0," + (incrementalSyncMode ? "document.body.scrollHeight" : "0") + ");}catch(e){}return !!r;"
                + "}catch(e){return false;}})()";
        webView.evaluateJavascript(initJs, null);
        scheduleCollectionFrame(700);
    }

    private void scheduleExtraction(long delayMs) {
        // Kept for compatibility with older call sites; use the full collector now.
        if (!collectionStarted) main.postDelayed(this::beginFullCollection, delayMs);
        else scheduleCollectionFrame(delayMs);
    }

    private void scheduleCollectionFrame(long delayMs) {
        if (!extracting) return;
        main.postDelayed(() -> {
            if (!extracting) return;
            extractionAttempt++;
            final boolean walkUp = incrementalSyncMode || (!incrementalSyncMode && initialSweepPhase == 1);
            final String nextTopExpr = walkUp ? "Math.max(0,top-step)" : "Math.min(max,top+step)";
            final String fallbackTopExpr = walkUp ? "Math.max(0,before-step)" : "Math.min(zs-zh,before+step)";
            final String windowStepExpr = walkUp ? "-step" : "step";
            String js = "(function(){"
                    + "function pickRoot(){var r=window.__maeummonScrollRoot;try{if(r&&r.isConnected&&r.scrollHeight-r.clientHeight>120)return r;}catch(e){}"
                    + "var c=[];try{if(document.scrollingElement)c.push(document.scrollingElement);}catch(e){}"
                    + "try{var a=document.querySelectorAll('main,section,div');for(var i=0;i<a.length;i++)c.push(a[i]);}catch(e){}"
                    + "var best=null,score=-1;for(var j=0;j<c.length;j++){var e=c[j];if(!e)continue;var ch=e.clientHeight||0,sh=e.scrollHeight||0,cw=e.clientWidth||0;"
                    + "if(ch<220||cw<240||sh-ch<180)continue;var ov='';try{ov=getComputedStyle(e).overflowY||'';}catch(x){}"
                    + "var bonus=/(auto|scroll|overlay)/i.test(ov)?1000000:0;var sc=bonus+(sh-ch)*10+sh;if(sc>score){score=sc;best=e;}}"
                    + "window.__maeummonScrollRoot=best||document.scrollingElement||document.documentElement||document.body;return window.__maeummonScrollRoot;}"
                    + "try{var els=[].slice.call(document.querySelectorAll('button,[role=button]'));for(var i=0;i<els.length;i++){var x=((els[i].innerText||els[i].textContent||'')+'').trim();"
                    + "if(/^(모두 허용|모두 동의|전체 허용|Accept all|Allow all|Accept cookies)$/i.test(x)){try{els[i].click();}catch(e){}}"
                    + "if(/^(더 보기|더보기|계속 보기|계속 읽기|Show more|Continue reading)$/i.test(x)){try{els[i].click();}catch(e){}}}}catch(e){}"
                    + "var bodyText=((document.body&&document.body.innerText)||'');var blocks=[];var seen={};function add(role,tx){tx=((tx||'')+'').trim();if(tx.length<2)return;var k=role+'|'+tx;if(seen[k])return;seen[k]=1;blocks.push(role+'\\n'+tx);}"
                    + "var n=[],turns=[],articles=[];try{n=document.querySelectorAll('[data-message-author-role]');for(var j=0;j<n.length;j++)add(n[j].getAttribute('data-message-author-role')||'message',n[j].innerText||n[j].textContent||'');}catch(e){}"
                    + "try{turns=document.querySelectorAll('[data-testid^=conversation-turn],[data-testid*=conversation-turn]');for(var k=0;k<turns.length;k++){var el=turns[k];if(el.querySelector&&el.querySelector('[data-message-author-role]'))continue;var tx=((el.innerText||el.textContent||'')+'').trim();if(tx.length>8)add('turn',tx);}}catch(e){}"
                    + "try{articles=document.querySelectorAll('main article,article');for(var aidx=0;aidx<articles.length;aidx++){var ae=articles[aidx];if(ae.querySelector&&ae.querySelector('[data-message-author-role],[data-testid^=conversation-turn],[data-testid*=conversation-turn]'))continue;var at=((ae.innerText||ae.textContent||'')+'').trim();if(at.length>8)add('article',at);}}catch(e){}"
                    + "var users=0,assist=0;try{users=document.querySelectorAll('[data-message-author-role=user]').length;assist=document.querySelectorAll('[data-message-author-role=assistant]').length;}catch(e){}"
                    + "var firstV='',lastV='';try{var vis=n.length?n:(turns.length?turns:articles);if(vis.length){firstV=((vis[0].innerText||vis[0].textContent||'')+'').trim().slice(0,140);lastV=((vis[vis.length-1].innerText||vis[vis.length-1].textContent||'')+'').trim().slice(0,140);}}catch(e){}"
                    + "try{MaeumMonBridge.receiveDiagV1(bodyText.length,n.length,turns.length,articles.length,users,assist,blocks.length,firstV,lastV);}catch(e){}"
                    + "try{var ss=[].slice.call(document.scripts||[]),sc=0,jc=0,rc=0;for(var si=0;si<ss.length;si++){var stx=((ss[si].textContent||ss[si].innerText||'')+'');sc+=stx.length;if(((ss[si].type||'')+'').toLowerCase().indexOf('json')>=0)jc++;if(stx.indexOf('__next_f.push')>=0||stx.indexOf('self.__next_f')>=0)rc++;}"
                    + "var hb=[],hs={};function hadd(role,tx){tx=((tx||'')+'').trim();if(tx.length<2||tx.length>120000)return;var kk=role+'|'+tx;if(hs[kk])return;hs[kk]=1;hb.push(role+'\\n'+tx);}"
                    + "try{var jsn=document.querySelectorAll('script[type*=json]');for(var ji=0;ji<jsn.length;ji++){try{var obj=JSON.parse(jsn[ji].textContent||'{}');(function walk(o,d){if(!o||d>18)return;if(Array.isArray(o)){for(var ai=0;ai<o.length;ai++)walk(o[ai],d+1);return;}if(typeof o!=='object')return;var role='';try{role=(o.author&&o.author.role)||o.role||'';}catch(e){}var txt='';try{if(o.content&&Array.isArray(o.content.parts))txt=o.content.parts.filter(function(v){return typeof v==='string';}).join('\\n');else if(typeof o.content==='string')txt=o.content;else if(typeof o.text==='string')txt=o.text;}catch(e){}if((role==='user'||role==='assistant')&&txt)hadd(role,txt);for(var k in o){if(Object.prototype.hasOwnProperty.call(o,k))walk(o[k],d+1);}})(obj,0);}catch(e){}}}catch(e){}"
                    + "var hf=hb.length?hb[0].slice(0,160):'',hl=hb.length?hb[hb.length-1].slice(0,160):'';try{MaeumMonBridge.receiveHiddenDiagV1(ss.length,sc,jc,rc,hb.length,hf,hl);}catch(e){}"
                    + "if(hb.length>blocks.length){for(var hi=0;hi<hb.length;hi++){var sep=hb[hi].indexOf('\\n'),hr=sep>=0?hb[hi].slice(0,sep):'hidden',ht=sep>=0?hb[hi].slice(sep+1):hb[hi];add(hr,ht);}}}catch(e){}"
                    + "var mode=blocks.length>0;var structuredText=blocks.join('\\n␞\\n');var suspicious=(bodyText.length>Math.max(3500,structuredText.length*2.2)&&blocks.length<10);var t=mode?structuredText:bodyText;"
                    + "var root=pickRoot();var top=0,max=0,client=0,scroll=0,rootName='none';if(root){top=root.scrollTop||0;client=root.clientHeight||0;scroll=root.scrollHeight||0;max=Math.max(0,scroll-client);rootName=((root.tagName||'node')+'#'+(root.id||'')+'.'+((root.className||'')+'').split(' ').slice(0,2).join('.'));}"
                    + "try{MaeumMonBridge.receiveFrameV2(t,top,max,client,scroll,mode,rootName);}catch(e){try{MaeumMonBridge.receiveFrame(t,top,max,mode);}catch(ee){try{MaeumMonBridge.receive(t);}catch(eee){}}}"
                    + "var step=Math.max(420,Math.floor(((root&&root.clientHeight)||window.innerHeight||800)*0.70));"
                    + "if(root&&max>120){try{root.scrollTop=" + nextTopExpr + ";root.dispatchEvent(new Event('scroll',{bubbles:true}));}catch(e){}}else{try{var all=document.querySelectorAll('html,body,main,section,div');for(var q=0;q<all.length;q++){var z=all[q],zh=z.clientHeight||0,zs=z.scrollHeight||0;if(zh>120&&zs-zh>120){var before=z.scrollTop||0;z.scrollTop=" + fallbackTopExpr + ";if((z.scrollTop||0)!==before)z.dispatchEvent(new Event('scroll',{bubbles:true}));}}}catch(e){}}"
                    + "try{window.scrollBy(0," + windowStepExpr + ");}catch(e){}"
                    + "return JSON.stringify({len:t.length,top:top,max:max,client:client,scroll:scroll,blocks:blocks.length,root:rootName});})()";
            webView.evaluateJavascript(js, null);
        }, delayMs);
    }

    private void handleCollectionFrame(String raw, double top, double max, double client, double scroll, boolean messageMode, String rootName) {
        if (!extracting) return;
        String clean = cleanupRenderedText(raw);

        int frameNew = 0;
        int frameKnown = 0;
        if (messageMode && clean.contains("␞")) {
            String[] blocks = clean.split("␞");
            for (String block : blocks) {
                String b = block == null ? "" : block.trim();
                if (b.length() >= 8 && !looksLikeChatGptShell(b)) {
                    String h = MindTrainingStore.sharedTurnHashForBlock(b);
                    if (knownTurnHashes.contains(h)) frameKnown++; else frameNew++;
                    collectedMessageBlocks.add(b);
                }
            }
        } else if (messageMode && clean.length() >= 8 && !looksLikeChatGptShell(clean)) {
            String h = MindTrainingStore.sharedTurnHashForBlock(clean);
            if (knownTurnHashes.contains(h)) frameKnown++; else frameNew++;
            collectedMessageBlocks.add(clean);
        } else if (!looksLikeChatGptShell(clean) && clean.length() > bestBodySnapshot.length()) {
            bestBodySnapshot = clean;
        }
        if (incrementalSyncMode) {
            if (frameNew > 0) { incrementalNewSeen = true; incrementalKnownBoundaryPasses = 0; }
            else if (frameKnown > 0) incrementalKnownBoundaryPasses++;
        }

        String collected = buildCollectedTranscript();
        int len = collected.length();
        if (len > lastCollectedLength + 24) stableCollectionPasses = 0;
        else stableCollectionPasses++;
        lastCollectedLength = Math.max(lastCollectedLength, len);

        long elapsed = collectionStartedAt <= 0 ? 0 : System.currentTimeMillis() - collectionStartedAt;
        int messageCount = collectedMessageBlocks.size();
        boolean hasScrollableRoot = max > 120d && scroll > client + 120d;
        if (!hasScrollableRoot) noScrollableRootPasses++; else noScrollableRootPasses = 0;
        if (lastObservedScrollHeight >= 0d && Math.abs(scroll - lastObservedScrollHeight) < 2d) stableScrollHeightPasses++;
        else stableScrollHeightPasses = 0;
        lastObservedScrollHeight = scroll;
        int percent = hasScrollableRoot ? (int) Math.max(0, Math.min(100, Math.round((top / max) * 100d))) : 0;
        boolean moved = lastScrollTop >= 0d && Math.abs(top - lastScrollTop) > 2d;
        lastScrollTop = top;
        lastScrollMax = max;
        String rootDiag = rootName == null ? "" : rootName;
        if (rootDiag.length() > 28) rootDiag = rootDiag.substring(0, 28) + "…";
        statusText.setText("상담 원문 수집 중… 누적 " + len + "자 · 메시지 " + messageCount
                + "개 · 스크롤 " + (hasScrollableRoot ? percent + "%" : "탐색중")
                + " · top " + (int) top + "/" + (int) max
                + (moved ? " ↕" : "") + " · " + Math.max(1, elapsed / 1000) + "초"
                + (!incrementalSyncMode ? " · 전체검증 " + (initialSweepPhase + 1) + "/3" : "")
                + (rootDiag.isEmpty() ? "" : "\n스크롤영역: " + rootDiag)
                + "\nDOM진단: body " + diagBodyChars + "자 · role " + diagRoleNodes
                + " · turn " + diagTurnNodes + " · article " + diagArticleNodes
                + " · user " + diagUserNodes + " / assistant " + diagAssistantNodes);

        // max==0 is NOT completion. Initial sync must verify the real bottom. Incremental sync starts at the bottom and walks upward until it meets stored turns.
        boolean nearBottom = hasScrollableRoot && top >= Math.max(0d, max - 80d);
        boolean nearTop = hasScrollableRoot && top <= 80d;
        long phaseElapsed = phaseStartedAt <= 0 ? elapsed : System.currentTimeMillis() - phaseStartedAt;
        boolean stableEdge = stableCollectionPasses >= COLLECTION_STABLE_PASSES_AT_BOTTOM
                && stableScrollHeightPasses >= 3 && phaseElapsed >= COLLECTION_MIN_PHASE_MS;
        boolean initialComplete = false;
        if (!incrementalSyncMode && len >= 180 && hasScrollableRoot) {
            if (initialSweepPhase == 0 && nearBottom && stableEdge) {
                initialSweepPhase = 1;
                sweepNewTurnBaseline = collectedMessageBlocks.size();
                stableCollectionPasses = 0; stableScrollHeightPasses = 0; phaseStartedAt = System.currentTimeMillis();
                statusText.setText("1차 바닥까지 읽었어. 놓친 대화가 없는지 다시 위로 훑는 중이야…");
                scheduleCollectionFrame(500);
                return;
            }
            if (initialSweepPhase == 1 && nearTop && stableEdge) {
                initialSweepPhase = 2;
                stableCollectionPasses = 0; stableScrollHeightPasses = 0; phaseStartedAt = System.currentTimeMillis();
                statusText.setText("맨 위까지 재검증했어. 마지막으로 아래까지 한 번 더 확인할게…");
                scheduleCollectionFrame(500);
                return;
            }
            if (initialSweepPhase == 2 && nearBottom
                    && stableCollectionPasses >= COLLECTION_FINAL_STABLE_PASSES
                    && stableScrollHeightPasses >= 4 && phaseElapsed >= COLLECTION_MIN_PHASE_MS) {
                initialComplete = true;
            }
        }
        boolean incrementalBoundaryReached = incrementalSyncMode && (
                (incrementalNewSeen && incrementalKnownBoundaryPasses >= 2) ||
                (!incrementalNewSeen && incrementalKnownBoundaryPasses >= 3) || nearTop);
        long hardLimit = incrementalSyncMode ? 70000L : COLLECTION_HARD_TIMEOUT_MS;
        boolean timedOut = elapsed >= hardLimit;

        if (initialComplete) {
            finishFullCollection(collected, false, true);
            return;
        }
        if (incrementalBoundaryReached) {
            finishFullCollection(collected, false, true);
            return;
        }
        if (timedOut) {
            // Never certify an initial import as complete merely because time ran out.
            // Keep the safely collected middle state and let the same link resume later.
            finishFullCollection(collected, true, incrementalSyncMode);
            return;
        }
        scheduleCollectionFrame(650);
    }

    private String buildCollectedTranscript() {
        if (!collectedMessageBlocks.isEmpty()) {
            StringBuilder b = new StringBuilder();
            for (String block : collectedMessageBlocks) {
                if (b.length() > 0) b.append("\n\n");
                b.append(block.trim());
            }
            return cleanupRenderedText(b.toString());
        }
        return bestBodySnapshot == null ? "" : bestBodySnapshot.trim();
    }

    private String collectionDiagnosticSummary() {
        StringBuilder b = new StringBuilder();
        b.append("\n\n🔎 수집 상세 기록 · 엔진 ").append(COLLECTOR_VERSION)
                .append("\n🔎 DOM 수집 진단")
                .append("\n페이지 전체 텍스트 ").append(diagBodyChars).append("자")
                .append(" · role ").append(diagRoleNodes)
                .append(" · conversation-turn ").append(diagTurnNodes)
                .append(" · article ").append(diagArticleNodes)
                .append("\nuser ").append(diagUserNodes).append(" / assistant ").append(diagAssistantNodes)
                .append(" · 구조화 블록 ").append(diagStructuredBlocks);
        if (!diagFirstVisible.isEmpty()) b.append("\n↑ DOM 첫 블록: ").append(clip(diagFirstVisible, 120));
        if (!diagLastVisible.isEmpty()) b.append("\n↓ DOM 최신 블록: ").append(clip(diagLastVisible, 120));
        b.append("\n\n🔧 페이지 내부 원본 데이터 확인")
                .append("\nscript ").append(diagScriptCount).append("개 · ").append(diagScriptChars).append("자")
                .append(" · JSON ").append(diagJsonScriptCount).append(" · RSC ").append(diagRscChunkCount)
                .append("\n숨은 대화 후보 ").append(diagHiddenCandidateTurns).append("턴");
        if (!diagHiddenFirst.isEmpty()) b.append("\n↑ 숨은 첫 후보: ").append(clip(diagHiddenFirst, 120));
        if (!diagHiddenLast.isEmpty()) b.append("\n↓ 숨은 최신 후보: ").append(clip(diagHiddenLast, 120));
        if (diagHiddenCandidateTurns > diagStructuredBlocks) {
            b.append("\n✅ 화면 DOM보다 원본 데이터에서 더 많은 대화 후보를 찾았어. 숨은 후보를 수집 결과에 합쳤어.");
        } else if (diagBodyChars > 4000 && diagStructuredBlocks <= 8) {
            b.append("\n⚠️ 페이지 글자는 많은데 구조화 대화 블록이 적어. ChatGPT DOM 선택자 변화 가능성이 커.");
        } else if (diagBodyChars > 0 && diagBodyChars < 2600 && diagStructuredBlocks <= 8 && diagHiddenCandidateTurns <= diagStructuredBlocks) {
            b.append("\nℹ️ DOM과 내부 원본 데이터 모두 짧아 보여. 이 공유페이지 자체가 짧은 스냅샷일 가능성이 커.");
        }
        return b.toString();
    }

    private void finishFullCollection(String collected, boolean timedOut, boolean markComplete) {
        if (!extracting) return;
        String clean = cleanupRenderedText(collected);
        if (looksLikeChatGptShell(clean) || clean.length() < 180) {
            fail("상담 전체를 충분히 불러오지 못했어. 아래 복붙 방식으로 가져오면 바로 분석할 수 있어.");
            previewText.setVisibility(View.VISIBLE);
            previewText.setText("읽힌 원문 " + clean.length() + "자\n\n" + clip(clean, 520));
            return;
        }
        List<String> blocks = new ArrayList<>(collectedMessageBlocks);
        MindTrainingStore.SharedTurnMergeResult merged = store.mergeSharedTurnBlocks(currentShareUrl, blocks, markComplete);
        showSyncVerification(store.sharedThreadByUrl(currentShareUrl), markComplete);
        String full = merged.fullText == null || merged.fullText.trim().isEmpty() ? clean : merged.fullText.trim();
        cacheCollectedTranscript(full);
        previewText.setVisibility(View.VISIBLE);

        if (!incrementalSyncMode && !markComplete) {
            extracting = false;
            importButton.setEnabled(true);
            previewText.setText("최초 전체수집 중간 저장 · " + merged.totalCount + "턴 · " + merged.totalChars + "자\n\n" + clip(full, 520));
            statusText.setText("⏳ 아직 상담 맨 끝까지 확인하지 못했어. 중간까지는 안전하게 저장했어. 같은 링크를 다시 누르면 중복은 빼고 최초 전체수집을 계속할게.");
            return;
        }

        if (incrementalSyncMode) {
            extracting = false;
            importButton.setEnabled(true);
            if (merged.addedCount <= 0) {
                MindTrainingStore.SharedThreadState state = store.sharedThreadByUrl(currentShareUrl);
                boolean needsAnalysis = state != null && (!"COMPLETE".equals(state.analysisState) || state.analyzedTurnCount < state.turnCount);
                if (needsAnalysis) {
                    previewText.setText("기존 " + merged.totalCount + "턴 · " + merged.totalChars + "자\n새 대화 0턴 · 중복은 자동 제외했어.\n지난 분석이 끝나지 않아 저장된 원문으로 분석만 다시 이어갈게.");
                    statusText.setText("🔁 새 대화는 없지만 지난 PT 분석이 미완료야. 재수집 없이 저장된 상담으로 분석을 다시 시도할게…");
                    retryStoredPendingAnalysis(state, merged.fullText);
                } else {
                    int applied = 0;
                    long centralId = store.latestSharedCounselingId();
                    long crownId = centralId >= 0 ? centralId : (state == null ? -1 : state.lastCounselingId);
                    if (crownId >= 0) {
                        applied = getSharedPreferences(AppPrefs.PREFS, MODE_PRIVATE)
                                .getInt(CROWN_POLICY_PREF_PREFIX + crownId, 0);
                    }
                    if (state != null && crownId >= 0 && applied < CROWN_POLICY_VERSION) {
                        previewText.setText("기존 " + merged.totalCount + "턴 · " + merged.totalChars + "자\n새 대화 0턴 · 중복은 자동 제외했어.\n👑 왕관 선정 기준이 업데이트되어 전체 상담을 다시 비교할게.");
                        rerankStoredCrown(state, merged.fullText);
                    } else {
                        previewText.setText("기존 " + merged.totalCount + "턴 · " + merged.totalChars + "자\n새 대화 0턴 · 중복은 자동 제외했어." + collectionDiagnosticSummary());
                        statusText.setText("✅ 상담의 처음부터 최신 턴까지 다시 확인했어. 새로 추가된 대화는 없어서 기존 기록은 그대로 두고, 왕관 PT도 전체 상담 기준으로 다시 확인했어.");
                    }
                }
                return;
            }
            previewText.setText("상담 업데이트 · 새 " + merged.addedCount + "턴 / " + merged.addedChars + "자 추가\n전체 " + merged.totalCount + "턴 · " + merged.totalChars + "자\n\n" + clip(merged.deltaText, 520));
            MindTrainingStore.SharedThreadState pendingState = store.sharedThreadByUrl(currentShareUrl);
            if (pendingState != null && (pendingState.analyzedTurnCount < pendingState.turnCount || !"COMPLETE".equals(pendingState.analysisState))) {
                statusText.setText("🔄 새 대화를 저장했어. 지난번 미완료분까지 합쳐서 아직 분석 안 된 대화만 이어서 분석할게…");
                retryStoredPendingAnalysis(pendingState, merged.fullText);
            } else {
                statusText.setText("🔄 새 대화 " + merged.addedCount + "턴만 분석해서 기존 마음 PT를 업데이트하는 중이야…");
                analyzeIncrementalTranscript(merged);
            }
            return;
        }

        MindTrainingStore.SharedCorpusState corpusState = store.sharedCorpusState();
        String corpusText = store.sharedCorpusTranscript();
        previewText.setText("✅ 이번 공유대화 전체수집 완료 · " + merged.totalCount + "턴 · " + merged.totalChars + "자" +
                "\n🧠 누적 상담DB · " + corpusState.threadCount + "개 대화 · " + corpusState.turnCount + "턴 · " + corpusState.charCount + "자" +
                "\n이후 같은 링크는 새 대화만 추가하고, 다른 링크는 누적DB에 합칠게." + collectionDiagnosticSummary() + "\n\n" + clip(full, 520));
        long centralCounselingId = store.latestSharedCounselingId();
        if (centralCounselingId >= 0 && corpusState.threadCount > 1) {
            store.bindSharedThreadCounseling(currentShareUrl, centralCounselingId);
            statusText.setText("🧠 이번 상담을 기존 누적 상담DB에 더했어. 기존 PT를 지우지 않고 새 근거만 반영한 뒤 왕관을 전체 기록으로 다시 볼게…");
            analyzeIncrementalTranscript(merged);
        } else {
            statusText.setText("✅ 첫 상담 기록을 저장했어. 누적 상담DB의 첫 마음 PT를 만드는 중이야…");
            analyzeCollectedTranscript(corpusText.isEmpty() ? full : corpusText);
        }
    }

    private void showSyncVerification(MindTrainingStore.SharedThreadState st, boolean justVerified) {
        if (verificationText == null) return;
        if (st == null || st.turnCount <= 0) { verificationText.setVisibility(View.GONE); return; }
        StringBuilder b = new StringBuilder();
        boolean verified = st.complete && (st.lastVerifiedAt > 0 || justVerified);
        b.append(verified ? "✅ 최신 턴까지 수집 검증됨" : "⏳ 전체수집 검증 진행 중");
        b.append("\n이번 공유대화 ").append(st.turnCount).append("턴 · ").append(st.charCount).append("자");
        MindTrainingStore.SharedCorpusState corpus = store.sharedCorpusState();
        b.append("\n🧠 누적 상담DB ").append(corpus.threadCount).append("개 대화 · ").append(corpus.turnCount).append("턴 · ").append(corpus.charCount).append("자");
        b.append("\n이번 링크 분석 ").append(Math.min(st.analyzedTurnCount, st.turnCount)).append("/").append(st.turnCount).append("턴 · ").append(analysisLabel(st.analysisState));
        if (!st.firstTurnPreview.isEmpty()) b.append("\n\n⬆ 첫 턴: ").append(st.firstTurnPreview);
        if (!st.lastTurnPreview.isEmpty()) b.append("\n⬇ 최신 턴: ").append(st.lastTurnPreview);
        if (!st.firstTurnHash.isEmpty()) b.append("\n\n첫 지문 ").append(shortHash(st.firstTurnHash));
        if (!st.lastTurnHash.isEmpty()) b.append(" · 최신 지문 ").append(shortHash(st.lastTurnHash));
        if (st.lastVerifiedAt > 0) b.append("\n마지막 전체검증: ").append(formatLocalTime(st.lastVerifiedAt));
        else if (st.lastSyncAt > 0) b.append("\n마지막 동기화: ").append(formatLocalTime(st.lastSyncAt));
        verificationText.setText(b.toString());
        verificationText.setVisibility(View.VISIBLE);
    }

    private String analysisLabel(String state) {
        if ("COMPLETE".equals(state)) return "완료";
        if ("RUNNING".equals(state)) return "분석 중";
        if ("FAILED".equals(state)) return "실패 · 저장 원문으로 재시도 가능";
        return "대기/미완료";
    }

    private String shortHash(String hash) {
        if (hash == null) return "";
        String x = hash.trim();
        return x.length() <= 10 ? x : x.substring(0, 10);
    }

    private String formatLocalTime(long ms) {
        try { return new java.text.SimpleDateFormat("MM-dd HH:mm:ss", java.util.Locale.KOREA).format(new java.util.Date(ms)); }
        catch (Exception ignored) { return String.valueOf(ms); }
    }

    private void retryStoredPendingAnalysis(MindTrainingStore.SharedThreadState thread, String fullText) {
        if (thread == null) return;
        String full = fullText == null || fullText.trim().isEmpty() ? store.sharedThreadTranscript(currentShareUrl) : fullText.trim();
        if (thread.lastCounselingId < 0 || thread.analyzedTurnCount <= 0) {
            long centralId = store.latestSharedCounselingId();
            if (centralId >= 0) {
                store.bindSharedThreadCounseling(currentShareUrl, centralId);
                MindTrainingStore.SharedTurnMergeResult resume = new MindTrainingStore.SharedTurnMergeResult();
                resume.threadId = thread.id; resume.existingCount = 0; resume.addedCount = thread.turnCount; resume.addedChars = thread.charCount;
                resume.totalCount = thread.turnCount; resume.totalChars = thread.charCount; resume.complete = thread.complete;
                resume.deltaText = store.sharedThreadTranscript(currentShareUrl); resume.fullText = resume.deltaText;
                statusText.setText("🧠 저장된 이번 상담을 기존 누적 PT에 이어 붙여 분석하고 있어…");
                analyzeIncrementalTranscript(resume);
            } else {
                statusText.setText("저장된 누적 상담DB를 다시 분석해서 첫 마음 PT를 만들고 있어…");
                String corpus = store.sharedCorpusTranscript();
                analyzeCollectedTranscript(corpus.isEmpty() ? full : corpus);
            }
            return;
        }
        String pending = store.sharedPendingAnalysisText(currentShareUrl);
        if (pending.trim().isEmpty()) {
            int applied = getSharedPreferences(AppPrefs.PREFS, MODE_PRIVATE)
                    .getInt(CROWN_POLICY_PREF_PREFIX + thread.lastCounselingId, 0);
            if (applied < CROWN_POLICY_VERSION) {
                rerankStoredCrown(thread, full);
                return;
            }
            store.markSharedThreadAnalysisComplete(currentShareUrl);
            statusText.setText("✅ 저장된 상담이 지금 링크의 최신 범위와 맞아. 원문과 PT는 그대로 보존했고, 왕관도 전체 상담 기준으로 확인돼 있어.");
            return;
        }
        MindTrainingStore.SharedTurnMergeResult resume = new MindTrainingStore.SharedTurnMergeResult();
        resume.threadId = thread.id; resume.existingCount = thread.analyzedTurnCount;
        resume.addedCount = Math.max(0, thread.turnCount - thread.analyzedTurnCount); resume.addedChars = pending.length();
        resume.totalCount = thread.turnCount; resume.totalChars = thread.charCount; resume.complete = thread.complete;
        resume.deltaText = pending; resume.fullText = full;
        statusText.setText("🔁 저장된 미분석 대화 " + resume.addedCount + "턴만 다시 분석하고 있어…");
        analyzeIncrementalTranscript(resume);
    }


    /** v10.16.4: policy upgrade audit and crown-only selection are isolated so training-parser failures cannot masquerade as crown failures. */
    private void rerankStoredCrown(MindTrainingStore.SharedThreadState thread, String fullText) {
        SharedPreferences prefs = getSharedPreferences(AppPrefs.PREFS, MODE_PRIVATE);
        String apiKey = prefs.getString(AppPrefs.KEY_API_KEY, "").trim();
        String model = prefs.getString(AppPrefs.KEY_COUNSELING_MODEL, "gpt-4.1-mini").trim();
        if (thread == null) return;
        if (apiKey.isEmpty()) {
            statusText.setText("왕관 기준이 새로 바뀌었어. 원문/PT는 그대로 저장돼 있고, API Key를 설정한 뒤 같은 링크를 다시 누르면 왕관만 재평가할게.");
            return;
        }
        long latestCentralId = store.latestSharedCounselingId();
        final long counselingId = latestCentralId >= 0 ? latestCentralId : thread.lastCounselingId;
        if (counselingId < 0) return;
        final String existing = store.existingProgramContext(counselingId);
        final String crownTranscript = store.sharedCorpusTranscript().trim().isEmpty() ? fullText : store.sharedCorpusTranscript();
        if (existing.trim().isEmpty()) {
            prefs.edit().putInt(CROWN_POLICY_PREF_PREFIX + counselingId, CROWN_POLICY_VERSION).apply();
            store.markSharedThreadAnalysisComplete(currentShareUrl);
            return;
        }
        statusText.setText("🧠 빠진 PT/단계는 별도로 점검하고, 왕관은 기존 PT ID 중 하나만 다시 고르고 있어…");
        importButton.setEnabled(false); extracting = true;
        new Thread(() -> {
            int prepChanged = 0;
            String prepWarning = "";
            try {
                try {
                    CounselingProgramAnalyzer.Analysis coverage = CounselingProgramAnalyzer.analyzeCoverageGaps(apiKey, model, crownTranscript, existing);
                    prepChanged += store.mergeIncrementalPrograms(counselingId, coverage);
                    String refreshedExisting = store.existingProgramContext(counselingId);
                    CounselingProgramAnalyzer.Analysis stepRefinement = CounselingProgramAnalyzer.refineExistingProgramSteps(apiKey, model, crownTranscript, refreshedExisting);
                    prepChanged += store.applyProgramStepRefinements(counselingId, stepRefinement);
                } catch (Exception prepError) {
                    // Coverage/step quality is optional here. Never block crown selection with a training-program parser error.
                    prepWarning = safeMessage(prepError);
                }

                String crownContext = store.existingProgramContext(counselingId);
                CounselingProgramAnalyzer.CrownOnlyResult crownResult = CounselingProgramAnalyzer.rerankExistingCrownOnly(apiKey, model, crownTranscript, crownContext);
                int crownChanged = store.setCrownProgramById(counselingId, crownResult.crownProgramId);
                final int changed = prepChanged + crownChanged;
                final String warning = prepWarning;
                store.bindAllSharedThreadsCounseling(counselingId);
                prefs.edit().putInt(CROWN_POLICY_PREF_PREFIX + counselingId, CROWN_POLICY_VERSION).apply();
                store.markSharedThreadAnalysisComplete(currentShareUrl);
                main.post(() -> {
                    extracting=false; importButton.setEnabled(true);
                    showSyncVerification(store.sharedThreadByUrl(currentShareUrl), false);
                    java.util.List<MindTrainingStore.ProgramSummary> ps=store.programsForCounseling(counselingId);
                    long crownId=store.crownProgramId(counselingId);
                    String crown="";
                    if(ps!=null) for(MindTrainingStore.ProgramSummary p:ps) if(p.id==crownId){crown=p.muscleName;break;}
                    String why = crownResult.crownReason == null ? "" : crownResult.crownReason.trim();
                    statusText.setText("✅ 전체 상담을 다시 비교했어. 원문·PT·단계·기록은 그대로 보존했고, 지금 가장 중요한 왕관 PT는 👑 " + crown + " 이야.");
                    String body="👑 왕관은 새 PT를 억지로 만들지 않고, 이미 저장된 마음 PT들 가운데 전체 상담에서 중요하고 최근에도 살아 있는 하나를 다시 골랐어." +
                            "\n원문과 기존 훈련 단계, 지금까지의 결과 기록은 바꾸지 않았어. 이번에 확인하거나 정리한 항목은 " + changed + "건이야.";
                    if(!warning.isEmpty()) body += "\n\nℹ️ 이번에는 일부 PT 보강을 억지로 적용하지 않고 기존 흐름을 우선 보존했어. 다음 상담 근거가 더 쌓이면 다시 자연스럽게 다듬을게.";
                    if(!why.isEmpty()) body += "\n\n👑 왜 지금 이 PT가 왕관이야?\n" + why;
                    programsText.setText(body);
                    programsText.setVisibility(View.VISIBLE);
                    MaeumMonClockWidget.refreshAll(this);
                });
            } catch(Exception crownError) {
                main.post(() -> {
                    extracting=false; importButton.setEnabled(true);
                    statusText.setText("👑 왕관은 기존 선택을 유지했어. PT/단계/원문은 그대로고, 다음 동기화 때 왕관만 다시 확인할게.");
                    programsText.setText("왕관 전용 ID 선택 단계에서만 재시도가 필요해. 기존 훈련 프로그램 생성/검증과는 분리돼 있어.");
                    programsText.setVisibility(View.VISIBLE);
                });
            }
        }).start();
    }

    private void analyzeIncrementalTranscript(MindTrainingStore.SharedTurnMergeResult merged) {
        SharedPreferences prefs = getSharedPreferences(AppPrefs.PREFS, MODE_PRIVATE);
        String apiKey = prefs.getString(AppPrefs.KEY_API_KEY, "").trim();
        String model = prefs.getString(AppPrefs.KEY_COUNSELING_MODEL, "gpt-4.1-mini").trim();
        MindTrainingStore.SharedThreadState thread = store.sharedThreadByUrl(currentShareUrl);
        if (apiKey.isEmpty()) { store.markSharedThreadAnalysisState(currentShareUrl,"PENDING","OpenAI API Key 필요"); fail("OpenAI API Key가 필요해. 새 대화는 이미 폰에 저장했어."); return; }
        if (thread == null) {
            statusText.setText("공유 상담 저장정보를 찾지 못했어.");
            return;
        }
        long latestCentralId = store.latestSharedCounselingId();
        long resolvedCounselingId = latestCentralId >= 0 ? latestCentralId : thread.lastCounselingId;
        if (resolvedCounselingId < 0) {
            statusText.setText("기존 중앙 PT가 없어서 누적 상담DB 전체를 처음 분석할게…");
            String corpus = store.sharedCorpusTranscript();
            analyzeCollectedTranscript(corpus.isEmpty() ? merged.fullText : corpus);
            return;
        }
        if (thread.lastCounselingId < 0) store.bindSharedThreadCounseling(currentShareUrl, resolvedCounselingId);
        final long counselingId = resolvedCounselingId;
        final String existing = store.existingProgramContext(counselingId);
        store.markSharedThreadAnalysisState(currentShareUrl,"RUNNING",""); showSyncVerification(store.sharedThreadByUrl(currentShareUrl), false);
        new Thread(() -> {
            try {
                CounselingProgramAnalyzer.Analysis analysis = CounselingProgramAnalyzer.analyzeIncremental(apiKey, model, existing, merged.deltaText);
                main.post(() -> showIncrementalApproval(counselingId, merged, analysis));
            } catch (Exception e) {
                main.post(() -> {
                    extracting = false; importButton.setEnabled(true);
                    store.markSharedThreadAnalysisState(currentShareUrl,"FAILED",safeMessage(e));
                    statusText.setText("⚠️ 새 대화 분석은 실패했지만 " + merged.addedCount + "턴은 이미 저장했어. 같은 링크를 다시 누르면 재수집 없이 분석만 이어서 시도할게: " + safeMessage(e));
                });
            }
        }).start();
    }

    private void showIncrementalApproval(long counselingId, MindTrainingStore.SharedTurnMergeResult merged, CounselingProgramAnalyzer.Analysis analysis) {
        extracting = false; importButton.setEnabled(true);
        store.markSharedThreadAnalysisState(currentShareUrl,"PENDING","");
        if (analysis.programs.isEmpty()) {
            String corpus = store.sharedCorpusTranscript();
            store.updateCounselingRawText(counselingId, corpus.isEmpty() ? merged.fullText : corpus, analysis);
            store.bindAllSharedThreadsCounseling(counselingId);
            store.markSharedThreadAnalysisComplete(currentShareUrl);
            showSyncVerification(store.sharedThreadByUrl(currentShareUrl), false);
            statusText.setText("✅ 새 PT 추가는 없었어. 그래도 새 상담 근거가 들어왔으니 왕관은 누적 상담DB 전체로 다시 확인할게…");
            rerankStoredCrown(store.sharedThreadByUrl(currentShareUrl), corpus);
            return;
        }
        int n=analysis.programs.size(); String[] items=new String[n]; boolean[] checked=new boolean[n];
        for(int i=0;i<n;i++){CounselingProgramAnalyzer.Program p=analysis.programs.get(i);items[i]=(i==0?"⭐ ":"🌱 ")+p.muscleName+"\n"+shortenReason(p.reason);checked[i]=true;}
        AlertDialog d=new AlertDialog.Builder(this).setTitle("새 대화가 마음 PT에 만든 변화").setMultiChoiceItems(items,checked,(dialog,which,isChecked)->checked[which]=isChecked).setNegativeButton("나중에",null).setPositiveButton("선택한 변화 반영",null).create();
        d.setOnShowListener(dialog->d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{
            CounselingProgramAnalyzer.Analysis selected=copyAnalysisMeta(analysis);for(int i=0;i<n;i++)if(checked[i])selected.programs.add(analysis.programs.get(i));
            d.dismiss(); String corpus=store.sharedCorpusTranscript(); store.updateCounselingRawText(counselingId,corpus.isEmpty()?merged.fullText:corpus,selected); int changed=store.mergeIncrementalPrograms(counselingId,selected); store.bindAllSharedThreadsCounseling(counselingId); store.markSharedThreadAnalysisComplete(currentShareUrl); showSyncVerification(store.sharedThreadByUrl(currentShareUrl), false);
            MindTrainingStore.SharedCorpusState cs=store.sharedCorpusState();
            statusText.setText("✅ 이번 상담을 누적DB에 반영했어 · 마음 PT " + changed + "개 갱신/추가 · 이제 왕관을 전체 기록으로 다시 볼게…");
            programsText.setText("이번 공유대화에서 새 " + merged.addedCount + "턴을 반영했어.\n🧠 누적 상담DB " + cs.threadCount + "개 대화 · " + cs.turnCount + "턴 · " + cs.charCount + "자\n기존 PT는 지우지 않고 새 근거에 맞춰 갱신/추가했어. 의미가 같은 PT는 중복 저장하지 않아.");programsText.setVisibility(View.VISIBLE);MaeumMonClockWidget.refreshAll(this);
            rerankStoredCrown(store.sharedThreadByUrl(currentShareUrl), corpus);
        })); d.show();
    }

    private void analyzeCollectedTranscript(String clean) {
        SharedPreferences prefs = getSharedPreferences(AppPrefs.PREFS, MODE_PRIVATE);
        String apiKey = prefs.getString(AppPrefs.KEY_API_KEY, "").trim();
        String model = prefs.getString(AppPrefs.KEY_COUNSELING_MODEL, "gpt-4.1-mini").trim();
        if (apiKey.isEmpty()) {
            store.markSharedThreadAnalysisState(currentShareUrl,"PENDING","OpenAI API Key 필요");
            fail("상담을 정확히 여러 훈련으로 나누려면 기존 마음몬 설정의 OpenAI API Key가 필요해. 원문은 폰에 저장돼 있으니 같은 링크로 나중에 분석만 다시 할 수 있어.");
            return;
        }
        store.markSharedThreadAnalysisState(currentShareUrl,"RUNNING",""); showSyncVerification(store.sharedThreadByUrl(currentShareUrl), false);
        new Thread(() -> {
            try {
                CounselingProgramAnalyzer.Analysis analysis = CounselingProgramAnalyzer.analyze(apiKey, model, clean);
                main.post(() -> showProgramApproval(clean, analysis));
            } catch (Exception e) {
                main.post(() -> {
                    extracting = false;
                    importButton.setEnabled(true);
                    String msg = safeMessage(e);
                    store.markSharedThreadAnalysisState(currentShareUrl,"FAILED",msg);
                    if (isNetworkProblem(e)) {
                        statusText.setText("⚠️ 분석 네트워크 연결이 불안정해: " + msg + "\n원문 " + clean.length() + "자는 폰에 저장했어. 같은 버튼을 누르면 재수집 없이 분석만 다시 시도할 수 있어.");
                    } else {
                        fail("분석 중 문제가 생겼어: " + msg + "\n원문은 폰에 저장해뒀어.");
                    }
                });
            }
        }).start();
    }

    private void cacheCollectedTranscript(String clean) {
        String url = extractShareUrl(linkInput.getText().toString());
        if (clean == null || clean.trim().length() < 180 || url.isEmpty()) return;
        getSharedPreferences(CACHE_PREFS, MODE_PRIVATE).edit()
                .putString(CACHE_URL, url)
                .putString(CACHE_TEXT, clean.trim())
                .putLong(CACHE_TS, System.currentTimeMillis())
                .apply();
    }

    private boolean isNetworkProblem(Throwable t) {
        Throwable x = t;
        while (x != null) {
            if (x instanceof java.net.UnknownHostException || x instanceof java.net.SocketTimeoutException || x instanceof java.net.ConnectException) return true;
            String m = x.getMessage();
            if (m != null) {
                String q = m.toLowerCase();
                if (q.contains("unable to resolve host") || q.contains("no address associated with hostname") || q.contains("timeout") || q.contains("timed out")) return true;
            }
            x = x.getCause();
        }
        return false;
    }


    private void showProgramApproval(String clean, CounselingProgramAnalyzer.Analysis analysis) {
        extracting = false;
        importButton.setEnabled(true);
        store.markSharedThreadAnalysisState(currentShareUrl,"PENDING","");
        int n = analysis.programs.size();
        if (n <= 0) {
            store.markSharedThreadAnalysisComplete(currentShareUrl);
            statusText.setText("✅ 상담 분석은 완료했지만 이번에는 저장할 마음 PT 후보가 없었어.");
            return;
        }
        String[] items = new String[n];
        boolean[] checked = new boolean[n];
        for (int i = 0; i < n; i++) {
            CounselingProgramAnalyzer.Program p = analysis.programs.get(i);
            boolean expansion = "EXPANSION".equals(p.source);
            items[i] = (i == 0 ? "⭐ 추천 · " : expansion ? "🌱 확장 PT · " : "✅ 직접 확인 · ")
                    + p.muscleName + "\n" + shortenReason(p.reason);
            checked[i] = true;
        }
        statusText.setText("🐣 상담에서 " + n + "개의 마음 PT 후보를 찾았어. 나한테 맞는 훈련을 골라줘.");

        AlertDialog d = new AlertDialog.Builder(this)
                .setTitle("이 훈련들도 나한테 필요한 것 같아?")
                .setMultiChoiceItems(items, checked, (dialog, which, isChecked) -> checked[which] = isChecked)
                .setNegativeButton("다시 보기", null)
                .setPositiveButton("선택한 PT 저장", null)
                .create();

        d.setOnShowListener(dialog -> {
            d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
                CounselingProgramAnalyzer.Analysis selected = copyAnalysisMeta(analysis);
                for (int i = 0; i < checked.length; i++) if (checked[i]) selected.programs.add(analysis.programs.get(i));
                if (selected.programs.isEmpty()) {
                    Toast.makeText(this, "최소 1개는 골라줘.", Toast.LENGTH_SHORT).show();
                    return;
                }
                d.dismiss();
                persistApprovedPrograms(clean, selected);
            });
        });
        d.show();
    }

    private CounselingProgramAnalyzer.Analysis copyAnalysisMeta(CounselingProgramAnalyzer.Analysis src) {
        CounselingProgramAnalyzer.Analysis a = new CounselingProgramAnalyzer.Analysis();
        a.title = src.title;
        a.currentConcern = src.currentConcern;
        a.formulation = src.formulation;
        a.priorityDirection = src.priorityDirection;
        a.caution = src.caution;
        a.discoveredCandidateCount = src.discoveredCandidateCount;
        a.groundedCandidateCount = src.groundedCandidateCount;
        return a;
    }

    private void persistApprovedPrograms(String clean, CounselingProgramAnalyzer.Analysis selected) {
        extracting = true;
        importButton.setEnabled(false);
        statusText.setText("선택한 마음 PT를 저장하고 있어…");
        new Thread(() -> {
            try {
                long counselingId = store.saveAnalyzedCounseling(clean, selected);
                if (currentShareUrl != null && !currentShareUrl.isEmpty()) { store.bindAllSharedThreadsCounseling(counselingId); store.markSharedThreadAnalysisComplete(currentShareUrl); }
                long trainingId = store.activateFirstProgramStep(counselingId, true);
                List<MindTrainingStore.ProgramSummary> programs = store.programsForCounseling(counselingId);
                main.post(() -> showSuccess(selected, programs, trainingId));
            } catch (Exception e) {
                main.post(() -> fail("저장 중 문제가 생겼어: " + safeMessage(e)));
            }
        }).start();
    }

    private String shortenReason(String s) {
        if (s == null || s.trim().isEmpty()) return "상담 장면에서 이어서 연습해볼 수 있는 훈련";
        String x = s.trim().replace("\n", " ");
        return x.length() <= 72 ? x : x.substring(0, 72).trim() + "…";
    }

    private void showSuccess(CounselingProgramAnalyzer.Analysis analysis, List<MindTrainingStore.ProgramSummary> programs, long trainingId) {
        extracting = false;
        importButton.setEnabled(true);
        statusText.setText(trainingId > 0 ? "✅ 상담을 읽고 오늘 시작할 PT까지 정했어." : "✅ 상담 프로그램을 저장했어.");
        StringBuilder b = new StringBuilder();
        b.append("탐색 후보 ").append(analysis.discoveredCandidateCount)
                .append("개 → 근거 후보 ").append(analysis.groundedCandidateCount)
                .append("개 → 저장된 훈련 ").append(programs.size()).append("개\n");
        b.append("내가 선택해서 저장한 마음 PT ").append(programs.size()).append("개\n");
        b.append("⭐ 추천 1개와 내가 승인한 확장 PT가 함께 저장됐어.\n\n");
        for (int i = 0; i < programs.size(); i++) {
            MindTrainingStore.ProgramSummary p = programs.get(i);
            b.append(i == 0 ? "⭐ " : "🌱 ").append(p.muscleName);
            b.append("\n   ").append(p.stepCount).append("단계 · 우선순위 ").append(p.priority);
            if (!p.reason.isEmpty()) b.append("\n   ").append(p.reason);
            if (i < programs.size() - 1) b.append("\n\n");
        }
        if (!analysis.caution.isEmpty()) b.append("\n\n⚠️ 안전 메모\n").append(shortenCaution(analysis.caution));
        b.append("\n\n⭐ 별표는 마음몬 추천이야. 선택한 PT들은 각각 독립적으로 진행도가 저장돼.");
        programsText.setText(b.toString());
        programsText.setVisibility(View.VISIBLE);
        MaeumMonClockWidget.refreshAll(this);
        setResult(RESULT_OK);
        Toast.makeText(this, "상담 완전판을 마음 PT 프로그램으로 바꿨어.", Toast.LENGTH_LONG).show();
    }

    private void fail(String message) {
        extracting = false;
        importButton.setEnabled(true);
        statusText.setText("⚠️ " + message);
    }

    private boolean looksLikeChatGptShell(String s) {
        if (s == null || s.trim().isEmpty()) return true;
        String t = s.toLowerCase();
        boolean cookie = (t.contains("저희는 쿠키를 사용합니다") || t.contains("쿠키 정책")
                || t.contains("we use cookies") || t.contains("cookie policy"));
        boolean loginShell = (t.contains("콘텐츠로 건너뛰기") || t.contains("skip to content"))
                && (t.contains("로그인") || t.contains("log in"));
        // If a real conversation is present it is normally much longer; do not reject
        // a long page merely because the global header still contains Login.
        return (cookie && s.length() < 900) || (loginShell && s.length() < 650);
    }

    private String cleanupRenderedText(String raw) {
        if (raw == null) return "";
        String s = raw.replace('\u00a0', ' ').replace("\r", "").trim();
        s = s.replaceAll("[ \\t]+", " " );
        StringBuilder filtered = new StringBuilder();
        String[] lines = s.split("\\n");
        for (String line : lines) {
            String x = line == null ? "" : line.trim();
            if (isSharePageUiNoise(x)) continue;
            if (filtered.length() > 0) filtered.append('\n');
            filtered.append(x);
        }
        s = filtered.toString().replaceAll("\\n{4,}", "\\n\\n\\n");
        return s.trim();
    }

    private boolean isSharePageUiNoise(String x) {
        if (x == null || x.isEmpty()) return false;
        String t = x.toLowerCase();
        return "콘텐츠로 건너뛰기".equals(x) || "로그인".equals(x) || "chatgpt".equals(t)
                || "대화 신고하기".equals(x) || "이미지 업로드됨".equals(x) || "음성".equals(x)
                || t.startsWith("공유된 chatgpt 채팅의 사본입니다")
                || t.startsWith("저희는 쿠키를 사용합니다")
                || t.startsWith("쿠키는 이 사이트의 기능 유지")
                || "모두 허용".equals(x) || "비필수사항 거부".equals(x);
    }

    private String shortenCaution(String s) {
        if (s == null) return "";
        String x = s.trim();
        if (x.length() <= 180) return x;
        return x.substring(0, 180).trim() + "…";
    }

    private String extractShareUrl(String text) {
        if (text == null) return "";
        String t = text.trim();
        int i = t.indexOf("https://chatgpt.com/share/");
        if (i < 0) return "";
        int end = t.length();
        for (int x = i; x < t.length(); x++) {
            char c = t.charAt(x);
            if (Character.isWhitespace(c) || c == ')' || c == ']' || c == '>' || c == '"') { end = x; break; }
        }
        return t.substring(i, end).trim();
    }

    private String clip(String s, int max) { return s.length() <= max ? s : s.substring(0, max) + "…"; }
    private String safeMessage(Exception e) {
        String m = e == null ? "알 수 없는 오류" : e.getMessage();
        if (m == null || m.trim().isEmpty()) m = e.getClass().getSimpleName();
        return m.length() > 260 ? m.substring(0, 260) + "…" : m;
    }
}
