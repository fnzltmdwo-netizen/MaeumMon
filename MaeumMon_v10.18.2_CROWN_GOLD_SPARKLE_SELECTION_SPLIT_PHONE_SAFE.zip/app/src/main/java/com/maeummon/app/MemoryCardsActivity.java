package com.maeummon.app;
import android.app.Activity;import android.os.Bundle;import android.view.View;import android.widget.LinearLayout;import android.widget.TextView;import org.json.JSONArray;import org.json.JSONObject;
public class MemoryCardsActivity extends Activity{
 @Override protected void onCreate(Bundle b){super.onCreate(b);setContentView(R.layout.activity_memory_cards);UiInsets.apply(this,findViewById(R.id.memoryRoot));render();}
 private void render(){LinearLayout box=findViewById(R.id.memoryCardsContainer);TextView empty=findViewById(R.id.memoryEmptyText);box.removeAllViews();JSONArray arr=MemoryManager.memories(this);empty.setVisibility(arr.length()==0?View.VISIBLE:View.GONE);for(int i=0;i<Math.min(arr.length(),30);i++){JSONObject o=arr.optJSONObject(i);if(o==null)continue;TextView card=new TextView(this);card.setBackgroundResource(R.drawable.bg_card);card.setPadding(dp(16),dp(14),dp(16),dp(14));card.setText("🌱 "+o.optString("title","기억")+"\n"+o.optString("text")+"\n\n"+o.optString("date")+"  ·  #"+o.optString("tag","마음"));card.setTextColor(0xFF555E6D);card.setTextSize(14f);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.bottomMargin=dp(10);box.addView(card,lp);}}
 private int dp(int v){return Math.round(v*getResources().getDisplayMetrics().density);}
}
