package com.maeummon.app.clinical;

import android.content.Context;
import org.json.*;

public final class CooldownEvidenceTemporalIndependenceBurstGuardRC14 {
    private CooldownEvidenceTemporalIndependenceBurstGuardRC14(){}

    public enum State {
        NONE,
        TEMPORALLY_INDEPENDENT,
        SAME_EPISODE_BURST,
        WAITING_FOR_SEPARATION,
        INELIGIBLE
    }

    public static final class Result {
        public boolean evaluated=false;
        public boolean temporallyIndependent=false;
        public boolean burstBlocked=false;
        public boolean waiting=false;
        public State state=State.NONE;
        public String transitionKey="";
        public String currentCause="";
        public long lastEligibleEvidenceAt=0L;
        public long separationMs=0L;
        public String reason="";
        public String summary="";
    }

    public static Result evaluate(
            Context c,
            ClinicalDecisionRC7 d){

        Result r=new Result();

        if(c==null||d==null){
            r.state=State.INELIGIBLE;
            r.reason="MISSING_INPUT";
            return finish(r);
        }

        r.evaluated=true;

        if(!d.transitionExplanationCorrectionApplied){
            r.state=State.INELIGIBLE;
            r.reason="NO_EXPLICIT_CURRENT_CORRECTION";
            return finish(r);
        }

        JSONObject f=
                CentralTherapyProfile.loadFormulation(c);

        String context=
                f.optString(
                        "current_context_scope",
                        "UNKNOWN");

        r.transitionKey=
                safe(d.decisionTransitionFromState)
                +"->"
                +safe(d.decisionTransitionToState)
                +"::"
                +context;

        r.currentCause=
                safe(d.transitionExplanationCorrectedCause);

        if(r.currentCause.isEmpty()){
            r.state=State.INELIGIBLE;
            r.reason="MISSING_CURRENT_CAUSE";
            return finish(r);
        }

        JSONObject p=
                CentralTherapyProfile.loadProfile(c);

        JSONArray ledger=
                p.optJSONArray(
                        "requarantine_cooldown_evidence_ledger");

        if(ledger==null||ledger.length()==0){
            r.temporallyIndependent=true;
            r.state=State.TEMPORALLY_INDEPENDENT;
            r.reason="FIRST_ELIGIBLE_EVIDENCE";
            return finish(r);
        }

        for(int i=ledger.length()-1;i>=0;i--){
            JSONObject row=ledger.optJSONObject(i);
            if(row==null)continue;

            if(!CooldownEvidenceLedgerIntegrityAntiSyntheticRC14
                    .rowEligible(row))
                continue;

            if(!r.transitionKey.equals(
                    row.optString("transition_key","")))
                continue;

            if(!r.currentCause.equals(
                    row.optString("current_cause","")))
                continue;

            long at=row.optLong("time",0L);
            if(at<=0L)continue;

            r.lastEligibleEvidenceAt=at;
            break;
        }

        if(r.lastEligibleEvidenceAt<=0L){
            r.temporallyIndependent=true;
            r.state=State.TEMPORALLY_INDEPENDENT;
            r.reason="NO_PRIOR_TIMESTAMPED_EVIDENCE";
            return finish(r);
        }

        long now=System.currentTimeMillis();
        r.separationMs=Math.max(0L,now-r.lastEligibleEvidenceAt);

        // Product heuristic:
        // confirmations inside 30 minutes are treated as one evidence episode.
        long burstWindow=
                30L*60L*1000L;

        if(r.separationMs<burstWindow){
            r.burstBlocked=true;
            r.waiting=true;
            r.state=State.SAME_EPISODE_BURST;
            r.reason="WITHIN_30_MINUTE_EVIDENCE_EPISODE";
            return finish(r);
        }

        r.temporallyIndependent=true;
        r.state=State.TEMPORALLY_INDEPENDENT;
        r.reason="TEMPORAL_SEPARATION_THRESHOLD_MET";
        return finish(r);
    }

    public static boolean mayCount(Result r){
        return r!=null
                &&r.temporallyIndependent
                &&!r.burstBlocked
                &&r.state==State.TEMPORALLY_INDEPENDENT;
    }

    public static String instruction(Result r){
        if(r==null||!r.evaluated)return "";

        if(r.state==State.SAME_EPISODE_BURST)
            return "COOLDOWN_EVIDENCE_TEMPORAL_INDEPENDENCE=BURST_BLOCKED. 같은 transition/cause의 확인이 30분 이내에 연속으로 나와 하나의 evidence episode로 보고 추가 confirmation으로 카운트하지 않는다.";

        if(r.state==State.TEMPORALLY_INDEPENDENT)
            return "COOLDOWN_EVIDENCE_TEMPORAL_INDEPENDENCE=INDEPENDENT. 이전 eligible evidence와 시간적으로 분리되어 독립 confirmation 후보가 된다.";

        return "";
    }

    private static Result finish(Result r){
        r.summary=
                r.state.name()
                +" | independent="+r.temporallyIndependent
                +" | burstBlocked="+r.burstBlocked
                +" | waiting="+r.waiting
                +" | transition="+r.transitionKey
                +" | cause="+r.currentCause
                +" | lastAt="+r.lastEligibleEvidenceAt
                +" | separationMs="+r.separationMs
                +" | reason="+r.reason;
        return r;
    }

    private static String safe(String s){
        return s==null?"":s;
    }
}
