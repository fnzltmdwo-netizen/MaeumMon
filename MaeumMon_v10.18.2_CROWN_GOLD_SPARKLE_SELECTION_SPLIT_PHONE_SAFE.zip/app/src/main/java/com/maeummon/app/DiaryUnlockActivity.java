package com.maeummon.app;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.Toast;

public class DiaryUnlockActivity extends Activity {

    private EditText pinInput;
    private String target;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_diary_unlock);
        UiInsets.apply(this, findViewById(R.id.unlockRoot));

        target = getIntent().getStringExtra("target");
        pinInput = findViewById(R.id.unlockPinInput);

        findViewById(R.id.unlockButton).setOnClickListener(v -> unlock());
    }

    private void unlock() {
        String pin = pinInput.getText().toString().trim();

        if (!DiarySecurity.verify(this, pin)) {
            Toast.makeText(this, "PIN이 맞지 않아.", Toast.LENGTH_SHORT).show();
            pinInput.setText("");
            return;
        }

        DiarySecurity.unlockForFiveMinutes(this);
        openTarget();
        finish();
    }

    private void openTarget() {
        Intent intent;

        if (EmotionDiaryActivity.class.getName().equals(target)) {
            intent = new Intent(this, EmotionDiaryActivity.class);
        } else if (MoodCalendarActivity.class.getName().equals(target)) {
            intent = new Intent(this, MoodCalendarActivity.class);
        } else if (WeeklyReportActivity.class.getName().equals(target)) {
            intent = new Intent(this, WeeklyReportActivity.class);
        } else if (MonthlyStatsActivity.class.getName().equals(target)) {
            intent = new Intent(this, MonthlyStatsActivity.class);
        } else {
            intent = new Intent(this, MainActivity.class);
        }

        startActivity(intent);
    }
}
