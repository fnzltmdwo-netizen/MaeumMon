package com.maeummon.app.clinical;

import android.content.Context;
import org.json.*;

public final class CorrectionProvenanceReinstatementIdempotencyRC14 {
    private CorrectionProvenanceReinstatementIdempotencyRC14(){}

    public enum State {
        NONE,
        ALLOW,
        DUPLICATE_SUPPRESSED,
        ALREADY_ACTIVE,
        BLOCKED
    }

    public static final class Result {
        public boolean evaluated=false;
        public boolean allow=false;
        public boolean duplicateSuppressed=false;
        public boolean alreadyActive=false;
        public boolean blocked=false;
        public State state=State.NONE;
        public String identity="";
        public String transitionKey="";
        public String evidenceId="";
        public String cause="";
        public String reason="";
        public String summary="";
    }

    public static Result evaluate(
            Context c,
            ClinicalDecisionRC7 d,
            QuarantinedCorrectionProvenanceReviewReinstatementRC14.Result candidate){

        Result r=new Result();

        if(c==null||d==null||candidate==null){
            r.blocked=true;
            r.state=State.BLOCKED;
            r.reason="MISSING_INPUT";
            return finish(r);
        }

        r.evaluated=true;

        if(!candidate.ready){
            r.state=State.NONE;
            r.reason="NO_READY_REINSTATEMENT";
            return finish(r);
        }

        r.transitionKey=safe(candidate.transitionKey);
        r.evidenceId=safe(candidate.evidenceId);
        r.cause=safe(candidate.correctedCause);

        r.identity=
                r.transitionKey
                +"::"
                +r.cause
                +"::"
                +r.evidenceId;

        JSONObject p=CentralTherapyProfile.loadProfile(c);

        JSONArray provenance=
                p.optJSONArray(
                        "transition_correction_commit_provenance_history");

        if(provenance!=null){
            for(int i=0;i<provenance.length();i++){
                JSONObject row=provenance.optJSONObject(i);
                if(row==null)continue;

                String rowTransition=
                        row.optString("transition_key","");
                String rowCause=
                        row.optString("corrected_cause","");
                String rowEvidence=
                        row.optString("user_evidence_id","");

                boolean same=
                        r.transitionKey.equals(rowTransition)
                        &&r.cause.equals(rowCause)
                        &&r.evidenceId.equals(rowEvidence);

                if(!same)continue;

                boolean quarantined=
                        row.optBoolean(
                                "correction_provenance_quarantined",
                                false);

                String state=
                        row.optString(
                                "correction_provenance_integrity_state",
                                "");

                if(!quarantined
                        &&("VALID".equals(state)
                            ||"REPAIRED".equals(state))){
                    r.alreadyActive=true;
                    r.duplicateSuppressed=true;
                    r.state=State.ALREADY_ACTIVE;
                    r.reason="MATCHING_PROVENANCE_ALREADY_ACTIVE";
                    return finish(r);
                }
            }
        }

        JSONArray audit=
                p.optJSONArray(
                        "correction_provenance_reinstatement_audit_history");

        if(audit==null)audit=new JSONArray();

        for(int i=0;i<audit.length();i++){
            JSONObject x=audit.optJSONObject(i);
            if(x==null)continue;

            if(r.identity.equals(
                    x.optString("reinstatement_identity",""))
                    &&"REINSTATED".equals(
                        x.optString("state",""))){

                r.duplicateSuppressed=true;
                r.state=State.DUPLICATE_SUPPRESSED;
                r.reason="REINSTATEMENT_IDENTITY_ALREADY_APPLIED";
                return finish(r);
            }
        }

        r.allow=true;
        r.state=State.ALLOW;
        r.reason="UNIQUE_REINSTATEMENT_IDENTITY";
        return finish(r);
    }

    public static void record(
            Context c,
            Result r,
            int reinstatedRows){

        if(c==null||r==null
                ||(!r.allow && !r.duplicateSuppressed))
            return;

        JSONObject p=CentralTherapyProfile.loadProfile(c);

        JSONArray audit=
                p.optJSONArray(
                        "correction_provenance_reinstatement_audit_history");

        if(audit==null)audit=new JSONArray();

        try{
            JSONObject item=new JSONObject();
            item.put("reinstatement_identity",r.identity);
            item.put("transition_key",r.transitionKey);
            item.put("corrected_cause",r.cause);
            item.put("user_evidence_id",r.evidenceId);
            item.put("state",
                    r.allow && reinstatedRows>0
                        ?"REINSTATED"
                        :r.state.name());
            item.put("reinstated_rows",reinstatedRows);
            item.put("time",System.currentTimeMillis());
            item.put("schema_version","6.9.2");

            audit.put(item);
        }catch(Exception e){
            return;
        }

        JSONArray trimmed=new JSONArray();
        int start=Math.max(0,audit.length()-40);
        for(int i=start;i<audit.length();i++)
            trimmed.put(audit.opt(i));

        try{
            p.put(
                    "correction_provenance_reinstatement_audit_history",
                    trimmed);
            p.put(
                    "last_correction_provenance_reinstatement_identity",
                    r.identity);
            p.put(
                    "last_correction_provenance_reinstatement_idempotency_state",
                    r.state.name());
            p.put(
                    "last_correction_provenance_reinstatement_idempotency_at",
                    System.currentTimeMillis());

            CentralTherapyProfile.replaceProfile(c,p);

        }catch(Exception ignored){}
    }

    public static String instruction(Result r){
        if(r==null||!r.evaluated)return "";

        if(r.state==State.ALREADY_ACTIVE)
            return "CORRECTION_REINSTATEMENT_IDEMPOTENCY=ALREADY_ACTIVE. 동일 provenance가 이미 활성 상태라 다시 복구하지 않는다.";

        if(r.state==State.DUPLICATE_SUPPRESSED)
            return "CORRECTION_REINSTATEMENT_IDEMPOTENCY=DUPLICATE_SUPPRESSED. 동일 reinstatement identity가 이미 적용되어 중복 resurrection을 막는다.";

        if(r.state==State.ALLOW)
            return "CORRECTION_REINSTATEMENT_IDEMPOTENCY=ALLOW. 이번 복구 identity는 아직 적용되지 않은 고유한 reinstatement다.";

        return "";
    }

    private static Result finish(Result r){
        r.summary=r.state.name()
                +" | allow="+r.allow
                +" | duplicate="+r.duplicateSuppressed
                +" | alreadyActive="+r.alreadyActive
                +" | identity="+r.identity
                +" | transition="+r.transitionKey
                +" | cause="+r.cause
                +" | evidenceId="+r.evidenceId
                +" | reason="+r.reason;
        return r;
    }

    private static String safe(String s){
        return s==null?"":s;
    }
}
