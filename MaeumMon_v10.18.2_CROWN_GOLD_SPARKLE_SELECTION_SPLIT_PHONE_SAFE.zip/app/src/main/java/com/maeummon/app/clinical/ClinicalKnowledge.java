package com.maeummon.app.clinical;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public final class ClinicalKnowledge {
    private ClinicalKnowledge() {}

    public static final class Unit {
        public final String id;
        public final String type; // FDU/QDU/IDU/SDU
        public final String title;
        public final List<String> signals;
        public final String target;
        public final String content;
        public final int priority;

        public Unit(String id, String type, String title, int priority, String target, String content, String... signals) {
            this.id=id; this.type=type; this.title=title; this.priority=priority;
            this.target=target==null?"":target; this.content=content==null?"":content;
            this.signals=Arrays.asList(signals);
        }
    }

    public static List<Unit> seeds() {
        List<Unit> x = new ArrayList<>();
        x.add(new Unit("FDU_REL_001","FDU","무응답-거절 해석 루프",8,"",
                "애매한 무응답을 즉시 거절로 확정하면 불안과 확인행동이 강화될 수 있다.","reply_delay","rejection_fear"));
        x.add(new Unit("FDU_REL_002","FDU","실제 관계거리 변화 가능성",7,"",
                "평소와 다른 반복적 행동 변화가 있다면 실제 관계 거리 변화 가설도 유지한다.","reply_delay","social_exclusion"));
        x.add(new Unit("FDU_ANX_001","FDU","회피의 부정적 강화",9,"",
                "회피가 즉각적인 불안 감소를 만들면 장기적으로 회피가 강화될 수 있다.","anxiety","avoidance"));
        x.add(new Unit("FDU_WORK_001","FDU","직장 평가 위협",7,"",
                "특정 업무 피드백을 능력 전체에 대한 평가로 일반화하면 불안과 수치가 커질 수 있다.","work_stress","anxiety"));

        x.add(new Unit("QDU_REL_001","QDU","평소 패턴과 최근 변화 비교",10,"baseline_relationship_change",
                "그 사람이 원래도 개인톡 답장이 늦는 편이었어, 아니면 최근 들어 너한테만 달라진 거야?","reply_delay"));
        x.add(new Unit("QDU_REL_002","QDU","사실과 해석 분리",9,"observable_fact",
                "일단 상대 의도는 빼고, 실제로 확인된 행동만 놓고 보면 무슨 일이 있었어?","reply_delay","social_exclusion"));
        x.add(new Unit("QDU_REL_003","QDU","부여한 의미 확인",8,"meaning_attribution",
                "그 장면이 제일 아팠던 이유가 뭐였어? '나를 무시한다'였어, '나는 별로 중요하지 않다'였어, 아니면 다른 의미였어?","reply_delay","social_exclusion","rejection_fear"));
        x.add(new Unit("QDU_WORK_001","QDU","추상적 호소를 구체적 장면으로",10,"recent_specific_episode",
                "회사생활 전체를 설명하려고 하지 말고, 오늘이나 어제 제일 기분이 확 상했던 장면 하나만 골라보자. 무슨 일이 있었어?","work_stress"));
        x.add(new Unit("QDU_WORK_002","QDU","업무와 관계 스트레스 분리",9,"workload_vs_relationship",
                "지금 힘든 건 일의 양 자체가 더 커, 아니면 사람 때문에 긴장하는 게 더 커?","work_stress"));
        x.add(new Unit("QDU_ANX_001","QDU","회피 후 단기 안도 확인",9,"short_term_relief",
                "그 상황을 피하고 나면 당장은 마음이 좀 편해져?","anxiety","avoidance"));
        x.add(new Unit("QDU_EMO_001","QDU","핵심 감정 구분",6,"emotion_differentiation",
                "그때 제일 큰 감정 하나만 고르면 화, 불안, 서운함 중 뭐에 가장 가까웠어?","anger","anxiety","sadness"));

        x.add(new Unit("IDU_REL_001","IDU","대안가설 생성",6,"",
                "현재 설명 하나를 사실로 확정하지 말고 최소 2~3개의 현실적인 대안가설을 비교한다.","reply_delay","social_exclusion"));
        x.add(new Unit("IDU_REL_002","IDU","불확실성 견디기",6,"",
                "확인행동 전에 짧은 유예를 두고 애매함을 견디는 작은 행동을 설계한다.","rejection_fear","anxiety"));
        x.add(new Unit("IDU_WORK_001","IDU","구체적 피드백으로 재구성",6,"",
                "평가를 인격/능력 전체가 아니라 수정 가능한 특정 행동 피드백으로 분리한다.","work_stress"));
        x.add(new Unit("IDU_ANX_001","IDU","점진적 접근",6,"",
                "회피가 유지요인으로 확인되고 안전상 문제가 없을 때 작은 단계의 접근 행동을 설계한다.","anxiety","avoidance"));

        x.add(new Unit("SDU_SAFE_001","SDU","자해/자살 위험",100,"","일반 상담보다 즉시 안전평가와 안정화가 우선한다.","self_harm"));
        x.add(new Unit("SDU_SAFE_002","SDU","정신증 의심",100,"","현실검증 저하가 의심되면 일반 관계 분석보다 안전과 전문평가 연결을 우선한다.","psychosis"));
        x.add(new Unit("SDU_SAFE_003","SDU","조증 의심",100,"","현저한 수면감소와 과도한 활성 신호가 있으면 일반 상담보다 안전/의료평가 고려가 우선한다.","mania"));
        return x;
    }
}
