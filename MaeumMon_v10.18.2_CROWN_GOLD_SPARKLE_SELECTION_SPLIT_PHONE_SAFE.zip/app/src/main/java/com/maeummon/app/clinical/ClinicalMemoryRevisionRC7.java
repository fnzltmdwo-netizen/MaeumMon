package com.maeummon.app.clinical;

import android.content.*;
import org.json.*;
import java.util.*;

public final class ClinicalMemoryRevisionRC7 {
    private ClinicalMemoryRevisionRC7(){}

    public static final class Result {
        public final int revised;
        public final int weakened;
        public final int deleted;
        public final List<String> notes;
        Result(int revised,int weakened,int deleted,List<String> notes){
            this.revised=revised; this.weakened=weakened; this.deleted=deleted;
            this.notes=notes==null?new ArrayList<>():notes;
        }
    }

    public static Result apply(Context c,String userText){
        if(c==null)return new Result(0,0,0,new ArrayList<>());
        String t=safe(userText).trim();
        ClinicalMemoryConsolidatorRC7.Snapshot snap=ClinicalMemoryConsolidatorRC7.load(c);
        List<JSONObject> stable=toList(snap.stableProfile);
        List<JSONObject> session=toList(snap.sessionSummary);

        int revised=0,weakened=0,deleted=0;
        List<String> notes=new ArrayList<>();

        // Explicit self-correction markers carry highest priority.
        boolean correction=containsAny(t,
                "아까 내가 잘못 말","내가 잘못 말했","정정할게","다시 생각해보니",
                "생각해보니까","사실은","그건 아니야","그건 아닌 것 같아");

        // Conflict-status contradiction.
        if(containsAny(t,"싸운 적 있었","다툰 적 있었","갈등이 있었","사실 싸웠")){
            int n=removeByKeyAndText(session,"recent_conflict",
                    "갈등이 없","싸운 일은 없어","다툰 건 없어");
            deleted+=n;
            if(n>0)notes.add("recent_conflict: no-conflict memory removed");
            try{
                session.add(0,memory("recent_conflict","최근 갈등/다툼이 있었다고 사용자가 정정함",0.96,"SESSION"));
                revised++;
            }catch(Exception ignored){}
        }else if(containsAny(t,"싸운 일은 없어","갈등은 없어","다툰 건 없어")){
            int n=removeByKeyAndText(session,"recent_conflict",
                    "갈등/다툼이 있었다","갈등이 있었");
            deleted+=n;
            if(n>0)notes.add("recent_conflict: conflict memory removed");
        }

        // Baseline revision.
        if(correction && containsAny(t,"원래 느린 건 아니","원래 그런 건 아니","최근부터 느려","최근에 달라")){
            int n=removeByKey(stable,"relationship_pattern");
            weakened+=n;
            if(n>0)notes.add("relationship_pattern weakened after baseline correction");
        }

        // Generalization retraction.
        if(containsAny(t,
                "항상 그런 건 아니","매번 그런 건 아니","자주 그런 건 아니",
                "여러 관계에서 그런 건 아니","이번만 그런 것 같아")){
            for(JSONObject o:stable){
                String key=o.optString("key","");
                if(key.endsWith("_pattern")){
                    double old=o.optDouble("confidence",0.75);
                    try{o.put("confidence",Math.max(0.45,old-0.25));}catch(Exception ignored){}
                    weakened++;
                }
            }
            removeLowConfidence(stable,0.70);
            notes.add("stable patterns weakened after generalization retraction");
        }

        // Response-need revision should replace current session preference, not accumulate.
        if(containsAny(t,"아니 해결책이 필요해","방법을 알고 싶어","구체적으로 뭘 해야")){
            deleted+=removeByKey(session,"response_need");
            try{
                session.add(0,memory("response_need","현재는 구체적인 방법/행동을 원함",0.94,"SESSION"));
                revised++;
            }catch(Exception ignored){}
        }else if(containsAny(t,"아니 해결책 말고","조언 말고","그냥 이해받고 싶")){
            deleted+=removeByKey(session,"response_need");
            try{
                session.add(0,memory("response_need","현재는 해결보다 이해/공감을 우선 원함",0.94,"SESSION"));
                revised++;
            }catch(Exception ignored){}
        }

        // Explicit "that's not my pattern" removes matching tentative stable patterns.
        if(containsAny(t,"내 패턴은 아닌 것 같","그런 경향은 없어","그건 나랑 안 맞아")){
            int before=stable.size();
            Iterator<JSONObject> it=stable.iterator();
            while(it.hasNext()){
                JSONObject o=it.next();
                if(o.optString("key","").endsWith("_pattern"))it.remove();
            }
            int n=before-stable.size();
            deleted+=n;
            if(n>0)notes.add("stable patterns removed by explicit user rejection");
        }

        ClinicalMemoryConsolidatorRC7.replaceSnapshot(c,stable,session);
        return new Result(revised,weakened,deleted,notes);
    }

    private static JSONObject memory(String key,String text,double confidence,String scope)throws Exception{
        JSONObject o=new JSONObject();
        o.put("key",key);
        o.put("text",text);
        o.put("confidence",confidence);
        o.put("scope",scope);
        o.put("updated_at",System.currentTimeMillis());
        return o;
    }

    private static int removeByKey(List<JSONObject> xs,String key){
        int n=0;
        Iterator<JSONObject> it=xs.iterator();
        while(it.hasNext()){
            JSONObject o=it.next();
            if(key.equals(o.optString("key",""))){it.remove();n++;}
        }
        return n;
    }

    private static int removeByKeyAndText(List<JSONObject> xs,String key,String... snippets){
        int n=0;
        Iterator<JSONObject> it=xs.iterator();
        while(it.hasNext()){
            JSONObject o=it.next();
            if(!key.equals(o.optString("key","")))continue;
            String tx=o.optString("text","");
            for(String s:snippets){
                if(tx.contains(s)){it.remove();n++;break;}
            }
        }
        return n;
    }

    private static void removeLowConfidence(List<JSONObject> xs,double min){
        Iterator<JSONObject> it=xs.iterator();
        while(it.hasNext()){
            if(it.next().optDouble("confidence",0)<min)it.remove();
        }
    }

    private static List<JSONObject> toList(JSONArray a){
        List<JSONObject> out=new ArrayList<>();
        for(int i=0;i<a.length();i++){
            JSONObject o=a.optJSONObject(i);
            if(o!=null)out.add(o);
        }
        return out;
    }

    private static boolean containsAny(String s,String... xs){
        for(String x:xs)if(s.contains(x))return true;
        return false;
    }
    private static String safe(String s){return s==null?"":s;}
}
