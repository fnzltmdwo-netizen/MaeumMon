package com.maeummon.app.clinical;

import android.content.Context;
import org.json.*;
import java.util.*;

public final class InterventionLearningPolicyMemoryRC11 {
    private InterventionLearningPolicyMemoryRC11(){}

    public enum Confidence {
        NONE, LOW, MEDIUM, HIGH
    }

    public static final class Result {
        public boolean updated=false;
        public String mechanism="";
        public String interventionId="";
        public String preferredMode="";
        public String preferredDose="";
        public Confidence confidence=Confidence.NONE;
        public int positiveCommits=0;
        public int negativeCommits=0;
        public int totalRelevantCommits=0;
        public boolean contextBounded=true;
        public String contextScope="";
        public String recommendation="";
        public String summary="";
    }

    public static Result consolidate(Context c,ClinicalDecisionRC7 d){
        Result r=new Result();
        if(c==null||d==null){
            r.summary="NO_UPDATE | NO_CONTEXT_OR_DECISION";
            return r;
        }

        if(!"COMMIT".equals(d.outcomeCommitState)){
            r.summary="NO_UPDATE | NO_COMMITTED_OUTCOME";
            return r;
        }

        String outcome=safe(d.outcomeCommitValue);
        if("UNKNOWN".equals(outcome)||outcome.isEmpty()){
            r.summary="NO_UPDATE | UNKNOWN_OUTCOME";
            return r;
        }

        JSONObject p=CentralTherapyProfile.loadProfile(c);
        JSONObject f=CentralTherapyProfile.loadFormulation(c);

        String mechanism=safe(d.centralMechanism);
        String intervention=safe(d.selectedInterventionId);
        String mode=safe(d.interventionPreferenceMode);
        String dose=safe(d.interventionDose);
        String context=f.optString("current_context_scope","UNKNOWN");

        r.mechanism=mechanism;
        r.interventionId=intervention;
        r.preferredMode=mode;
        r.preferredDose=dose;
        r.contextScope=context;

        JSONArray commitHistory=p.optJSONArray("micro_experiment_outcome_commit_history");
        if(commitHistory==null){
            r.summary="NO_UPDATE | NO_COMMIT_HISTORY";
            return r;
        }

        int positive=0;
        int negative=0;
        int relevant=0;
        int modePositive=0;
        int dosePositive=0;

        for(int i=Math.max(0,commitHistory.length()-20); i<commitHistory.length(); i++){
            JSONObject item=commitHistory.optJSONObject(i);
            if(item==null)continue;
            if(!ProvenanceIntegrityValidationBackfillGateRC12
                    .rowEligibleForLearning(item))
                continue;
            if(!"COMMIT".equals(item.optString("commit_state","")))continue;

            String itemOutcome=item.optString("outcome","UNKNOWN");

            if(!StructuredOutcomeProvenanceCanonicalIdentityRC12
                    .exactLearningMatch(
                            item,
                            mechanism,
                            intervention,
                            context))
                continue;

            relevant++;

            if("HELPED".equals(itemOutcome)||"PARTIAL".equals(itemOutcome)){
                positive++;

                String itemMode=item.optString("mode","");
                String itemDose=item.optString("dose","");
                String expId=item.optString("experiment_id","");

                if(!mode.isEmpty()){
                    if(!itemMode.isEmpty()){
                        if(mode.equals(itemMode))modePositive++;
                    }else if(expId.contains(mode)){
                        modePositive++; // legacy-only fallback
                    }
                }

                if(!dose.isEmpty()){
                    if(!itemDose.isEmpty()){
                        if(dose.equals(itemDose))dosePositive++;
                    }else if(expId.contains(dose)){
                        dosePositive++; // legacy-only fallback
                    }
                }
            }else if("NO_CHANGE".equals(itemOutcome)||"WORSE".equals(itemOutcome)){
                negative++;
            }
        }

        r.positiveCommits=positive;
        r.negativeCommits=negative;
        r.totalRelevantCommits=relevant;

        // Conservative promotion thresholds.
        if(relevant<2){
            r.confidence=Confidence.LOW;
        }else if(positive>=3 && negative==0){
            r.confidence=Confidence.HIGH;
        }else if(positive>=2 && positive>negative){
            r.confidence=Confidence.MEDIUM;
        }else{
            r.confidence=Confidence.LOW;
        }

        r.contextBounded=true;

        r.recommendation=buildRecommendation(
                r.confidence,positive,negative,mode,dose);

        persist(c,p,r,modePositive,dosePositive);
        r.updated=true;
        r.summary="UPDATED | mechanism="+mechanism
                +" | intervention="+intervention
                +" | positive="+positive
                +" | negative="+negative
                +" | confidence="+r.confidence.name()
                +" | context="+context;
        return r;
    }

    public static String instruction(Result r){
        if(r==null||!r.updated)return "";

        if(r.confidence==Confidence.HIGH){
            return "INTERVENTION_POLICY_MEMORY=HIGH. 같은 context와 mechanism에서 이전에 반복적으로 도움이 확인된 intervention delivery를 우선 후보로 고려하되, 현재 evidence가 다르면 새 판단을 우선한다.";
        }

        if(r.confidence==Confidence.MEDIUM){
            return "INTERVENTION_POLICY_MEMORY=MEDIUM. 과거 긍정 반응을 약한 선호 신호로만 사용하고 현재 formulation/bridge를 덮어쓰지 않는다.";
        }

        return "INTERVENTION_POLICY_MEMORY=LOW. 기록은 유지하지만 intervention 선택을 바꾸는 근거로 직접 사용하지 않는다.";
    }

    private static String buildRecommendation(
            Confidence c,int pos,int neg,String mode,String dose){

        if(c==Confidence.HIGH)
            return "same mechanism/context에서 현재 intervention을 우선 후보로 두고, mode="+mode+", dose="+dose+"를 참고한다.";

        if(c==Confidence.MEDIUM)
            return "현재 intervention을 약한 우선 후보로 두되 다른 evidence와 함께 판단한다.";

        return "학습 신호가 아직 약하므로 현재 formulation 기반 선택을 유지한다.";
    }

    private static void persist(
            Context c,JSONObject p,Result r,
            int modePositive,int dosePositive){

        try{
            JSONArray policies=p.optJSONArray("intervention_policy_memory");
            if(policies==null)policies=new JSONArray();

            String key=policyKey(
                    r.mechanism,r.interventionId,r.contextScope);

            JSONObject existing=null;
            int existingIndex=-1;

            for(int i=0;i<policies.length();i++){
                JSONObject x=policies.optJSONObject(i);
                if(x!=null&&key.equals(x.optString("key",""))){
                    existing=x;
                    existingIndex=i;
                    break;
                }
            }

            JSONObject item=existing==null?new JSONObject():existing;
            item.put("key",key);
            item.put("mechanism",r.mechanism);
            item.put("intervention_id",r.interventionId);
            item.put("context_scope",r.contextScope);
            item.put("context_bounded",true);
            item.put("positive_commits",r.positiveCommits);
            item.put("negative_commits",r.negativeCommits);
            item.put("total_relevant_commits",r.totalRelevantCommits);
            item.put("confidence",r.confidence.name());
            item.put("preferred_mode",
                    modePositive>=2?r.preferredMode:"");
            item.put("preferred_dose",
                    dosePositive>=2?r.preferredDose:"");
            item.put("recommendation",r.recommendation);
            item.put("updated_at",System.currentTimeMillis());

            if(existingIndex<0)policies.put(item);

            JSONArray trimmed=new JSONArray();
            int start=Math.max(0,policies.length()-24);
            for(int i=start;i<policies.length();i++)
                trimmed.put(policies.opt(i));

            p.put("intervention_policy_memory",trimmed);
            p.put("last_intervention_policy_key",key);
            p.put("last_intervention_policy_confidence",
                    r.confidence.name());
            p.put("intervention_policy_memory_updated_at",
                    System.currentTimeMillis());

            CentralTherapyProfile.replaceProfile(c,p);
        }catch(Exception ignored){}
    }

    public static JSONObject findApplicablePolicy(
            Context c,String mechanism,String context){

        JSONObject p=CentralTherapyProfile.loadProfile(c);
        JSONArray a=p.optJSONArray("intervention_policy_memory");
        if(a==null)return null;

        JSONObject best=null;
        int bestRank=-1;

        for(int i=0;i<a.length();i++){
            JSONObject x=a.optJSONObject(i);
            if(x==null)continue;

            if(!safe(mechanism).equals(
                    x.optString("mechanism","")))
                continue;

            String cx=x.optString("context_scope","UNKNOWN");
            if(!"GENERAL".equals(cx)
                    && !safe(context).equals(cx))
                continue;

            if("GENERAL".equals(cx)
                    && !GeneralPolicyExceptionBoundaryRC11.generalPolicyAllowedInContext(
                            x,safe(context)))
                continue;

            if(!PolicyMemoryDecayContradictionDemotionRC11.isPolicyUsable(x))
                continue;

            String conf=x.optString("confidence","LOW");
            int rank="HIGH".equals(conf)?3:
                    "MEDIUM".equals(conf)?2:0;

            if(rank>bestRank){
                best=x;
                bestRank=rank;
            }
        }

        return best;
    }

    private static String policyKey(
            String mechanism,String intervention,String context){
        return safe(mechanism)+"__"
                +safe(intervention)+"__"
                +safe(context);
    }

    private static String safe(String s){
        return s==null?"":s;
    }
}
