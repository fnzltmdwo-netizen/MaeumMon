package com.maeummon.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MindPtActivity extends Activity {
    private static final int REQ_IMPORT = 301;

    private EditText concernInput;
    private View resultCard;
    private View latestCounselingCard;
    private TextView latestCounselingTitle, latestCounselingSummary, programChoicesTitle;
    private View programChoicesSection;
    private LinearLayout programChoicesContainer;
    private TextView modeText, muscleText, exerciseText, criterionText, rationaleText, roadmapText, roadmapLabel, resultStatusText, ptSelectionNotice;
    private MindTrainingStore store;
    private TrainingRecommendationEngine engine;
    private long currentTrainingId = -1;
    private long selectedProgramId = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mind_pt);
        UiInsets.apply(this, findViewById(R.id.mindPtRoot));

        store = new MindTrainingStore(this);
        engine = new TrainingRecommendationEngine(this);

        concernInput = findViewById(R.id.concernInput);
        resultCard = findViewById(R.id.trainingResultCard);
        latestCounselingCard = findViewById(R.id.latestCounselingCard);
        latestCounselingTitle = findViewById(R.id.latestCounselingTitle);
        latestCounselingSummary = findViewById(R.id.latestCounselingSummary);
        programChoicesSection = findViewById(R.id.programChoicesSection);
        programChoicesContainer = findViewById(R.id.programChoicesContainer);
        programChoicesTitle = findViewById(R.id.programChoicesTitle);
        modeText = findViewById(R.id.modeText);
        muscleText = findViewById(R.id.muscleText);
        exerciseText = findViewById(R.id.exerciseText);
        criterionText = findViewById(R.id.criterionText);
        rationaleText = findViewById(R.id.rationaleText);
        roadmapText = findViewById(R.id.roadmapText);
        roadmapLabel = findViewById(R.id.roadmapLabel);
        resultStatusText = findViewById(R.id.resultStatusText);
        ptSelectionNotice = findViewById(R.id.ptSelectionNotice);

        findViewById(R.id.importCounselingButton).setOnClickListener(v -> openSharedLink(null));
        findViewById(R.id.openBookshelfButton).setOnClickListener(v -> startActivity(new Intent(this, CounselingBookshelfActivity.class)));
        findViewById(R.id.openGrowthButton).setOnClickListener(v -> startActivity(new Intent(this, V10GrowthActivity.class)));
        findViewById(R.id.openMyRoomButton).setOnClickListener(v -> startActivity(new Intent(this, V10MyRoomActivity.class)));
        findViewById(R.id.findTrainingButton).setOnClickListener(v -> createTraining());
        findViewById(R.id.outcomeHelped).setOnClickListener(v -> confirmHelpedOutcome());
        findViewById(R.id.outcomePartial).setOnClickListener(v -> saveOutcome("PARTIAL", "PARTIAL", "조금 했어"));
        findViewById(R.id.outcomeNoChange).setOnClickListener(v -> saveOutcome("NOT_COMPLETED", "NO_CHANGE", "못했어"));
        findViewById(R.id.outcomeWorse).setOnClickListener(v -> saveOutcome("PARTIAL", "WORSE", "더 힘들어졌어"));
        findViewById(R.id.outcomeNoOpportunity).setOnClickListener(v -> saveOutcome("NOT_COMPLETED", "NO_OPPORTUNITY", "연습할 상황이 없었어"));

        handleIncomingShare(getIntent());
        restoreActiveTraining();
        refreshLatestCounseling();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleIncomingShare(intent);
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshLatestCounseling();
    }

    private void handleIncomingShare(Intent intent) {
        if (intent == null) return;
        String action = intent.getAction();
        String type = intent.getType();
        if (Intent.ACTION_SEND.equals(action) && type != null && type.startsWith("text/")) {
            String shared = intent.getStringExtra(Intent.EXTRA_TEXT);
            if (shared != null && !shared.trim().isEmpty()) {
                if (shared.contains("https://chatgpt.com/share/")) openSharedLink(shared.trim());
                else openImport(shared.trim());
            }
        }
    }


    private void openSharedLink(String sharedText) {
        Intent i = new Intent(this, SharedCounselingLinkActivity.class);
        if (sharedText != null) i.putExtra(Intent.EXTRA_TEXT, sharedText);
        startActivityForResult(i, REQ_IMPORT);
    }

    private void openImport(String sharedText) {
        Intent i = new Intent(this, CounselingImportActivity.class);
        if (sharedText != null) i.putExtra(Intent.EXTRA_TEXT, sharedText);
        startActivityForResult(i, REQ_IMPORT);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_IMPORT && resultCode == RESULT_OK) {
            restoreActiveTraining();
            refreshLatestCounseling();
            Toast.makeText(this, "최근 상담을 여러 마음 PT로 나눠서 연결했어.", Toast.LENGTH_SHORT).show();
        }
    }

    private void refreshLatestCounseling() {
        MindTrainingStore.CounselingEntry e = store.latestCounseling();
        if (e == null) {
            latestCounselingCard.setVisibility(View.GONE);
            return;
        }
        latestCounselingCard.setVisibility(View.VISIBLE);
        latestCounselingTitle.setText("🧠 최근 상담에서 이어서");
        String primary = !e.muscleName.isEmpty() ? e.muscleName : (!e.priorityDirection.isEmpty() ? e.priorityDirection : e.title);
        java.util.List<MindTrainingStore.ProgramSummary> programs = store.programsForCounseling(e.id);
        if (programs == null || programs.isEmpty()) {
            latestCounselingSummary.setText(primary);
            return;
        }
        long crownProgramId = store.crownProgramId(e.id);
        MindTrainingStore.ProgramSummary crownProgram = programs.get(0);
        for (MindTrainingStore.ProgramSummary p : programs) if (p.id == crownProgramId) { crownProgram = p; break; }
        StringBuilder summary = new StringBuilder();
        summary.append("✨👑 최우선 PT · ").append(crownProgram.muscleName);
        summary.append("\n💪 이번 상담에서 마음 PT ").append(programs.size()).append("개가 준비됐어.");
        latestCounselingSummary.setText(summary.toString());
        renderProgramChoices(programs);
    }

    private void renderProgramChoices(java.util.List<MindTrainingStore.ProgramSummary> programs) {
        if (programChoicesSection == null || programChoicesContainer == null) return;
        programChoicesContainer.removeAllViews();
        if (programs == null || programs.isEmpty()) {
            programChoicesSection.setVisibility(View.GONE);
            return;
        }
        programChoicesSection.setVisibility(View.VISIBLE);
        programChoicesTitle.setText("전체 상담에서 이어진 마음 PT " + programs.size() + "개");
        long counselingId = programs.get(0).counselingId;
        long crownProgramId = store.crownProgramId(counselingId);
        for (int i = 0; i < programs.size(); i++) {
            final MindTrainingStore.ProgramSummary p = programs.get(i);
            TextView card = new TextView(this);
            card.setBackgroundResource(R.drawable.bg_input);
            int pad = dp(14);
            card.setPadding(pad, pad, pad, pad);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            if (i > 0) lp.topMargin = dp(8);
            card.setLayoutParams(lp);
            boolean selected = p.id == selectedProgramId;
            boolean crownPriority = p.id == crownProgramId;
            String badge;
            if (crownPriority && selected) badge = "✨ 👑 최우선 PT 👑 ✨  ·  ✅ 지금 선택됨";
            else if (crownPriority) badge = "✨ 👑 최우선 PT 👑 ✨";
            else if (selected) badge = "✅ 지금 선택됨";
            else badge = "🌱 마음 PT";
            String state = "DONE".equals(p.status) ? " · 완료" : "";
            String reason = friendlyReason(p.reason);
            int currentStep = p.stepCount <= 0 ? 0 : Math.min(p.stepCount, p.doneSteps + 1);
            StringBuilder text = new StringBuilder();
            text.append(badge).append(state).append("\n");
            text.append(p.muscleName).append("\n\n");
            if (p.stepCount > 0) text.append("🌱 현재 단계  ").append(currentStep).append("/").append(p.stepCount).append("단계");
            else text.append("🌱 현재 단계  준비 중");
            if (!reason.isEmpty()) {
                text.append("\n\n🧩 왜 이 PT가 생겼어?\n").append(reason);
            }
            String outcomeSummary = store.programOutcomeDisplay(p.id);
            if (!outcomeSummary.isEmpty()) {
                text.append("\n\n📈 지금까지 해본 결과\n").append(outcomeSummary);
            }
            text.append(selected ? "\n\n✅ 지금 아래에서 이 PT를 연습 중이야" : "\n\n👇 눌러서 이 PT의 자세한 훈련을 보기");
            card.setText(text.toString());
            if (crownPriority && selected) card.setBackgroundResource(R.drawable.bg_pt_crown_selected);
            else if (selected) card.setBackgroundResource(R.drawable.bg_button);
            else if (crownPriority) card.setBackgroundResource(R.drawable.bg_pt_crown);
            else card.setBackgroundResource(R.drawable.bg_input);
            card.setTextColor(getResources().getColor(selected ? R.color.white : R.color.brown));
            if (crownPriority) {
                card.setElevation(dp(5));
            } else {
                card.setElevation(0f);
            }
            card.setTextSize(15);
            card.setOnClickListener(v -> selectProgram(p));
            programChoicesContainer.addView(card);
            if (crownPriority) startCrownSparkle(card);
        }
    }

    private void startCrownSparkle(View crownCard) {
        if (crownCard == null) return;
        android.view.animation.AnimationSet set = new android.view.animation.AnimationSet(true);
        android.view.animation.AlphaAnimation glow =
                new android.view.animation.AlphaAnimation(0.94f, 1.0f);
        glow.setDuration(900L);
        glow.setRepeatMode(android.view.animation.Animation.REVERSE);
        glow.setRepeatCount(android.view.animation.Animation.INFINITE);
        android.view.animation.ScaleAnimation pulse = new android.view.animation.ScaleAnimation(
                1.0f, 1.012f, 1.0f, 1.012f,
                android.view.animation.Animation.RELATIVE_TO_SELF, 0.5f,
                android.view.animation.Animation.RELATIVE_TO_SELF, 0.5f);
        pulse.setDuration(900L);
        pulse.setRepeatMode(android.view.animation.Animation.REVERSE);
        pulse.setRepeatCount(android.view.animation.Animation.INFINITE);
        set.addAnimation(glow);
        set.addAnimation(pulse);
        set.setInterpolator(new android.view.animation.AccelerateDecelerateInterpolator());
        crownCard.startAnimation(set);
    }

    private void selectProgram(MindTrainingStore.ProgramSummary p) {
        long trainingId = store.activateProgramStep(p.id, true);
        if (trainingId <= 0) {
            Toast.makeText(this, "이 마음 PT는 지금 시작할 단계가 없어.", Toast.LENGTH_SHORT).show();
            refreshLatestCounseling();
            return;
        }
        currentTrainingId = trainingId;
        selectedProgramId = p.id;
        restoreActiveTraining();
        refreshLatestCounseling();
        MaeumMonClockWidget.refreshAll(this);
        showPtSelectionNotice();
    }

    private void showPtSelectionNotice() {
        if (ptSelectionNotice == null) return;
        ptSelectionNotice.setText("✅ 연습할 PT만 바뀌었어. 지금까지의 단계와 기록은 그대로야.");
        ptSelectionNotice.setVisibility(View.VISIBLE);
        ptSelectionNotice.animate().cancel();
        ptSelectionNotice.setAlpha(1f);
        ptSelectionNotice.postDelayed(() -> {
            if (ptSelectionNotice == null || isFinishing()) return;
            ptSelectionNotice.animate()
                    .alpha(0f)
                    .setDuration(220L)
                    .withEndAction(() -> {
                        ptSelectionNotice.setVisibility(View.GONE);
                        ptSelectionNotice.setAlpha(1f);
                    })
                    .start();
        }, 2400L);
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private String friendlyReason(String reason) {
        if (reason == null) return "";
        String r = reason.trim();
        if (r.isEmpty()) return "";
        // v10.17.0: 사용자는 PT가 왜 생겼는지 긴 근거를 읽는 편을 선호한다.
        // 카드에서도 상담 근거를 임의로 잘라내지 않고 저장된 설명을 그대로 보여준다.
        return r;
    }

    private void restoreActiveTraining() {
        CentralMindPtState.Snapshot s = CentralMindPtState.current(this);
        if (!s.active) return;
        currentTrainingId = s.trainingId;
        selectedProgramId = store.programIdForTraining(currentTrainingId);
        modeText.setText(modeLabel(s.mode, s.exercise));
        muscleText.setText(s.muscle);
        exerciseText.setText(s.exercise);
        criterionText.setText(s.criterion);
        rationaleText.setText(friendlyRationale(s.rationale));
        bindRoadmap(selectedProgramId);
        resultStatusText.setText("진행 중인 마음 PT야. 해본 뒤 결과를 눌러줘.");
        resultCard.setVisibility(View.VISIBLE);
    }

    private void createTraining() {
        String text = concernInput.getText().toString().trim();
        MindTrainingStore.CounselingEntry latest = store.latestCounseling();
        if (text.isEmpty() && latest == null) {
            Toast.makeText(this, "지금 마음에 걸리는 걸 한 문장만 적거나, 상담 완전판 내용을 먼저 가져와줘.", Toast.LENGTH_SHORT).show();
            return;
        }

        TrainingRecommendationEngine.Recommendation r = engine.recommend(text, latest);
        String concernForLog = text.isEmpty() ? "[최근 상담에서 이어서] " + latest.title : text;
        long concernId = store.saveConcern(concernForLog, r.mode);
        long muscleId = store.getOrCreateMuscle(r.muscleName, r.mechanism);
        currentTrainingId = store.saveTraining(concernId, muscleId, r);

        modeText.setText(modeLabel(r.mode, r.exerciseText));
        muscleText.setText(r.muscleName);
        exerciseText.setText(r.exerciseText);
        criterionText.setText(r.successCriterion);
        rationaleText.setText(friendlyRationale(r.rationale));
        if (roadmapText != null) roadmapText.setText("이 훈련은 최근 상담에서 바로 만든 단일 연습이야. 상담 완전판에서 이어진 PT를 선택하면 1→2→3단계 전체 길을 함께 보여줄게.");
        if (roadmapLabel != null) roadmapLabel.setVisibility(View.VISIBLE);
        resultStatusText.setText("훈련을 해본 뒤 아래에서 결과만 눌러줘.");
        resultCard.setVisibility(View.VISIBLE);
        MaeumMonClockWidget.refreshAll(this);
    }


    private void bindRoadmap(long programId) {
        if (roadmapText == null || roadmapLabel == null) return;
        if (programId <= 0) {
            roadmapLabel.setVisibility(View.GONE);
            roadmapText.setVisibility(View.GONE);
            return;
        }
        String roadmap = store.programRoadmap(programId);
        if (roadmap == null || roadmap.trim().isEmpty()) {
            roadmapLabel.setVisibility(View.GONE);
            roadmapText.setVisibility(View.GONE);
            return;
        }
        roadmapLabel.setVisibility(View.VISIBLE);
        roadmapText.setVisibility(View.VISIBLE);
        roadmapText.setText(roadmap);
    }

    private String modeLabel(String mode, String exercise) {
        String e = exercise == null ? "" : exercise;
        boolean realRecovery = e.contains("쉬") || e.contains("휴식") || e.contains("회복") || e.contains("자극에서 떨어") || e.contains("안정");
        if ("RECOVERY".equals(mode) && realRecovery) return "🌙 오늘은 회복 PT";
        if ("STABILIZE".equals(mode) && realRecovery) return "🫧 오늘은 안정 PT";
        if ("REVIEW".equals(mode)) return "🔎 오늘은 복기 PT";
        if ("MAINTENANCE".equals(mode)) return "🌳 오늘은 유지 PT";
        return "🏋️ 오늘의 마음 PT";
    }

    private String friendlyRationale(String rationale) {
        if (rationale == null || rationale.trim().isEmpty()) {
            return "이번 상담에서 이 부분을 연습해보면 도움이 될 것 같아서 골랐어.";
        }
        String r = rationale.trim();
        if (r.contains("최근 상담 완전판") || r.contains("최우선 근거") || r.contains("정리된 방향을 오늘 훈련")) {
            return "이번 상담에서 이 부분이 중요하게 보여서, 오늘 작은 연습으로 이어가보는 거야.";
        }
        return r;
    }

    private void confirmHelpedOutcome() {
        if (currentTrainingId < 0) {
            Toast.makeText(this, "먼저 연습할 마음 PT를 골라줘.", Toast.LENGTH_SHORT).show();
            return;
        }
        new AlertDialog.Builder(this)
                .setTitle("이 단계를 완료할까?")
                .setMessage("'해냈어'로 기록하면 성공 기준을 충족한 것으로 보고 다음 단계로 넘어갈 수 있어.\n\n카드를 눌러 PT를 바꾸는 것만으로는 단계가 올라가지 않아.")
                .setNegativeButton("아직이야", null)
                .setPositiveButton("완료로 기록", (d, w) -> saveOutcome("COMPLETED", "HELPED", "해냈어"))
                .show();
    }

    private void saveOutcome(String attempt, String effect, String label) {
        if (currentTrainingId < 0) {
            Toast.makeText(this, "먼저 오늘의 훈련을 만들어줘.", Toast.LENGTH_SHORT).show();
            return;
        }
        long finishedTrainingId = currentTrainingId;
        store.saveOutcome(finishedTrainingId, attempt, effect, "");
        long nextTrainingId = store.advanceProgramAfterOutcome(finishedTrainingId, effect);
        if ("HELPED".equals(effect)) {
            resultStatusText.setText(nextTrainingId > 0
                    ? "🐣 " + label + " — 성공 기준을 충족했어. 이제 같은 마음근육의 다음 단계로 올라갈게."
                    : "🐣 " + label + " — 이 PT의 현재 프로그램을 끝냈어. 다음 상담 근거와 결과를 보고 다음 훈련을 정할게.");
        } else if ("PARTIAL".equals(effect)) {
            resultStatusText.setText("🐣 " + label + " — 단계는 올리지 않았어. 이미 된 부분을 살리고, 같은 핵심을 더 작은 행동 하나로 다시 준비했어.");
        } else if ("NO_CHANGE".equals(effect)) {
            resultStatusText.setText("🐣 " + label + " — 실패로 세지 않았어. 지금 크기가 어려웠던 걸로 보고, 같은 목표를 더 작고 쉬운 행동으로 낮췄어.");
        } else if ("WORSE".equals(effect)) {
            resultStatusText.setText("🐣 " + label + " — 이 방법은 지금 강도가 높았어. 같은 훈련을 밀어붙이지 않고 먼저 안정화하는 단계로 낮췄어.");
        } else if ("NO_OPPORTUNITY".equals(effect)) {
            resultStatusText.setText("🐣 " + label + " — 연습 기회가 없었던 거라 실패가 아니야. 단계와 난이도는 그대로 두고 다음 비슷한 상황을 기다릴게.");
        } else {
            resultStatusText.setText("🐣 " + label + " — 기록했어. 다음 선택에 반영할게.");
        }
        Toast.makeText(this, "기록했어", Toast.LENGTH_SHORT).show();
        MaeumMonClockWidget.refreshAll(this);
        currentTrainingId = nextTrainingId;
        if (nextTrainingId > 0) restoreActiveTraining();
        refreshLatestCounseling();
    }
}
