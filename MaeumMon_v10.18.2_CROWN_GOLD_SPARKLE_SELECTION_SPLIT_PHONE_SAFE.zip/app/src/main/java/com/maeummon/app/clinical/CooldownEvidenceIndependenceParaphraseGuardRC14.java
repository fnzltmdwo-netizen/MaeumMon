package com.maeummon.app.clinical;

import android.content.Context;
import org.json.*;
import java.util.*;

public final class CooldownEvidenceIndependenceParaphraseGuardRC14 {
    private CooldownEvidenceIndependenceParaphraseGuardRC14(){}

    public enum State {
        NONE,
        INDEPENDENT,
        EXACT_DUPLICATE,
        NEAR_DUPLICATE,
        TOO_SHORT_TO_ESTABLISH_INDEPENDENCE,
        INELIGIBLE
    }

    public static final class Result {
        public boolean evaluated=false;
        public boolean independent=false;
        public boolean duplicate=false;
        public boolean nearDuplicate=false;
        public boolean blocked=false;
        public State state=State.NONE;
        public String transitionKey="";
        public String currentCause="";
        public String evidenceText="";
        public String matchedEvidenceId="";
        public double similarity=0.0;
        public String reason="";
        public String summary="";
    }

    public static Result evaluate(
            Context c,
            ClinicalDecisionRC7 d,
            String userText){

        Result r=new Result();

        if(c==null||d==null){
            r.blocked=true;
            r.state=State.INELIGIBLE;
            r.reason="MISSING_INPUT";
            return finish(r);
        }

        r.evaluated=true;

        if(!d.transitionExplanationCorrectionApplied){
            r.blocked=true;
            r.state=State.INELIGIBLE;
            r.reason="NO_EXPLICIT_CURRENT_CORRECTION";
            return finish(r);
        }

        JSONObject f=CentralTherapyProfile.loadFormulation(c);
        String context=f.optString("current_context_scope","UNKNOWN");

        r.transitionKey=
                safe(d.decisionTransitionFromState)
                +"->"
                +safe(d.decisionTransitionToState)
                +"::"
                +context;

        r.currentCause=
                safe(d.transitionExplanationCorrectedCause);

        r.evidenceText=normalize(userText);

        if(r.evidenceText.isEmpty()||r.currentCause.isEmpty()){
            r.blocked=true;
            r.state=State.INELIGIBLE;
            r.reason="MISSING_EVIDENCE_OR_CAUSE";
            return finish(r);
        }

        String compact=semanticCompact(r.evidenceText);

        // Very short utterances are not strong enough to establish independent confirmation.
        if(compact.length()<8){
            r.blocked=true;
            r.state=State.TOO_SHORT_TO_ESTABLISH_INDEPENDENCE;
            r.reason="EVIDENCE_TOO_SHORT";
            return finish(r);
        }

        JSONObject p=CentralTherapyProfile.loadProfile(c);
        JSONArray ledger=p.optJSONArray(
                "requarantine_cooldown_evidence_ledger");

        if(ledger==null||ledger.length()==0){
            r.independent=true;
            r.state=State.INDEPENDENT;
            r.reason="FIRST_ELIGIBLE_EVIDENCE";
            return finish(r);
        }

        double best=0.0;
        String bestId="";

        for(int i=ledger.length()-1;i>=0;i--){
            JSONObject row=ledger.optJSONObject(i);
            if(row==null)continue;

            if(!CooldownEvidenceLedgerIntegrityAntiSyntheticRC14
                    .rowEligible(row))
                continue;

            if(!r.transitionKey.equals(
                    row.optString("transition_key","")))
                continue;

            if(!r.currentCause.equals(
                    row.optString("current_cause","")))
                continue;

            String prior=normalize(
                    row.optString("user_evidence_text",""));

            if(prior.isEmpty())continue;

            if(r.evidenceText.equals(prior)){
                r.duplicate=true;
                r.blocked=true;
                r.state=State.EXACT_DUPLICATE;
                r.similarity=1.0;
                r.matchedEvidenceId=
                        row.optString("user_evidence_id","");
                r.reason="EXACT_NORMALIZED_EVIDENCE_MATCH";
                return finish(r);
            }

            double sim=trigramDice(
                    semanticCompact(prior),
                    compact);

            if(sim>best){
                best=sim;
                bestId=row.optString("user_evidence_id","");
            }
        }

        r.similarity=best;
        r.matchedEvidenceId=bestId;

        // Product heuristic: very high lexical/character overlap is a paraphrase,
        // not an independent confirmation.
        if(best>=0.84){
            r.nearDuplicate=true;
            r.duplicate=true;
            r.blocked=true;
            r.state=State.NEAR_DUPLICATE;
            r.reason="PARAPHRASE_SIMILARITY_THRESHOLD_MET";
            return finish(r);
        }

        r.independent=true;
        r.state=State.INDEPENDENT;
        r.reason="DISTINCT_USER_EVIDENCE";
        return finish(r);
    }

    public static boolean mayCount(Result r){
        return r!=null
                &&r.independent
                &&!r.blocked
                &&r.state==State.INDEPENDENT;
    }

    public static String instruction(Result r){
        if(r==null||!r.evaluated)return "";

        if(r.state==State.EXACT_DUPLICATE)
            return "COOLDOWN_EVIDENCE_INDEPENDENCE=EXACT_DUPLICATE. 같은 사용자 근거를 반복한 것이므로 새 confirmation으로 카운트하지 않는다.";

        if(r.state==State.NEAR_DUPLICATE)
            return "COOLDOWN_EVIDENCE_INDEPENDENCE=NEAR_DUPLICATE. 표현만 조금 달라진 동일 취지의 근거로 판단되어 독립 confirmation으로 카운트하지 않는다.";

        if(r.state==State.TOO_SHORT_TO_ESTABLISH_INDEPENDENCE)
            return "COOLDOWN_EVIDENCE_INDEPENDENCE=TOO_SHORT. 너무 짧은 확인은 독립적인 새 근거로 승격하지 않는다.";

        if(r.state==State.INDEPENDENT)
            return "COOLDOWN_EVIDENCE_INDEPENDENCE=INDEPENDENT. 기존 ledger와 충분히 구별되는 명시적 사용자 근거라 독립 confirmation 후보가 된다.";

        return "";
    }

    private static double trigramDice(String a,String b){
        if(a==null||b==null)return 0.0;
        if(a.equals(b))return 1.0;
        if(a.length()<3||b.length()<3)
            return a.equals(b)?1.0:0.0;

        HashSet<String> A=grams(a);
        HashSet<String> B=grams(b);

        if(A.isEmpty()||B.isEmpty())return 0.0;

        int intersection=0;
        for(String x:A)
            if(B.contains(x))intersection++;

        return (2.0*intersection)/(A.size()+B.size());
    }

    private static HashSet<String> grams(String s){
        HashSet<String> out=new HashSet<>();
        for(int i=0;i<=s.length()-3;i++)
            out.add(s.substring(i,i+3));
        return out;
    }

    private static String semanticCompact(String s){
        if(s==null)return "";
        return s.replaceAll("[^0-9a-zA-Z가-힣]","")
                .toLowerCase();
    }

    private static String normalize(String s){
        if(s==null)return "";
        return s.trim()
                .replaceAll("\\s+"," ")
                .toLowerCase();
    }

    private static Result finish(Result r){
        r.summary=r.state.name()
                +" | independent="+r.independent
                +" | duplicate="+r.duplicate
                +" | nearDuplicate="+r.nearDuplicate
                +" | similarity="+r.similarity
                +" | transition="+r.transitionKey
                +" | cause="+r.currentCause
                +" | matchedEvidenceId="+r.matchedEvidenceId
                +" | reason="+r.reason;
        return r;
    }

    private static String safe(String s){
        return s==null?"":s;
    }
}
