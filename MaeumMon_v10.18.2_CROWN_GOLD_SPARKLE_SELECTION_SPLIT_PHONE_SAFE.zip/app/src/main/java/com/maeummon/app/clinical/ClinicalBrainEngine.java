package com.maeummon.app.clinical;

import android.content.Context;
import android.content.SharedPreferences;
import java.util.*;

public final class ClinicalBrainEngine {
    private ClinicalBrainEngine() {}
    private static final String PREF="clinical_brain_v1";
    private static final String KEY_LAST_Q="last_qdu";
    private static final String KEY_LAST_TARGET="last_target";

    public static final class Snapshot {
        public final Set<String> signals = new LinkedHashSet<>();
        public final List<String> hypotheses = new ArrayList<>();
        public final List<String> missing = new ArrayList<>();
        public String recommendedQuestion="";
        public String recommendedQuestionId="";
        public String recommendedTarget="";
        public String recommendedIntervention="";
        public boolean safetyOverride=false;
        public String safetyReason="";

        public String toPromptBlock() {
            StringBuilder b=new StringBuilder();
            b.append("[CLINICAL BRAIN v0.2 / 구조화 임상판단 보조층]\n");
            b.append("역할: 기존 TherapistBrain/MetaCounselDecision을 대체하지 않는다. 현재 발화에서 가능한 가설과 정보공백을 구조화하여 최종 판단을 돕는다. 가설을 사실로 취급하지 않는다.\n");
            b.append("signals=").append(signals).append("\n");
            b.append("candidate_hypotheses=").append(hypotheses).append("\n");
            b.append("missing_information=").append(missing).append("\n");
            if (safetyOverride) b.append("SAFETY_OVERRIDE_CANDIDATE=true; reason=").append(safetyReason).append("\n");
            if (!recommendedQuestion.isEmpty()) {
                b.append("recommended_qdu=").append(recommendedQuestionId).append("; target=").append(recommendedTarget).append("\n");
                b.append("recommended_question=").append(recommendedQuestion).append("\n");
                b.append("이 질문은 참고 후보일 뿐이다. history/stateMemory에서 이미 답했거나, 답이 달라도 개입이 같거나, 사용자가 즉시 행동을 원하면 사용하지 않는다.\n");
            }
            if (!recommendedIntervention.isEmpty()) b.append("candidate_intervention=").append(recommendedIntervention).append("\n");
            b.append("규칙: 1) FACT/INTERPRETATION 분리 2) H1~H3 유지 3) 가장 정보가치 높은 빈칸 하나만 질문 4) 질문한 다음 턴에는 새 안전/turning point가 아니면 formulation 우선 5) 기존 CURRENT_FORMULATION과 새 사실이 충돌하면 새 사실 우선.\n");
            return b.toString();
        }
    }

    public static Snapshot analyze(Context c, String text, String historyText) {
        Snapshot s=new Snapshot();
        String t=(text==null?"":text).toLowerCase(Locale.KOREA);
        detect(t,s.signals);
        buildHypotheses(s);
        buildMissing(s);
        applySafety(s);
        chooseQdu(c, s, historyText==null?"":historyText);
        chooseIdu(s);
        return s;
    }

    public static void recordQuestionUsed(Context c, String qduId, String target) {
        if (c==null) return;
        c.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit()
                .putString(KEY_LAST_Q, qduId==null?"":qduId)
                .putString(KEY_LAST_TARGET, target==null?"":target).apply();
    }

    private static void detect(String t, Set<String> s) {
        if (has(t,"답장","카톡","읽씹","안읽","연락이 안","답이 안")) s.add("reply_delay");
        if (has(t,"나 빼고","빼고 놀","제외","나만 빼","초대 안","단톡")) s.add("social_exclusion");
        if (has(t,"싫어하","미워하","버릴","버려질","거절","손절","멀어질")) s.add("rejection_fear");
        if (has(t,"회사","직장","업무","상사","프로님","출근","일이 너무")) s.add("work_stress");
        if (has(t,"불안","무서","초조","걱정","공포","숨 막")) s.add("anxiety");
        if (has(t,"화나","빡쳐","짜증","분노")) s.add("anger");
        if (has(t,"서운","속상","슬퍼","울고 싶","울 것")) s.add("sadness");
        if (has(t,"피하고","피하","도망","숨고","안 만나고","회피")) s.add("avoidance");
        if (has(t,"죽고 싶","죽고싶","자살","자해","목숨을 끊")) s.add("self_harm");
        if (has(t,"환청","환각","누가 감시","도청당")) s.add("psychosis");
        if (has(t,"며칠째 안 자","잠 안 자도 멀쩡","잠이 필요 없","과하게 들뜬","폭주하듯")) s.add("mania");
    }

    private static void buildHypotheses(Snapshot s) {
        if (s.signals.contains("reply_delay")) {
            s.hypotheses.add("H1 정상적인 답장 지연/우선순위 차이");
            s.hypotheses.add("H2 실제 관계거리 변화");
            s.hypotheses.add("H3 무응답을 거절로 빠르게 해석하는 확대 가능성");
        } else if (s.signals.contains("social_exclusion")) {
            s.hypotheses.add("H1 실제 배제 또는 관계거리 변화");
            s.hypotheses.add("H2 상황적/우연한 모임 구성");
            s.hypotheses.add("H3 배제 신호의 의미가 정서적으로 확대된 가능성");
        } else if (s.signals.contains("work_stress")) {
            s.hypotheses.add("H1 업무량/과업 부담");
            s.hypotheses.add("H2 사람/평가 상황에서의 긴장");
            s.hypotheses.add("H3 소진/회복 부족");
        }
        if (s.signals.contains("anxiety") && s.signals.contains("avoidance")) {
            s.hypotheses.add("회피가 단기 안도를 주어 장기적으로 불안을 유지하는 고리 가능성");
        }
        while (s.hypotheses.size()>3) s.hypotheses.remove(s.hypotheses.size()-1);
    }

    private static void buildMissing(Snapshot s) {
        if (s.signals.contains("reply_delay")) Collections.addAll(s.missing,"baseline_relationship_change","recent_conflict","meaning_attribution");
        if (s.signals.contains("social_exclusion")) Collections.addAll(s.missing,"repetition_vs_oneoff","grouping_context","meaning_attribution");
        if (s.signals.contains("work_stress")) Collections.addAll(s.missing,"recent_specific_episode","workload_vs_relationship","meaning_attribution");
        if (s.signals.contains("anxiety")) Collections.addAll(s.missing,"body_activation","avoidance_or_reassurance_behavior");
        LinkedHashSet<String> d=new LinkedHashSet<>(s.missing); s.missing.clear(); s.missing.addAll(d);
    }

    private static void applySafety(Snapshot s) {
        for (ClinicalKnowledge.Unit u: ClinicalKnowledge.seeds()) {
            if (!"SDU".equals(u.type)) continue;
            for (String sig:u.signals) if (s.signals.contains(sig)) {
                s.safetyOverride=true; s.safetyReason=u.title; return;
            }
        }
    }

    private static void chooseQdu(Context c, Snapshot s, String history) {
        if (s.safetyOverride) return;
        SharedPreferences p=c==null?null:c.getSharedPreferences(PREF, Context.MODE_PRIVATE);
        String lastId=p==null?"":p.getString(KEY_LAST_Q,"");
        String lastTarget=p==null?"":p.getString(KEY_LAST_TARGET,"");
        int best=Integer.MIN_VALUE; ClinicalKnowledge.Unit pick=null;
        for (ClinicalKnowledge.Unit u:ClinicalKnowledge.seeds()) {
            if (!"QDU".equals(u.type)) continue;
            int overlap=0; for(String sig:u.signals) if(s.signals.contains(sig)) overlap++;
            if (overlap==0) continue;
            int score=u.priority+overlap*10;
            if (s.missing.contains(u.target)) score+=20;
            if (u.id.equals(lastId)) score-=50;
            if (!u.target.isEmpty() && u.target.equals(lastTarget)) score-=20;
            if (history.contains(u.content)) score-=50;
            if (score>best) {best=score;pick=u;}
        }
        if (pick!=null && best>0) {
            s.recommendedQuestionId=pick.id; s.recommendedTarget=pick.target; s.recommendedQuestion=pick.content;
        }
    }

    private static void chooseIdu(Snapshot s) {
        int best=Integer.MIN_VALUE; ClinicalKnowledge.Unit pick=null;
        for (ClinicalKnowledge.Unit u:ClinicalKnowledge.seeds()) {
            if (!"IDU".equals(u.type)) continue;
            int overlap=0; for(String sig:u.signals) if(s.signals.contains(sig)) overlap++;
            int score=u.priority+overlap*10;
            if (overlap>0 && score>best) {best=score;pick=u;}
        }
        if (pick!=null) s.recommendedIntervention=pick.title+": "+pick.content;
    }

    private static boolean has(String t,String...xs){ for(String x:xs) if(t.contains(x.toLowerCase(Locale.KOREA))) return true; return false; }
}
