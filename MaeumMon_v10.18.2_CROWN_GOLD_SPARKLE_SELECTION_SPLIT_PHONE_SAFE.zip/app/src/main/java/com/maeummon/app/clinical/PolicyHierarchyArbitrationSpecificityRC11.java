package com.maeummon.app.clinical;

import android.content.Context;
import org.json.*;

public final class PolicyHierarchyArbitrationSpecificityRC11 {
    private PolicyHierarchyArbitrationSpecificityRC11(){}

    public enum Winner {
        NONE,
        CONTEXT_SPECIFIC,
        GENERAL,
        CURRENT_ONLY
    }

    public static final class Result {
        public boolean evaluated=false;
        public Winner winner=Winner.NONE;
        public boolean contextPolicyFound=false;
        public boolean generalPolicyFound=false;
        public boolean bothFound=false;
        public String contextPolicyKey="";
        public String generalPolicyKey="";
        public String contextConfidence="NONE";
        public String generalConfidence="NONE";
        public String selectedPolicyKey="";
        public String selectedInterventionId="";
        public String selectedMode="";
        public String selectedDose="";
        public String reason="";
        public String summary="";
    }

    public static Result arbitrate(Context c,ClinicalDecisionRC7 d){
        Result r=new Result();
        if(c==null||d==null){
            r.summary="NONE | NO_CONTEXT_OR_DECISION";
            return r;
        }

        JSONObject p=CentralTherapyProfile.loadProfile(c);
        JSONObject f=CentralTherapyProfile.loadFormulation(c);
        JSONArray policies=p.optJSONArray("intervention_policy_memory");

        if(policies==null||policies.length()==0){
            r.summary="NONE | NO_POLICY_MEMORY";
            return r;
        }

        String mechanism=safe(d.centralMechanism);
        String context=f.optString("current_context_scope","UNKNOWN");

        if(mechanism.isEmpty()){
            r.summary="CURRENT_ONLY | NO_MECHANISM";
            r.winner=Winner.CURRENT_ONLY;
            return r;
        }

        JSONObject contextPolicy=findBest(
                policies,mechanism,context,false);

        JSONObject generalPolicy=findBest(
                policies,mechanism,context,true);

        r.contextPolicyFound=contextPolicy!=null;
        r.generalPolicyFound=generalPolicy!=null;
        r.bothFound=r.contextPolicyFound&&r.generalPolicyFound;

        if(contextPolicy!=null){
            r.contextPolicyKey=contextPolicy.optString("key","");
            r.contextConfidence=contextPolicy.optString("confidence","LOW");
        }

        if(generalPolicy!=null){
            r.generalPolicyKey=generalPolicy.optString("key","");
            r.generalConfidence=generalPolicy.optString("confidence","LOW");
        }

        r.evaluated=true;

        // Current evidence can block all policy influence.
        if(d.safetyOverride
                ||d.allianceRupture
                ||f.optBoolean("formulation_reopened",false)
                ||f.optInt("unresolved_evidence_conflicts",0)>0
                ||!f.optBoolean("central_insight_usable",false)){

            r.winner=Winner.CURRENT_ONLY;
            r.reason="CURRENT_EVIDENCE_BLOCKS_POLICY";
            persist(c,r);
            return finish(r);
        }

        // Specificity wins whenever usable.
        if(contextPolicy!=null){
            r.winner=Winner.CONTEXT_SPECIFIC;
            fillSelected(r,contextPolicy);
            r.reason=generalPolicy!=null
                    ?"CONTEXT_SPECIFIC_OVERRIDES_GENERAL"
                    :"CONTEXT_SPECIFIC_ONLY";
            persist(c,r);
            return finish(r);
        }

        // GENERAL is fallback only, and exceptions were already enforced in findBest.
        if(generalPolicy!=null){
            r.winner=Winner.GENERAL;
            fillSelected(r,generalPolicy);
            r.reason="GENERAL_FALLBACK";
            persist(c,r);
            return finish(r);
        }

        r.winner=Winner.CURRENT_ONLY;
        r.reason="NO_USABLE_POLICY";
        persist(c,r);
        return finish(r);
    }

    public static String instruction(Result r){
        if(r==null||!r.evaluated)return "";

        if(r.winner==Winner.CONTEXT_SPECIFIC){
            return "POLICY_HIERARCHY=CONTEXT_SPECIFIC. 같은 mechanism에서 GENERAL보다 현재 context에서 직접 검증된 policy를 우선한다. 그래도 현재 formulation/bridge를 덮어쓰지는 않는다.";
        }

        if(r.winner==Winner.GENERAL){
            return "POLICY_HIERARCHY=GENERAL_FALLBACK. 현재 context 전용 policy가 없을 때만 GENERAL policy를 약한 prior로 사용한다.";
        }

        if(r.winner==Winner.CURRENT_ONLY){
            return "POLICY_HIERARCHY=CURRENT_ONLY. 현재 evidence가 불안정하거나 usable policy가 없어 과거 policy를 사용하지 않는다.";
        }

        return "";
    }

    public static boolean hierarchyAllowsPolicy(Result r){
        return r!=null
                && (r.winner==Winner.CONTEXT_SPECIFIC
                    ||r.winner==Winner.GENERAL)
                && !r.selectedPolicyKey.isEmpty();
    }

    private static JSONObject findBest(
            JSONArray policies,String mechanism,
            String context,boolean wantGeneral){

        JSONObject best=null;
        int bestRank=-1;

        for(int i=0;i<policies.length();i++){
            JSONObject x=policies.optJSONObject(i);
            if(x==null)continue;

            if(!mechanism.equals(x.optString("mechanism","")))
                continue;

            String cx=x.optString("context_scope","UNKNOWN");

            if(wantGeneral){
                if(!"GENERAL".equals(cx))continue;
                if(!GeneralPolicyExceptionBoundaryRC11.generalPolicyAllowedInContext(
                        x,context))
                    continue;
            }else{
                if("GENERAL".equals(cx))continue;
                if(!context.equals(cx))continue;
            }

            if(!PolicyMemoryDecayContradictionDemotionRC11.isPolicyUsable(x))
                continue;

            String conf=x.optString("confidence","LOW");
            int rank="HIGH".equals(conf)?3:
                    "MEDIUM".equals(conf)?2:0;

            if(rank>bestRank){
                best=x;
                bestRank=rank;
            }
        }

        return best;
    }

    private static void fillSelected(
            Result r,JSONObject p){

        r.selectedPolicyKey=p.optString("key","");
        r.selectedInterventionId=p.optString("intervention_id","");
        r.selectedMode=p.optString("preferred_mode","");
        r.selectedDose=p.optString("preferred_dose","");
    }

    private static void persist(Context c,Result r){
        try{
            JSONObject f=CentralTherapyProfile.loadFormulation(c);

            f.put("policy_hierarchy_winner",r.winner.name());
            f.put("policy_hierarchy_context_policy_found",r.contextPolicyFound);
            f.put("policy_hierarchy_general_policy_found",r.generalPolicyFound);
            f.put("policy_hierarchy_selected_key",r.selectedPolicyKey);
            f.put("policy_hierarchy_reason",r.reason);
            f.put("policy_hierarchy_updated_at",System.currentTimeMillis());

            CentralTherapyProfile.replaceFormulation(c,f);
        }catch(Exception ignored){}
    }

    private static Result finish(Result r){
        r.summary=r.winner.name()
                +" | contextFound="+r.contextPolicyFound
                +" | generalFound="+r.generalPolicyFound
                +" | selected="+r.selectedPolicyKey
                +" | reason="+r.reason;
        return r;
    }

    private static String safe(String s){
        return s==null?"":s;
    }
}
