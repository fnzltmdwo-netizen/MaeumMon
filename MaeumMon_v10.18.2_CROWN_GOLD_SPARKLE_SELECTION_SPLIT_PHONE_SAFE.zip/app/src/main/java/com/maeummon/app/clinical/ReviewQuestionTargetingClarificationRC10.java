package com.maeummon.app.clinical;

import android.content.Context;
import org.json.*;

public final class ReviewQuestionTargetingClarificationRC10 {
    private ReviewQuestionTargetingClarificationRC10(){}

    public static final class Result {
        public boolean clarificationNeeded=false;
        public boolean askAllowed=false;
        public String question="";
        public String target="";
        public String source="";
        public String reason="";
        public String summary="";
    }

    public static Result build(
            Context c,String userText,ClinicalDecisionRC7 d,
            MicroExperimentReviewEvidenceMapperRC10.Result mapping){

        Result r=new Result();

        if(d==null){
            r.summary="NOT_NEEDED | NO_DECISION";
            return r;
        }

        if(mapping==null || !mapping.activeExperiment){
            r.summary="NOT_NEEDED | NO_ACTIVE_EXPERIMENT";
            return r;
        }

        if(!mapping.needsClarification){
            r.summary="NOT_NEEDED | ATTRIBUTION_CLEAR";
            return r;
        }

        if(d.safetyOverride){
            r.summary="BLOCKED | SAFETY";
            return r;
        }

        if(d.allianceRupture){
            r.summary="BLOCKED | ALLIANCE";
            return r;
        }

        r.clarificationNeeded=true;
        r.askAllowed=true;
        r.source="MICRO_EXPERIMENT_REVIEW";
        r.target="experiment_outcome_attribution";

        JSONObject s=CentralTherapyProfile.loadSessionState(c);
        String action=s.optString("active_micro_experiment_action","");
        String review=s.optString("active_micro_experiment_review_criterion","");
        String intervention=s.optString("active_micro_experiment_intervention_id","");

        r.question=buildQuestion(action,review,intervention,userText);
        r.reason="결과 표현은 있으나 직전 micro-experiment에 대한 결과인지 불확실하므로 귀인 확인 질문 1개가 필요하다.";

        if(r.question.isEmpty()){
            r.askAllowed=false;
            r.summary="BLOCKED | QUESTION_BUILD_FAILED";
            return r;
        }

        r.summary="READY | target="+r.target+" | source="+r.source;
        return r;
    }

    public static String instruction(Result r){
        if(r==null||!r.clarificationNeeded||!r.askAllowed)return "";

        return "REVIEW_ATTRIBUTION_CLARIFICATION_REQUIRED=true. "
                +"다른 질문이나 새로운 개입을 섞지 말고 아래 질문 1개만 한다: "
                +r.question
                +" 이 답을 받기 전에는 직전 micro-experiment를 HELPED/PARTIAL/NO_CHANGE/WORSE로 확정 학습하지 않는다.";
    }

    private static String buildQuestion(
            String action,String review,String intervention,String userText){

        if("REALITY_TEST".equals(intervention)){
            return "방금 말한 변화가, 전에 해본 '사실과 해석을 나누기'를 했을 때 나타난 변화야?";
        }

        if("AMBIGUITY_TOLERANCE".equals(intervention)){
            return "방금 말한 변화가, 애매한 상황을 바로 결론내리지 않고 잠깐 남겨둬봤을 때 나타난 변화야?";
        }

        if("COMMUNICATION_SCRIPT".equals(intervention)){
            return "방금 말한 변화가, 상대에게 확인 문장을 실제로 써봤을 때 생긴 결과야?";
        }

        if("REPAIR_OR_BOUNDARY".equals(intervention)){
            return "방금 말한 변화가, 수리할 부분과 지킬 경계를 나눠봤을 때 생긴 결과야?";
        }

        if("FACT_VS_EVALUATION".equals(intervention)){
            return "방금 말한 변화가, 실제 사실과 자기평가를 나눠봤을 때 나타난 변화야?";
        }

        if("LOAD_REDUCTION".equals(intervention)){
            return "방금 말한 변화가, 해야 할 것 하나를 실제로 줄이거나 미뤄봤을 때 생긴 결과야?";
        }

        if("WORK_BOUNDARY_SCRIPT".equals(intervention)){
            return "방금 말한 변화가, 준비한 경계 문장을 실제 상황에서 써봤을 때 생긴 결과야?";
        }

        if("RECOVERY_FIRST".equals(intervention)){
            return "방금 말한 변화가, 문제를 더 생각하기 전에 짧게 회복부터 해봤을 때 생긴 결과야?";
        }

        if("GRADED_APPROACH".equals(intervention)){
            return "방금 말한 변화가, 피하고 싶은 상황에 가장 작은 접근 행동을 해봤을 때 생긴 결과야?";
        }

        if(action!=null&&!action.isEmpty()){
            String compact=compact(action,90);
            return "방금 말한 변화가, 전에 해보기로 한 '"+compact+"'를 실제로 했을 때 생긴 결과야?";
        }

        if(review!=null&&!review.isEmpty()){
            return "방금 말한 변화가, 직전에 같이 정한 실험을 해본 결과를 말하는 거야?";
        }

        return "";
    }

    public static void persistPendingClarification(
            Context c,Result r){

        if(c==null||r==null||!r.askAllowed)return;

        try{
            JSONObject s=CentralTherapyProfile.loadSessionState(c);
            s.put("pending_review_attribution_clarification",true);
            s.put("pending_review_attribution_question",r.question);
            s.put("pending_review_attribution_target",r.target);
            s.put("pending_review_attribution_started_at",System.currentTimeMillis());
            CentralTherapyProfile.replaceSessionState(c,s);
        }catch(Exception ignored){}
    }

    public static boolean resolvePendingClarification(
            Context c,String userText){

        if(c==null)return false;

        JSONObject s=CentralTherapyProfile.loadSessionState(c);
        if(!s.optBoolean("pending_review_attribution_clarification",false))
            return false;

        String u=userText==null?"":userText.trim();

        boolean yes=containsAny(u,
                "응","맞아","맞아 그거","그거 맞아","그거 했을 때",
                "그 방법","그 실험","해봤을 때","그거 해보니까");

        boolean no=containsAny(u,
                "아니","그건 아니","그거 때문은 아니","상관없",
                "그 실험 얘기 아니","그 방법 말고");

        if(!yes&&!no)return false;

        try{
            s.put("pending_review_attribution_clarification",false);
            s.put("last_review_attribution_resolution",yes?"CONFIRMED":"REJECTED");
            s.put("last_review_attribution_resolution_at",System.currentTimeMillis());
            CentralTherapyProfile.replaceSessionState(c,s);
        }catch(Exception ignored){}

        return true;
    }

    private static boolean containsAny(String s,String... xs){
        if(s==null)return false;
        for(String x:xs)if(x!=null&&!x.isEmpty()&&s.contains(x))return true;
        return false;
    }

    private static String compact(String s,int max){
        s=s==null?"":s.trim();
        return s.length()<=max?s:s.substring(0,max);
    }
}
