package com.maeummon.app.clinical;

import android.content.Context;
import org.json.*;
import java.security.MessageDigest;

public final class QuarantinedCorrectionProvenanceReviewReinstatementRC14 {
    // v6.9.2: reinstatement write is externally gated by CorrectionProvenanceReinstatementIdempotencyRC14.
    public static final boolean reinstatement_idempotency_guarded=true;
    private QuarantinedCorrectionProvenanceReviewReinstatementRC14(){}

    public enum State {
        NONE,
        NO_QUARANTINED_MATCH,
        REVIEW_REQUIRED,
        REINSTATEMENT_READY,
        REINSTATED,
        REINSTATEMENT_BLOCKED
    }

    public static final class Result {
        public boolean evaluated=false;
        public boolean reviewRequired=false;
        public boolean ready=false;
        public boolean reinstated=false;
        public boolean blocked=false;
        public State state=State.NONE;
        public int matchingRows=0;
        public int reinstatedRows=0;
        public String transitionKey="";
        public String contextScope="";
        public String correctedCause="";
        public String evidenceId="";
        public String reason="";
        public String summary="";
    }

    public static Result review(
            Context c,
            ClinicalDecisionRC7 d,
            String userText){

        Result r=new Result();

        if(c==null||d==null){
            r.summary="NONE | MISSING_INPUT";
            return r;
        }

        r.evaluated=true;

        // Only fresh explicit correction can reopen quarantine review.
        if(!d.transitionExplanationCorrectionApplied
                ||!d.transitionCorrectionCommitAllowed){
            r.reason="NO_FRESH_EXPLICIT_CORRECTION";
            return finish(r);
        }

        JSONObject p=CentralTherapyProfile.loadProfile(c);
        JSONObject f=CentralTherapyProfile.loadFormulation(c);

        r.contextScope=
                f.optString("current_context_scope","UNKNOWN");
        r.transitionKey=
                safe(d.decisionTransitionFromState)
                +"->"
                +safe(d.decisionTransitionToState)
                +"::"
                +r.contextScope;
        r.correctedCause=
                safe(d.transitionExplanationCorrectedCause);

        String normalized=normalize(userText);
        if(normalized.isEmpty()
                ||r.correctedCause.isEmpty()){
            r.blocked=true;
            r.state=State.REINSTATEMENT_BLOCKED;
            r.reason="MISSING_EXPLICIT_REVIEW_EVIDENCE";
            return finish(r);
        }

        r.evidenceId=sha256(normalized);

        JSONArray h=p.optJSONArray(
                "transition_correction_commit_provenance_history");

        if(h==null||h.length()==0){
            r.state=State.NO_QUARANTINED_MATCH;
            r.reason="NO_PROVENANCE_HISTORY";
            return finish(r);
        }

        for(int i=0;i<h.length();i++){
            JSONObject row=h.optJSONObject(i);
            if(row==null)continue;

            boolean quarantined=
                    row.optBoolean(
                        "correction_provenance_quarantined",
                        false);

            String integrityState=
                    row.optString(
                        "correction_provenance_integrity_state",
                        "");

            if(!quarantined
                    &&!"QUARANTINED".equals(integrityState)
                    &&!"LEGACY_UNRESOLVED".equals(integrityState))
                continue;

            String rowTransition=
                    row.optString("transition_key","");
            String rowContext=
                    row.optString("context_scope","");
            String rowCause=
                    row.optString("corrected_cause","");

            boolean transitionMatch=
                    !rowTransition.isEmpty()
                    &&rowTransition.equals(r.transitionKey);

            boolean contextMatch=
                    !rowContext.isEmpty()
                    &&rowContext.equals(r.contextScope);

            boolean causeMatch=
                    !rowCause.isEmpty()
                    &&rowCause.equals(r.correctedCause);

            if(transitionMatch
                    &&contextMatch
                    &&causeMatch){
                r.matchingRows++;
            }
        }

        if(r.matchingRows==0){
            r.state=State.NO_QUARANTINED_MATCH;
            r.reason="NO_EXACT_QUARANTINED_IDENTITY_MATCH";
            return finish(r);
        }

        r.reviewRequired=true;

        // Explicit evidence allows exact repair candidate creation.
        r.ready=true;
        r.state=State.REINSTATEMENT_READY;
        r.reason="EXACT_QUARANTINED_MATCH_WITH_FRESH_USER_EVIDENCE";

        return finish(r);
    }

    public static void reinstate(
            Context c,
            ClinicalDecisionRC7 d,
            Result r,
            String userText){

        if(c==null||d==null||r==null||!r.ready)return;

        JSONObject p=CentralTherapyProfile.loadProfile(c);
        JSONArray h=p.optJSONArray(
                "transition_correction_commit_provenance_history");

        if(h==null)return;

        String evidenceText=normalize(userText);
        String evidenceId=sha256(evidenceText);

        for(int i=0;i<h.length();i++){
            JSONObject row=h.optJSONObject(i);
            if(row==null)continue;

            boolean quarantined=
                    row.optBoolean(
                        "correction_provenance_quarantined",
                        false);

            String state=row.optString(
                    "correction_provenance_integrity_state","");

            if(!quarantined
                    &&!"QUARANTINED".equals(state)
                    &&!"LEGACY_UNRESOLVED".equals(state))
                continue;

            String rowTransition=
                    row.optString("transition_key","");
            String rowContext=
                    row.optString("context_scope","");
            String rowCause=
                    row.optString("corrected_cause","");

            if(!r.transitionKey.equals(rowTransition)
                    ||!r.contextScope.equals(rowContext)
                    ||!r.correctedCause.equals(rowCause))
                continue;

            String canonical=sha256(
                    r.transitionKey
                    +"::"
                    +r.correctedCause
                    +"::"
                    +evidenceId);

            try{
                row.put("user_evidence_text",evidenceText);
                row.put("user_evidence_id",evidenceId);
                row.put("source_type","EXPLICIT_USER_CORRECTION");
                row.put("canonical_commit_key",canonical);
                row.put(
                        "correction_provenance_integrity_state",
                        "REPAIRED");
                row.put(
                        "correction_provenance_quarantined",
                        false);
                row.put(
                        "correction_provenance_integrity_reason",
                        "REINSTATED_FROM_FRESH_EXPLICIT_USER_EVIDENCE");
                row.put(
                        "correction_provenance_reinstated_at",
                        System.currentTimeMillis());
                row.put(
                        "correction_provenance_reinstatement_schema",
                        "6.9.1");

                r.reinstatedRows++;
            }catch(Exception rowWriteError){
                r.blocked=true;
                r.reason="REINSTATEMENT_ROW_WRITE_FAILED";
            }
        }

        try{
            p.put(
                "transition_correction_commit_provenance_history",
                h);
            p.put(
                "last_correction_provenance_reinstatement_at",
                System.currentTimeMillis());
            p.put(
                "last_correction_provenance_reinstated_rows",
                r.reinstatedRows);
            p.put(
                "last_correction_provenance_reinstatement_transition",
                r.transitionKey);

            CentralTherapyProfile.replaceProfile(c,p);

            if(r.reinstatedRows>0){
                r.reinstated=true;
                r.ready=false;
                r.state=State.REINSTATED;
                r.reason="QUARANTINED_PROVENANCE_REINSTATED";
            }else{
                r.blocked=true;
                r.state=State.REINSTATEMENT_BLOCKED;
                r.reason="NO_ROW_REINSTATED_AFTER_REVIEW";
            }

            finish(r);

        }catch(Exception e){
            r.blocked=true;
            r.state=State.REINSTATEMENT_BLOCKED;
            r.reason="REINSTATEMENT_WRITE_FAILED";
            finish(r);
        }
    }

    public static String instruction(Result r){
        if(r==null||!r.evaluated)return "";

        if(r.state==State.REINSTATED)
            return "CORRECTION_PROVENANCE_REINSTATEMENT=REINSTATED. 과거 격리된 correction provenance가 동일 transition/context의 새 명시적 사용자 근거로 검증되어 복구되었다.";

        if(r.state==State.REINSTATEMENT_BLOCKED)
            return "CORRECTION_PROVENANCE_REINSTATEMENT=BLOCKED. 격리된 correction provenance는 새 사용자 근거로 안전하게 복구할 수 없어 계속 제외한다.";

        if(r.state==State.REINSTATEMENT_READY)
            return "CORRECTION_PROVENANCE_REINSTATEMENT=READY. 동일 transition/context의 명시적 사용자 근거가 다시 확보되어 격리 row를 복구할 수 있다.";

        return "";
    }

    private static String normalize(String s){
        if(s==null)return "";
        return s.trim()
                .replaceAll("\\s+"," ")
                .toLowerCase();
    }

    private static String sha256(String s){
        try{
            MessageDigest md=
                    MessageDigest.getInstance("SHA-256");
            byte[] b=md.digest(
                    safe(s).getBytes("UTF-8"));

            StringBuilder out=new StringBuilder();
            for(byte x:b)
                out.append(String.format("%02x",x));
            return out.toString();

        }catch(Exception e){
            return Integer.toHexString(
                    safe(s).hashCode());
        }
    }

    private static Result finish(Result r){
        r.summary=r.state.name()
                +" | matchingRows="+r.matchingRows
                +" | reinstatedRows="+r.reinstatedRows
                +" | transition="+r.transitionKey
                +" | context="+r.contextScope
                +" | cause="+r.correctedCause
                +" | evidenceId="+r.evidenceId
                +" | reason="+r.reason;
        return r;
    }

    private static String safe(String s){
        return s==null?"":s;
    }
}
