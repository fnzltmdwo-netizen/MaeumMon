package com.maeummon.app.clinical;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONObject;
import org.json.JSONArray;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.*;

/** v6.0.3: RC7 decision + final reply QA logger. Internal app storage only. */
public final class ClinicalQaRC7 {
    private ClinicalQaRC7(){}
    private static final String PREF="clinical_rc7_qa";
    private static final String FILE="rc7_qa_log.jsonl";
    private static final int MAX_BYTES=1024*1024; // keep QA log bounded (~1 MB)

    public static boolean enabled(Context c){
        return c!=null && c.getSharedPreferences(PREF,Context.MODE_PRIVATE).getBoolean("enabled",false);
    }
    public static void setEnabled(Context c,boolean value){
        if(c!=null)c.getSharedPreferences(PREF,Context.MODE_PRIVATE).edit().putBoolean("enabled",value).apply();
    }

    public static void stageDecision(Context c,String userText,ClinicalDecisionRC7 d){
        if(c==null||d==null||!enabled(c))return;
        SharedPreferences.Editor e=c.getSharedPreferences(PREF,Context.MODE_PRIVATE).edit();
        e.putLong("pending_time",System.currentTimeMillis());
        e.putString("pending_user",safe(userText));
        e.putString("pending_decision",d.toJson().toString());
        e.apply();
    }

    public static void recordFinal(Context c,String userText,String finalReply,String source){
        if(c==null||!enabled(c))return;
        SharedPreferences p=c.getSharedPreferences(PREF,Context.MODE_PRIVATE);
        JSONObject o=new JSONObject();
        try{
            long now=System.currentTimeMillis();
            o.put("time_ms",now);
            o.put("time",new SimpleDateFormat("yyyy-MM-dd HH:mm:ss",Locale.KOREA).format(new Date(now)));
            o.put("user_text",safe(userText));
            o.put("reply",safe(finalReply));
            o.put("response_source",safe(source));
            String raw=p.getString("pending_decision","");
            if(!raw.isEmpty())o.put("rc7",new JSONObject(raw));
            else o.put("rc7",JSONObject.NULL);
            long pending=p.getLong("pending_time",0L);
            if(pending>0)o.put("latency_ms",Math.max(0L,now-pending));
            ClinicalDecisionRC7 decision=null;
            if(!raw.isEmpty()){
                try{ decision=parseDecision(new JSONObject(raw)); }catch(Exception ignored){}
            }
            ClinicalResponseQualityRC7.Result quality=ClinicalResponseQualityRC7.evaluate(userText,finalReply,decision);
            o.put("quality",quality.toJson());
            append(c,o.toString());
        }catch(Exception ignored){}
        p.edit().remove("pending_time").remove("pending_user").remove("pending_decision").apply();
    }

    public static void recordFinalWithCorrection(
            Context c,String userText,String finalReply,String source,
            String originalReply,
            ClinicalResponseQualityRC7.Result originalQuality,
            String revisedReply,
            ClinicalResponseQualityRC7.Result revisedQuality,
            String selected,
            ClinicalResponseComparatorRC7.Result comparator,
            ClinicalConversationCoherenceRC7.Result originalCoherence,
            ClinicalConversationCoherenceRC7.Result revisedCoherence
    ){
        if(c==null||!enabled(c))return;
        SharedPreferences p=c.getSharedPreferences(PREF,Context.MODE_PRIVATE);
        JSONObject o=new JSONObject();
        try{
            long now=System.currentTimeMillis();
            o.put("time_ms",now);
            o.put("time",new SimpleDateFormat("yyyy-MM-dd HH:mm:ss",Locale.KOREA).format(new Date(now)));
            o.put("user_text",safe(userText));
            o.put("reply",safe(finalReply));
            o.put("response_source",safe(source));
            String raw=p.getString("pending_decision","");
            if(!raw.isEmpty())o.put("rc7",new JSONObject(raw));
            else o.put("rc7",JSONObject.NULL);
            long pending=p.getLong("pending_time",0L);
            if(pending>0)o.put("latency_ms",Math.max(0L,now-pending));

            ClinicalDecisionRC7 decision=null;
            if(!raw.isEmpty()){
                try{decision=parseDecision(new JSONObject(raw));}catch(Exception ignored){}
            }
            ClinicalResponseQualityRC7.Result finalQuality=
                    ClinicalResponseQualityRC7.evaluate(userText,finalReply,decision);
            o.put("quality",finalQuality.toJson());

            JSONObject correction=new JSONObject();
            correction.put("attempted",revisedReply!=null&&!revisedReply.trim().isEmpty());
            correction.put("selected",safe(selected));
            correction.put("original_reply",safe(originalReply));
            if(originalQuality!=null)correction.put("original_quality",originalQuality.toJson());
            if(revisedReply!=null)correction.put("revised_reply",safe(revisedReply));
            if(revisedQuality!=null)correction.put("revised_quality",revisedQuality.toJson());
            if(comparator!=null){
                JSONObject cmp=new JSONObject();
                cmp.put("meaning_score",comparator.meaningScore);
                cmp.put("continuity_score",comparator.continuityScore);
                cmp.put("mechanical_penalty",comparator.mechanicalPenalty);
                cmp.put("total",comparator.total);
                JSONArray ci=new JSONArray();
                for(String issue:comparator.issues)ci.put(issue);
                cmp.put("issues",ci);
                correction.put("comparator",cmp);
            }
            if(originalCoherence!=null){
                JSONObject cg=new JSONObject();
                cg.put("original_score",originalCoherence.score);
                JSONArray oi=new JSONArray();
                for(String issue:originalCoherence.issues)oi.put(issue);
                cg.put("original_issues",oi);
                if(revisedCoherence!=null){
                    cg.put("revised_score",revisedCoherence.score);
                    JSONArray ri=new JSONArray();
                    for(String issue:revisedCoherence.issues)ri.put(issue);
                    cg.put("revised_issues",ri);
                }
                o.put("coherence",cg);
            }
            o.put("self_correction",correction);

            append(c,o.toString());
        }catch(Exception ignored){}
        p.edit().remove("pending_time").remove("pending_user").remove("pending_decision").apply();
    }

    private static synchronized void append(Context c,String line){
        try{
            File f=new File(c.getFilesDir(),FILE);
            if(f.exists()&&f.length()>MAX_BYTES){
                File old=new File(c.getFilesDir(),FILE+".old");
                if(old.exists())old.delete();
                f.renameTo(old);
            }
            try(FileOutputStream out=new FileOutputStream(f,true)){
                out.write((line+"\n").getBytes("UTF-8"));
            }
        }catch(Exception ignored){}
    }

    public static String latest(Context c,int maxLines){
        if(c==null)return "";
        File f=new File(c.getFilesDir(),FILE);
        if(!f.exists())return "아직 QA 로그가 없어.";
        ArrayDeque<String> q=new ArrayDeque<>();
        try(BufferedReader br=new BufferedReader(new InputStreamReader(new FileInputStream(f),"UTF-8"))){
            String line;
            while((line=br.readLine())!=null){
                q.addLast(line);
                while(q.size()>Math.max(1,maxLines))q.removeFirst();
            }
        }catch(Exception e){return "QA 로그 읽기 실패: "+e.getMessage();}
        StringBuilder b=new StringBuilder();
        int n=0;
        for(String line:q){
            n++;
            try{
                JSONObject o=new JSONObject(line);
                JSONObject d=o.optJSONObject("rc7");
                b.append("#").append(n).append(" ").append(o.optString("time","")).append("\n")
                 .append("USER: ").append(shorten(o.optString("user_text",""),120)).append("\n");
                if(d!=null)b.append("RC7: ").append(d.optString("preferred_move",""))
                    .append(" / ").append(d.optString("target_variable",""))
                    .append(" / ").append(d.optString("selected_unit_id","")).append("\n");
                b.append("SRC: ").append(o.optString("response_source","")).append("\n");
                JSONObject ql=o.optJSONObject("quality");
                if(ql!=null)b.append("QUALITY: ").append(ql.optString("grade",""))
                    .append(" ").append(ql.optInt("score",0)).append(" / 100")
                    .append(" ").append(ql.optJSONArray("issues")).append("\n");
                JSONObject sc=o.optJSONObject("self_correction");
                if(sc!=null&&sc.optBoolean("attempted",false)){
                    b.append("CORRECTION: ").append(sc.optString("selected","")).append("\n");
                    JSONObject cmp=sc.optJSONObject("comparator");
                    if(cmp!=null)b.append("SEMANTIC: ").append(cmp.optInt("total",0))
                            .append(" (meaning ").append(cmp.optInt("meaning_score",0))
                            .append(", continuity ").append(cmp.optInt("continuity_score",0)).append(")\n");
                }
                JSONObject coh=o.optJSONObject("coherence");
                if(coh!=null)b.append("COHERENCE: ").append(coh.optInt("original_score",0))
                        .append(coh.has("revised_score") ? " -> "+coh.optInt("revised_score",0) : "").append("\n");
                b.append("REPLY: ").append(shorten(o.optString("reply",""),220)).append("\n\n");
            }catch(Exception e){b.append(line).append("\n");}
        }
        return b.length()==0?"아직 QA 로그가 없어.":b.toString();
    }

    public static String qualitySummary(Context c,int maxLines){
        if(c==null)return "품질 로그 없음";
        File f=new File(c.getFilesDir(),FILE);
        if(!f.exists())return "아직 QA 품질 로그가 없어.";
        ArrayDeque<String> q=new ArrayDeque<>();
        try(BufferedReader br=new BufferedReader(new InputStreamReader(new FileInputStream(f),"UTF-8"))){
            String line;
            while((line=br.readLine())!=null){ q.addLast(line); while(q.size()>Math.max(1,maxLines))q.removeFirst(); }
        }catch(Exception e){return "품질 로그 읽기 실패: "+e.getMessage();}
        int n=0,total=0,pass=0,warn=0,fail=0;
        Map<String,Integer> issueCounts=new LinkedHashMap<>();
        for(String line:q){
            try{
                JSONObject o=new JSONObject(line); JSONObject quality=o.optJSONObject("quality"); if(quality==null)continue;
                n++; int sc=quality.optInt("score",0); total+=sc;
                String g=quality.optString("grade",""); if("PASS".equals(g))pass++; else if("WARN".equals(g))warn++; else fail++;
                JSONArray arr=quality.optJSONArray("issues");
                if(arr!=null)for(int i=0;i<arr.length();i++){String x=arr.optString(i,""); if(!x.isEmpty())issueCounts.put(x,issueCounts.containsKey(x)?issueCounts.get(x)+1:1);}
            }catch(Exception ignored){}
        }
        if(n==0)return "아직 품질평가 가능한 QA 로그가 없어.";
        List<Map.Entry<String,Integer>> xs=new ArrayList<>(issueCounts.entrySet());
        Collections.sort(xs,(a,b)->Integer.compare(b.getValue(),a.getValue()));
        StringBuilder b=new StringBuilder();
        b.append("최근 ").append(n).append("턴 품질 요약\n")
         .append("평균: ").append(Math.round(total/(double)n)).append(" / 100\n")
         .append("PASS ").append(pass).append(" · WARN ").append(warn).append(" · FAIL ").append(fail).append("\n\n")
         .append("주요 경고\n");
        if(xs.isEmpty())b.append("없음 ✓");
        else for(int i=0;i<Math.min(6,xs.size());i++)b.append("- ").append(xs.get(i).getKey()).append(": ").append(xs.get(i).getValue()).append("회\n");
        return b.toString();
    }

    public static void recordMemoryRevision(Context c,ClinicalMemoryRevisionRC7.Result r){
        if(c==null||r==null)return;
        try{
            SharedPreferences p=c.getSharedPreferences(PREF,Context.MODE_PRIVATE);
            JSONObject o=new JSONObject();
            o.put("revised",r.revised);
            o.put("weakened",r.weakened);
            o.put("deleted",r.deleted);
            JSONArray a=new JSONArray();
            for(String n:r.notes)a.put(n);
            o.put("notes",a);
            p.edit().putString("last_memory_revision",o.toString()).apply();
        }catch(Exception ignored){}
    }

    public static String lastMemoryRevision(Context c){
        if(c==null)return "";
        return c.getSharedPreferences(PREF,Context.MODE_PRIVATE)
                .getString("last_memory_revision","");
    }

    public static String memorySummary(Context c){
        try{
            ClinicalMemoryConsolidatorRC7.Snapshot s=ClinicalMemoryConsolidatorRC7.load(c);
            return "STABLE_PROFILE: "+s.stableProfile.length()
                    +"\\nSESSION_SUMMARY: "+s.sessionSummary.length();
        }catch(Exception e){
            return "memory unavailable";
        }
    }

    public static void clear(Context c){
        if(c==null)return;
        File f=new File(c.getFilesDir(),FILE); if(f.exists())f.delete();
        File old=new File(c.getFilesDir(),FILE+".old"); if(old.exists())old.delete();
        c.getSharedPreferences(PREF,Context.MODE_PRIVATE).edit()
            .remove("pending_time").remove("pending_user").remove("pending_decision").apply();
    }

    private static ClinicalDecisionRC7 parseDecision(JSONObject o){
        ClinicalDecisionRC7 d=new ClinicalDecisionRC7();
        if(o==null)return d;
        d.move=o.optString("preferred_move","FORMULATE");
        d.target=o.optString("target_variable","");
        d.unitId=o.optString("selected_unit_id","");
        d.safetyOverride=o.optBoolean("safety_override",false);
        d.allianceRupture=o.optBoolean("alliance_rupture_active",false);
        d.responseInstruction=o.optString("response_instruction","");
        d.confidence=o.optString("confidence","LOW");
        JSONArray sig=o.optJSONArray("signals");
        if(sig!=null)for(int i=0;i<sig.length();i++){String x=sig.optString(i,"");if(!x.isEmpty())d.signals.add(x);}
        JSONArray known=o.optJSONArray("known_variables");
        if(known!=null)for(int i=0;i<known.length();i++){String x=known.optString(i,"");if(!x.isEmpty())d.known.add(x);}
        JSONArray hs=o.optJSONArray("hypotheses");
        if(hs!=null)for(int i=0;i<hs.length();i++){String x=hs.optString(i,"");if(!x.isEmpty())d.hypotheses.add(x);}
        JSONArray mi=o.optJSONArray("missing_information");
        if(mi!=null)for(int i=0;i<mi.length();i++){String x=mi.optString(i,"");if(!x.isEmpty())d.missing.add(x);}
        return d;
    }

    public static File logFile(Context c){return c==null?null:new File(c.getFilesDir(),FILE);}
    private static String safe(String s){return s==null?"":s;}
    private static String shorten(String s,int n){if(s==null)return "";return s.length()<=n?s:s.substring(0,n)+"…";}
}
