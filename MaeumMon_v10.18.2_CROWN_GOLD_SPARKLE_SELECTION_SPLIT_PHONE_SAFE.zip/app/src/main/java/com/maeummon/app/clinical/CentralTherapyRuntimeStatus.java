package com.maeummon.app.clinical;

import android.content.Context;

public final class CentralTherapyRuntimeStatus {
    private CentralTherapyRuntimeStatus(){}

    public static String report(Context c){
        return "Central Therapy Runtime v6.1.1\n"
                + "- counseling: CONNECTED\n"
                + "- focus coaching: CONNECTED\n"
                + "- check-in/emotion diary: CONNECTED (read/write)\n"
                + "- daily letter: CONNECTED\n"
                + "- diary/day summary: CONNECTED\n"
                + "- weekly report: CONNECTED\n"
                + "- monthly report: CONNECTED\n"
                + "- widget: CONNECTED\n"
                + "- tamagotchi/overlay: CONNECTED\n"
                + "- profile: "+CentralTherapyProfile.compactSummary(c);
    }
}
