package com.maeummon.app.clinical;

import android.content.Context;
import org.json.*;

public final class SessionPhaseTherapeuticPacingRC8 {
    private SessionPhaseTherapeuticPacingRC8(){}

    public static final String ORIENT="ORIENT";
    public static final String UNDERSTAND="UNDERSTAND";
    public static final String CHANGE="CHANGE";
    public static final String PRACTICE="PRACTICE";
    public static final String CONSOLIDATE="CONSOLIDATE";
    public static final String COMPLETE="COMPLETE";

    public static final String SLOW="SLOW";
    public static final String MODERATE="MODERATE";
    public static final String ACTIVE="ACTIVE";
    public static final String GENTLE="GENTLE";

    public static final class State {
        public String phase=ORIENT;
        public String pacing=SLOW;
        public String rationale="";
        public int questionBudget=1;
        public boolean allowIntervention=false;
        public boolean preferReview=false;
        public boolean preferConsolidation=false;
    }

    public static State infer(Context c,ClinicalDecisionRC7 d,String userText){
        State s=new State();
        ClinicalSessionMemoryRC7.State session=ClinicalSessionMemoryRC7.load(c);
        JSONObject f=CentralTherapyProfile.loadFormulation(c);
        JSONObject p=CentralTherapyProfile.loadProfile(c);

        int turns=session.turns;
        int progress=p.optInt("goal_progress_score",50);
        String goalStatus=p.optString("last_goal_status","UNCHANGED");
        String outcome=f.optString("last_intervention_outcome","");
        String adaptive=f.optString("adaptive_plan_action","");
        JSONArray interventionHistory=f.optJSONArray("intervention_history");
        int interventionCount=interventionHistory==null?0:interventionHistory.length();
        JSONArray hypotheses=f.optJSONArray("alternative_hypotheses");
        int hypothesisCount=hypotheses==null?0:hypotheses.length();

        // Safety/alliance processes always override normal pacing.
        if(d!=null && (d.isStabilize() || d.isAllianceRepair())){
            s.phase=ORIENT;
            s.pacing=GENTLE;
            s.questionBudget=1;
            s.allowIntervention=false;
            s.rationale=d.isStabilize()?"safety override":"alliance repair override";
            return s;
        }

        // Completion: don't keep treating the old goal as a live problem.
        if("COMPLETED".equals(goalStatus)){
            s.phase=COMPLETE;
            s.pacing=GENTLE;
            s.questionBudget=0;
            s.allowIntervention=false;
            s.preferConsolidation=true;
            s.rationale="active therapeutic goal completed";
            return s;
        }

        // Consolidation: progress + repeated practice + at least some benefit/maintenance.
        if(progress>=75 && interventionCount>=2 &&
                ("HELPED".equals(outcome) || "PARTIAL".equals(outcome) || progress>=85)){
            s.phase=CONSOLIDATE;
            s.pacing=MODERATE;
            s.questionBudget=1;
            s.allowIntervention=false;
            s.preferReview=true;
            s.preferConsolidation=true;
            s.rationale="meaningful progress with repeated practice";
            return s;
        }

        // Practice: intervention is already underway. Review before adding another technique.
        if(interventionCount>=1 &&
                !"REOPEN_FORMULATION".equals(adaptive) &&
                !"WORSE".equals(outcome)){
            s.phase=PRACTICE;
            s.pacing=ACTIVE;
            s.questionBudget=1;
            s.allowIntervention=true;
            s.preferReview=true;
            s.rationale="active intervention/practice cycle";
            return s;
        }

        // Change: formulation has enough structure and user is ready for action.
        boolean formulationUsable=
                hypothesisCount>=2 &&
                !"LOW".equalsIgnoreCase(f.optString("confidence","LOW"));
        boolean actionReady=
                has(userText,"어떻게 해야","뭘 해야","해보고 싶","바꾸고 싶",
                        "실제로 해볼","방법","조언");
        if(formulationUsable && (actionReady || (d!=null && d.isIntervene()))){
            s.phase=CHANGE;
            s.pacing=ACTIVE;
            s.questionBudget=0;
            s.allowIntervention=true;
            s.rationale="usable formulation plus change readiness";
            return s;
        }

        // Understand: enough context has accumulated to formulate rather than restart intake.
        if(turns>=3 || hypothesisCount>=2 || (d!=null && d.known.size()>=2)){
            s.phase=UNDERSTAND;
            s.pacing=MODERATE;
            s.questionBudget=2;
            s.allowIntervention=false;
            s.rationale="sufficient context for formulation";
            return s;
        }

        // Orient: early contact, low-information situation.
        s.phase=ORIENT;
        s.pacing=SLOW;
        s.questionBudget=1;
        s.allowIntervention=false;
        s.rationale="early session / limited shared context";
        return s;
    }

    public static String responseInstruction(State s){
        if(s==null)return "";

        if(ORIENT.equals(s.phase)){
            return "SESSION_PHASE=ORIENT. 아직 초기 단계다. 안전/현재 문제/사용자가 원하는 도움을 우선 맞춘다. "
                    +"성급한 핵심신념 해석이나 행동과제를 피하고, 질문은 최대 1개만 한다.";
        }
        if(UNDERSTAND.equals(s.phase)){
            return "SESSION_PHASE=UNDERSTAND. 이미 나온 사실을 다시 묻지 않는다. "
                    +"고가치 질문과 잠정 formulation 사이를 오가되 질문만 연속하지 않는다. "
                    +"FACT와 INTERPRETATION을 분리한다.";
        }
        if(CHANGE.equals(s.phase)){
            return "SESSION_PHASE=CHANGE. 이해를 반복 설명하기보다 현재 maintaining mechanism과 연결된 "
                    +"개입 하나만 선택한다. 사용자의 준비도와 response_need를 존중한다.";
        }
        if(PRACTICE.equals(s.phase)){
            return "SESSION_PHASE=PRACTICE. 새 기법을 계속 추가하지 않는다. "
                    +"이미 정한 개입을 실제로 해봤는지, 무엇이 도움이/방해됐는지 REVIEW하는 것을 우선한다.";
        }
        if(CONSOLIDATE.equals(s.phase)){
            return "SESSION_PHASE=CONSOLIDATE. 효과 있었던 전략과 사용자가 스스로 해낸 변화를 강화한다. "
                    +"재발 신호와 유지 계획을 짧게 정리하고 새로운 문제를 억지로 만들지 않는다.";
        }
        if(COMPLETE.equals(s.phase)){
            return "SESSION_PHASE=COMPLETE. 완료된 목표를 계속 병리화하거나 끌어오지 않는다. "
                    +"성취를 정리하고, 사용자가 새 목표를 원할 때만 다음 목표로 넘어간다.";
        }
        return "";
    }

    public static boolean phaseAllowsAsk(State s){
        return s!=null && s.questionBudget>0 && !COMPLETE.equals(s.phase);
    }

    public static boolean phaseAllowsIntervention(State s){
        return s!=null && s.allowIntervention;
    }

    private static boolean has(String t,String... xs){
        if(t==null)return false;
        for(String x:xs)if(t.contains(x))return true;
        return false;
    }
}
