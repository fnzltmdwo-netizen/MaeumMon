package com.maeummon.app.clinical;

import android.content.Context;
import org.json.*;

public final class CentralInsightInterventionBridgeRC8 {
    private CentralInsightInterventionBridgeRC8(){}

    public static final class Bridge {
        public boolean ready=false;
        public String mechanism="";
        public String interventionId="";
        public String target="";
        public String rationale="";
        public String blockedReason="";
    }

    public static Bridge select(Context c,ClinicalDecisionRC7 d){
        Bridge b=new Bridge();
        if(c==null||d==null)return b;

        JSONObject f=CentralTherapyProfile.loadFormulation(c);
        String mechanism=f.optString("central_mechanism","");
        boolean usable=f.optBoolean("central_insight_usable",false);
        String phase=d.sessionPhase==null?"":d.sessionPhase;
        String need=f.optString("response_need","");
        int unresolved=f.optInt("unresolved_evidence_conflicts",0);

        b.mechanism=mechanism;

        if(!usable){
            b.blockedReason="CENTRAL_INSIGHT_NOT_USABLE";
            return b;
        }
        if(unresolved>0){
            b.blockedReason="UNRESOLVED_EVIDENCE_CONFLICT";
            return b;
        }
        if("ORIENT".equals(phase)||"UNDERSTAND".equals(phase)){
            b.blockedReason="SESSION_PHASE_NOT_READY";
            return b;
        }
        if("COMPLETE".equals(phase)){
            b.blockedReason="GOAL_COMPLETED";
            return b;
        }

        if("AMBIGUITY_TO_REJECTION".equals(mechanism)){
            b.interventionId="REALITY_TEST";
            b.target="interpretation_not_fact";
            b.rationale="central mechanism is ambiguity being converted into rejection certainty";
        }else if("ACTUAL_RELATIONSHIP_CHANGE".equals(mechanism)){
            b.interventionId="COMMUNICATION_SCRIPT";
            b.target="clarify_relationship_change";
            b.rationale="central mechanism suggests actual relational shift should be clarified directly";
        }else if("REAL_CONFLICT_OR_REJECTION".equals(mechanism)){
            b.interventionId="REPAIR_OR_BOUNDARY";
            b.target="repair_or_boundary";
            b.rationale="actual conflict/rejection requires repair or boundary rather than cognitive reframing";
        }else if("NORMAL_VARIATION".equals(mechanism)){
            b.interventionId="AMBIGUITY_TOLERANCE";
            b.target="tolerate_uncertainty";
            b.rationale="normal variation is being over-read as threat";
        }else if("EVALUATION_THREAT".equals(mechanism)){
            b.interventionId="FACT_VS_EVALUATION";
            b.target="separate_performance_fact_from_global_self_judgment";
            b.rationale="evaluation threat is maintaining anxiety";
        }else if("LOAD_EXCEEDS_CAPACITY".equals(mechanism)){
            b.interventionId="LOAD_REDUCTION";
            b.target="reduce_commitment_or_task_load";
            b.rationale="load exceeds current recovery capacity";
        }else if("INTERPERSONAL_THREAT".equals(mechanism)){
            b.interventionId="WORK_BOUNDARY_SCRIPT";
            b.target="reduce_interpersonal_threat_exposure";
            b.rationale="interpersonal work stress is the central maintaining mechanism";
        }else if("RECOVERY_DEFICIT".equals(mechanism)){
            b.interventionId="RECOVERY_FIRST";
            b.target="restore_regulation_capacity";
            b.rationale="recovery deficit should be treated before deeper cognitive work";
        }else if("SHORT_TERM_RELIEF_MAINTAINS_AVOIDANCE".equals(mechanism)){
            b.interventionId="GRADED_APPROACH";
            b.target="replace_avoidance_with_small_approach";
            b.rationale="short-term relief is reinforcing avoidance";
        }else{
            b.blockedReason="NO_MECHANISM_MAPPING";
            return b;
        }

        // UNDERSTANDING need blocks premature action even if other signals suggest it.
        if("UNDERSTANDING".equalsIgnoreCase(need)){
            b.blockedReason="RESPONSE_NEED_UNDERSTANDING";
            b.interventionId="";
            b.target="";
            return b;
        }

        b.ready=true;
        return b;
    }

    public static void apply(Context c,Bridge b){
        if(c==null||b==null)return;
        try{
            JSONObject f=CentralTherapyProfile.loadFormulation(c);
            f.put("central_bridge_ready",b.ready);
            f.put("central_bridge_intervention_id",b.interventionId);
            f.put("central_bridge_target",b.target);
            f.put("central_bridge_rationale",b.rationale);
            f.put("central_bridge_blocked_reason",b.blockedReason);
            f.put("central_bridge_updated_at",System.currentTimeMillis());
            CentralTherapyProfile.replaceFormulation(c,f);
        }catch(Exception ignored){}
    }

    public static String instruction(Bridge b){
        if(b==null)return "";
        if(!b.ready){
            return "CENTRAL_INSIGHT_BRIDGE_READY=false. central insight가 있어도 개입 조건이 맞지 않으면 행동기법을 서두르지 않는다. blocked_reason="
                    +b.blockedReason;
        }
        return "CENTRAL_INSIGHT_BRIDGE_READY=true. 설명과 개입을 분리하지 말고, "
                +"central mechanism과 직접 연결된 intervention 하나만 사용한다. "
                +"intervention="+b.interventionId+", target="+b.target+". "
                +"새 기법을 여러 개 나열하지 않는다.";
    }
}
