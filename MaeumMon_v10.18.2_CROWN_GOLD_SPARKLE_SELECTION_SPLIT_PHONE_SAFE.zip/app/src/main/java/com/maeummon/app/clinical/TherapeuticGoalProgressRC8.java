package com.maeummon.app.clinical;

import android.content.Context;
import org.json.*;
import java.util.*;

public final class TherapeuticGoalProgressRC8 {
    private TherapeuticGoalProgressRC8(){}

    public static final class Update {
        public String activeGoal="";
        public String goalSource="";
        public int progressDelta=0;
        public String signal="";
        public String note="";
    }

    public static Update detect(Context c,String userText){
        Update u=new Update();
        if(c==null)return u;
        String t=userText==null?"":userText;

        JSONObject p=CentralTherapyProfile.loadProfile(c);
        JSONObject f=CentralTherapyProfile.loadFormulation(c);
        u.activeGoal=p.optString("active_therapy_goal","");

        // Explicit goals have priority.
        if(containsAny(t,"내 목표는","바꾸고 싶은 건","되고 싶은 건","앞으로는")){
            String g=compact(t,180);
            u.activeGoal=g;
            u.goalSource="EXPLICIT_USER_GOAL";
            u.note="explicit goal captured";
        }

        // Infer a practical goal only if no explicit goal exists.
        if(u.activeGoal.isEmpty()){
            String leading=f.optString("leading_hypothesis","");
            if("rejection_interpretation_amplification".equals(leading)){
                u.activeGoal="애매한 관계 신호를 곧바로 거절로 확정하지 않고 견디는 힘 키우기";
                u.goalSource="FORMULATION_INFERRED";
            }else if("avoidance_negative_reinforcement".equals(leading)){
                u.activeGoal="회피 대신 감당 가능한 작은 접근 행동을 늘리기";
                u.goalSource="FORMULATION_INFERRED";
            }else if("evaluation_threat".equals(leading)){
                u.activeGoal="평가 불안을 사실과 해석으로 나누고 실제 행동을 유지하기";
                u.goalSource="FORMULATION_INFERRED";
            }else if("exhaustion_or_burnout".equals(leading)){
                u.activeGoal="무리 누적을 줄이고 회복과 경계설정을 먼저 챙기기";
                u.goalSource="FORMULATION_INFERRED";
            }
        }

        // Progress signals.
        if(containsAny(t,"전보다 덜 불안","예전보다 덜","조금 나아졌","잘 참았","거절했어",
                "피하지 않았","확인하지 않고 기다렸","생각을 바로 믿지 않았")){
            u.progressDelta=+1;
            u.signal="POSITIVE_PROGRESS";
            u.note="user reports behavior/emotion improvement";
        }
        if(containsAny(t,"다시 똑같","더 심해졌","계속 반복","전보다 더 불안","또 피했어")){
            u.progressDelta=-1;
            u.signal="SETBACK";
            u.note="user reports setback/repetition";
        }
        if(containsAny(t,"유지했어","계속 하고 있어","이번에도 해냈")){
            u.progressDelta=+1;
            u.signal="MAINTENANCE";
            u.note="new behavior maintained";
        }

        return u;
    }

    public static void apply(Context c,Update u){
        if(c==null||u==null)return;
        try{
            JSONObject p=CentralTherapyProfile.loadProfile(c);

            if(!u.activeGoal.isEmpty()){
                String old=p.optString("active_therapy_goal","");
                if(old.isEmpty() || "EXPLICIT_USER_GOAL".equals(u.goalSource)){
                    p.put("active_therapy_goal",u.activeGoal);
                    p.put("goal_source",u.goalSource);
                    p.put("goal_started_at",System.currentTimeMillis());
                }
            }

            int score=p.optInt("goal_progress_score",50);
            if(u.progressDelta!=0){
                score=Math.max(0,Math.min(100,score+(u.progressDelta*5)));
                p.put("goal_progress_score",score);

                JSONArray history=p.optJSONArray("goal_progress_history");
                if(history==null)history=new JSONArray();
                JSONObject item=new JSONObject();
                item.put("delta",u.progressDelta);
                item.put("score",score);
                item.put("signal",u.signal);
                item.put("note",u.note);
                item.put("time",System.currentTimeMillis());
                history.put(item);
                p.put("goal_progress_history",tail(history,40));
            }
            p.put("updated_at",System.currentTimeMillis());
            CentralTherapyProfile.replaceProfile(c,p);
        }catch(Exception ignored){}
    }

    public static String progressSummary(Context c){
        JSONObject p=CentralTherapyProfile.loadProfile(c);
        String goal=p.optString("active_therapy_goal","");
        int score=p.optInt("goal_progress_score",50);
        JSONArray h=p.optJSONArray("goal_progress_history");
        String trend="STABLE";
        if(h!=null&&h.length()>0){
            int pos=0,neg=0;
            int start=Math.max(0,h.length()-5);
            for(int i=start;i<h.length();i++){
                JSONObject x=h.optJSONObject(i);
                if(x==null)continue;
                int d=x.optInt("delta",0);
                if(d>0)pos++; else if(d<0)neg++;
            }
            if(pos>neg)trend="IMPROVING";
            else if(neg>pos)trend="WORSENING";
        }
        return "goal="+goal+", progress="+score+"/100, trend="+trend;
    }

    public static String promptContext(Context c){
        JSONObject p=CentralTherapyProfile.loadProfile(c);
        String goal=p.optString("active_therapy_goal","");
        String goalStatus=p.optString("last_goal_status","UNCHANGED");
        if(goal.isEmpty()||"COMPLETED".equals(goalStatus))return "";
        return "[THERAPEUTIC_GOAL]\n"
                +"goal="+goal+"\n"
                +"progress_score="+p.optInt("goal_progress_score",50)+"\n"
                +"rule=현재 대화가 이 목표와 관련 있을 때만 연결하고, 매번 억지로 목표를 끌어오지 않는다.\n";
    }

    private static JSONArray tail(JSONArray src,int max){
        JSONArray out=new JSONArray();
        int start=Math.max(0,src.length()-max);
        for(int i=start;i<src.length();i++)out.put(src.opt(i));
        return out;
    }

    private static boolean containsAny(String s,String... xs){
        for(String x:xs)if(s.contains(x))return true;
        return false;
    }
    private static String compact(String s,int max){
        s=s==null?"":s.trim();
        return s.length()<=max?s:s.substring(0,max);
    }
}
