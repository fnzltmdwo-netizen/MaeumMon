package com.maeummon.app.clinical;

import android.content.Context;
import org.json.*;

public final class InterventionPreferenceFitCalibrationRC10 {
    private InterventionPreferenceFitCalibrationRC10(){}

    public enum Mode {
        DEFAULT,
        VERBAL,
        WRITING,
        BEHAVIOR,
        OBSERVATION,
        SCRIPT,
        ULTRA_SHORT
    }

    public static final class Result {
        public Mode mode=Mode.DEFAULT;
        public boolean explicitPreference=false;
        public boolean inferredPreference=false;
        public boolean modalityChanged=false;
        public boolean mechanismPreserved=true;
        public String source="";
        public String adaptedInstruction="";
        public String rationale="";
        public String summary="";
    }

    public static Result calibrate(
            Context c,String userText,ClinicalDecisionRC7 d){

        Result r=new Result();
        if(d==null){
            r.summary="DEFAULT | NO_DECISION";
            return r;
        }

        JSONObject p=CentralTherapyProfile.loadProfile(c);
        String u=userText==null?"":userText.trim();

        Mode explicit=detectExplicit(u);
        if(explicit!=Mode.DEFAULT){
            r.mode=explicit;
            r.explicitPreference=true;
            r.source="CURRENT_USER";
        }else{
            Mode stored=readStoredPreference(p);
            if(stored!=Mode.DEFAULT){
                r.mode=stored;
                r.source="STABLE_PROFILE";
            }else{
                Mode inferred=inferFromBarriersAndHistory(p,d);
                if(inferred!=Mode.DEFAULT){
                    r.mode=inferred;
                    r.inferredPreference=true;
                    r.source="OUTCOME_BARRIER_HISTORY";
                }
            }
        }

        // Never change the clinical mechanism or selected intervention ID.
        r.mechanismPreserved=true;
        r.modalityChanged=r.mode!=Mode.DEFAULT;
        r.adaptedInstruction=instructionFor(r.mode,d);
        r.rationale=r.modalityChanged
                ?"같은 intervention/mechanism을 유지하고 전달 형태만 사용자 선호에 맞춘다."
                :"선호 신호가 부족해 기본 전달형을 유지한다.";

        persist(c,r,d);
        r.summary=r.mode.name()
                +" | explicit="+r.explicitPreference
                +" | inferred="+r.inferredPreference
                +" | source="+r.source
                +" | mechanismPreserved="+r.mechanismPreserved;
        return r;
    }

    public static Mode detectExplicit(String u){
        if(u==null||u.trim().isEmpty())return Mode.DEFAULT;

        if(containsAny(u,
                "말로 하는 게 좋아","그냥 말로","대화로 하자",
                "말하면서 정리"))
            return Mode.VERBAL;

        if(containsAny(u,
                "적는 게 좋아","글로 쓰는 게","메모하는 게",
                "써보는 게 좋아","기록하는 게 좋아"))
            return Mode.WRITING;

        if(containsAny(u,
                "생각 말고 행동","그냥 해보는 게","행동으로 해보자",
                "직접 해보는 게"))
            return Mode.BEHAVIOR;

        if(containsAny(u,
                "그냥 관찰만","지켜보는 게","바로 뭘 하긴 싫",
                "일단 보기만"))
            return Mode.OBSERVATION;

        if(containsAny(u,
                "뭐라고 말할지","문장으로 줘","대사로 줘",
                "스크립트로","그대로 보낼 말"))
            return Mode.SCRIPT;

        if(containsAny(u,
                "짧게 해줘","한 줄로","귀찮아","너무 길어",
                "최대한 짧게","간단하게"))
            return Mode.ULTRA_SHORT;

        return Mode.DEFAULT;
    }

    public static String instruction(Result r){
        if(r==null||r.mode==Mode.DEFAULT)return "";
        return "INTERVENTION_PREFERENCE_MODE="+r.mode.name()+". "
                +r.adaptedInstruction
                +" 선택한 intervention과 central mechanism은 바꾸지 않는다.";
    }

    private static String instructionFor(
            Mode mode,ClinicalDecisionRC7 d){

        String target=d==null?"":safe(d.selectedInterventionTarget);

        switch(mode){
            case VERBAL:
                return "쓰기 숙제보다 대화형 질문/말로 정리하는 방식으로 전달한다.";
            case WRITING:
                return "말로 길게 설명하기보다 1~3줄 메모 또는 짧은 기록 형식으로 바꾼다.";
            case BEHAVIOR:
                return "분석을 길게 하지 말고 실제 행동실험 하나로 변환한다.";
            case OBSERVATION:
                return "즉시 행동변화를 요구하지 말고 먼저 상황/생각/감정 중 한 항목만 관찰하게 한다.";
            case SCRIPT:
                return "실제 사용할 수 있는 짧은 문장 또는 대화 스크립트 한 개로 제공한다.";
            case ULTRA_SHORT:
                return "핵심 설명 한 문장 + 행동 한 문장 이내로 압축한다.";
            default:
                return "";
        }
    }

    private static Mode readStoredPreference(JSONObject p){
        String x=p.optString("preferred_intervention_mode","");
        try{
            if(!x.isEmpty())return Mode.valueOf(x);
        }catch(Exception ignored){}
        return Mode.DEFAULT;
    }

    private static Mode inferFromBarriersAndHistory(
            JSONObject p,ClinicalDecisionRC7 d){

        String barrier=safe(d.interventionBarrier);

        if("TOO_BIG".equals(barrier)
                ||"LOW_ENERGY".equals(barrier))
            return Mode.ULTRA_SHORT;

        if("UNCLEAR".equals(barrier))
            return Mode.SCRIPT;

        if("FEAR_OR_AVOIDANCE".equals(barrier))
            return Mode.OBSERVATION;

        JSONArray history=p.optJSONArray("intervention_preference_feedback_history");
        if(history==null)return Mode.DEFAULT;

        int writing=0,behavior=0,script=0,verbal=0,observation=0,shortMode=0;
        for(int i=Math.max(0,history.length()-10);i<history.length();i++){
            JSONObject item=history.optJSONObject(i);
            if(item==null)continue;
            String mode=item.optString("mode","");
            boolean liked=item.optBoolean("positive",false);
            if(!liked)continue;

            if("WRITING".equals(mode))writing++;
            else if("BEHAVIOR".equals(mode))behavior++;
            else if("SCRIPT".equals(mode))script++;
            else if("VERBAL".equals(mode))verbal++;
            else if("OBSERVATION".equals(mode))observation++;
            else if("ULTRA_SHORT".equals(mode))shortMode++;
        }

        int max=Math.max(writing,Math.max(behavior,
                Math.max(script,Math.max(verbal,
                Math.max(observation,shortMode)))));

        if(max<2)return Mode.DEFAULT;
        if(max==writing)return Mode.WRITING;
        if(max==behavior)return Mode.BEHAVIOR;
        if(max==script)return Mode.SCRIPT;
        if(max==verbal)return Mode.VERBAL;
        if(max==observation)return Mode.OBSERVATION;
        return Mode.ULTRA_SHORT;
    }

    public static void recordFeedback(
            Context c,String mode,boolean positive,String evidence){

        try{
            JSONObject p=CentralTherapyProfile.loadProfile(c);
            JSONArray h=p.optJSONArray("intervention_preference_feedback_history");
            if(h==null)h=new JSONArray();

            JSONObject item=new JSONObject();
            item.put("mode",mode==null?"":mode);
            item.put("positive",positive);
            item.put("evidence",compact(evidence,300));
            item.put("time",System.currentTimeMillis());
            h.put(item);

            JSONArray trimmed=new JSONArray();
            int start=Math.max(0,h.length()-20);
            for(int i=start;i<h.length();i++)trimmed.put(h.opt(i));
            p.put("intervention_preference_feedback_history",trimmed);

            if(positive && countRecentPositive(trimmed,mode)>=3){
                p.put("preferred_intervention_mode",mode);
                p.put("preferred_intervention_mode_confidence","MEDIUM");
                p.put("preferred_intervention_mode_updated_at",System.currentTimeMillis());
            }

            CentralTherapyProfile.replaceProfile(c,p);
        }catch(Exception ignored){}
    }

    private static int countRecentPositive(JSONArray a,String mode){
        int n=0;
        for(int i=Math.max(0,a.length()-10);i<a.length();i++){
            JSONObject x=a.optJSONObject(i);
            if(x==null)continue;
            if(x.optBoolean("positive",false)
                    && safe(mode).equals(x.optString("mode","")))
                n++;
        }
        return n;
    }

    private static void persist(
            Context c,Result r,ClinicalDecisionRC7 d){
        try{
            JSONObject f=CentralTherapyProfile.loadFormulation(c);
            f.put("current_intervention_preference_mode",r.mode.name());
            f.put("intervention_preference_source",r.source);
            f.put("intervention_mechanism_preserved",true);
            f.put("intervention_preference_updated_at",System.currentTimeMillis());
            CentralTherapyProfile.replaceFormulation(c,f);
        }catch(Exception ignored){}
    }

    private static boolean containsAny(String s,String... xs){
        for(String x:xs)if(s.contains(x))return true;
        return false;
    }

    private static String compact(String s,int max){
        s=s==null?"":s.trim();
        return s.length()<=max?s:s.substring(0,max);
    }

    private static String safe(String s){
        return s==null?"":s;
    }
}
