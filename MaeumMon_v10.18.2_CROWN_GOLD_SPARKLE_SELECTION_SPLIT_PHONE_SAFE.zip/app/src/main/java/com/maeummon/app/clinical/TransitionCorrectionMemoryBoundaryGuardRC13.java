package com.maeummon.app.clinical;

import android.content.Context;
import org.json.*;

public final class TransitionCorrectionMemoryBoundaryGuardRC13 {
    private TransitionCorrectionMemoryBoundaryGuardRC13(){}

    public enum Match {
        NONE,
        EXACT_TRANSITION,
        SAME_CONTEXT_WEAK,
        CONTEXT_MISMATCH,
        STALE,
        BLOCKED
    }

    public static final class Result {
        public boolean evaluated=false;
        public boolean reusable=false;
        public boolean exact=false;
        public boolean blocked=false;
        public Match match=Match.NONE;
        public String correctedCause="";
        public String correctedReason="";
        public String sourceContext="";
        public String currentContext="";
        public String sourceFrom="";
        public String sourceTo="";
        public String currentFrom="";
        public String currentTo="";
        public String reason="";
        public String summary="";
    }

    public static Result retrieve(Context c, ClinicalDecisionRC7 d){
        Result r=new Result();
        if(c==null||d==null){
            r.summary="NONE | MISSING_INPUT";
            return r;
        }

        r.evaluated=true;

        JSONObject p=CentralTherapyProfile.loadProfile(c);
        JSONObject f=CentralTherapyProfile.loadFormulation(c);
        JSONArray h=p.optJSONArray("transition_explanation_correction_history");

        r.currentContext=f.optString("current_context_scope","UNKNOWN");
        r.currentFrom=safe(d.decisionTransitionFromState);
        r.currentTo=safe(d.decisionTransitionToState);

        if(h==null||h.length()==0){
            r.reason="NO_CORRECTION_HISTORY";
            return finish(r);
        }

        long now=System.currentTimeMillis();
        long staleMs=90L*24L*60L*60L*1000L;

        for(int i=h.length()-1;i>=0;i--){
            JSONObject x=h.optJSONObject(i);
            if(x==null)continue;

            String from=x.optString("decision_transition_from","");
            String to=x.optString("decision_transition_to","");
            String context=x.optString("context_scope","UNKNOWN");
            long time=x.optLong("time",0L);

            if(time>0 && (now-time)>staleMs){
                continue;
            }

            boolean exactTransition=
                    !from.isEmpty()
                    &&!to.isEmpty()
                    &&from.equals(r.currentFrom)
                    &&to.equals(r.currentTo);

            boolean sameContext=
                    !context.isEmpty()
                    &&context.equals(r.currentContext);

            if(exactTransition && sameContext){
                String cause=x.optString("corrected_cause","");
                if(!correctionHasEligibleProvenance(
                        p,from,to,context,cause)){
                    r.match=Match.BLOCKED;
                    r.blocked=true;
                    r.reason="CORRECTION_PROVENANCE_NOT_ELIGIBLE";
                    continue;
                }

                r.reusable=true;
                r.exact=true;
                r.match=Match.EXACT_TRANSITION;
                r.correctedCause=x.optString("corrected_cause","");
                r.correctedReason=x.optString("corrected_reason","");
                r.sourceContext=context;
                r.sourceFrom=from;
                r.sourceTo=to;
                r.reason="EXACT_TRANSITION_AND_CONTEXT_MATCH";
                return finish(r);
            }

            // Same-context correction alone is not automatically reusable.
            if(sameContext){
                r.match=Match.SAME_CONTEXT_WEAK;
                r.sourceContext=context;
                r.sourceFrom=from;
                r.sourceTo=to;
                r.reason="SAME_CONTEXT_BUT_DIFFERENT_TRANSITION";
                continue;
            }

            if(!sameContext){
                r.match=Match.CONTEXT_MISMATCH;
                r.reason="CORRECTION_CONTEXT_MISMATCH";
            }
        }

        if(r.match==Match.NONE){
            r.match=Match.STALE;
            r.reason="NO_FRESH_MATCHING_CORRECTION";
        }

        return finish(r);
    }

    public static boolean shouldApply(Result r){
        return r!=null
                &&r.evaluated
                &&r.reusable
                &&r.exact
                &&r.match==Match.EXACT_TRANSITION;
    }

    public static String instruction(Result r){
        if(r==null||!r.evaluated)return "";

        if(shouldApply(r)){
            return "TRANSITION_CORRECTION_MEMORY=EXACT_MATCH. 과거 사용자 교정은 동일한 전환과 동일한 맥락에서만 약한 설명 prior로 재사용할 수 있다: "
                    +r.correctedReason;
        }

        if(r.match==Match.SAME_CONTEXT_WEAK){
            return "TRANSITION_CORRECTION_MEMORY=BOUNDARY. 같은 맥락의 과거 교정이 있어도 현재 전환이 다르므로 자동 재사용하지 않는다.";
        }

        if(r.match==Match.CONTEXT_MISMATCH){
            return "TRANSITION_CORRECTION_MEMORY=BLOCKED_CONTEXT. 다른 맥락의 교정은 현재 전환 설명에 사용하지 않는다.";
        }

        if(r.match==Match.STALE){
            return "TRANSITION_CORRECTION_MEMORY=STALE_OR_NONE. 오래되었거나 정확히 맞는 교정이 없어 현재 설명은 현재 근거로 새로 판단한다.";
        }

        return "";
    }

    public static void annotateLatestCorrectionWithContext(
            Context c,
            ClinicalDecisionRC7 d){

        if(c==null||d==null)return;

        JSONObject p=CentralTherapyProfile.loadProfile(c);
        JSONObject f=CentralTherapyProfile.loadFormulation(c);
        JSONArray h=p.optJSONArray("transition_explanation_correction_history");
        if(h==null||h.length()==0)return;

        JSONObject last=h.optJSONObject(h.length()-1);
        if(last==null)return;

        try{
            if(last.optString("context_scope","").isEmpty())
                last.put("context_scope",
                        f.optString("current_context_scope","UNKNOWN"));

            if(last.optString("mechanism","").isEmpty())
                last.put("mechanism",safe(d.centralMechanism));

            if(last.optString("intervention_id","").isEmpty())
                last.put("intervention_id",safe(d.selectedInterventionId));

            last.put("correction_boundary_schema","6.8.4");
            last.put("correction_context_bound",true);
            p.put("transition_explanation_correction_history",h);
            CentralTherapyProfile.replaceProfile(c,p);
        }catch(Exception ignored){}
    }


    private static boolean correctionHasEligibleProvenance(
            JSONObject profile,
            String from,
            String to,
            String context,
            String cause){

        JSONArray p=profile.optJSONArray(
                "transition_correction_commit_provenance_history");

        if(p==null)return false;

        String transition=
                safe(from)+"->"+safe(to)+"::"+safe(context);

        for(int i=p.length()-1;i>=0;i--){
            JSONObject x=p.optJSONObject(i);
            if(x==null)continue;

            if(!transition.equals(
                    x.optString("transition_key","")))
                continue;

            if(!safe(cause).equals(
                    x.optString("corrected_cause","")))
                continue;

            return CorrectionProvenanceIntegrityBackfillQuarantineRC14
                    .rowEligibleForCorrectionMemory(x);
        }

        return false;
    }

    private static Result finish(Result r){
        r.summary=r.match.name()
                +" | reusable="+r.reusable
                +" | exact="+r.exact
                +" | sourceContext="+r.sourceContext
                +" | currentContext="+r.currentContext
                +" | source="+r.sourceFrom+"->"+r.sourceTo
                +" | current="+r.currentFrom+"->"+r.currentTo
                +" | reason="+r.reason;
        return r;
    }

    private static String safe(String s){
        return s==null?"":s;
    }
}
