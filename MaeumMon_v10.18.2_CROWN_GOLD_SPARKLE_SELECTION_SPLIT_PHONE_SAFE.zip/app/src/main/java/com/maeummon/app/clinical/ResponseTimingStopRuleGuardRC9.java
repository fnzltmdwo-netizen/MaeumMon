package com.maeummon.app.clinical;

import android.content.Context;
import org.json.*;
import java.util.*;

public final class ResponseTimingStopRuleGuardRC9 {
    private ResponseTimingStopRuleGuardRC9(){}

    public static final class Check {
        public boolean pass=true, rewriteRequired=false;
        public final List<String> failures=new ArrayList<>();
        public String instruction="", summary="PASS";
        void fail(String code){ pass=false; rewriteRequired=true; failures.add(code); }
    }

    public static Check inspect(Context c,String userText,String response,ClinicalDecisionRC7 d){
        Check x=new Check();
        JSONObject f=CentralTherapyProfile.loadFormulation(c);
        JSONObject s=CentralTherapyProfile.loadSessionState(c);

        String u=userText==null?"":userText.trim();
        String r=response==null?"":response.trim();
        String move=d==null?"":safe(d.move);
        String phase=d==null?"":safe(d.sessionPhase);

        int qBudget=d==null?0:d.phaseQuestionBudget;
        int turnCount=s.optInt("turn_count",0);
        int unresolved=f.optInt("unresolved_evidence_conflicts",0);
        boolean reopened=f.optBoolean("formulation_reopened",false);
        boolean centralUsable=f.optBoolean("central_insight_usable",false);
        String confidence=f.optString("confidence","LOW");

        if("ASK".equals(move) && centralUsable && unresolved==0 && !reopened
                && !"LOW".equalsIgnoreCase(confidence) && qBudget<=1 && turnCount>=3)
            x.fail("ASK_CONTINUES_AFTER_FORMULATION_READY");

        if("ASK".equals(move) && qBudget<=0)
            x.fail("ASK_AFTER_BUDGET_EXHAUSTED");

        if("FORMULATE".equals(move) && d!=null && d.target!=null && !d.target.trim().isEmpty()
                && !targetLikelyAnswered(d.target,u) && "UNDERSTAND".equals(phase) && !centralUsable)
            x.fail("FORMULATE_BEFORE_KEY_DISCRIMINATOR");

        if("INTERVENE".equals(move) && (reopened || unresolved>0))
            x.fail("INTERVENE_BEFORE_FORMULATION_STABILIZES");

        if(("PRACTICE".equals(phase)||"CONSOLIDATE".equals(phase)) && "ASK".equals(move)
                && containsAny(r,"무슨 일이 있었어?","처음부터 말해줄래?","요즘 가장 힘든 게 뭐야?","어떤 문제로 상담하고 싶어?"))
            x.fail("LATE_PHASE_BROAD_REOPENING");

        if("COMPLETE".equals(phase) && ("ASK".equals(move)||"INTERVENE".equals(move)))
            x.fail("ACTIVE_WORK_AFTER_COMPLETE");

        if(containsAny(u,"결론만","그래서 결론은","그래서 뭐가 맞아","답만 말해","그래서 어떻게 해야")
                && "ASK".equals(move) && centralUsable)
            x.fail("ASSESSMENT_CONTINUES_AFTER_DIRECT_ANSWER_REQUEST");

        if(containsAny(u,"질문 그만","이제 질문 말고","그만 물어봐","정리해줘","이제 답해줘")
                && "ASK".equals(move))
            x.fail("ASK_IGNORES_USER_STOP_SIGNAL");

        if(containsAny(u,"그건 아니야","완전 반대야","정정할게","아까 말 잘못했어")
                && "INTERVENE".equals(move))
            x.fail("INTERVENTION_IGNORES_NEW_CONTRADICTION");

        int askStreak=s.optInt("ask_streak",0);
        if("ASK".equals(move) && askStreak>=3 && !reopened && unresolved==0)
            x.fail("EXCESSIVE_ASK_STREAK");

        if(!x.pass) x.instruction=buildInstruction(x,d,centralUsable,unresolved,reopened,qBudget);
        x.summary=x.pass?"PASS":"FAIL "+x.failures;
        return x;
    }

    public static void updateTimingState(Context c,ClinicalDecisionRC7 d){
        if(c==null)return;
        JSONObject s=CentralTherapyProfile.loadSessionState(c);
        try{
            String move=d==null?"":safe(d.move);
            int streak=s.optInt("ask_streak",0);
            s.put("ask_streak","ASK".equals(move)?streak+1:0);
            s.put("last_timing_move",move);
            s.put("last_phase",d==null?"":safe(d.sessionPhase));
            s.put("last_phase_question_budget",d==null?0:d.phaseQuestionBudget);
            s.put("timing_state_updated_at",System.currentTimeMillis());
            CentralTherapyProfile.replaceSessionState(c,s);
        }catch(Exception ignored){}
    }

    private static String buildInstruction(Check x,ClinicalDecisionRC7 d,
            boolean centralUsable,int unresolved,boolean reopened,int budget){
        return "RESPONSE_TIMING_GUARD_FAIL=true. 질문/정리/개입 타이밍을 다시 맞춘다. "
                +"formulation이 충분하면 ASK를 멈추고, 핵심 discriminator가 비어 있으면 성급한 FORMULATE를 피한다. "
                +"reopen/conflict 상태에서는 INTERVENE를 미룬다. "
                +"사용자가 질문 중단이나 결론 요청을 명시하면 그 요청을 우선한다. "
                +"central_usable="+centralUsable+", unresolved="+unresolved
                +", reopened="+reopened+", question_budget="+budget
                +", current_move="+(d==null?"":safe(d.move))+", failures="+x.failures;
    }

    private static boolean targetLikelyAnswered(String t,String u){
        if(t==null||t.isEmpty())return true;
        if(t.contains("baseline"))return containsAny(u,"원래","예전","최근","전부터","갑자기");
        if(t.contains("conflict"))return containsAny(u,"싸","갈등","다툼","없어","없었");
        if(t.contains("evaluation"))return containsAny(u,"평가","실수","무능","보일까","상사");
        if(t.contains("episode"))return u.length()>60||containsAny(u,"어제","오늘","그때","최근");
        if(t.contains("relief"))return containsAny(u,"편해","안도","피하고","당장은");
        return u.length()>25;
    }

    private static boolean containsAny(String s,String... xs){
        if(s==null)return false;
        for(String x:xs)if(x!=null&&!x.isEmpty()&&s.contains(x))return true;
        return false;
    }

    private static String safe(String s){return s==null?"":s;}
}
