package com.maeummon.app.clinical;

import android.content.Context;
import org.json.*;
import java.util.*;

public final class InterventionSelectorRC8 {
    private InterventionSelectorRC8(){}

    public static final class Selection {
        public String interventionId="";
        public String target="";
        public String rationale="";
        public String directive="";
        public double score=0.0;
        public ClinicalKnowledgeRC7.Unit unit;
    }

    public static Selection select(Context c,ClinicalDecisionRC7 d,String userText){
        Selection best=new Selection();
        JSONObject f=CentralTherapyProfile.loadFormulation(c);
        String leading=f.optString("leading_hypothesis","");
        String need=f.optString("response_need","");
        String t=userText==null?"":userText;

        List<Candidate> cs=new ArrayList<>();

        if("rejection_interpretation_amplification".equals(leading)){
            cs.add(new Candidate("REALITY_TEST","evidence_check",0.86,
                    "사실과 해석을 분리하고 대안가설을 하나 검토한다."));
            cs.add(new Candidate("AMBIGUITY_TOLERANCE","alternative_hypothesis",0.74,
                    "애매함을 즉시 거절로 확정하지 않는 연습을 제안한다."));
        }

        if("relationship_distance_change".equals(leading)){
            cs.add(new Candidate("COMMUNICATION_SCRIPT","communication",0.82,
                    "추측 대신 부담 낮은 확인 대화를 한 번 시도하도록 돕는다."));
            cs.add(new Candidate("BOUNDARY_CLARIFICATION","need_clarification",0.66,
                    "관계에서 원하는 것과 감당 가능한 범위를 명확히 한다."));
        }

        if("actual_rejection_or_conflict".equals(leading)){
            cs.add(new Candidate("REPAIR_OR_BOUNDARY","communication",0.84,
                    "갈등 수리 또는 경계설정 중 한 가지를 선택해 실행하게 한다."));
        }

        if("evaluation_threat".equals(leading)){
            cs.add(new Candidate("FACT_VS_EVALUATION","evidence_check",0.85,
                    "실제 피드백과 스스로 만든 평가 의미를 분리한다."));
            cs.add(new Candidate("BEHAVIORAL_EXPERIMENT","action",0.72,
                    "작은 업무 행동으로 실제 평가 예측을 확인한다."));
        }

        if("workload_stress".equals(leading)){
            cs.add(new Candidate("LOAD_REDUCTION","action",0.88,
                    "오늘 줄이거나 미룰 업무 하나를 정한다."));
        }

        if("interpersonal_work_stress".equals(leading)){
            cs.add(new Candidate("WORK_BOUNDARY_SCRIPT","communication",0.82,
                    "직장 관계에서 사용할 짧은 경계 문장을 만든다."));
        }

        if("exhaustion_or_burnout".equals(leading)){
            cs.add(new Candidate("RECOVERY_FIRST","regulation",0.90,
                    "문제해결보다 회복 행동 하나를 먼저 배치한다."));
        }

        if("avoidance_negative_reinforcement".equals(leading)){
            cs.add(new Candidate("GRADED_APPROACH","action",0.92,
                    "회피를 완전히 끊지 말고 가장 작은 접근 행동 하나를 정한다."));
            cs.add(new Candidate("COST_BENEFIT","cost_benefit",0.70,
                    "회피의 단기 이득과 장기 비용을 비교한다."));
        }

        // Response need modifies candidate ranking.
        for(Candidate cnd:cs){
            double s=cnd.base;
            if("UNDERSTANDING".equalsIgnoreCase(need)){
                if(cnd.id.contains("SCRIPT")||cnd.id.contains("ACTION")||cnd.id.contains("APPROACH"))s-=0.18;
                if("evidence_check".equals(cnd.target)||"need_clarification".equals(cnd.target))s+=0.08;
            }
            if("ACTION".equalsIgnoreCase(need)){
                if("action".equals(cnd.target)||"communication".equals(cnd.target))s+=0.12;
            }
            if(containsAny(t,"지금 너무 불안","진정이 안","숨이 막")){
                if("regulation".equals(cnd.target))s+=0.20;
                else s-=0.10;
            }

            ClinicalKnowledgeRC7.Unit u=bestInterventionUnit(c,cnd.target,d);
            if(u!=null)s+=Math.max(0,Math.min(0.10,(u.weight-0.5)*0.20));

            if(s>best.score){
                best.score=s;
                best.interventionId=cnd.id;
                best.target=cnd.target;
                best.rationale="leading="+leading+", need="+need+", target="+cnd.target;
                best.directive=cnd.directive;
                best.unit=u;
            }
        }

        // Generic fallback based on available IDU.
        if(best.interventionId.isEmpty()){
            ClinicalKnowledgeRC7.Unit u=bestGenericIntervention(c,d);
            if(u!=null){
                best.interventionId="GENERIC_IDU";
                best.target=u.target;
                best.unit=u;
                best.score=0.55;
                best.rationale="generic IDU fallback";
                best.directive=!u.intervention.isEmpty()?u.intervention:u.principle;
            }else{
                best.interventionId="ONE_SMALL_ACTION";
                best.target="action";
                best.score=0.45;
                best.rationale="safe fallback";
                best.directive="현재 formulation과 직접 연결되는 가장 작은 행동 하나만 제안한다.";
            }
        }
        return best;
    }

    public static String instruction(Selection s){
        if(s==null)return "개입 하나만 제안한다.";
        StringBuilder b=new StringBuilder();
        b.append("개입은 하나만 제안한다. ");
        b.append("intervention=").append(s.interventionId).append(". ");
        b.append(s.directive).append(" ");
        if(s.unit!=null && !s.unit.intervention.isEmpty()){
            b.append("근거 IDU 요지: ").append(s.unit.intervention).append(" ");
        }
        b.append("사용자가 바로 실행할 수 있는 크기로 줄이고, 여러 방법을 한꺼번에 나열하지 않는다.");
        return b.toString();
    }

    private static ClinicalKnowledgeRC7.Unit bestInterventionUnit(
            Context c,String target,ClinicalDecisionRC7 d){
        ClinicalKnowledgeRC7.Unit best=null;
        double bs=-999;
        for(ClinicalKnowledgeRC7.Unit u:ClinicalKnowledgeRC7.all(c)){
            if(!"IDU".equals(u.type))continue;
            if(target!=null&&!target.isEmpty()&&!target.equals(u.target))continue;
            double s=u.weight;
            int overlap=0;
            for(String sig:u.signals)if(d.signals.contains(sig))overlap++;
            s+=overlap*0.08;
            if(s>bs){bs=s;best=u;}
        }
        return best;
    }

    private static ClinicalKnowledgeRC7.Unit bestGenericIntervention(
            Context c,ClinicalDecisionRC7 d){
        ClinicalKnowledgeRC7.Unit best=null;
        double bs=-999;
        for(ClinicalKnowledgeRC7.Unit u:ClinicalKnowledgeRC7.all(c)){
            if(!"IDU".equals(u.type))continue;
            int overlap=0;
            for(String sig:u.signals)if(d.signals.contains(sig))overlap++;
            if(overlap==0)continue;
            double s=u.weight+overlap*0.08;
            if(s>bs){bs=s;best=u;}
        }
        return best;
    }

    private static final class Candidate{
        final String id,target,directive;
        final double base;
        Candidate(String id,String target,double base,String directive){
            this.id=id;this.target=target;this.base=base;this.directive=directive;
        }
    }

    private static boolean containsAny(String s,String... xs){
        for(String x:xs)if(s.contains(x))return true;
        return false;
    }
}
