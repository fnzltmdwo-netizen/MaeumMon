package com.maeummon.app;

import android.content.Context;
import java.util.Locale;

/** Keeps one counseling session moving instead of circling in one phase. */
public final class SessionPhaseEngineV53 {
    private SessionPhaseEngineV53() {}

    public static String buildContext(Context c, String userMessage) {
        String t = userMessage == null ? "" : userMessage.toLowerCase(Locale.KOREA);
        boolean action = has(t, "어떻게", "어케", "뭐라고", "방법", "해야", "해볼까", "바꾸고", "고치고");
        boolean depth = has(t, "왜 나는", "근본", "뿌리", "어릴 때", "예전부터", "왜 이래");
        boolean review = has(t, "해봤", "말해봤", "해보니까", "그 뒤", "결과", "됐어", "실패", "성공");
        boolean close = has(t, "오늘은 여기", "마무리", "정리해줘", "그만", "끝낼", "이제 됐");
        String hint = close ? "INTEGRATE" : review ? "REVIEW" : action ? "CHANGE" : depth ? "EXPLORE_DEPTH" : "EXPLORE_OR_FORMULATE";
        return "[SESSION PHASE v5.3]\n"
                + "phase_hint=" + hint + ".\n"
                + "- 가능한 단계: STABILIZE → EXPLORE → FORMULATE → CHANGE → PRACTICE → REVIEW → INTEGRATE. 순서는 고정 철도가 아니라 현재 필요에 따른 지도다.\n"
                + "- EXPLORE에서 같은 질문을 반복하지 않는다. 핵심 구조가 충분해지면 FORMULATE로 이동한다.\n"
                + "- 사용자가 행동을 원하면 안전/핵심정보가 충분한 한 CHANGE/PRACTICE로 간다. 다시 원인 탐색으로 후퇴하지 않는다.\n"
                + "- 개입을 실제로 해봤다는 새 정보가 나오면 REVIEW에서 EXPECTED vs ACTUAL을 먼저 본다. 성공/실패 모두 formulation의 새 증거다.\n"
                + "- 사용자가 마무리를 원하면 INTEGRATE에서 오늘 발견→변화 목표→다음 연결고리를 정리하고 새 질문을 열지 않는다.\n"
                + "- 정서가 급격히 올라가거나 위험하면 어느 단계에서든 STABILIZE로 이동할 수 있다.\n"
                + "현재 스레드는 아래 ACTIVE_SESSION_MEMORY를 우선 참고하고, phase_hint는 보조 신호로만 사용한다.";
    }

    public static String prompt() {
        return "[SESSION PHASE v5.3] STABILIZE/EXPLORE/FORMULATE/CHANGE/PRACTICE/REVIEW/INTEGRATE 중 지금 단계를 선택하고, 같은 단계에 불필요하게 머물지 않는다. 행동 요청이면 CHANGE로, 실행 결과가 있으면 REVIEW로, 명시적 마무리면 INTEGRATE로 이동한다.";
    }

    private static boolean has(String t, String... xs) {
        for (String x : xs) if (t.contains(x.toLowerCase(Locale.KOREA))) return true;
        return false;
    }
}
