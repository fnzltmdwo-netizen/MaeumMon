package com.maeummon.app.clinical;

import android.content.Context;
import org.json.*;

public final class PolicyMemoryConflictOverrideResolutionRC11 {
    private PolicyMemoryConflictOverrideResolutionRC11(){}

    public enum Resolution {
        NONE,
        CURRENT_WINS,
        POLICY_SUPPORTS_CURRENT,
        POLICY_MODE_ONLY,
        POLICY_DOSE_ONLY,
        POLICY_MODE_AND_DOSE,
        BLOCKED
    }

    public static final class Result {
        public Resolution resolution=Resolution.NONE;
        public boolean conflictDetected=false;
        public boolean policyCanAffectIntervention=false;
        public boolean policyCanAffectMode=false;
        public boolean policyCanAffectDose=false;
        public String currentIntervention="";
        public String policyIntervention="";
        public String currentMode="";
        public String policyMode="";
        public String currentDose="";
        public String policyDose="";
        public String reason="";
        public String summary="";
    }

    public static Result resolve(
            Context c,ClinicalDecisionRC7 d,
            PolicyMemoryRetrievalContextMatchGuardRC11.Result policy){

        Result r=new Result();
        if(d==null || policy==null){
            r.resolution=Resolution.BLOCKED;
            r.reason="NO_DECISION_OR_POLICY";
            return finish(r);
        }

        r.currentIntervention=safe(d.selectedInterventionId);
        r.policyIntervention=safe(policy.policyInterventionId);
        r.currentMode=safe(d.interventionPreferenceMode);
        r.policyMode=safe(policy.policyMode);
        r.currentDose=safe(d.interventionDose);
        r.policyDose=safe(policy.policyDose);

        if(!policy.applicable){
            r.resolution=Resolution.BLOCKED;
            r.reason="POLICY_NOT_APPLICABLE";
            return finish(r);
        }

        boolean interventionConflict=
                !r.policyIntervention.isEmpty()
                && !r.currentIntervention.isEmpty()
                && !r.policyIntervention.equals(r.currentIntervention);

        boolean modeConflict=
                !r.policyMode.isEmpty()
                && !r.currentMode.isEmpty()
                && !"DEFAULT".equals(r.currentMode)
                && !r.policyMode.equals(r.currentMode);

        boolean doseConflict=
                !r.policyDose.isEmpty()
                && !r.currentDose.isEmpty()
                && !"NONE".equals(r.currentDose)
                && !r.policyDose.equals(r.currentDose);

        r.conflictDetected=
                interventionConflict || modeConflict || doseConflict;

        // Highest priority: current bridge always wins intervention conflict.
        if(interventionConflict){
            r.resolution=Resolution.CURRENT_WINS;
            r.policyCanAffectIntervention=false;
            r.policyCanAffectMode=false;
            r.policyCanAffectDose=false;
            r.reason="CURRENT_BRIDGE_INTERVENTION_OVERRIDES_POLICY";
            persist(c,r);
            return finish(r);
        }

        // If same intervention, policy may only assist delivery preferences.
        r.policyCanAffectIntervention=
                !r.currentIntervention.isEmpty()
                && r.currentIntervention.equals(r.policyIntervention);

        boolean currentModeDefault=
                r.currentMode.isEmpty()
                ||"DEFAULT".equals(r.currentMode);

        boolean currentDoseUnset=
                r.currentDose.isEmpty()
                ||"NONE".equals(r.currentDose);

        if(currentModeDefault
                && !r.policyMode.isEmpty()
                && currentDoseUnset
                && !r.policyDose.isEmpty()){

            r.resolution=Resolution.POLICY_MODE_AND_DOSE;
            r.policyCanAffectMode=true;
            r.policyCanAffectDose=true;
            r.reason="CURRENT_DELIVERY_UNSPECIFIED_POLICY_CAN_FILL";
            persist(c,r);
            return finish(r);
        }

        if(currentModeDefault && !r.policyMode.isEmpty()){
            r.resolution=Resolution.POLICY_MODE_ONLY;
            r.policyCanAffectMode=true;
            r.reason="CURRENT_MODE_DEFAULT";
            persist(c,r);
            return finish(r);
        }

        if(currentDoseUnset && !r.policyDose.isEmpty()){
            r.resolution=Resolution.POLICY_DOSE_ONLY;
            r.policyCanAffectDose=true;
            r.reason="CURRENT_DOSE_UNSET";
            persist(c,r);
            return finish(r);
        }

        // Explicit/currently inferred current delivery always wins conflicts.
        if(modeConflict || doseConflict){
            r.resolution=Resolution.CURRENT_WINS;
            r.policyCanAffectMode=false;
            r.policyCanAffectDose=false;
            r.reason="CURRENT_DELIVERY_PREFERENCE_OVERRIDES_POLICY";
            persist(c,r);
            return finish(r);
        }

        r.resolution=Resolution.POLICY_SUPPORTS_CURRENT;
        r.reason="POLICY_ALIGNS_WITH_CURRENT";
        persist(c,r);
        return finish(r);
    }

    public static String instruction(Result r){
        if(r==null)return "";

        switch(r.resolution){
            case CURRENT_WINS:
                return "POLICY_CONFLICT_RESOLUTION=CURRENT_WINS. 과거 policy와 현재 판단이 다르면 현재 bridge/formulation/preference/dose를 유지한다.";
            case POLICY_MODE_ONLY:
                return "POLICY_CONFLICT_RESOLUTION=POLICY_MODE_ONLY. 현재 mode가 비어 있을 때만 과거에 잘 맞았던 mode를 보조적으로 사용한다.";
            case POLICY_DOSE_ONLY:
                return "POLICY_CONFLICT_RESOLUTION=POLICY_DOSE_ONLY. 현재 dose가 정해지지 않았을 때만 과거 dose를 참고한다.";
            case POLICY_MODE_AND_DOSE:
                return "POLICY_CONFLICT_RESOLUTION=POLICY_MODE_AND_DOSE. intervention은 현재 선택을 유지하고 비어 있는 delivery mode/dose만 과거 policy로 채운다.";
            case POLICY_SUPPORTS_CURRENT:
                return "POLICY_CONFLICT_RESOLUTION=SUPPORTS_CURRENT. 과거 policy가 현재 판단과 일치하므로 confidence를 보조 신호로만 사용한다.";
            default:
                return "";
        }
    }

    public static void applyAllowedBias(
            Result r,ClinicalDecisionRC7 d){

        if(r==null||d==null)return;

        if(r.policyCanAffectMode
                && (d.interventionPreferenceMode==null
                    ||d.interventionPreferenceMode.isEmpty()
                    ||"DEFAULT".equals(d.interventionPreferenceMode))){

            d.interventionPreferenceMode=r.policyMode;
            d.interventionPreferenceSource="POLICY_MEMORY";
            d.interventionPreferenceModalityChanged=true;
        }

        if(r.policyCanAffectDose
                && (d.interventionDose==null
                    ||d.interventionDose.isEmpty()
                    ||"NONE".equals(d.interventionDose))){

            d.interventionDose=r.policyDose;
            d.interventionDoseRationale="POLICY_MEMORY_FILL_ONLY";
        }
    }

    private static void persist(Context c,Result r){
        try{
            JSONObject f=CentralTherapyProfile.loadFormulation(c);
            f.put("policy_conflict_detected",r.conflictDetected);
            f.put("policy_conflict_resolution",r.resolution.name());
            f.put("policy_conflict_reason",r.reason);
            f.put("policy_conflict_current_intervention",r.currentIntervention);
            f.put("policy_conflict_policy_intervention",r.policyIntervention);
            f.put("policy_conflict_updated_at",System.currentTimeMillis());
            CentralTherapyProfile.replaceFormulation(c,f);
        }catch(Exception ignored){}
    }

    private static Result finish(Result r){
        r.summary=r.resolution.name()
                +" | conflict="+r.conflictDetected
                +" | interventionBias="+r.policyCanAffectIntervention
                +" | modeBias="+r.policyCanAffectMode
                +" | doseBias="+r.policyCanAffectDose
                +" | reason="+r.reason;
        return r;
    }

    private static String safe(String s){
        return s==null?"":s;
    }
}
