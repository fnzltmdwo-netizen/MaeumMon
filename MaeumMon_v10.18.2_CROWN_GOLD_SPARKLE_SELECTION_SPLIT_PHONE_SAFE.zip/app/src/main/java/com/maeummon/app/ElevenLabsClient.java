package com.maeummon.app;

import android.content.Context;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.os.Handler;
import android.os.Looper;

import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ElevenLabsClient {

    public interface Listener {
        void onStarted();
        void onSuccess();
        void onError(String message);
    }

    private static final ExecutorService EXECUTOR = Executors.newSingleThreadExecutor();
    private static final Handler MAIN = new Handler(Looper.getMainLooper());
    private static MediaPlayer player;
    private static HttpURLConnection activeConnection;

    public static synchronized void stop() {
        try {
            if (activeConnection != null) activeConnection.disconnect();
        } catch (Exception ignored) {}
        activeConnection = null;

        try {
            if (player != null) {
                player.stop();
                player.release();
            }
        } catch (Exception ignored) {}
        player = null;
    }

    public static void speak(Context context, String apiKey, String voiceId, String modelId,
                             String text, Listener listener) {
        if (text == null || text.trim().isEmpty()) return;
        if (apiKey == null || apiKey.trim().isEmpty() || voiceId == null || voiceId.trim().isEmpty()) {
            if (listener != null) listener.onError("ElevenLabs API Key 또는 Voice ID가 비어 있어.");
            return;
        }

        final Context appContext = context.getApplicationContext();
        final String safeModel = (modelId == null || modelId.trim().isEmpty())
                ? "eleven_multilingual_v2" : modelId.trim();
        final String cleanText = text.replace("\n", " ").trim();

        EXECUTOR.execute(() -> {
            HttpURLConnection conn = null;
            File audioFile = null;
            try {
                stop();
                if (listener != null) MAIN.post(listener::onStarted);

                String endpoint = "https://api.elevenlabs.io/v1/text-to-speech/"
                        + voiceId.trim() + "?output_format=mp3_44100_128";
                conn = (HttpURLConnection) new URL(endpoint).openConnection();
                activeConnection = conn;
                conn.setRequestMethod("POST");
                conn.setConnectTimeout(15000);
                conn.setReadTimeout(45000);
                conn.setDoOutput(true);
                conn.setRequestProperty("Accept", "audio/mpeg");
                conn.setRequestProperty("Content-Type", "application/json");
                conn.setRequestProperty("xi-api-key", apiKey.trim());

                JSONObject voiceSettings = new JSONObject();
                voiceSettings.put("stability", 0.56);
                voiceSettings.put("similarity_boost", 0.78);
                voiceSettings.put("style", 0.18);
                voiceSettings.put("use_speaker_boost", true);
                voiceSettings.put("speed", 0.93);

                JSONObject body = new JSONObject();
                body.put("text", cleanText);
                body.put("model_id", safeModel);
                body.put("voice_settings", voiceSettings);

                byte[] request = body.toString().getBytes(StandardCharsets.UTF_8);
                try (OutputStream os = new BufferedOutputStream(conn.getOutputStream())) {
                    os.write(request);
                    os.flush();
                }

                int status = conn.getResponseCode();
                if (status < 200 || status >= 300) {
                    InputStream err = conn.getErrorStream();
                    String detail = err == null ? "HTTP " + status : readUtf8(err);
                    throw new Exception("ElevenLabs 오류 " + status + ": " + detail);
                }

                audioFile = File.createTempFile("maeummon_eleven_", ".mp3", appContext.getCacheDir());
                try (InputStream in = new BufferedInputStream(conn.getInputStream());
                     FileOutputStream fos = new FileOutputStream(audioFile)) {
                    byte[] buffer = new byte[8192];
                    int len;
                    while ((len = in.read(buffer)) != -1) fos.write(buffer, 0, len);
                }

                final File finalAudioFile = audioFile;
                MAIN.post(() -> playFile(finalAudioFile, listener));
            } catch (Exception e) {
                if (audioFile != null) {
                    try { audioFile.delete(); } catch (Exception ignored) {}
                }
                final String msg = e.getMessage() == null ? "ElevenLabs 음성 생성에 실패했어." : e.getMessage();
                if (listener != null) MAIN.post(() -> listener.onError(msg));
            } finally {
                try {
                    if (conn != null) conn.disconnect();
                } catch (Exception ignored) {}
                if (activeConnection == conn) activeConnection = null;
            }
        });
    }

    private static synchronized void playFile(File file, Listener listener) {
        try {
            if (player != null) {
                try { player.stop(); } catch (Exception ignored) {}
                try { player.release(); } catch (Exception ignored) {}
            }
            player = new MediaPlayer();
            player.setAudioAttributes(new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ASSISTANCE_ACCESSIBILITY)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build());
            player.setDataSource(file.getAbsolutePath());
            player.setOnPreparedListener(MediaPlayer::start);
            player.setOnCompletionListener(mp -> {
                try { mp.release(); } catch (Exception ignored) {}
                player = null;
                try { file.delete(); } catch (Exception ignored) {}
                if (listener != null) listener.onSuccess();
            });
            player.setOnErrorListener((mp, what, extra) -> {
                try { mp.release(); } catch (Exception ignored) {}
                player = null;
                try { file.delete(); } catch (Exception ignored) {}
                if (listener != null) listener.onError("ElevenLabs 음성 재생에 실패했어.");
                return true;
            });
            player.prepareAsync();
        } catch (Exception e) {
            try { file.delete(); } catch (Exception ignored) {}
            if (listener != null) listener.onError("ElevenLabs 음성 재생에 실패했어.");
        }
    }

    private static String readUtf8(InputStream in) throws Exception {
        try (InputStream input = in; ByteArrayOutputStream bos = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[4096];
            int len;
            while ((len = input.read(buffer)) != -1) bos.write(buffer, 0, len);
            String text = bos.toString("UTF-8");
            return text.length() > 350 ? text.substring(0, 350) : text;
        }
    }
}
