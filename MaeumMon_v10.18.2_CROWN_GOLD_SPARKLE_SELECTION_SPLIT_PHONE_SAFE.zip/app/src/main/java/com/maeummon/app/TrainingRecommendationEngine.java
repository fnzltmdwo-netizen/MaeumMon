package com.maeummon.app;

import android.content.Context;
import java.util.Locale;

public class TrainingRecommendationEngine {
    public static class Recommendation {
        public String mode;
        public String muscleName;
        public String mechanism;
        public String exerciseType;
        public String exerciseText;
        public String successCriterion;
        public String rationale;
        public int difficulty;
        public boolean fromCounseling;
    }

    private final MindTrainingStore store;

    public TrainingRecommendationEngine(Context context) {
        store = new MindTrainingStore(context);
    }

    public Recommendation recommend(String raw) {
        return recommend(raw, null);
    }

    public Recommendation recommend(String currentConcern, MindTrainingStore.CounselingEntry latestCounseling) {
        String current = currentConcern == null ? "" : currentConcern.trim();

        // 현재 사용자의 직접 발화 중 회복/안정 신호는 오래된 상담 기록보다 우선한다.
        Recommendation immediate = detectImmediateState(current);
        if (immediate != null) return immediate;

        if (latestCounseling != null) {
            Recommendation fromCounseling = buildFromCounseling(latestCounseling, current);
            if (fromCounseling != null) return fromCounseling;
        }

        return recommendLocally(current);
    }

    private Recommendation detectImmediateState(String raw) {
        String lower = normalized(raw);
        if (lower.isEmpty()) return null;

        if (containsAny(lower,
                "집가서 쉬고", "집 가서 쉬고", "그냥 쉬고 싶", "쉬고파", "눕고 싶", "누워있고 싶",
                "너무 지쳐", "완전 지쳐", "기운이 없", "에너지가 없", "방전", "번아웃", "기진맥진",
                "너무 피곤", "녹초", "아무것도 못하겠", "오늘은 못하겠", "그만하고 싶")) {
            Recommendation r = new Recommendation();
            r.mode = "RECOVERY";
            r.muscleName = "내 상태를 무시하지 않고 필요한 회복을 선택하는 힘";
            r.mechanism = "회복이 필요한 상태에서도 무조건 버티거나 자신을 밀어붙이는 패턴";
            r.exerciseType = "REDUCE_LOAD";
            r.difficulty = 1;
            r.exerciseText = "지금 남은 일 중 오늘 꼭 해야 하는 것 하나만 남기고, 나머지 하나는 의식적으로 미루거나 줄이기.";
            r.successCriterion = "더 많이 해내는 게 아니라 오늘의 부하를 실제로 하나 줄이면 성공.";
            r.rationale = "지금 직접 적은 문장에서는 훈련을 더 얹기보다 회복 여지를 만드는 게 먼저로 보여.";
            return r;
        }

        if (containsAny(lower, "당장", "미치겠", "너무 불안", "심장이", "가슴이", "숨이", "폭발", "패닉", "공황 같")) {
            Recommendation r = new Recommendation();
            r.mode = "STABILIZE";
            r.muscleName = "강한 감정 속에서도 행동을 잠깐 멈추는 힘";
            r.mechanism = "감정 강도가 높을 때 즉시 행동으로 옮기는 패턴";
            r.exerciseType = "DELAY_ACTION";
            r.difficulty = 1;
            r.exerciseText = "지금 하려던 행동을 3분만 미루고, 폰을 내려놓거나 자리에서 잠깐 움직이기.";
            r.successCriterion = "감정이 없어지는 게 아니라 3분 동안 즉시 행동하지 않으면 성공.";
            r.rationale = "지금은 생각을 더 밀어붙이기보다 행동 속도를 먼저 낮추는 게 우선이야.";
            return r;
        }
        return null;
    }

    private Recommendation buildFromCounseling(MindTrainingStore.CounselingEntry e, String currentConcern) {
        boolean structured = notBlank(e.muscleName) || notBlank(e.trainingText) || notBlank(e.priorityDirection) || notBlank(e.successCriterion);
        if (structured) {
            Recommendation r = new Recommendation();
            r.fromCounseling = true;
            String sourceText = join(e.priorityDirection, e.formulation, e.caution, e.rawText);
            r.mode = inferModeFromCounseling(sourceText);
            r.muscleName = notBlank(e.muscleName) ? e.muscleName : "상담에서 잡은 방향을 현실에서 반복하는 힘";
            r.mechanism = notBlank(e.formulation) ? e.formulation : emptyTo(e.priorityDirection, "최근 상담에서 정리된 핵심 방향");
            r.exerciseType = "GPT_COUNSELING_IMPORT";
            r.difficulty = adaptDifficulty(r.muscleName);
            r.exerciseText = notBlank(e.trainingText) ? e.trainingText : fallbackExercise(r.mode, e.priorityDirection, currentConcern);
            r.successCriterion = notBlank(e.successCriterion) ? e.successCriterion : fallbackCriterion(r.mode);
            r.rationale = adaptiveRationale(r.muscleName,
                    "최근 '상담 완전판'에서 정리된 방향을 오늘 훈련의 최우선 근거로 이어갈게." +
                            (notBlank(currentConcern) ? " 방금 적은 고민은 현재 맥락으로 함께 반영했어." : ""));
            return r;
        }

        // 별도 요약을 요구하지 않은 전체 대화도 그대로 쓸 수 있다.
        // 원문 전체를 키워드 검색해 오래된 발화를 현재 문제로 오인하지 않도록,
        // 파서가 찾아낸 최근 사용자 발화 + 최근 ChatGPT 답변을 우선 참고한다.
        if (notBlank(e.rawText)) {
            String seed;
            if (notBlank(currentConcern)) {
                seed = currentConcern;
            } else {
                seed = join(e.currentConcern, e.formulation);
                if (!notBlank(seed)) seed = e.rawText;
            }
            Recommendation r = recommendLocally(seed);
            r.fromCounseling = true;
            r.rationale = adaptiveRationale(r.muscleName,
                    "붙여넣은 GPT 상담 원문은 그대로 보관하고, 그중 최근 대화 흐름을 우선 참고해 오늘의 훈련으로 이어봤어.");
            return r;
        }
        return null;
    }

    private Recommendation recommendLocally(String raw) {
        String text = raw == null ? "" : raw.trim();
        String lower = normalized(text);
        Recommendation r = new Recommendation();

        Recommendation immediate = detectImmediateState(text);
        if (immediate != null) return immediate;

        if (containsAny(lower, "어제 결국", "또 해버렸", "후회", "왜 또", "이미 보냈", "이미 말했")) {
            r.mode = "REVIEW";
            r.muscleName = "행동이 커지기 직전의 신호를 알아차리는 힘";
            r.mechanism = "사건 이후 결과만 후회하고 직전 전환점을 놓치는 패턴";
            r.exerciseType = "POST_EVENT_REVIEW";
            r.difficulty = 1;
            r.exerciseText = "그 행동을 하기 직전 5분 안에 있었던 생각·감정·몸 느낌 중 하나를 한 줄로 적기.";
            r.successCriterion = "잘잘못을 결론내리지 않고 '직전 신호' 하나를 찾으면 성공.";
            r.rationale = "이미 일어난 일을 다시 처벌하기보다 다음에 끼어들 지점을 찾는 게 더 도움이 돼.";
            return r;
        }

        if (containsAny(lower, "거절", "싫다고", "부탁", "서운해할", "기분 나빠", "상처줄")) {
            r.mode = "TRAINING";
            r.muscleName = "상대의 실망과 내 선택을 동시에 허용하는 힘";
            r.mechanism = "상대의 실망을 피하려고 내 의사를 너무 빨리 양보하는 패턴";
            r.exerciseType = "ASK_FOR_TIME";
            int d = adaptDifficulty(r.muscleName);
            r.difficulty = d;
            r.exerciseText = d <= 1 ? "부탁을 받으면 바로 답하지 말고 '조금 생각해볼게'라고 한 번 말하기." :
                    "작은 부탁 하나에 '오늘은 어려울 것 같아'처럼 짧게 내 의사를 말하기.";
            r.successCriterion = "상대가 만족했는지가 아니라 내 선택을 바로 지우지 않고 한 문장으로 표현하면 성공.";
            r.rationale = adaptiveRationale(r.muscleName, "경계를 직접 세게 말하기보다 지금 감당 가능한 단계부터 연습할게.");
            return r;
        }

        if (containsAny(lower, "답장", "안읽", "읽씹", "단톡", "반응 없", "무시", "연락 안")) {
            r.mode = "TRAINING";
            r.muscleName = "애매한 관계 신호를 바로 거절로 확정하지 않는 힘";
            r.mechanism = "확실하지 않은 관계 신호를 빠르게 부정적 결론으로 바꾸는 패턴";
            r.exerciseType = "FACT_INFERENCE_SPLIT";
            int d = adaptDifficulty(r.muscleName);
            r.difficulty = d;
            r.exerciseText = "지금 확실히 아는 사실 1개와 내가 추측하는 것 1개를 따로 적고, " + (d <= 1 ? "5분" : d == 2 ? "10분" : "20분") + " 동안 결론을 보류하기.";
            r.successCriterion = "불안이 사라지는 게 아니라 추측을 사실로 확정하지 않고 정해진 시간만큼 보류하면 성공.";
            r.rationale = adaptiveRationale(r.muscleName, "답을 찾아내기보다 사실과 해석을 분리하는 연습이 지금 고민과 가장 직접적으로 연결돼.");
            return r;
        }

        if (containsAny(lower, "멍청", "한심", "난 왜", "또 실수", "나는 원래", "내가 이상")) {
            r.mode = "TRAINING";
            r.muscleName = "한 사건과 나 전체에 대한 평가를 분리하는 힘";
            r.mechanism = "한 번의 실수나 사건을 자기 전체의 가치 판단으로 확대하는 패턴";
            r.exerciseType = "SELF_EVALUATION_SEPARATION";
            r.difficulty = adaptDifficulty(r.muscleName);
            r.exerciseText = "종이에 '실제로 일어난 일' 한 줄과 '나 자신에 대한 평가' 한 줄을 따로 적기.";
            r.successCriterion = "자기비난이 완전히 없어지지 않아도 사건과 자기평가를 두 문장으로 분리하면 성공.";
            r.rationale = adaptiveRationale(r.muscleName, "지금은 나를 설득하기보다 사건과 자기평가를 분리하는 게 먼저야.");
            return r;
        }

        r.mode = "TRAINING";
        r.muscleName = "불편한 감정이 있어도 내가 고른 행동을 계속하는 힘";
        r.mechanism = "불편함이 생기면 현재 행동을 중단하거나 즉시 해결하려는 패턴";
        r.exerciseType = "CONTINUE_ACTIVITY";
        r.difficulty = adaptDifficulty(r.muscleName);
        r.exerciseText = "지금 가장 작게 계속할 수 있는 원래 행동 하나를 정해서 5분만 이어가기.";
        r.successCriterion = "기분이 좋아지는 게 아니라 5분 동안 선택한 행동을 계속하면 성공.";
        r.rationale = adaptiveRationale(r.muscleName, "원인을 단정하기 어려워서 가장 작고 범용적인 행동 훈련부터 제안할게.");
        return r;
    }

    private String inferModeFromCounseling(String source) {
        String lower = normalized(source);
        if (containsAny(lower, "회복 우선", "회복이 먼저", "소진", "과부하", "쉬어", "휴식", "강도를 낮")) return "RECOVERY";
        if (containsAny(lower, "안정화", "행동을 멈", "즉시 행동하지", "감정 강도")) return "STABILIZE";
        if (containsAny(lower, "복기", "직전 신호", "이미 일어난")) return "REVIEW";
        if (containsAny(lower, "유지", "스스로 해낸", "이미 할 수")) return "MAINTENANCE";
        return "TRAINING";
    }

    private String fallbackExercise(String mode, String priority, String currentConcern) {
        if ("RECOVERY".equals(mode)) return "상담에서 정한 방향을 지키면서 오늘의 부하를 하나 줄이기.";
        if ("STABILIZE".equals(mode)) return "상담에서 정한 행동을 하기 전 3분만 속도를 늦추기.";
        if (notBlank(priority)) return "상담에서 정한 우선 방향을 오늘 한 번 실행할 수 있는 가장 작은 행동으로 바꿔서 해보기.";
        return "최근 상담에서 잡은 방향을 오늘 5분짜리 행동 하나로 옮겨보기.";
    }

    private String fallbackCriterion(String mode) {
        if ("RECOVERY".equals(mode)) return "기분이 완전히 좋아지는 게 아니라 부하를 하나 줄이면 성공.";
        if ("STABILIZE".equals(mode)) return "감정이 없어지는 게 아니라 즉시 행동을 잠깐 늦추면 성공.";
        return "감정 변화보다 상담에서 정한 행동을 실제로 한 번 선택하면 성공.";
    }

    private int adaptDifficulty(String muscleName) {
        String effect = store.latestEffectForMuscle(muscleName);
        int previous = store.latestDifficultyForMuscle(muscleName);
        if ("WORSE".equals(effect)) return Math.max(1, previous - 1);
        if ("HELPED".equals(effect)) return Math.min(3, previous + 1);
        return Math.max(1, Math.min(3, previous));
    }

    private String adaptiveRationale(String muscleName, String base) {
        String effect = store.latestEffectForMuscle(muscleName);
        if ("WORSE".equals(effect)) return "지난번엔 더 힘들어졌다는 기록이 있어서 이번엔 강도를 낮출게. " + base;
        if ("HELPED".equals(effect)) return "지난번에 도움이 됐던 기록이 있어서 아주 조금만 확장해볼게. " + base;
        if ("PARTIAL".equals(effect)) return "지난번엔 일부만 가능했으니 강도는 유지하고 방식은 가볍게 이어갈게. " + base;
        return base;
    }

    private String normalized(String s) {
        return s == null ? "" : s.toLowerCase(Locale.KOREAN).replace("\n", " ");
    }

    private boolean containsAny(String text, String... keys) {
        for (String k : keys) if (text.contains(k)) return true;
        return false;
    }

    private boolean notBlank(String s) { return s != null && !s.trim().isEmpty(); }
    private String emptyTo(String s, String fallback) { return notBlank(s) ? s.trim() : fallback; }
    private String join(String... values) {
        StringBuilder b = new StringBuilder();
        for (String v : values) if (notBlank(v)) b.append(v).append(' ');
        return b.toString();
    }
}
