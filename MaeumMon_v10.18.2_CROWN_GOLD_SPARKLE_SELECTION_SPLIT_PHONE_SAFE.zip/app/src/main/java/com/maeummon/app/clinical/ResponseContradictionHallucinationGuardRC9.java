package com.maeummon.app.clinical;

import android.content.Context;
import org.json.*;
import java.util.*;

public final class ResponseContradictionHallucinationGuardRC9 {
    private ResponseContradictionHallucinationGuardRC9(){}

    public static final class Check {
        public boolean pass=true;
        public boolean rewriteRequired=false;
        public final List<String> failures=new ArrayList<>();
        public String instruction="";
        public String summary="PASS";
        void fail(String x){
            pass=false;
            rewriteRequired=true;
            failures.add(x);
        }
    }

    public static Check inspect(Context c,String userText,String response){
        Check x=new Check();
        String u=userText==null?"":userText.trim();
        String r=response==null?"":response.trim();

        if(r.isEmpty()){
            x.fail("EMPTY_RESPONSE");
            x.instruction="응답이 비어 있다. 현재 move와 formulation을 유지한 채 짧은 정상 응답으로 다시 생성한다.";
            x.summary=summary(x);
            return x;
        }

        JSONObject f=CentralTherapyProfile.loadFormulation(c);
        JSONObject p=CentralTherapyProfile.loadProfile(c);

        // 1. Direct contradiction with user's current correction / negation.
        if(containsAny(u,"싸운 일 없어","갈등 없어","다툰 적 없어")
                && containsAny(r,"싸운 게","갈등이 있었","다툼이 있었","실제 갈등이")){
            x.fail("CONTRADICTS_USER_NO_CONFLICT");
        }

        if(containsAny(u,"원래도 느려","평소에도 느려","늘 느렸")
                && containsAny(r,"최근 갑자기 달라진","최근부터 변한 게 핵심","관계가 최근 변해서")){
            x.fail("CONTRADICTS_USER_BASELINE");
        }

        if(containsAny(u,"나한테만 그런 건 아니","누구에게나 그래","모두한테 그래")
                && containsAny(r,"나한테만","유독 너에게만","선택적으로 너에게")){
            x.fail("CONTRADICTS_USER_SELECTIVITY");
        }

        // 2. Do not turn inference into fact.
        String centralUncertainty=f.optString("central_uncertainty","");
        boolean insightUsable=f.optBoolean("central_insight_usable",false);
        if(!insightUsable && containsAny(r,
                "분명해","확실해","틀림없어","사실은","명백히")){
            x.fail("OVERCLAIM_WITH_UNUSABLE_INSIGHT");
        }

        if(containsAny(centralUncertainty,"잠정","확정할 수 없다","가능성이 비슷")
                && containsAny(r,"확실히","분명히","결론은","틀림없이")){
            x.fail("OVERCLAIM_AGAINST_UNCERTAINTY");
        }

        // 3. No unsupported diagnostic/personality labels.
        if(containsAny(r,
                "너는 회피형이야","너는 불안형이야","성격장애","경계선 성격장애",
                "공황장애가 맞아","우울증이야","번아웃이 확실해",
                "ADHD라서 그런 거야")){
            x.fail("UNSUPPORTED_DIAGNOSTIC_OR_TRAIT_LABEL");
        }

        // 4. No invented history or repeated-pattern claims without stable support.
        boolean stableHasPattern=hasActiveStablePattern(p);
        if(!stableHasPattern && containsAny(r,
                "늘 그래왔어","항상 반복됐어","예전부터 계속","원래 네 패턴은",
                "항상 이런 관계를 반복")){
            x.fail("INVENTED_LONGITUDINAL_PATTERN");
        }

        // 5. Completed goal should not be re-pathologized.
        if("COMPLETED".equals(p.optString("last_goal_status","UNCHANGED"))
                && containsAny(r,"아직 이 문제를 고쳐야","계속 이 목표를 연습해야",
                "여전히 이 문제부터 해결")){
            x.fail("REPATHOLOGIZES_COMPLETED_GOAL");
        }

        // 6. Context-bounded memory cannot be generalized in wording.
        int blocked=countBlockedStable(p);
        if(blocked>0 && containsAny(r,
                "어디서든","모든 관계에서","항상 직장에서도","가족에서도 똑같이",
                "전반적으로 너는")){
            x.fail("CROSS_CONTEXT_OVERGENERALIZATION");
        }

        // 7. Do not invent intentions of third parties.
        if(containsAny(r,
                "걔는 너를 싫어해서","상대가 일부러 무시한 거야","너를 버리려고",
                "널 만만하게 봐서 그런 거야","일부러 거리를 두는 거야")
                && !containsAny(u,"걔가 직접 싫다고","일부러 무시한다고 말했","거리 두겠다고 말했")){
            x.fail("INVENTED_THIRD_PARTY_INTENT");
        }

        // 8. Preserve safety priority in response language.
        if(f.optBoolean("safety_override",false)
                && containsAny(r,"일단 행동실험부터","그 사람에게 바로 연락해","그냥 참아봐")){
            x.fail("SAFETY_RESPONSE_DRIFT");
        }

        if(!x.pass){
            x.instruction=buildRewriteInstruction(x);
        }
        x.summary=summary(x);
        return x;
    }

    public static String buildRewriteInstruction(Check x){
        return "RESPONSE_FACT_GUARD_FAIL=true. 아래 오류를 제거해서 응답을 다시 쓴다: "
                +x.failures
                +". 사용자 직접 발화와 CURRENT_FORMULATION에 없는 사실/동기/진단을 새로 만들지 않는다. "
                +"잠정 가설은 잠정적으로 표현하고, 완료된 목표나 context-blocked memory를 다시 확정 문제로 만들지 않는다.";
    }

    private static boolean hasActiveStablePattern(JSONObject p){
        JSONArray a=p.optJSONArray("stable_profile");
        if(a==null)return false;
        for(int i=0;i<a.length();i++){
            JSONObject o=a.optJSONObject(i);
            if(o==null)continue;
            if("ACTIVE".equals(o.optString("status","ACTIVE"))
                    && o.optDouble("confidence",0)>=0.70
                    && o.optBoolean("usable_in_current_context",true))
                return true;
        }
        return false;
    }

    private static int countBlockedStable(JSONObject p){
        JSONArray a=p.optJSONArray("stable_profile");
        if(a==null)return 0;
        int n=0;
        for(int i=0;i<a.length();i++){
            JSONObject o=a.optJSONObject(i);
            if(o!=null&&!o.optBoolean("usable_in_current_context",true))n++;
        }
        return n;
    }

    private static String summary(Check x){
        return x.pass?"PASS":"FAIL "+x.failures.toString();
    }

    private static boolean containsAny(String s,String... xs){
        if(s==null)return false;
        for(String x:xs)if(s.contains(x))return true;
        return false;
    }
}
