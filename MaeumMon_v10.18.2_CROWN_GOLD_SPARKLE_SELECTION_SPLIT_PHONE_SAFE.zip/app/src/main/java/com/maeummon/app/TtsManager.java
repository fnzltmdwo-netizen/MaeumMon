package com.maeummon.app;

import android.content.Context;
import android.content.SharedPreferences;
import android.speech.tts.TextToSpeech;

import java.util.Calendar;
import java.util.Locale;
import java.util.UUID;

public class TtsManager {

    public interface SpeakListener {
        void onEngine(String engineName);
        void onError(String message);
    }

    private static TextToSpeech tts;
    private static boolean ready = false;
    private static boolean initializing = false;

    private static synchronized void ensure(Context context, Runnable onReady) {
        if (ready && tts != null) {
            onReady.run();
            return;
        }
        if (initializing) return;
        initializing = true;
        Context appContext = context.getApplicationContext();
        tts = new TextToSpeech(appContext, status -> {
            initializing = false;
            if (status == TextToSpeech.SUCCESS) {
                int result = tts.setLanguage(Locale.KOREAN);
                if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                    tts.setLanguage(Locale.KOREA);
                }
                tts.setPitch(1.06f);
                tts.setSpeechRate(0.92f);
                ready = true;
                onReady.run();
            }
        });
    }

    public static boolean isQuietHour(Context context) {
        SharedPreferences prefs = context.getSharedPreferences(AppPrefs.PREFS, Context.MODE_PRIVATE);
        if (!prefs.getBoolean(AppPrefs.KEY_VOICE_QUIET_NIGHT, true)) return false;
        int hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
        return hour >= 23 || hour < 7;
    }

    public static boolean canUseTypecast(Context context) {
        SharedPreferences prefs = context.getSharedPreferences(AppPrefs.PREFS, Context.MODE_PRIVATE);
        return prefs.getBoolean(AppPrefs.KEY_TYPECAST_ENABLED, false)
                && !prefs.getString(AppPrefs.KEY_TYPECAST_API_KEY, "").trim().isEmpty()
                && !prefs.getString(AppPrefs.KEY_TYPECAST_VOICE_ID, "").trim().isEmpty();
    }

    public static void speak(Context context, String text) {
        speak(context, text, null);
    }

    public static void speak(Context context, String text, SpeakListener listener) {
        if (text == null || text.trim().isEmpty()) return;
        if (isQuietHour(context)) return;
        String clean = text.replace("\n", " ").trim();
        SharedPreferences prefs = context.getSharedPreferences(AppPrefs.PREFS, Context.MODE_PRIVATE);

        // v1.6.7: one-time Studio Match preset based on the Typecast editor screenshot.
        // Keep API key / voice ID untouched; only align synthesis settings.
        if (!prefs.getBoolean(AppPrefs.KEY_TYPECAST_STUDIO_MATCH_V167, false)) {
            prefs.edit()
                    .putString(AppPrefs.KEY_TYPECAST_MODEL_ID, "ssfm-v30")
                    .putBoolean(AppPrefs.KEY_TYPECAST_SMART_EMOTION, false)
                    .putString(AppPrefs.KEY_TYPECAST_EMOTION_PRESET, "sad")
                    .putFloat(AppPrefs.KEY_TYPECAST_EMOTION_INTENSITY, 1.0f)
                    .putInt(AppPrefs.KEY_TYPECAST_VOLUME, 100)
                    .putInt(AppPrefs.KEY_TYPECAST_PITCH, 0)
                    .putFloat(AppPrefs.KEY_TYPECAST_TEMPO, 1.0f)
                    .putBoolean(AppPrefs.KEY_TYPECAST_STUDIO_MATCH_V167, true)
                    .apply();
        }

        if (canUseTypecast(context)) {
            String apiKey = prefs.getString(AppPrefs.KEY_TYPECAST_API_KEY, "").trim();
            String voiceId = prefs.getString(AppPrefs.KEY_TYPECAST_VOICE_ID, "").trim();
            String modelId = prefs.getString(AppPrefs.KEY_TYPECAST_MODEL_ID, "ssfm-v30").trim();
            boolean smartEmotion = prefs.getBoolean(AppPrefs.KEY_TYPECAST_SMART_EMOTION, true);
            String emotionPreset = prefs.getString(AppPrefs.KEY_TYPECAST_EMOTION_PRESET, "normal").trim();
            float emotionIntensity = prefs.getFloat(AppPrefs.KEY_TYPECAST_EMOTION_INTENSITY, 1.0f);
            int volume = prefs.getInt(AppPrefs.KEY_TYPECAST_VOLUME, 100);
            int pitch = prefs.getInt(AppPrefs.KEY_TYPECAST_PITCH, 0);
            float tempo = prefs.getFloat(AppPrefs.KEY_TYPECAST_TEMPO, 1.0f);
            TypecastClient.speak(context, apiKey, voiceId, modelId, smartEmotion, emotionPreset,
                    emotionIntensity, volume, pitch, tempo, clean, new TypecastClient.Listener() {
                @Override public void onStarted() {
                    if (listener != null) listener.onEngine("Typecast 어린 승재 음성 생성 중…");
                }
                @Override public void onSuccess() {
                    if (listener != null) listener.onEngine("Typecast 어린 승재 음성");
                }
                @Override public void onError(String message) {
                    if (listener != null) listener.onError(message + " · 다른 음성으로 재생할게.");
                    speakAndroid(context, clean, listener);
                }
            });
            return;
        }

        speakAndroid(context, clean, listener);
    }

    private static void speakAndroid(Context context, String clean, SpeakListener listener) {
        ensure(context, () -> {
            if (tts != null) {
                if (listener != null) listener.onEngine("Android 기본 음성");
                tts.speak(clean, TextToSpeech.QUEUE_FLUSH, null, "maeummon_" + UUID.randomUUID());
            }
        });
    }

    public static void stop() {
        TypecastClient.stop();
        if (tts != null) tts.stop();
    }
}
