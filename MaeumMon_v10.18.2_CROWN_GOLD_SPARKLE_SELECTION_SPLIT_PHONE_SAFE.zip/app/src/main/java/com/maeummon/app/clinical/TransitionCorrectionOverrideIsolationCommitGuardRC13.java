package com.maeummon.app.clinical;

import android.content.Context;
import org.json.*;

public final class TransitionCorrectionOverrideIsolationCommitGuardRC13 {
    private TransitionCorrectionOverrideIsolationCommitGuardRC13(){}

    public enum State {
        NONE,
        EPHEMERAL_OVERRIDE,
        EXPLICIT_CORRECTION_COMMIT_ALLOWED,
        MEMORY_COMMIT_BLOCKED,
        DUPLICATE_COMMIT_SUPPRESSED
    }

    public static final class Result {
        public boolean evaluated=false;
        public boolean ephemeral=false;
        public boolean commitAllowed=false;
        public boolean commitBlocked=false;
        public boolean duplicateSuppressed=false;
        public State state=State.NONE;
        public String effectiveCause="";
        public String effectiveReason="";
        public String commitIdentity="";
        public String reason="";
        public String summary="";
    }

    public static Result evaluate(
            Context c,
            ClinicalDecisionRC7 d){

        Result r=new Result();

        if(c==null||d==null){
            r.summary="NONE | MISSING_INPUT";
            return r;
        }

        r.evaluated=true;

        String freshState=safe(
                d.transitionCorrectionFreshEvidenceState);

        boolean currentOverride=
                d.transitionCorrectionCurrentTurnOverride
                ||"CURRENT_TURN_OVERRIDES_MEMORY".equals(freshState);

        boolean explicitApplied=
                d.transitionExplanationCorrectionApplied
                &&!safe(d.transitionExplanationCorrectedCause).isEmpty();

        r.effectiveCause=safe(
                d.transitionCorrectionFreshEvidenceEffectiveCause);

        if(r.effectiveCause.isEmpty())
            r.effectiveCause=safe(
                    d.transitionExplanationCorrectedCause);

        r.effectiveReason=safe(
                d.transitionCorrectionFreshEvidenceEffectiveReason);

        if(r.effectiveReason.isEmpty())
            r.effectiveReason=safe(
                    d.transitionExplanationCorrectedReason);

        r.commitIdentity=
                safe(d.decisionTransitionFromState)
                +"->"
                +safe(d.decisionTransitionToState)
                +"::"
                +safe(d.transitionCorrectionFreshEvidenceEffectiveCause)
                +"::"
                +safe(d.transitionCorrectionMemoryCurrentContext);

        // A current-turn override caused only by rejection / ambiguity is ephemeral.
        if(currentOverride && !explicitApplied){
            r.ephemeral=true;
            r.commitBlocked=true;
            r.state=State.EPHEMERAL_OVERRIDE;
            r.reason="OVERRIDE_WITHOUT_EXPLICIT_CORRECTION";
            return finish(r);
        }

        // Only an explicit applied user correction can become correction memory.
        if(explicitApplied){
            JSONObject session=
                    CentralTherapyProfile.loadSessionState(c);

            String lastIdentity=
                    session.optString(
                            "last_transition_correction_commit_identity",
                            "");

            if(!r.commitIdentity.isEmpty()
                    &&r.commitIdentity.equals(lastIdentity)){
                r.duplicateSuppressed=true;
                r.commitBlocked=true;
                r.state=State.DUPLICATE_COMMIT_SUPPRESSED;
                r.reason="SAME_CORRECTION_ALREADY_COMMITTED_THIS_TRANSITION";
                return finish(r);
            }

            r.commitAllowed=true;
            r.state=State.EXPLICIT_CORRECTION_COMMIT_ALLOWED;
            r.reason="EXPLICIT_USER_CORRECTION_ONLY";
            return finish(r);
        }

        // Memory reuse never creates a new memory commit.
        if(d.transitionCorrectionMemoryAllowed){
            r.commitBlocked=true;
            r.state=State.MEMORY_COMMIT_BLOCKED;
            r.reason="MEMORY_REUSE_CANNOT_SELF_REINFORCE";
            return finish(r);
        }

        r.commitBlocked=true;
        r.state=State.MEMORY_COMMIT_BLOCKED;
        r.reason="NO_EXPLICIT_CORRECTION_TO_COMMIT";
        return finish(r);
    }

    public static void recordCommitIdentity(
            Context c,
            Result r){

        if(c==null||r==null||!r.commitAllowed)return;

        JSONObject session=
                CentralTherapyProfile.loadSessionState(c);

        try{
            session.put(
                    "last_transition_correction_commit_identity",
                    r.commitIdentity);
            session.put(
                    "last_transition_correction_commit_at",
                    System.currentTimeMillis());
            session.put(
                    "last_transition_correction_commit_schema",
                    "6.8.8");

            CentralTherapyProfile.replaceSessionState(
                    c,session);
        }catch(Exception ignored){}
    }

    public static String instruction(Result r){
        if(r==null||!r.evaluated)return "";

        if(r.state==State.EPHEMERAL_OVERRIDE)
            return "CORRECTION_OVERRIDE_MEMORY=EPHEMERAL. 이번 턴의 부정/보류는 현재 답변에만 적용하고 장기 correction memory로 저장하지 않는다.";

        if(r.state==State.EXPLICIT_CORRECTION_COMMIT_ALLOWED)
            return "CORRECTION_OVERRIDE_MEMORY=COMMIT_ALLOWED. 사용자가 원인을 명시적으로 바로잡은 경우에만 해당 transition/context의 correction memory로 저장할 수 있다.";

        if(r.state==State.DUPLICATE_COMMIT_SUPPRESSED)
            return "CORRECTION_OVERRIDE_MEMORY=DUPLICATE_SUPPRESSED. 동일 transition의 동일 correction이 이미 commit되어 이번 턴 중복 저장을 막는다.";

        if(r.state==State.MEMORY_COMMIT_BLOCKED)
            return "CORRECTION_OVERRIDE_MEMORY=BLOCKED. 과거 memory 재사용이나 추론만으로는 새로운 correction memory를 만들지 않는다.";

        return "";
    }

    public static boolean mayPersistCorrection(Result r){
        return r!=null
                &&r.commitAllowed
                &&!r.commitBlocked
                &&r.state==State.EXPLICIT_CORRECTION_COMMIT_ALLOWED;
    }

    private static Result finish(Result r){
        r.summary=r.state.name()
                +" | ephemeral="+r.ephemeral
                +" | commitAllowed="+r.commitAllowed
                +" | commitBlocked="+r.commitBlocked
                +" | duplicate="+r.duplicateSuppressed
                +" | cause="+r.effectiveCause
                +" | identity="+r.commitIdentity
                +" | reason="+r.reason;
        return r;
    }

    private static String safe(String s){
        return s==null?"":s;
    }
}
