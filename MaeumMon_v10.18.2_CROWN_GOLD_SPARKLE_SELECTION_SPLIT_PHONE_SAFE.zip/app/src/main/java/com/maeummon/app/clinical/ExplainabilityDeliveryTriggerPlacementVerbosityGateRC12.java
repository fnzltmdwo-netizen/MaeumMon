package com.maeummon.app.clinical;

import android.content.Context;
import org.json.*;

public final class ExplainabilityDeliveryTriggerPlacementVerbosityGateRC12 {
    private ExplainabilityDeliveryTriggerPlacementVerbosityGateRC12(){}

    public enum DeliveryMode {
        SILENT_INTERNAL,
        COMPACT_INLINE,
        DIRECT_WHY_ANSWER,
        SUPPRESSED
    }

    public static final class Result {
        public boolean evaluated=false;
        public boolean shouldSurface=false;
        public boolean userAskedWhy=false;
        public boolean decisionNeedsJustification=false;
        public boolean recentRationaleShown=false;
        public boolean suppressedForRepetition=false;
        public DeliveryMode mode=DeliveryMode.SILENT_INTERNAL;
        public String text="";
        public String placement="";
        public int maxSentences=0;
        public String reason="";
        public String summary="";
    }

    public static Result decide(
            Context c,
            ClinicalDecisionRC7 d,
            String userText){

        Result r=new Result();
        if(c==null||d==null){
            r.mode=DeliveryMode.SUPPRESSED;
            r.reason="MISSING_INPUT";
            r.summary="SUPPRESSED | MISSING_INPUT";
            return r;
        }

        r.evaluated=true;

        JSONObject s=CentralTherapyProfile.loadSessionState(c);

        String finalRationale=safe(d.decisionRationaleFinal);
        if(finalRationale.isEmpty())
            finalRationale=safe(d.decisionRationaleText);

        if(d.decisionRationaleFidelityBlocked
                ||finalRationale.isEmpty()){

            r.mode=DeliveryMode.SUPPRESSED;
            r.reason="NO_SAFE_RATIONALE";
            return finish(r);
        }

        r.userAskedWhy=isWhyQuestion(userText);
        r.decisionNeedsJustification=needsJustification(d);

        long lastShown=s.optLong("last_user_facing_rationale_at",0L);
        int turnCount=s.optInt("turn_count",0);
        int lastShownTurn=s.optInt(
                "last_user_facing_rationale_turn",-999);

        r.recentRationaleShown=
                lastShown>0
                && (turnCount-lastShownTurn)<=2;

        if(d.transitionExplanationCorrectionApplied
                &&!safe(d.transitionExplanationCorrectedReason).isEmpty()){

            r.shouldSurface=true;
            r.mode=DeliveryMode.COMPACT_INLINE;
            r.text=limitSentences(
                    safe(d.transitionExplanationCorrectedReason),
                    1);
            r.placement="ANSWER_FIRST";
            r.maxSentences=1;
            r.reason="USER_CORRECTED_TRANSITION_EXPLANATION";
            persistShown(c,s,turnCount,r.mode);
            return finish(r);
        }

        if(r.userAskedWhy){
            r.shouldSurface=true;
            r.mode=DeliveryMode.DIRECT_WHY_ANSWER;
            r.text=limitSentences(finalRationale,2);
            r.placement="ANSWER_FIRST";
            r.maxSentences=2;
            r.reason="USER_EXPLICITLY_ASKED_WHY";
            persistShown(c,s,turnCount,r.mode);
            return finish(r);
        }

        if(r.recentRationaleShown){
            r.shouldSurface=false;
            r.suppressedForRepetition=true;
            r.mode=DeliveryMode.SILENT_INTERNAL;
            r.placement="NONE";
            r.maxSentences=0;
            r.reason="RECENT_RATIONALE_ALREADY_SHOWN";
            return finish(r);
        }

        if(r.decisionNeedsJustification){
            r.shouldSurface=true;
            r.mode=DeliveryMode.COMPACT_INLINE;

            String transitionReason=
                    safe(d.decisionTransitionHumanReason);

            r.text=limitSentences(
                    compact(
                        transitionReason.isEmpty()
                            ?finalRationale
                            :transitionReason),
                    1);

            r.placement=placementFor(d);
            r.maxSentences=1;
            r.reason=transitionReason.isEmpty()
                    ?"DECISION_TRANSITION_NEEDS_JUSTIFICATION"
                    :"DECISION_TRANSITION_CAUSE_AVAILABLE";
            persistShown(c,s,turnCount,r.mode);
            return finish(r);
        }

        r.shouldSurface=false;
        r.mode=DeliveryMode.SILENT_INTERNAL;
        r.placement="NONE";
        r.maxSentences=0;
        r.reason="RATIONALE_AVAILABLE_BUT_NOT_NEEDED";
        return finish(r);
    }

    public static String instruction(Result r){
        if(r==null||!r.evaluated)return "";

        if(r.mode==DeliveryMode.DIRECT_WHY_ANSWER){
            return "WHY_DELIVERY=DIRECT. 사용자가 이유를 직접 물었으므로 답변 첫부분에서 다음 근거를 최대 2문장으로 바로 설명한다: "
                    +r.text;
        }

        if(r.mode==DeliveryMode.COMPACT_INLINE){
            return "WHY_DELIVERY=COMPACT_INLINE. 다음 근거를 최대 1문장으로 자연스럽게 포함하되 설명 자체가 답변의 중심이 되지 않게 한다: "
                    +r.text;
        }

        if(r.mode==DeliveryMode.SILENT_INTERNAL){
            return "WHY_DELIVERY=SILENT. rationale은 내부 판단 근거로만 유지하고 이번 답변에는 별도 WHY 설명을 붙이지 않는다.";
        }

        return "WHY_DELIVERY=SUPPRESSED. 안전하게 설명 가능한 근거가 없어 사용자-facing rationale을 추가하지 않는다.";
    }

    private static boolean needsJustification(ClinicalDecisionRC7 d){
        String move=safe(d.move);

        boolean moveChanged=
                DecisionTransitionSnapshotContinuityRC13
                        .meaningfulMoveTransition(d);

        boolean interventionChanged=
                DecisionTransitionSnapshotContinuityRC13
                        .meaningfulInterventionTransition(d);

        boolean reviewOrReopen=
                "REVIEW".equals(move)
                ||d.outcomeRevisionReviewRequired
                ||d.outcomeRevisionApplied;

        boolean repair=
                d.allianceRupture
                ||d.decisionRationaleFidelityRepaired;

        boolean targetChanged=
                DecisionTransitionSnapshotContinuityRC13
                        .meaningfulTargetTransition(d);

        return moveChanged
                ||interventionChanged
                ||targetChanged
                ||reviewOrReopen
                ||repair;
    }

    private static String placementFor(ClinicalDecisionRC7 d){
        if("ASK".equals(d.move))
            return "BEFORE_QUESTION";
        if("INTERVENE".equals(d.move))
            return "BEFORE_ACTION";
        if("REVIEW".equals(d.move))
            return "BEFORE_REVIEW";
        if("FORMULATE".equals(d.move))
            return "AFTER_CORE_INSIGHT";
        return "EARLY";
    }

    private static boolean isWhyQuestion(String userText){
        String u=userText==null?"":userText.trim();

        return containsAny(u,
                "왜?",
                "왜 ",
                "왜이",
                "왜 이",
                "왜 그렇게",
                "왜 그걸",
                "왜 이걸",
                "이유가 뭐",
                "이유가머",
                "왜 그런",
                "무슨 근거",
                "근거가 뭐",
                "어떻게 그렇게 판단",
                "왜 그렇게 판단");
    }

    private static String compact(String s){
        if(s==null)return "";
        String x=s.trim();

        if(x.length()<=120)return x;

        int p=x.indexOf(".");

        if(p>20&&p<140)
            return x.substring(0,p+1);

        return x.substring(0,120)+"…";
    }

    private static String limitSentences(String s,int max){
        if(s==null||s.trim().isEmpty()||max<=0)return "";

        String x=s.trim();
        StringBuilder out=new StringBuilder();
        int count=0;
        int start=0;

        for(int i=0;i<x.length();i++){
            char ch=x.charAt(i);

            if(ch=='.'||ch=='?'||ch=='!'){
                out.append(x.substring(start,i+1).trim());
                count++;
                start=i+1;

                if(count>=max)
                    return out.toString();
                out.append(" ");
            }
        }

        if(start<x.length()&&count<max)
            out.append(x.substring(start).trim());

        return out.toString().trim();
    }

    private static void persistShown(
            Context c,
            JSONObject s,
            int turnCount,
            DeliveryMode mode){

        try{
            s.put("last_user_facing_rationale_at",
                    System.currentTimeMillis());
            s.put("last_user_facing_rationale_turn",
                    turnCount);
            s.put("last_user_facing_rationale_mode",
                    mode.name());

            CentralTherapyProfile.replaceSessionState(c,s);
        }catch(Exception ignored){}
    }

    private static boolean containsAny(String s,String... xs){
        if(s==null)return false;

        for(String x:xs)
            if(x!=null&&!x.isEmpty()&&s.contains(x))
                return true;

        return false;
    }

    private static Result finish(Result r){
        r.summary=r.mode.name()
                +" | surface="+r.shouldSurface
                +" | why="+r.userAskedWhy
                +" | needsJustification="+r.decisionNeedsJustification
                +" | recent="+r.recentRationaleShown
                +" | repeatedSuppression="+r.suppressedForRepetition
                +" | placement="+r.placement
                +" | maxSentences="+r.maxSentences
                +" | reason="+r.reason;

        return r;
    }

    private static String safe(String s){
        return s==null?"":s;
    }
}
