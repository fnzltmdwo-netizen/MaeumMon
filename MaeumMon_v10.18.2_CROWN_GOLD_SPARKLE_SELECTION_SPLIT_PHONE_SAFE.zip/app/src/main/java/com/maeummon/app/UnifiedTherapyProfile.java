package com.maeummon.app;

import android.content.Context;
import org.json.JSONObject;

/**
 * One shared formulation used by counseling, coaching, widget, mascot,
 * letters, check-in, diary reports and statistics.
 * It never invents a diagnosis; it only exposes what the counseling engine
 * has already stored as current working material.
 */
public final class UnifiedTherapyProfile {
    private UnifiedTherapyProfile() {}

    private static String clean(String s) {
        if (s == null) return "";
        return s.replace("\r", " ").replace("\n", " ").replaceAll("\\s+", " ").trim();
    }

    private static String first(JSONObject p, String... keys) {
        for (String k : keys) {
            String v = clean(p.optString(k, ""));
            if (!v.isEmpty()) return v;
        }
        return "";
    }

    private static String shortText(String s, int max) {
        s = clean(s);
        if (s.length() <= max) return s;
        return s.substring(0, Math.max(0, max - 1)).trim() + "…";
    }

    public static boolean hasFormulation(Context c) {
        JSONObject p = TherapyMemoryManager.getProfile(c);
        return p.length() > 0 && !(first(p, "focus", "pattern", "automatic_thought", "core_fear").isEmpty());
    }

    public static String buildSharedContext(Context c) {
        JSONObject p = TherapyMemoryManager.getProfile(c);
        if (p.length() == 0) return "[통합 상담 프로필] 아직 충분한 상담 기록이 없어. 오늘 실제 사건을 우선해서 이해한다.";

        String focus = first(p, "focus");
        String pattern = first(p, "pattern", "relationship_pattern");
        String thought = first(p, "automatic_thought", "working_hypothesis");
        String fear = first(p, "core_fear");
        String need = first(p, "current_need", "unmet_need");
        String protect = first(p, "protective_strategy");
        String reframe = first(p, "reframe");
        String experiment = first(p, "experiment", "effective_intervention");
        String strength = first(p, "strength");
        String change = first(p, "recent_change", "corrective_experience");
        String goal = first(p, "user_goal");
        String hypothesis = first(p, "root_hypothesis", "working_hypothesis");
        String status = first(p, "hypothesis_status");
        int evidence = p.optInt("hypothesis_evidence_count", 0);

        StringBuilder sb = new StringBuilder();
        sb.append("[통합 상담 프로필 / 앱 전체가 공유하는 현재 이해]\n");
        append(sb, "요즘 핵심", focus);
        append(sb, "반복되는 장면", pattern);
        append(sb, "그 순간 붙는 뜻", thought);
        append(sb, "그 밑의 두려움", fear);
        append(sb, "실제로 필요한 것", need);
        append(sb, "나를 지키려고 해온 방식", protect);
        append(sb, "도움이 되는 새 관점", reframe);
        append(sb, "지금 연습 중인 것", experiment);
        append(sb, "이미 확인된 힘", strength);
        append(sb, "최근 달라진 점", change);
        append(sb, "가고 싶은 방향", goal);
        if (!hypothesis.isEmpty()) {
            sb.append("현재 근본 가설: ").append(hypothesis);
            if (!status.isEmpty()) sb.append(" [").append(status).append("]");
            if (evidence > 0) sb.append(" 근거 ").append(evidence).append("개");
            sb.append("\n");
        }
        sb.append("사용 원칙: 오늘의 실제 사건이 최우선이다. 이 프로필은 현재 작업가설이며 새 증거가 나오면 고친다. 상대의 속마음이나 진단을 사실처럼 단정하지 않는다.\n");
        String journey = TherapyJourneyManager.shortLabel(c);
        if (!journey.isEmpty()) sb.append("현재 변화 여정: ").append(journey).append("\n");
        sb.append("공유 원칙: 상담에서 새로 확인된 핵심/연습/변화는 앱 전체가 참고하되, 각 화면은 자기 역할에 맞는 깊이로 번역한다. 다마고치와 위젯은 심층 분석을 그대로 말하지 않는다.\n");
        sb.append(TherapyThreadManager.snapshot(c)).append("\n");
        return sb.toString();
    }

    private static void append(StringBuilder sb, String label, String value) {
        value = clean(value);
        if (!value.isEmpty()) sb.append(label).append(": ").append(value).append("\n");
    }

    public static String currentPractice(Context c) {
        JSONObject p = TherapyMemoryManager.getProfile(c);
        return first(p, "experiment", "effective_intervention", "reframe");
    }

    public static String compactTheme(Context c) {
        JSONObject p = TherapyMemoryManager.getProfile(c);
        String focus = first(p, "focus", "pattern", "automatic_thought");
        String practice = first(p, "experiment", "reframe");
        if (focus.isEmpty() && practice.isEmpty()) return "";
        if (practice.isEmpty()) return shortText(focus, 72);
        if (focus.isEmpty()) return shortText(practice, 72);
        return shortText(focus, 46) + " / 연습: " + shortText(practice, 46);
    }

    public static String widgetLine(Context c) {
        JSONObject p = TherapyMemoryManager.getProfile(c);
        String thought = first(p, "automatic_thought");
        String reframe = first(p, "reframe");
        String practice = first(p, "experiment");
        String fear = first(p, "core_fear");
        String change = first(p, "recent_change", "corrective_experience");

        if (!change.isEmpty() && practice.isEmpty()) return TherapySurfacePolicyV501.compactWidgetText("이미 달라진 것도 네 변화야. " + change, 28);
        if (!practice.isEmpty()) return TherapySurfacePolicyV501.compactWidgetText(toEverydayPractice(practice), 28);
        if (!reframe.isEmpty()) return TherapySurfacePolicyV501.compactWidgetText(toEverydayPractice(reframe), 28);
        if (!thought.isEmpty() || !fear.isEmpty()) return "아직 모르는 마음까지 먼저 결론내리진 말자.";
        return "";
    }

    public static String mascotLine(Context c) {
        JSONObject p = TherapyMemoryManager.getProfile(c);
        String practice = first(p, "experiment");
        String need = first(p, "current_need", "unmet_need");
        String thought = first(p, "automatic_thought");
        String change = first(p, "recent_change", "corrective_experience");
        if (!change.isEmpty() && !practice.isEmpty()) return shortText("이번엔 예전과 달랐던 점도 기억하자. " + toEverydayPractice(practice), 46);
        if (!practice.isEmpty()) return shortText(toEverydayPractice(practice), 46);
        if (!thought.isEmpty()) return "마음이 먼저 결론내리려 하면, 사실부터 같이 보자.";
        if (!need.isEmpty()) return "오늘은 네가 진짜 필요한 게 뭔지 한 번만 챙겨보자.";
        return "";
    }

    public static String checkInReply(Context c, int score) {
        JSONObject p = TherapyMemoryManager.getProfile(c);
        String practice = first(p, "experiment", "reframe");
        String base;
        switch (score) {
            case 1: base = "오늘은 버티는 것만 해도 되는 날이야. 네 마음을 더 몰아붙이지 말자."; break;
            case 2: base = "오늘 마음이 꽤 지쳤구나. 제일 부담되는 것 하나는 줄여도 돼."; break;
            case 3: base = "오늘은 그냥저냥 버틴 날이구나. 마음이 흔들린 장면 하나만 봐도 충분해."; break;
            case 4: base = "오늘은 조금 숨통이 트였구나. 뭐가 덜 힘들게 했는지 기억해두자."; break;
            case 5: base = "좋은 날이네. 오늘 괜찮았던 조건 하나는 네 편으로 남겨두자."; break;
            default: base = "오늘 마음 알려줘서 고마워.";
        }
        if (!practice.isEmpty() && score <= 3) {
            return base + " 요즘 연습하던 것도 오늘은 작게만 해보자: " + shortText(toEverydayPractice(practice), 54);
        }
        return base;
    }

    public static String reportFocus(Context c) {
        JSONObject p = TherapyMemoryManager.getProfile(c);
        String focus = first(p, "focus", "pattern");
        String thought = first(p, "automatic_thought");
        String practice = first(p, "experiment");
        String change = first(p, "recent_change", "corrective_experience");
        if (focus.isEmpty() && thought.isEmpty() && practice.isEmpty() && change.isEmpty()) return "";
        StringBuilder sb = new StringBuilder("\n\n이번 상담 흐름과 연결해서 보면\n");
        if (!focus.isEmpty()) sb.append("• 요즘 핵심: ").append(shortText(focus, 100)).append("\n");
        if (!thought.isEmpty()) sb.append("• 마음이 빨리 붙이는 뜻: ").append(shortText(thought, 100)).append("\n");
        if (!change.isEmpty()) sb.append("• 최근 달라진 점: ").append(shortText(change, 100)).append("\n");
        if (!practice.isEmpty()) sb.append("• 지금 연습: ").append(shortText(toEverydayPractice(practice), 100));
        return sb.toString().trim();
    }

    public static String monthlyAdvice(Context c, String defaultText) {
        String theme = compactTheme(c);
        if (theme.isEmpty()) return defaultText;
        return defaultText + "\n\n그리고 이번 달 기록은 요즘 상담에서 보고 있는 흐름과도 같이 봐보자. " + shortText(theme, 120);
    }

    private static String toEverydayPractice(String s) {
        s = clean(s);
        s = s.replace("사실/해석", "사실과 내 생각")
             .replace("경계", "내 선")
             .replace("자기방어", "나를 지키는 방식")
             .replace("패턴", "반복되는 흐름")
             .replace("자기자비", "내 편이 되는 말");
        return s;
    }
}
