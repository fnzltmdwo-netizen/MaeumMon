package com.maeummon.app;

import android.content.Context;
import android.content.SharedPreferences;

/**
 * v4.1 상담 상태 메모리.
 * 직전 상태 + FORMULATE 확인 여부 + QUESTION_BUDGET을 보존한다.
 */
public final class CounselingStateMemory {
    private static final String PREF = "maeummon_counseling_state_v410";
    private static final String K_STATE = "last_state";
    private static final String K_FORMULATION = "last_formulation";
    private static final String K_AWAITING_CONFIRM = "awaiting_formulation_confirmation";
    private static final String K_INTERVENTION = "last_intervention_focus";
    private static final String K_QUESTION = "last_question";
    private static final String K_QUESTIONS_SINCE_FORMULATION = "questions_since_last_formulation";
    private static final String K_LAST_CORE_SENTENCE = "last_core_sentence";
    private static final String K_LAST_PATTERN_LOOP = "last_pattern_loop";

    private CounselingStateMemory() {}

    private static SharedPreferences p(Context c) {
        return c.getSharedPreferences(PREF, Context.MODE_PRIVATE);
    }

    public static String snapshot(Context c) {
        SharedPreferences s = p(c);
        int questionBudget = s.getInt(K_QUESTIONS_SINCE_FORMULATION, 0);
        StringBuilder b = new StringBuilder();
        b.append("last_state=").append(s.getString(K_STATE, "NONE")).append("\n");
        b.append("awaiting_formulation_confirmation=").append(s.getBoolean(K_AWAITING_CONFIRM, false)).append("\n");
        b.append("questions_since_last_formulation=").append(questionBudget).append("\n");
        b.append("prefer_formulation=").append(questionBudget >= 1).append("\n");
        String f = s.getString(K_FORMULATION, "");
        if (!f.isEmpty()) b.append("last_formulation=").append(trim(f, 1800)).append("\n");
        String core = s.getString(K_LAST_CORE_SENTENCE, "");
        if (!core.isEmpty()) b.append("last_core_sentence=").append(trim(core, 800)).append("\n");
        String loop = s.getString(K_LAST_PATTERN_LOOP, "");
        if (!loop.isEmpty()) b.append("last_pattern_loop=").append(trim(loop, 1200)).append("\n");
        String q = s.getString(K_QUESTION, "");
        if (!q.isEmpty()) b.append("last_question=").append(trim(q, 600)).append("\n");
        String i = s.getString(K_INTERVENTION, "");
        if (!i.isEmpty()) b.append("last_intervention_focus=").append(trim(i, 600)).append("\n");
        return b.toString();
    }

    public static int questionsSinceLastFormulation(Context c) {
        return p(c).getInt(K_QUESTIONS_SINCE_FORMULATION, 0);
    }

    public static void record(Context c, OpenAiClient.MetaCounselDecision d) {
        if (d == null) return;
        SharedPreferences s = p(c);
        SharedPreferences.Editor e = s.edit().putString(K_STATE, d.action);

        if ("ASK".equals(d.action)) {
            int n = s.getInt(K_QUESTIONS_SINCE_FORMULATION, 0);
            e.putString(K_QUESTION, d.question == null ? "" : d.question)
             .putInt(K_QUESTIONS_SINCE_FORMULATION, Math.min(3, n + 1));
        }

        if ("FORMULATE".equals(d.action)) {
            e.putString(K_FORMULATION, d.formulation == null ? "" : d.formulation)
             .putString(K_LAST_CORE_SENTENCE, d.coreSentence == null ? "" : d.coreSentence)
             .putString(K_LAST_PATTERN_LOOP, d.patternLoop == null ? "" : d.patternLoop)
             .putBoolean(K_AWAITING_CONFIRM, true)
             .putInt(K_QUESTIONS_SINCE_FORMULATION, 0);
        } else if ("INTERVENE".equals(d.action)) {
            e.putBoolean(K_AWAITING_CONFIRM, false)
             .putString(K_INTERVENTION, d.interventionFocus == null ? "" : d.interventionFocus)
             .putInt(K_QUESTIONS_SINCE_FORMULATION, 0);
        } else if ("STABILIZE".equals(d.action)) {
            // 안정화 후에는 질문 예산을 누적하지 않는다.
            e.putInt(K_QUESTIONS_SINCE_FORMULATION, 0);
        }
        e.apply();
    }

    public static void clear(Context c) {
        p(c).edit().clear().apply();
    }

    private static String trim(String s, int max) {
        if (s == null) return "";
        return s.length() <= max ? s : s.substring(0, max);
    }
}
