package com.maeummon.app;

import com.maeummon.app.clinical.CentralTherapyProfile;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

public class EmotionDiaryActivity extends Activity {

    private static final int PICK_PHOTO = 4201;
    private String selectedSticker="calm", selectedLabel="잔잔", selectedCause="", photoUri="";
    private String currentDate=EmotionDiaryStorage.today();
    private TextView selectedStickerText, diaryReplyText, diaryDateText, selectedCauseText;
    private EditText diaryEditText, tagInput;
    private ImageView photoPreview;
    private final int[] stickerIds={R.id.stickerCard1,R.id.stickerCard2,R.id.stickerCard3,R.id.stickerCard4,R.id.stickerCard5,R.id.stickerCard6,R.id.stickerCard7,R.id.stickerCard8};
    private final String[] stickers={"good","calm","tired","sad","anxious","angry","comfort","sleepy"};
    private final String[] labels={"좋음","잔잔","지침","슬픔","불안","화남","위로","잠옴"};
    private final int[] causeIds={R.id.causeWork,R.id.causePeople,R.id.causeRest,R.id.causeBody,R.id.causeMoney,R.id.causeFamily,R.id.causeLove,R.id.causeOther};
    private final String[] causes={"업무","사람관계","휴식","몸/피곤","돈","가족","연애","기타"};

    @Override protected void onCreate(Bundle savedInstanceState){super.onCreate(savedInstanceState);if(DiarySecurity.redirectToUnlockIfNeeded(this))return;setContentView(R.layout.activity_emotion_diary);UiInsets.apply(this,findViewById(R.id.diaryRoot));
        selectedStickerText=findViewById(R.id.selectedStickerText);diaryReplyText=findViewById(R.id.diaryReplyText);diaryDateText=findViewById(R.id.diaryDateText);diaryEditText=findViewById(R.id.diaryEditText);selectedCauseText=findViewById(R.id.selectedCauseText);tagInput=findViewById(R.id.tagInput);photoPreview=findViewById(R.id.diaryPhotoPreview);
        String extra=getIntent().getStringExtra("date");if(extra!=null&&!extra.trim().isEmpty())currentDate=extra;setupStickers();setupCauses();findViewById(R.id.prevDateButton).setOnClickListener(v->moveDate(-1));findViewById(R.id.nextDateButton).setOnClickListener(v->moveDate(1));findViewById(R.id.saveDiaryButton).setOnClickListener(v->saveCurrent());findViewById(R.id.addPhotoButton).setOnClickListener(v->pickPhoto());findViewById(R.id.removePhotoButton).setOnClickListener(v->{photoUri="";renderPhoto();});loadCurrentDate();}

    private void moveDate(int delta){Calendar c=Calendar.getInstance();c.setTime(EmotionDiaryStorage.parseDate(currentDate));c.add(Calendar.DAY_OF_MONTH,delta);currentDate=new SimpleDateFormat(EmotionDiaryStorage.DATE_FORMAT,Locale.KOREA).format(c.getTime());loadCurrentDate();}
    private void setupStickers(){for(int i=0;i<stickerIds.length;i++){final int x=i;findViewById(stickerIds[i]).setOnClickListener(v->{selectedSticker=stickers[x];selectedLabel=labels[x];selectedStickerText.setText("선택한 스티커: "+selectedLabel);diaryReplyText.setText(replyFor(selectedLabel));applyStickerUi();});}}
    private void setupCauses(){for(int i=0;i<causeIds.length;i++){final int x=i;findViewById(causeIds[i]).setOnClickListener(v->{selectedCause=causes[x];selectedCauseText.setText("선택한 원인: "+selectedCause);applyCauseUi();});}}
    private void loadCurrentDate(){diaryDateText.setText(currentDate);JSONObject o=EmotionDiaryStorage.getEntryByDate(this,currentDate);if(o!=null){selectedSticker=o.optString("sticker","calm");selectedLabel=o.optString("label","잔잔");selectedCause=o.optString("cause","");photoUri=o.optString("photoUri","");diaryEditText.setText(o.optString("text",""));tagInput.setText(o.optString("tags","").replace(",",", "));}else{selectedSticker="calm";selectedLabel="잔잔";selectedCause="";photoUri="";diaryEditText.setText("");tagInput.setText("");}selectedStickerText.setText("선택한 스티커: "+selectedLabel);selectedCauseText.setText(selectedCause.isEmpty()?"오늘 마음에 가장 영향을 준 원인을 골라줘.":"선택한 원인: "+selectedCause);diaryReplyText.setText(replyFor(selectedLabel));applyStickerUi();applyCauseUi();renderPhoto();}
    private void applyStickerUi(){for(int i=0;i<stickerIds.length;i++){View v=findViewById(stickerIds[i]);boolean s=labels[i].equals(selectedLabel);v.setBackgroundResource(s?R.drawable.bg_sticker_tile_selected:R.drawable.bg_sticker_tile);v.setScaleX(s?1.03f:1f);v.setScaleY(s?1.03f:1f);}}
    private void applyCauseUi(){for(int i=0;i<causeIds.length;i++){View v=findViewById(causeIds[i]);v.setBackgroundResource(causes[i].equals(selectedCause)?R.drawable.bg_tag_choice_selected:R.drawable.bg_tag_choice);}}
    private void pickPhoto(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("image/*");startActivityForResult(i,PICK_PHOTO);}
    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){super.onActivityResult(requestCode,resultCode,data);if(requestCode==PICK_PHOTO&&resultCode==RESULT_OK&&data!=null&&data.getData()!=null){Uri uri=data.getData();try{getContentResolver().takePersistableUriPermission(uri,Intent.FLAG_GRANT_READ_URI_PERMISSION);}catch(Exception ignored){}photoUri=uri.toString();renderPhoto();}}
    private void renderPhoto(){if(photoUri.isEmpty()){photoPreview.setVisibility(View.GONE);photoPreview.setImageDrawable(null);return;}try{photoPreview.setImageURI(Uri.parse(photoUri));photoPreview.setVisibility(View.VISIBLE);}catch(Exception e){photoUri="";photoPreview.setVisibility(View.GONE);}}
    private String replyFor(String label){
        switch(label){
            case "좋음": return "기분이 밝고 마음에 여유가 있는 날이네. 오늘 좋았던 이유를 한 줄 남겨두자.";
            case "잔잔": return "크게 들뜨지도 가라앉지도 않은 편안한 상태야. 이런 평온한 날의 패턴도 소중해.";
            case "지침": return "몸도 마음도 축 처지고 에너지가 부족한 느낌이야. 오늘은 버티기보다 쉬어야 할 신호가 있었는지 적어보자.";
            case "슬픔": return "마음이 가라앉고 눈물이 날 것 같은 날이구나. 이유를 억지로 정리하지 않아도 지금 느낌만 적어도 돼.";
            case "불안": return "걱정이 많고 마음이 편하지 않은 상태야. 무엇이 실제 상황이고 무엇이 걱정의 상상인지 나눠보자.";
            case "화남": return "짜증이나 화가 올라온 날이네. 누가 잘못했는지보다 어떤 상황이 네 선을 넘었는지 적어보자.";
            case "위로": return "누군가에게 다독임을 받고 싶거나, 스스로를 좀 안아주고 싶은 마음이야. 오늘 네게 필요한 말을 적어보자.";
            case "잠옴": return "몸이 졸리고 쉬고 싶다는 신호가 강한 날이야. 지금 해결보다 수면과 회복이 먼저일 수도 있어.";
            default: return "오늘 마음과 원인을 천천히 적어두면 나중에 네 패턴을 더 잘 찾을 수 있어.";
        }
    }
    private void saveCurrent(){String text=diaryEditText.getText().toString().trim();if(text.isEmpty()){Toast.makeText(this,"오늘 마음을 한 줄이라도 적어줘 🌱",Toast.LENGTH_SHORT).show();return;}EmotionDiaryStorage.saveOrUpdate(this,currentDate,selectedSticker,selectedLabel,text,selectedCause,tagInput.getText().toString().trim(),photoUri);MemoryManager.captureDiary(this,selectedLabel,text);CentralTherapyProfile.mergeCheckIn(this,selectedLabel,selectedCause.isEmpty()?text:selectedCause+" · "+text);CentralTherapyProfile.mergeDiaryInsight(this,"감정="+selectedLabel+(selectedCause.isEmpty()?"":" / 원인="+selectedCause)+" / "+(text.length()>180?text.substring(0,180):text),"emotion_diary");PetStateManager.onDiarySaved(this,selectedLabel);CompanionProfile.addAffection(this,2);Toast.makeText(this,currentDate+" 일기 저장 완료 📘",Toast.LENGTH_SHORT).show();finish();}
}
