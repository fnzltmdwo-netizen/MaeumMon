package com.maeummon.app;

import com.maeummon.app.clinical.TherapySurfaceContext;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class DailyLetterActivity extends Activity {

    private TextView letterText;
    private TextView dateText;
    private Button readLetterButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_daily_letter);
        UiInsets.apply(this, findViewById(R.id.letterRoot));

        letterText = findViewById(R.id.letterText);
        dateText = findViewById(R.id.letterDateText);
        readLetterButton = findViewById(R.id.readLetterButton);

        findViewById(R.id.regenerateLetterButton).setOnClickListener(v -> refreshFromCurrentMind(true));

        findViewById(R.id.shareLetterButton).setOnClickListener(v -> {
            Intent intent = new Intent(Intent.ACTION_SEND);
            intent.setType("text/plain");
            intent.putExtra(Intent.EXTRA_SUBJECT, "어린 승재의 오늘 편지");
            intent.putExtra(Intent.EXTRA_TEXT, letterText.getText().toString());
            startActivity(Intent.createChooser(intent, "편지 공유하기"));
        });

        readLetterButton.setOnClickListener(v -> readLetterWithTypecast());

        render();
        if (LiveMindManager.aiRefreshNeeded(this)) refreshFromCurrentMind(false);
    }

    private void readLetterWithTypecast() {
        if (!TtsManager.canUseTypecast(this)) {
            Toast.makeText(this, "먼저 상담 화면에서 Typecast API Key와 어린 승재 목소리를 설정해줘.", Toast.LENGTH_LONG).show();
            return;
        }

        String text = letterText.getText().toString().trim();
        if (text.isEmpty()) return;

        readLetterButton.setEnabled(false);
        readLetterButton.setText("🔊 어린 승재가 읽는 중…");

        TtsManager.speak(this, text, new TtsManager.SpeakListener() {
            @Override
            public void onEngine(String engineName) {
                runOnUiThread(() -> {
                    readLetterButton.setEnabled(true);
                    readLetterButton.setText("🔊 Typecast로 편지 읽기");
                });
            }

            @Override
            public void onError(String message) {
                runOnUiThread(() -> {
                    readLetterButton.setEnabled(true);
                    readLetterButton.setText("🔊 Typecast로 편지 읽기");
                    Toast.makeText(DailyLetterActivity.this, message, Toast.LENGTH_LONG).show();
                });
            }
        });
    }

    @Override
    protected void onDestroy() {
        TtsManager.stop();
        super.onDestroy();
    }

    private void render() {
        dateText.setText(EmotionDiaryStorage.today() + " · 최근 상담/일기 반영");
        letterText.setText(LiveMindManager.getLiveLetter(this));
    }

    private void refreshFromCurrentMind(boolean userRequested) {
        SharedPreferences prefs = getSharedPreferences(AppPrefs.PREFS, MODE_PRIVATE);
        String apiKey = prefs.getString(AppPrefs.KEY_API_KEY, "").trim();
        if (apiKey.isEmpty()) {
            letterText.setText(YoungSeungjaeHome.regenerateDailyLetter(this));
            if (userRequested) Toast.makeText(this, "API Key가 없어 최근 기록 기반 기본 편지로 바꿨어.", Toast.LENGTH_SHORT).show();
            return;
        }
        Button button = findViewById(R.id.regenerateLetterButton);
        button.setEnabled(false);
        button.setText("최근 마음 읽는 중…");
        final String context = LiveMindManager.recentContext(this)
                + "\n\n" + TherapySurfaceContext.forSurface(this, TherapySurfaceContext.DAILY_LETTER)
                + "\n\n" + UnifiedTherapyProfile.buildSharedContext(this);
        final String state = PetStateManager.summary(this);
        new Thread(() -> {
            try {
                String result = OpenAiClient.getLiveDailyLetter(apiKey, context, state, System.nanoTime());
                LiveMindManager.saveAiLetter(this, result);
                runOnUiThread(() -> letterText.setText(result));
            } catch (Exception e) {
                runOnUiThread(() -> {
                    letterText.setText(YoungSeungjaeHome.regenerateDailyLetter(this));
                    if (userRequested) Toast.makeText(this, "지금은 기본 편지로 바꿨어.", Toast.LENGTH_SHORT).show();
                });
            } finally {
                runOnUiThread(() -> {
                    button.setEnabled(true);
                    button.setText("지금 마음으로 편지 새로 쓰기");
                });
            }
        }).start();
    }
}
