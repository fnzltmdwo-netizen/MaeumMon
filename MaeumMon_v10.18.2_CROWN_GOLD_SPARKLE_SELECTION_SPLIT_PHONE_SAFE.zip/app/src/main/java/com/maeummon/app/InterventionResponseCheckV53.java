package com.maeummon.app;

import java.util.Locale;

/** Checks whether an intervention actually landed before stacking another one. */
public final class InterventionResponseCheckV53 {
    private InterventionResponseCheckV53() {}

    public static String buildContext(String userMessage) {
        String t = userMessage == null ? "" : userMessage.toLowerCase(Locale.KOREA);
        boolean resistance = has(t, "근데", "그래도", "못하겠", "어렵", "무리", "안 와닿", "부담", "싫어", "현실적으로");
        boolean uptake = has(t, "해볼게", "할 수 있", "좋다", "와닿", "그건 맞", "그렇게 해볼", "알겠");
        return "[INTERVENTION RESPONSE CHECK v5.3]\n"
                + "resistance_or_mismatch=" + resistance + ", uptake_signal=" + uptake + ".\n"
                + "- 상담기법/행동을 제안한 직후에는 새 기법을 연달아 쌓기보다 사용자의 반응을 증거로 본다.\n"
                + "- '근데/그래도/못하겠어/부담돼'가 나오면 저항으로 낙인찍지 말고 난이도·타이밍·목표가 안 맞았는지 확인해 개입을 낮추거나 바꾼다.\n"
                + "- 사용자가 해볼 만하다고 느끼면 구체적 실행 장면/문장 하나만 선명하게 하고 끝낸다.\n"
                + "- 실제 실행 후에는 EXPECTED vs ACTUAL: 무엇을 예상했는지, 실제 상대반응/내 감정/행동은 어땠는지 비교한다.\n"
                + "- 효과가 없던 기법을 '더 열심히 하라'며 반복하지 않는다. 개입 실패는 사람 실패가 아니라 formulation 또는 dose를 수정할 정보다.";
    }

    public static String prompt() {
        return "[INTERVENTION RESPONSE CHECK v5.3] 개입 후 사용자의 와닿음/부담/실행 가능성/실제 결과를 새 증거로 사용한다. 안 맞으면 사람을 탓하지 말고 기법·난이도·formulation을 수정한다. 실행 후 EXPECTED vs ACTUAL을 회수한다.";
    }

    private static boolean has(String t, String... xs) {
        for (String x : xs) if (t.contains(x.toLowerCase(Locale.KOREA))) return true;
        return false;
    }
}
