package com.maeummon.app.clinical;

import android.content.Context;
import org.json.JSONObject;

public final class TransitionCorrectionFreshEvidenceSupremacyRC13 {
    private TransitionCorrectionFreshEvidenceSupremacyRC13(){}

    public enum State {
        NONE,
        MEMORY_ALLOWED,
        CURRENT_TURN_OVERRIDES_MEMORY,
        MEMORY_BLOCKED_BY_CONFLICT,
        MEMORY_BLOCKED_BY_RETIRED,
        MEMORY_BLOCKED_BY_NO_EXACT_MATCH
    }

    public static final class Result {
        public boolean evaluated=false;
        public boolean memoryAllowed=false;
        public boolean currentTurnOverride=false;
        public boolean blocked=false;
        public State state=State.NONE;
        public String memoryCause="";
        public String memoryReason="";
        public String currentCause="";
        public String currentReason="";
        public String effectiveCause="";
        public String effectiveReason="";
        public String reason="";
        public String summary="";
    }

    public static Result arbitrate(
            Context c,
            ClinicalDecisionRC7 d,
            String userText){

        Result r=new Result();
        if(c==null||d==null){
            r.summary="NONE | MISSING_INPUT";
            return r;
        }

        r.evaluated=true;

        r.memoryCause=safe(
                d.transitionCorrectionConflictActiveCause);
        r.memoryReason=safe(
                d.transitionCorrectionConflictActiveReason);

        r.currentCause=safe(
                d.transitionExplanationCorrectedCause);
        r.currentReason=safe(
                d.transitionExplanationCorrectedReason);

        boolean explicitCurrentCorrection=
                d.transitionExplanationCorrectionApplied
                &&!r.currentCause.isEmpty();

        // Fresh explicit user correction always wins immediately.
        if(explicitCurrentCorrection){
            r.currentTurnOverride=true;
            r.state=State.CURRENT_TURN_OVERRIDES_MEMORY;
            r.effectiveCause=r.currentCause;
            r.effectiveReason=r.currentReason;
            r.reason="EXPLICIT_CURRENT_USER_CORRECTION";
            return finish(r);
        }

        // Current turn can also explicitly reject a previously learned WHY.
        if(d.transitionExplanationCorrectionDetected
                &&d.transitionExplanationClarificationRequired){
            r.currentTurnOverride=true;
            r.blocked=true;
            r.state=State.CURRENT_TURN_OVERRIDES_MEMORY;
            r.effectiveCause="";
            r.effectiveReason="";
            r.reason="CURRENT_USER_REJECTED_PRIOR_EXPLANATION";
            return finish(r);
        }

        String conflictState=safe(
                d.transitionCorrectionConflictState);

        if("CONFLICTED".equals(conflictState)
                ||"REPLACEMENT_PENDING".equals(conflictState)){
            r.blocked=true;
            r.state=State.MEMORY_BLOCKED_BY_CONFLICT;
            r.reason="CORRECTION_MEMORY_NOT_STABLE";
            return finish(r);
        }

        if("RETIRED".equals(conflictState)){
            r.blocked=true;
            r.state=State.MEMORY_BLOCKED_BY_RETIRED;
            r.reason="CORRECTION_MEMORY_RETIRED";
            return finish(r);
        }

        boolean exactBoundary=
                d.transitionCorrectionMemoryReusable
                &&d.transitionCorrectionMemoryExact
                &&"EXACT_TRANSITION".equals(
                    safe(d.transitionCorrectionMemoryMatch));

        if(!exactBoundary){
            r.blocked=true;
            r.state=State.MEMORY_BLOCKED_BY_NO_EXACT_MATCH;
            r.reason="NO_EXACT_TRANSITION_CONTEXT_MATCH";
            return finish(r);
        }

        if(("STABLE".equals(conflictState)
                ||"REPLACED".equals(conflictState))
                &&!r.memoryCause.isEmpty()){
            r.memoryAllowed=true;
            r.state=State.MEMORY_ALLOWED;
            r.effectiveCause=r.memoryCause;
            r.effectiveReason=r.memoryReason;
            r.reason="STABLE_EXACT_MEMORY_WEAK_PRIOR";
            return finish(r);
        }

        r.blocked=true;
        r.state=State.MEMORY_BLOCKED_BY_NO_EXACT_MATCH;
        r.reason="NO_USABLE_CORRECTION_MEMORY";
        return finish(r);
    }

    public static String instruction(Result r){
        if(r==null||!r.evaluated)return "";

        if(r.state==State.CURRENT_TURN_OVERRIDES_MEMORY){
            if(!r.effectiveReason.isEmpty())
                return "CORRECTION_MEMORY_PRIORITY=CURRENT_TURN. 이번 턴 사용자의 직접 수정이 과거 correction memory보다 항상 우선한다. 다음 이유를 사용한다: "
                        +r.effectiveReason;

            return "CORRECTION_MEMORY_PRIORITY=CURRENT_TURN_BLOCK. 사용자가 기존 WHY 설명을 이번 턴에 부정했으므로 과거 correction memory를 답변에 사용하지 않는다.";
        }

        if(r.state==State.MEMORY_ALLOWED)
            return "CORRECTION_MEMORY_PRIORITY=MEMORY_ALLOWED_WEAK. 현재 턴에 충돌하는 새 사용자 정보가 없고 exact transition/context가 유지될 때만 과거 correction memory를 약한 설명 prior로 사용한다.";

        if(r.blocked)
            return "CORRECTION_MEMORY_PRIORITY=BLOCKED. 현재 correction memory는 이번 턴 WHY 설명에 영향을 주지 않는다.";

        return "";
    }

    public static boolean memoryMayInfluence(Result r){
        return r!=null
                &&r.memoryAllowed
                &&!r.currentTurnOverride
                &&r.state==State.MEMORY_ALLOWED;
    }

    private static Result finish(Result r){
        r.summary=r.state.name()
                +" | memoryAllowed="+r.memoryAllowed
                +" | currentOverride="+r.currentTurnOverride
                +" | blocked="+r.blocked
                +" | memoryCause="+r.memoryCause
                +" | currentCause="+r.currentCause
                +" | effectiveCause="+r.effectiveCause
                +" | reason="+r.reason;
        return r;
    }

    private static String safe(String s){
        return s==null?"":s;
    }
}
