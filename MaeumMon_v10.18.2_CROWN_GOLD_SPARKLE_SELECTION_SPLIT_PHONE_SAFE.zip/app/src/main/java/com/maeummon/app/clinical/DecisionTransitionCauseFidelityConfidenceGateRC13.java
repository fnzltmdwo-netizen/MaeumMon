package com.maeummon.app.clinical;

import android.content.Context;
import org.json.*;
import java.util.*;

public final class DecisionTransitionCauseFidelityConfidenceGateRC13 {
    private DecisionTransitionCauseFidelityConfidenceGateRC13(){}

    public enum Confidence {
        NONE,
        LOW,
        MEDIUM,
        HIGH
    }

    public enum State {
        PASS,
        MULTI_CAUSE,
        DOWNGRADED,
        REPAIRED,
        BLOCKED
    }

    public static final class Result {
        public boolean evaluated=false;
        public boolean repaired=false;
        public boolean blocked=false;
        public boolean multiCause=false;
        public State state=State.PASS;
        public Confidence confidence=Confidence.NONE;
        public String primaryCause="NONE";
        public String secondaryCause="";
        public String finalHumanReason="";
        public String reason="";
        public String summary="";
    }

    public static Result validate(
            Context c,
            ClinicalDecisionRC7 d,
            DecisionTransitionCauseAttributionRC13.Result cause){

        Result r=new Result();

        if(c==null||d==null||cause==null){
            r.evaluated=true;
            r.blocked=true;
            r.state=State.BLOCKED;
            r.confidence=Confidence.NONE;
            r.reason="MISSING_INPUT";
            r.summary="BLOCKED | MISSING_INPUT";
            return r;
        }

        r.evaluated=true;
        r.primaryCause=cause.primaryCause.name();
        r.secondaryCause=safe(cause.secondaryCause);
        r.finalHumanReason=safe(cause.humanReason);

        if(!cause.transitionDetected){
            r.state=State.PASS;
            r.confidence=Confidence.NONE;
            r.reason="NO_TRANSITION";
            return finish(r);
        }

        JSONObject f=CentralTherapyProfile.loadFormulation(c);

        ArrayList<String> candidates=new ArrayList<>();

        if(d.safetyOverride)
            candidates.add("SAFETY_OVERRIDE");

        if(d.allianceRupture)
            candidates.add("ALLIANCE_REPAIR");

        if(d.outcomeRevisionReviewRequired)
            candidates.add("OUTCOME_REVIEW");

        if(d.outcomeRevisionApplied)
            candidates.add("OUTCOME_REVISION");

        if(f.optBoolean("formulation_reopened",false))
            candidates.add("FORMULATION_REOPEN");

        if("REVIEW".equals(safe(d.move)))
            candidates.add("OUTCOME_REVIEW");

        if(DecisionTransitionSnapshotContinuityRC13
                .meaningfulTargetTransition(d))
            candidates.add("TARGET_INFORMATION_GAIN");

        if(DecisionTransitionSnapshotContinuityRC13
                .meaningfulInterventionTransition(d)){

            if(!safe(d.interventionReviewOutcome).isEmpty())
                candidates.add("INTERVENTION_OUTCOME_ADAPTATION");

            if(d.policyRetrievalApplicable
                    &&!d.policySelectionSuppressed
                    &&!safe(d.policySelectionEffectiveKey).isEmpty())
                candidates.add("POLICY_MEMORY_SUPPORT");

            candidates.add("NEW_USER_EVIDENCE");
        }

        if(DecisionTransitionSnapshotContinuityRC13
                .meaningfulMoveTransition(d))
            candidates.add("NEW_USER_EVIDENCE");

        dedupe(candidates);

        r.multiCause=candidates.size()>1;

        // Strong direct causes.
        if("SAFETY_OVERRIDE".equals(r.primaryCause)
                &&d.safetyOverride){
            r.confidence=Confidence.HIGH;
            r.state=r.multiCause?State.MULTI_CAUSE:State.PASS;
            r.secondaryCause=secondaryAfter(candidates,r.primaryCause);
            r.reason="DIRECT_SAFETY_SIGNAL";
            return finish(r);
        }

        if("ALLIANCE_REPAIR".equals(r.primaryCause)
                &&d.allianceRupture){
            r.confidence=Confidence.HIGH;
            r.state=r.multiCause?State.MULTI_CAUSE:State.PASS;
            r.secondaryCause=secondaryAfter(candidates,r.primaryCause);
            r.reason="DIRECT_ALLIANCE_SIGNAL";
            return finish(r);
        }

        if("OUTCOME_REVISION".equals(r.primaryCause)
                &&d.outcomeRevisionApplied){
            r.confidence=Confidence.HIGH;
            r.state=r.multiCause?State.MULTI_CAUSE:State.PASS;
            r.secondaryCause=secondaryAfter(candidates,r.primaryCause);
            r.reason="DIRECT_REVISION_SIGNAL";
            return finish(r);
        }

        if("OUTCOME_REVIEW".equals(r.primaryCause)
                &&(d.outcomeRevisionReviewRequired
                    ||"REVIEW".equals(safe(d.move)))){
            r.confidence=Confidence.HIGH;
            r.state=r.multiCause?State.MULTI_CAUSE:State.PASS;
            r.secondaryCause=secondaryAfter(candidates,r.primaryCause);
            r.reason="DIRECT_REVIEW_SIGNAL";
            return finish(r);
        }

        if("FORMULATION_REOPEN".equals(r.primaryCause)
                &&f.optBoolean("formulation_reopened",false)){
            r.confidence=Confidence.HIGH;
            r.state=r.multiCause?State.MULTI_CAUSE:State.PASS;
            r.secondaryCause=secondaryAfter(candidates,r.primaryCause);
            r.reason="DIRECT_REOPEN_SIGNAL";
            return finish(r);
        }

        // Moderately grounded causes.
        if("TARGET_INFORMATION_GAIN".equals(r.primaryCause)
                &&DecisionTransitionSnapshotContinuityRC13
                    .meaningfulTargetTransition(d)){
            r.confidence=Confidence.MEDIUM;
            r.state=r.multiCause?State.MULTI_CAUSE:State.PASS;
            r.secondaryCause=secondaryAfter(candidates,r.primaryCause);
            r.reason="TARGET_TRANSITION_SUPPORTED";
            return finish(r);
        }

        if("INTERVENTION_OUTCOME_ADAPTATION".equals(r.primaryCause)
                &&DecisionTransitionSnapshotContinuityRC13
                    .meaningfulInterventionTransition(d)
                &&!safe(d.interventionReviewOutcome).isEmpty()){
            r.confidence=Confidence.MEDIUM;
            r.state=r.multiCause?State.MULTI_CAUSE:State.PASS;
            r.secondaryCause=secondaryAfter(candidates,r.primaryCause);
            r.reason="INTERVENTION_REVIEW_SUPPORTS_CAUSE";
            return finish(r);
        }

        // Policy can support, but never be a high-confidence sole cause.
        if("POLICY_MEMORY_SUPPORT".equals(r.primaryCause)){
            if(d.policyRetrievalApplicable
                    &&!d.policySelectionSuppressed
                    &&!safe(d.policySelectionEffectiveKey).isEmpty()){
                r.confidence=Confidence.LOW;
                r.state=State.DOWNGRADED;
                r.secondaryCause="NEW_USER_EVIDENCE";
                r.finalHumanReason="현재 판단이 먼저 바뀌었고, 비슷한 상황의 과거 기록은 그 선택을 보조하는 정도로만 참고했어.";
                r.reason="POLICY_CAUSE_DOWNGRADED_TO_SUPPORT";
                return finish(r);
            }

            r.repaired=true;
            r.state=State.REPAIRED;
            r.confidence=Confidence.LOW;
            r.primaryCause="NEW_USER_EVIDENCE";
            r.secondaryCause="";
            r.finalHumanReason="방금 나온 정보가 이전 판단의 우선순위를 바꿔서 다음 움직임을 조정한 거야.";
            r.reason="POLICY_CAUSE_NOT_ELIGIBLE_REPAIRED";
            return finish(r);
        }

        // Generic new evidence should remain modest unless a direct discriminator exists.
        if("NEW_USER_EVIDENCE".equals(r.primaryCause)){
            r.confidence=r.multiCause?Confidence.LOW:Confidence.MEDIUM;
            r.state=r.multiCause?State.MULTI_CAUSE:State.PASS;
            r.secondaryCause=secondaryAfter(candidates,r.primaryCause);
            r.reason=r.multiCause
                    ?"NEW_EVIDENCE_WITH_COMPETING_CAUSES"
                    :"NEW_EVIDENCE_SUPPORTED_BY_TRANSITION";
            return finish(r);
        }

        // Unknown / unsupported classification.
        if(!candidates.contains(r.primaryCause)){
            r.repaired=true;
            r.state=State.REPAIRED;
            r.confidence=Confidence.LOW;
            r.primaryCause=candidates.isEmpty()
                    ?"UNKNOWN"
                    :candidates.get(0);
            r.secondaryCause=secondaryAfter(
                    candidates,r.primaryCause);
            r.finalHumanReason=genericReason(r.primaryCause);
            r.reason="PRIMARY_CAUSE_NOT_SUPPORTED_BY_CURRENT_STATE";
            return finish(r);
        }

        r.state=r.multiCause?State.MULTI_CAUSE:State.PASS;
        r.confidence=Confidence.MEDIUM;
        r.secondaryCause=secondaryAfter(candidates,r.primaryCause);
        r.reason="CAUSE_SUPPORTED";
        return finish(r);
    }

    public static String instruction(Result r){
        if(r==null||!r.evaluated)return "";

        if(r.state==State.BLOCKED)
            return "TRANSITION_CAUSE_FIDELITY=BLOCKED. 전환 원인을 사용자에게 확정적으로 설명하지 않는다.";

        String certainty=
                r.confidence==Confidence.HIGH
                    ?"분명한 직접 신호가 있어서"
                    :r.confidence==Confidence.MEDIUM
                        ?"현재 흐름상 가장 가능성이 높아서"
                        :"여러 가능성 중 하나로";

        return "TRANSITION_CAUSE_FIDELITY="
                +r.state.name()
                +" confidence="+r.confidence.name()
                +". 전환 이유를 설명할 때 원인을 확정 사실처럼 말하지 말고, "
                +certainty
                +" 다음 문장을 우선 사용한다: "
                +r.finalHumanReason;
    }

    private static void dedupe(ArrayList<String> xs){
        LinkedHashSet<String> s=new LinkedHashSet<>(xs);
        xs.clear();
        xs.addAll(s);
    }

    private static String secondaryAfter(
            ArrayList<String> candidates,
            String primary){

        for(String x:candidates)
            if(!x.equals(primary))
                return x;

        return "";
    }

    private static String genericReason(String cause){
        if("SAFETY_OVERRIDE".equals(cause))
            return "지금은 안전과 안정화를 우선해야 해서 방향을 바꾼 거야.";
        if("ALLIANCE_REPAIR".equals(cause))
            return "서로 이해가 맞는지 다시 확인하는 게 먼저라서 방향을 조정한 거야.";
        if("FORMULATION_REOPEN".equals(cause))
            return "새 정보가 기존 해석과 잘 맞지 않아서 이전 결론을 다시 열어본 거야.";
        if("OUTCOME_REVIEW".equals(cause))
            return "직전 방법의 실제 영향을 확인해야 해서 다음 움직임을 REVIEW 쪽으로 바꾼 거야.";
        if("TARGET_INFORMATION_GAIN".equals(cause))
            return "상담 방향을 더 크게 가를 정보가 보여서 질문의 초점을 바꾼 거야.";
        return "현재 새 정보와 상담 흐름을 반영해서 다음 움직임을 조정했어.";
    }

    private static Result finish(Result r){
        r.summary=r.state.name()
                +" | confidence="+r.confidence.name()
                +" | primary="+r.primaryCause
                +" | secondary="+r.secondaryCause
                +" | multiCause="+r.multiCause
                +" | repaired="+r.repaired
                +" | reason="+r.reason;
        return r;
    }

    private static String safe(String s){
        return s==null?"":s;
    }
}
