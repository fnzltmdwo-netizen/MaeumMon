package com.maeummon.app;

import android.os.Handler;

import java.util.Random;

public class MascotStateMachine {

    public interface Listener {
        void onState(AnimatedTerriermonView.State state);
    }

    private final Handler handler;
    private final Random random = new Random();
    private final Listener listener;
    private boolean running = false;

    private final Runnable loop = new Runnable() {
        @Override
        public void run() {
            if (!running) return;

            int r = random.nextInt(100);
            AnimatedTerriermonView.State next;

            if (r < 45) next = AnimatedTerriermonView.State.WALK;
            else if (r < 68) next = AnimatedTerriermonView.State.IDLE;
            else if (r < 78) next = AnimatedTerriermonView.State.HAPPY;
            else if (r < 87) next = AnimatedTerriermonView.State.TALK;
            else if (r < 94) next = AnimatedTerriermonView.State.SLEEP;
            else next = AnimatedTerriermonView.State.JUMP;

            listener.onState(next);

            long delay;
            switch (next) {
                case WALK: delay = 5000 + random.nextInt(3500); break;
                case SLEEP: delay = 6500 + random.nextInt(3500); break;
                case TALK: delay = 3200 + random.nextInt(1800); break;
                default: delay = 2600 + random.nextInt(3000); break;
            }

            handler.postDelayed(this, delay);
        }
    };

    public MascotStateMachine(Handler handler, Listener listener) {
        this.handler = handler;
        this.listener = listener;
    }

    public void start() {
        if (running) return;
        running = true;
        handler.post(loop);
    }

    public void stop() {
        running = false;
        handler.removeCallbacks(loop);
    }
}
