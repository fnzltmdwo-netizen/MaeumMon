package com.maeummon.app.clinical;

import android.content.Context;
import org.json.*;
import java.util.*;

public final class EvidenceConflictResolutionRC8 {
    private EvidenceConflictResolutionRC8(){}

    public static final class Conflict {
        public String key="";
        public String sideA="";
        public String sideB="";
        public String winner="UNRESOLVED";
        public double winnerStrength=0.0;
        public String rationale="";
        public boolean unresolved=true;

        JSONObject toJson(){
            JSONObject o=new JSONObject();
            try{
                o.put("key",key);
                o.put("side_a",sideA);
                o.put("side_b",sideB);
                o.put("winner",winner);
                o.put("winner_strength",round(winnerStrength));
                o.put("rationale",rationale);
                o.put("unresolved",unresolved);
            }catch(Exception ignored){}
            return o;
        }
    }

    public static final class Result {
        public int conflicts=0;
        public int unresolved=0;
        public String summary="";
        public final JSONArray matrix=new JSONArray();
    }

    public static Result resolve(Context c,String userText){
        Result r=new Result();
        if(c==null)return r;

        JSONObject f=CentralTherapyProfile.loadFormulation(c);
        JSONArray hs=f.optJSONArray("alternative_hypotheses");
        if(hs==null)return r;

        List<Conflict> conflicts=new ArrayList<>();

        // Relationship baseline conflict
        Conflict baseline=detectPair(
                "relationship_baseline",
                userText,
                new String[]{"원래도 느려","늘 느렸","평소에도 그래"},
                "NORMAL_BASELINE",
                new String[]{"최근부터 느려","갑자기 느려","예전엔 빨랐","요즘 달라"},
                "RECENT_CHANGE");
        if(baseline!=null)conflicts.add(baseline);

        // Conflict presence
        Conflict conflict=detectPair(
                "recent_conflict",
                userText,
                new String[]{"싸웠","갈등 있었","다퉜","서운한 일 있었"},
                "CONFLICT_PRESENT",
                new String[]{"싸운 일 없어","갈등 없어","다툰 적 없어","별일 없었"},
                "NO_CONFLICT");
        if(conflict!=null)conflicts.add(conflict);

        // Selective vs global style
        Conflict selective=detectPair(
                "selective_change",
                userText,
                new String[]{"나한테만","나한테 유독","다른 사람한텐 안"},
                "SELECTIVE",
                new String[]{"누구에게나 느려","원래 다 그래","모두한테 그래"},
                "GLOBAL_STYLE");
        if(selective!=null)conflicts.add(selective);

        // Work: evaluation vs workload
        Conflict work=detectPair(
                "work_stressor",
                userText,
                new String[]{"무능","평가","능력 없","일 못하는 사람"},
                "EVALUATION_THREAT",
                new String[]{"일이 많","업무량","시간이 부족","할 일이 너무 많"},
                "WORKLOAD");
        if(work!=null)conflicts.add(work);

        // Merge with prior unresolved matrix and resolve using recency/directness.
        JSONArray prior=f.optJSONArray("evidence_conflict_matrix");
        Map<String,Conflict> merged=new LinkedHashMap<>();

        if(prior!=null){
            for(int i=0;i<prior.length();i++){
                JSONObject o=prior.optJSONObject(i);
                if(o==null)continue;
                Conflict x=new Conflict();
                x.key=o.optString("key","");
                x.sideA=o.optString("side_a","");
                x.sideB=o.optString("side_b","");
                x.winner=o.optString("winner","UNRESOLVED");
                x.winnerStrength=o.optDouble("winner_strength",0);
                x.rationale=o.optString("rationale","");
                x.unresolved=o.optBoolean("unresolved",true);
                if(!x.key.isEmpty())merged.put(x.key,x);
            }
        }

        for(Conflict x:conflicts){
            Conflict old=merged.get(x.key);
            if(old==null){
                merged.put(x.key,x);
            }else{
                // Latest explicit statement beats older unresolved/weak statement.
                if(x.winnerStrength>=old.winnerStrength || old.unresolved){
                    merged.put(x.key,x);
                }
            }
        }

        // Apply conflict outcomes gently to hypotheses.
        JSONArray matrix=new JSONArray();
        for(Conflict x:merged.values()){
            applyToHypotheses(hs,x);
            matrix.put(x.toJson());
            r.conflicts++;
            if(x.unresolved)r.unresolved++;
        }

        try{
            f.put("alternative_hypotheses",hs);
            f.put("evidence_conflict_matrix",matrix);
            f.put("evidence_conflict_count",r.conflicts);
            f.put("unresolved_evidence_conflicts",r.unresolved);
            f.put("evidence_conflict_updated_at",System.currentTimeMillis());
            CentralTherapyProfile.replaceFormulation(c,f);
        }catch(Exception ignored){}

        r.summary="conflicts="+r.conflicts+", unresolved="+r.unresolved;
        for(int i=0;i<matrix.length();i++)r.matrix.put(matrix.opt(i));
        return r;
    }

    public static String instruction(Result r){
        if(r==null||r.conflicts==0)return "";
        if(r.unresolved>0){
            return "EVIDENCE_CONFLICT=true. 서로 충돌하는 정보가 남아 있다. "
                    +"한쪽을 억지로 사실로 확정하지 말고, 해결되지 않은 충돌을 formulation의 불확실성으로 유지한다. "
                    +r.summary;
        }
        return "EVIDENCE_CONFLICT_RESOLVED=true. 최근 직접 확인된 정보와 명시적 정정을 우선 반영하되, "
                +"이전 상반된 evidence는 삭제하지 않고 conflict history로 남긴다. "+r.summary;
    }

    private static Conflict detectPair(
            String key,String text,
            String[] a,String labelA,
            String[] b,String labelB){
        if(text==null)return null;

        boolean hasA=containsAny(text,a);
        boolean hasB=containsAny(text,b);
        if(!hasA&&!hasB)return null;

        Conflict c=new Conflict();
        c.key=key;
        c.sideA=labelA;
        c.sideB=labelB;

        if(hasA&&hasB){
            c.winner="UNRESOLVED";
            c.winnerStrength=0.0;
            c.unresolved=true;
            c.rationale="same utterance contains contradictory evidence";
        }else if(hasA){
            c.winner=labelA;
            c.winnerStrength=0.85;
            c.unresolved=false;
            c.rationale="latest direct statement supports "+labelA;
        }else{
            c.winner=labelB;
            c.winnerStrength=0.85;
            c.unresolved=false;
            c.rationale="latest direct statement supports "+labelB;
        }
        return c;
    }

    private static void applyToHypotheses(JSONArray hs,Conflict c){
        if(hs==null||c==null||c.unresolved)return;

        if("relationship_baseline".equals(c.key)){
            if("NORMAL_BASELINE".equals(c.winner)){
                adjust(hs,"normal_response_variation",+0.08);
                adjust(hs,"relationship_distance_change",-0.08);
            }else if("RECENT_CHANGE".equals(c.winner)){
                adjust(hs,"relationship_distance_change",+0.08);
                adjust(hs,"normal_response_variation",-0.08);
            }
        }

        if("recent_conflict".equals(c.key)){
            if("CONFLICT_PRESENT".equals(c.winner)){
                adjust(hs,"actual_rejection_or_conflict",+0.08);
            }else if("NO_CONFLICT".equals(c.winner)){
                adjust(hs,"actual_rejection_or_conflict",-0.10);
            }
        }

        if("selective_change".equals(c.key)){
            if("SELECTIVE".equals(c.winner)){
                adjust(hs,"relationship_distance_change",+0.08);
                adjust(hs,"normal_response_variation",-0.06);
            }else if("GLOBAL_STYLE".equals(c.winner)){
                adjust(hs,"normal_response_variation",+0.08);
                adjust(hs,"relationship_distance_change",-0.06);
            }
        }

        if("work_stressor".equals(c.key)){
            if("EVALUATION_THREAT".equals(c.winner)){
                adjust(hs,"evaluation_threat",+0.08);
                adjust(hs,"workload_stress",-0.04);
            }else if("WORKLOAD".equals(c.winner)){
                adjust(hs,"workload_stress",+0.08);
                adjust(hs,"evaluation_threat",-0.04);
            }
        }

        renormalizeActive(hs);
    }

    private static void adjust(JSONArray hs,String id,double delta){
        for(int i=0;i<hs.length();i++){
            JSONObject h=hs.optJSONObject(i);
            if(h==null||!id.equals(h.optString("id","")))continue;
            try{
                double v=h.optDouble("confidence",0.0);
                h.put("confidence",Math.max(0.02,Math.min(0.95,v+delta)));
            }catch(Exception ignored){}
        }
    }

    private static void renormalizeActive(JSONArray hs){
        double sum=0.0;
        for(int i=0;i<hs.length();i++){
            JSONObject h=hs.optJSONObject(i);
            if(h!=null&&h.optBoolean("active",true))sum+=h.optDouble("confidence",0);
        }
        if(sum<=0)return;
        for(int i=0;i<hs.length();i++){
            JSONObject h=hs.optJSONObject(i);
            if(h==null||!h.optBoolean("active",true))continue;
            try{h.put("confidence",round(h.optDouble("confidence",0)/sum));}
            catch(Exception ignored){}
        }
    }

    private static boolean containsAny(String s,String[] xs){
        for(String x:xs)if(s.contains(x))return true;
        return false;
    }

    private static double round(double x){return Math.round(x*1000.0)/1000.0;}
}
