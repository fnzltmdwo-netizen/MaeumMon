package com.maeummon.app.clinical;

import android.content.Context;
import org.json.*;

public final class AttributionResolutionOutcomeCommitGateRC10 {
    private AttributionResolutionOutcomeCommitGateRC10(){}

    public enum CommitState {
        NONE,
        PENDING,
        COMMIT,
        REJECT
    }

    public static final class Result {
        public CommitState state=CommitState.NONE;
        public boolean outcomeLearningAllowed=false;
        public boolean suppressGenericOutcomeLearning=false;
        public String committedOutcome="UNKNOWN";
        public String experimentId="";
        public String attributionResolution="";
        public String reason="";
        public String summary="";
    }

    public static Result resolve(
            Context c,String userText,ClinicalDecisionRC7 d,
            MicroExperimentReviewEvidenceMapperRC10.Result mapping){

        Result r=new Result();
        JSONObject s=CentralTherapyProfile.loadSessionState(c);
        JSONObject p=CentralTherapyProfile.loadProfile(c);

        boolean pending=s.optBoolean(
                "pending_review_attribution_clarification",false);

        String priorResolution=s.optString(
                "last_review_attribution_resolution","");

        String experimentId=s.optString(
                "active_micro_experiment_id",
                p.optString("active_micro_experiment_id",""));

        r.experimentId=experimentId;

        // 1. Direct/probable attribution does not need clarification.
        if(mapping!=null && mapping.outcomeEligible){
            r.state=CommitState.COMMIT;
            r.outcomeLearningAllowed=true;
            r.suppressGenericOutcomeLearning=false;
            r.committedOutcome=mapping.mappedOutcome;
            r.attributionResolution=mapping.attribution.name();
            r.reason="직전 micro-experiment 결과로 충분히 연결되어 outcome learning을 허용한다.";
            persist(c,r,userText);
            return finish(r);
        }

        // 2. Pending clarification: do not learn until explicit yes/no resolution.
        if(pending){
            String resolution=detectResolution(userText);

            if("CONFIRMED".equals(resolution)){
                r.state=CommitState.COMMIT;
                r.outcomeLearningAllowed=true;
                r.suppressGenericOutcomeLearning=false;
                r.committedOutcome=
                        InterventionOutcomeLearningLoopRC10.detectOutcome(userText).name();

                // If confirmation message only says "응 맞아" with no fresh outcome word,
                // recover the outcome from the previously uncertain user evidence.
                if("UNKNOWN".equals(r.committedOutcome)){
                    String buffered=s.optString(
                            "pending_review_attribution_outcome_candidate","UNKNOWN");
                    r.committedOutcome=buffered;
                }

                r.attributionResolution="CONFIRMED";
                r.reason="사용자가 직전 결과가 활성 experiment에 대한 것이라고 확인했다.";

                clearPending(c,s,"CONFIRMED");
                persist(c,r,userText);
                return finish(r);
            }

            if("REJECTED".equals(resolution)){
                r.state=CommitState.REJECT;
                r.outcomeLearningAllowed=false;
                r.suppressGenericOutcomeLearning=true;
                r.committedOutcome="UNKNOWN";
                r.attributionResolution="REJECTED";
                r.reason="사용자가 해당 변화가 직전 experiment 결과가 아니라고 확인했다.";

                clearPending(c,s,"REJECTED");
                persist(c,r,userText);
                return finish(r);
            }

            r.state=CommitState.PENDING;
            r.outcomeLearningAllowed=false;
            r.suppressGenericOutcomeLearning=true;
            r.committedOutcome="UNKNOWN";
            r.attributionResolution="PENDING";
            r.reason="귀인 확인 답변이 아직 없어 outcome learning을 보류한다.";
            return finish(r);
        }

        // 3. POSSIBLE attribution: buffer candidate outcome and wait.
        if(mapping!=null
                && mapping.attribution
                    == MicroExperimentReviewEvidenceMapperRC10.Attribution.POSSIBLE){

            String candidate=
                    InterventionOutcomeLearningLoopRC10.detectOutcome(userText).name();

            try{
                s.put("pending_review_attribution_clarification",true);
                s.put("pending_review_attribution_outcome_candidate",candidate);
                s.put("pending_review_attribution_experiment_id",experimentId);
                s.put("pending_review_attribution_original_evidence",
                        compact(userText,400));
                s.put("pending_review_attribution_started_at",
                        System.currentTimeMillis());
                CentralTherapyProfile.replaceSessionState(c,s);
            }catch(Exception ignored){}

            r.state=CommitState.PENDING;
            r.outcomeLearningAllowed=false;
            r.suppressGenericOutcomeLearning=true;
            r.committedOutcome="UNKNOWN";
            r.attributionResolution="PENDING";
            r.reason="POSSIBLE attribution은 확인 전까지 outcome candidate만 버퍼링한다.";
            return finish(r);
        }

        // 4. Previously rejected outcome must not leak back through generic detector.
        if("REJECTED".equals(priorResolution)){
            r.state=CommitState.NONE;
            r.outcomeLearningAllowed=false;
            r.suppressGenericOutcomeLearning=false;
            r.committedOutcome="UNKNOWN";
            r.attributionResolution="REJECTED_PREVIOUS";
            r.reason="직전 귀인 거절은 이미 처리되어 새 결과 신호가 없으면 추가 학습하지 않는다.";
            return finish(r);
        }

        r.state=CommitState.NONE;
        r.outcomeLearningAllowed=false;
        r.suppressGenericOutcomeLearning=false;
        r.summary="NONE | NO_ATTRIBUTABLE_OUTCOME";
        return r;
    }

    public static String instruction(Result r){
        if(r==null)return "";

        if(r.state==CommitState.COMMIT){
            return "OUTCOME_COMMIT=YES. 확인된 micro-experiment 결과만 outcome learning에 반영한다. committed_outcome="
                    +r.committedOutcome+".";
        }

        if(r.state==CommitState.REJECT){
            return "OUTCOME_COMMIT=REJECTED. 이번 변화는 직전 experiment 효과로 학습하지 않는다.";
        }

        if(r.state==CommitState.PENDING){
            return "OUTCOME_COMMIT=PENDING. 귀인 확인 전에는 generic HELPED/PARTIAL/NO_CHANGE/WORSE 학습을 억제한다.";
        }

        return "";
    }

    public static String detectResolution(String userText){
        String u=userText==null?"":userText.trim();

        if(containsAny(u,
                "응","맞아","맞아 그거","그거 맞아",
                "그거 했을 때","그 방법 맞아","그 실험 맞아",
                "해봤을 때 맞아","응 그 얘기야"))
            return "CONFIRMED";

        if(containsAny(u,
                "아니","그건 아니","그거 때문은 아니",
                "그 실험 얘기 아니","그 방법 말고",
                "상관없어","다른 얘기야"))
            return "REJECTED";

        return "";
    }

    private static void clearPending(
            Context c,JSONObject s,String resolution){

        try{
            s.put("pending_review_attribution_clarification",false);
            s.put("last_review_attribution_resolution",resolution);
            s.put("last_review_attribution_resolution_at",
                    System.currentTimeMillis());
            s.remove("pending_review_attribution_question");
            s.remove("pending_review_attribution_target");
            s.remove("pending_review_attribution_outcome_candidate");
            s.remove("pending_review_attribution_original_evidence");
            CentralTherapyProfile.replaceSessionState(c,s);
        }catch(Exception ignored){}
    }

    private static void persist(
            Context c,Result r,String userText){

        try{
            JSONObject p=CentralTherapyProfile.loadProfile(c);
            JSONObject s=CentralTherapyProfile.loadSessionState(c);

            JSONObject item=new JSONObject();
            item.put("experiment_id",r.experimentId);
            item.put("commit_state",r.state.name());
            item.put("resolution",r.attributionResolution);
            item.put("outcome",r.committedOutcome);
            item.put("evidence",compact(userText,400));
            item.put("reason",r.reason);
            item.put("time",System.currentTimeMillis());

            JSONArray h=p.optJSONArray(
                    "micro_experiment_outcome_commit_history");
            if(h==null)h=new JSONArray();
            h.put(item);

            JSONArray trimmed=new JSONArray();
            int start=Math.max(0,h.length()-30);
            for(int i=start;i<h.length();i++)
                trimmed.put(h.opt(i));

            p.put("micro_experiment_outcome_commit_history",trimmed);
            p.put("last_outcome_commit_state",r.state.name());
            p.put("last_outcome_commit_value",r.committedOutcome);
            p.put("last_outcome_commit_resolution",
                    r.attributionResolution);

            s.put("last_outcome_commit_state",r.state.name());
            s.put("last_outcome_commit_value",r.committedOutcome);

            CentralTherapyProfile.replaceProfile(c,p);
            CentralTherapyProfile.replaceSessionState(c,s);
        }catch(Exception ignored){}
    }

    private static Result finish(Result r){
        r.summary=r.state.name()
                +" | learningAllowed="+r.outcomeLearningAllowed
                +" | suppressGeneric="+r.suppressGenericOutcomeLearning
                +" | outcome="+r.committedOutcome
                +" | resolution="+r.attributionResolution;
        return r;
    }

    private static boolean containsAny(String s,String... xs){
        if(s==null)return false;
        for(String x:xs)
            if(x!=null&&!x.isEmpty()&&s.contains(x))
                return true;
        return false;
    }

    private static String compact(String s,int max){
        s=s==null?"":s.trim();
        return s.length()<=max?s:s.substring(0,max);
    }
}
