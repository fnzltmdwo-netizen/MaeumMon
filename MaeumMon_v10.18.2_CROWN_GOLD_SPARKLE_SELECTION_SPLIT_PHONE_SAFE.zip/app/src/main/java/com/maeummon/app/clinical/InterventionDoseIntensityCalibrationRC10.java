package com.maeummon.app.clinical;

import android.content.Context;
import org.json.*;

public final class InterventionDoseIntensityCalibrationRC10 {
    private InterventionDoseIntensityCalibrationRC10(){}

    public enum Dose {
        NONE, MICRO, LIGHT, STANDARD, DEEP
    }

    public static final class Result {
        public Dose dose=Dose.NONE;
        public int maxSteps=0;
        public boolean homeworkAllowed=false;
        public int exerciseMinutes=0;
        public String deliveryStyle="";
        public String rationale="";
        public String blockedReason="";
    }

    public static Result calibrate(Context c,ClinicalDecisionRC7 d){
        Result r=new Result();
        if(d==null){
            r.blockedReason="NO_DECISION";
            return r;
        }

        JSONObject f=CentralTherapyProfile.loadFormulation(c);
        JSONObject p=CentralTherapyProfile.loadProfile(c);

        String phase=safe(d.sessionPhase);
        String pacing=safe(d.therapeuticPacing);
        String need=f.optString("response_need","");
        String outcome=readLastOutcome(p,f);
        String readiness=readReadiness(p,f);
        boolean bridgeReady=d.centralBridgeReady;

        // 1. Hard blocks.
        if(d.safetyOverride){
            block(r,"SAFETY_OVERRIDE");
            return r;
        }
        if(d.allianceRupture){
            block(r,"ALLIANCE_RUPTURE");
            return r;
        }
        if(!bridgeReady){
            block(r,"BRIDGE_NOT_READY");
            return r;
        }
        if("ORIENT".equals(phase)||"UNDERSTAND".equals(phase)){
            block(r,"PHASE_NOT_READY");
            return r;
        }
        if("COMPLETE".equals(phase)){
            block(r,"COMPLETE_PHASE");
            return r;
        }
        if("UNDERSTANDING".equalsIgnoreCase(need)
                ||"VENTING".equalsIgnoreCase(need)){
            block(r,"RESPONSE_NEED_NOT_ACTION");
            return r;
        }

        // 2. Start from phase baseline.
        if("CHANGE".equals(phase)){
            setLight(r,"CHANGE_PHASE");
        }else if("PRACTICE".equals(phase)){
            setStandard(r,"PRACTICE_PHASE");
        }else if("CONSOLIDATE".equals(phase)){
            setLight(r,"CONSOLIDATE_PHASE");
        }else{
            setMicro(r,"UNSPECIFIED_PHASE");
        }

        // 3. Outcome adaptation.
        if("WORSE".equals(outcome)){
            setMicro(r,"LAST_OUTCOME_WORSE");
            r.homeworkAllowed=false;
            r.exerciseMinutes=0;
        }else if("NO_CHANGE".equals(outcome)){
            if(r.dose==Dose.DEEP)setStandard(r,"NO_CHANGE_NO_BLIND_ESCALATION");
        }else if("HELPED".equals(outcome)||"PARTIAL".equals(outcome)){
            if("PRACTICE".equals(phase)
                    && isReady(readiness)
                    && !"GENTLE".equals(pacing)
                    && !"SLOW".equals(pacing)){
                setDeep(r,"HELPED_AND_READY_IN_PRACTICE");
            }
        }

        // 4. Pacing caps.
        if("GENTLE".equals(pacing)){
            capAt(r,Dose.MICRO,"GENTLE_CAP");
        }else if("SLOW".equals(pacing)){
            capAt(r,Dose.LIGHT,"SLOW_CAP");
        }

        // 5. Consolidation never introduces deep work.
        if("CONSOLIDATE".equals(phase)){
            capAt(r,Dose.STANDARD,"CONSOLIDATE_CAP");
        }

        // 6. Low readiness caps intensity.
        if("LOW".equalsIgnoreCase(readiness)){
            capAt(r,Dose.MICRO,"LOW_READINESS_CAP");
        }else if("MEDIUM".equalsIgnoreCase(readiness)){
            capAt(r,Dose.STANDARD,"MEDIUM_READINESS_CAP");
        }

        // 7. High action-oriented need permits baseline dose, but not more than rules allow.
        if("ACTION".equalsIgnoreCase(need)||"DECISION".equalsIgnoreCase(need)){
            if(r.dose==Dose.NONE)setMicro(r,"ACTION_NEED_MINIMUM");
        }

        r.deliveryStyle=styleFor(r.dose);
        return r;
    }

    public static String instruction(Result r){
        if(r==null||r.dose==Dose.NONE){
            return "INTERVENTION_DOSE=NONE. 일반 개입을 밀어붙이지 않는다.";
        }

        switch(r.dose){
            case MICRO:
                return "INTERVENTION_DOSE=MICRO. 한 문장 설명 + 아주 작은 행동 1개만. 과제는 주지 않는다.";
            case LIGHT:
                return "INTERVENTION_DOSE=LIGHT. 설명은 짧게, 한 단계만 제안한다. 복잡한 숙제는 금지한다.";
            case STANDARD:
                return "INTERVENTION_DOSE=STANDARD. 개입 이유 + 행동실험 1개 + 다음에 확인할 기준 1개만 준다.";
            case DEEP:
                return "INTERVENTION_DOSE=DEEP. 구조화된 연습 1개만, 최대 "+r.exerciseMinutes+"분. 사용자가 준비된 상태에서만 진행한다.";
            default:
                return "";
        }
    }

    private static void block(Result r,String why){
        r.dose=Dose.NONE;
        r.maxSteps=0;
        r.homeworkAllowed=false;
        r.exerciseMinutes=0;
        r.deliveryStyle="NO_INTERVENTION";
        r.blockedReason=why;
        r.rationale=why;
    }

    private static void setMicro(Result r,String why){
        r.dose=Dose.MICRO;
        r.maxSteps=1;
        r.homeworkAllowed=false;
        r.exerciseMinutes=0;
        r.rationale=why;
        r.deliveryStyle="ONE_TINY_STEP";
    }

    private static void setLight(Result r,String why){
        r.dose=Dose.LIGHT;
        r.maxSteps=1;
        r.homeworkAllowed=false;
        r.exerciseMinutes=2;
        r.rationale=why;
        r.deliveryStyle="ONE_CONCRETE_STEP";
    }

    private static void setStandard(Result r,String why){
        r.dose=Dose.STANDARD;
        r.maxSteps=1;
        r.homeworkAllowed=true;
        r.exerciseMinutes=5;
        r.rationale=why;
        r.deliveryStyle="RATIONALE_PLUS_ONE_EXPERIMENT";
    }

    private static void setDeep(Result r,String why){
        r.dose=Dose.DEEP;
        r.maxSteps=1;
        r.homeworkAllowed=true;
        r.exerciseMinutes=10;
        r.rationale=why;
        r.deliveryStyle="STRUCTURED_SINGLE_EXERCISE";
    }

    private static void capAt(Result r,Dose cap,String why){
        if(rank(r.dose)<=rank(cap))return;
        if(cap==Dose.MICRO)setMicro(r,why);
        else if(cap==Dose.LIGHT)setLight(r,why);
        else if(cap==Dose.STANDARD)setStandard(r,why);
    }

    private static int rank(Dose d){
        if(d==Dose.NONE)return 0;
        if(d==Dose.MICRO)return 1;
        if(d==Dose.LIGHT)return 2;
        if(d==Dose.STANDARD)return 3;
        return 4;
    }

    private static String styleFor(Dose d){
        if(d==Dose.MICRO)return "ONE_TINY_STEP";
        if(d==Dose.LIGHT)return "ONE_CONCRETE_STEP";
        if(d==Dose.STANDARD)return "RATIONALE_PLUS_ONE_EXPERIMENT";
        if(d==Dose.DEEP)return "STRUCTURED_SINGLE_EXERCISE";
        return "NO_INTERVENTION";
    }

    private static boolean isReady(String r){
        return "HIGH".equalsIgnoreCase(r)||"READY".equalsIgnoreCase(r);
    }

    private static String readLastOutcome(JSONObject p,JSONObject f){
        String x=f.optString("last_intervention_outcome","");
        if(x.isEmpty())x=p.optString("last_intervention_outcome","");
        return x.toUpperCase();
    }

    private static String readReadiness(JSONObject p,JSONObject f){
        String x=f.optString("readiness","");
        if(x.isEmpty())x=p.optString("readiness","");
        if(x.isEmpty())x="MEDIUM";
        return x.toUpperCase();
    }

    private static String safe(String s){return s==null?"":s;}
}
