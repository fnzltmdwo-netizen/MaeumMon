package com.maeummon.app;

import android.content.Context;
import android.content.SharedPreferences;

/**
 * Keeps one counseling topic alive across multiple turns so the conversation
 * can feel like a continuous session rather than isolated one-shot answers.
 * This stores only a lightweight working thread, not a diagnosis.
 */
public final class TherapyThreadManager {
    public static final String PREF = "maeummon_therapy_thread_v4323";

    private static final String K_ACTIVE = "active";
    private static final String K_TOPIC = "topic";
    private static final String K_STAGE = "stage";
    private static final String K_SCENE = "scene";
    private static final String K_MEANING = "meaning";
    private static final String K_FEAR = "fear";
    private static final String K_CORE_EMOTION = "core_emotion";
    private static final String K_NEED = "need";
    private static final String K_PROTECTIVE = "protective";
    private static final String K_TRIGGER = "trigger";
    private static final String K_TURNING = "turning_point";
    private static final String K_REVISION = "revision";
    private static final String K_PATTERN = "pattern";
    private static final String K_ROOT = "root";
    private static final String K_CHANGE = "change";
    private static final String K_UNKNOWN = "unknown";
    private static final String K_LAST_QUESTION = "last_question";
    private static final String K_TURNS = "turns";
    private static final String K_UPDATED = "updated";

    private TherapyThreadManager() {}

    private static SharedPreferences p(Context c) {
        return c.getSharedPreferences(PREF, Context.MODE_PRIVATE);
    }

    public static String snapshot(Context c) {
        SharedPreferences s = p(c);
        if (!s.getBoolean(K_ACTIVE, false)) {
            return "[ACTIVE_THERAPY_THREAD] 없음. 사용자가 새 상담 주제를 꺼내면 한 주제를 여러 턴 이어갈지 판단한다.";
        }
        StringBuilder b = new StringBuilder();
        b.append("[ACTIVE_THERAPY_THREAD / 현재 세션에서 놓치지 말아야 할 한 줄기]\n");
        append(b, "주제", s.getString(K_TOPIC, ""));
        append(b, "현재 단계", s.getString(K_STAGE, "EXPLORE"));
        append(b, "확인된 장면/사실", s.getString(K_SCENE, ""));
        append(b, "그 장면에 붙는 의미", s.getString(K_MEANING, ""));
        append(b, "핵심 두려움/걱정", s.getString(K_FEAR, ""));
        append(b, "핵심 감정", s.getString(K_CORE_EMOTION, ""));
        append(b, "핵심 욕구", s.getString(K_NEED, ""));
        append(b, "나를 지키는 방식", s.getString(K_PROTECTIVE, ""));
        append(b, "주요 트리거", s.getString(K_TRIGGER, ""));
        append(b, "최근 전환점", s.getString(K_TURNING, ""));
        append(b, "최근 가설 수정", s.getString(K_REVISION, ""));
        append(b, "반복되는 흐름", s.getString(K_PATTERN, ""));
        append(b, "뿌리 가설", s.getString(K_ROOT, ""));
        append(b, "현재 변화 목표", s.getString(K_CHANGE, ""));
        append(b, "아직 모르는 핵심", s.getString(K_UNKNOWN, ""));
        append(b, "직전 질문", s.getString(K_LAST_QUESTION, ""));
        b.append("이 주제를 이어온 턴 수: ").append(s.getInt(K_TURNS, 0)).append("\n");
        b.append("운영 원칙: 사용자가 명확히 다른 주제로 옮기지 않았다면 같은 줄기를 유지한다. 새 메시지를 별도 상담으로 재시작하지 않는다. ")
         .append("아직 핵심이 충분히 안 잡혔으면 다음 개입을 바꿀 질문 하나만 이어가고, 충분히 잡혔으면 FORMULATE/CHANGE로 넘어간다. ")
         .append("사용자가 '그래서 왜?', '어떻게 바꿔?', '정리해줘'라고 하면 탐색을 닫고 현재까지의 연결을 돌려준다.\n");
        return b.toString().trim();
    }

    /** Update the thread from the meta-counselor even when the reply is direct ASK/FORMULATE. */
    public static synchronized void recordMeta(Context c, OpenAiClient.MetaCounselDecision d, String userMessage) {
        if (d == null) return;
        SharedPreferences s = p(c);
        SharedPreferences.Editor e = s.edit();

        boolean active = s.getBoolean(K_ACTIVE, false);
        int turns = s.getInt(K_TURNS, 0);

        // A strong direction/novelty change usually means the user genuinely moved topics.
        boolean clearShift = active && d.directionChangeScore >= 75 && d.noveltyScore >= 65;
        if (!active || clearShift) {
            e.clear();
            e.putBoolean(K_ACTIVE, true);
            e.putString(K_TOPIC, topicSeed(d, userMessage));
            turns = 0;
        }
        turns++;

        String stage = stageFor(d);
        e.putString(K_STAGE, stage)
         .putInt(K_TURNS, Math.min(99, turns))
         .putLong(K_UPDATED, System.currentTimeMillis());

        put(e, K_SCENE, d.facts);
        put(e, K_UNKNOWN, firstUseful(d.highImpactMissingInformation, d.unknowns));
        if ("ASK".equals(d.action)) put(e, K_LAST_QUESTION, d.question);
        if ("FORMULATE".equals(d.action)) {
            put(e, K_MEANING, firstUseful(d.coreSentence, d.formulation));
            put(e, K_PATTERN, d.patternLoop);
        }
        put(e, K_CORE_EMOTION, d.coreEmotion);
        put(e, K_FEAR, d.coreFear);
        put(e, K_NEED, d.coreNeed);
        put(e, K_PROTECTIVE, d.protectiveBehavior);
        if (d.turningPointDetected) {
            String oldMeaning = s.getString(K_MEANING, "");
            put(e, K_TURNING, d.turningPoint);
            if (!oldMeaning.isEmpty() && !clean(d.coreSentence).isEmpty() && !oldMeaning.equals(clean(d.coreSentence))) {
                put(e, K_REVISION, "이전 가설: " + oldMeaning + " → 새 가설: " + clean(d.coreSentence));
            }
        }
        if ("INTERVENE".equals(d.action)) put(e, K_CHANGE, d.interventionFocus);
        if (!clean(d.therapistNextFocus).isEmpty()) put(e, K_UNKNOWN, d.therapistNextFocus);
        if ("REVIEW".equals(d.action)) put(e, K_CHANGE, d.reviewPrompt);
        e.apply();
    }

    /** Enrich the same thread with the structured counseling result. */
    public static synchronized void recordResult(Context c, OpenAiClient.CounselingResult r) {
        if (r == null) return;
        SharedPreferences.Editor e = p(c).edit().putBoolean(K_ACTIVE, true).putLong(K_UPDATED, System.currentTimeMillis());
        put(e, K_TOPIC, firstUseful(r.focus, r.userGoal));
        put(e, K_SCENE, r.confirmedFacts);
        put(e, K_MEANING, firstUseful(r.automaticThought, r.workingHypothesis));
        put(e, K_FEAR, r.coreFear);
        put(e, K_CORE_EMOTION, r.coreEmotion);
        put(e, K_NEED, r.unmetNeed);
        put(e, K_PROTECTIVE, r.protectiveStrategy);
        put(e, K_TRIGGER, r.trigger);
        put(e, K_PATTERN, firstUseful(r.pattern, r.relationshipPattern));
        put(e, K_ROOT, firstUseful(r.rootHypothesis, r.coreBelief));
        put(e, K_CHANGE, firstUseful(r.experiment, r.nextSessionLink, r.reframe));
        put(e, K_UNKNOWN, r.openQuestion);
        String phase = clean(r.phase);
        if (!phase.isEmpty()) e.putString(K_STAGE, phase.toUpperCase());
        e.apply();
    }

    public static void clear(Context c) {
        p(c).edit().clear().apply();
    }

    private static String stageFor(OpenAiClient.MetaCounselDecision d) {
        if (d == null) return "EXPLORE";
        if ("STABILIZE".equals(d.action)) return "STABILIZE";
        if ("ASK".equals(d.action)) return "EXPLORE";
        if ("FORMULATE".equals(d.action)) return "FORMULATE";
        if ("REVIEW".equals(d.action)) return "REVIEW";
        if ("INTERVENE".equals(d.action)) return "CHANGE";
        return "EXPLORE";
    }

    private static String topicSeed(OpenAiClient.MetaCounselDecision d, String userMessage) {
        String v = firstUseful(d == null ? "" : d.coreSentence, d == null ? "" : d.formulation,
                d == null ? "" : d.facts, userMessage);
        v = clean(v);
        if (v.length() > 180) v = v.substring(0, 180) + "…";
        return v;
    }

    private static void put(SharedPreferences.Editor e, String key, String value) {
        String v = clean(value);
        if (!v.isEmpty() && !"없음".equals(v) && !"해당 없음".equals(v)) e.putString(key, v);
    }

    private static String firstUseful(String... values) {
        if (values == null) return "";
        for (String v : values) if (!clean(v).isEmpty()) return clean(v);
        return "";
    }

    private static String clean(String s) { return s == null ? "" : s.trim(); }

    private static void append(StringBuilder b, String label, String value) {
        String v = clean(value);
        if (!v.isEmpty()) b.append(label).append(": ").append(v).append("\n");
    }
}
