package com.maeummon.app.clinical;

import android.content.Context;
import org.json.*;
import java.util.*;

public final class ResponseContinuityTurnCoherenceGuardRC9 {
    private ResponseContinuityTurnCoherenceGuardRC9(){}

    public static final class Check {
        public boolean pass=true, rewriteRequired=false;
        public final List<String> failures=new ArrayList<>();
        public String instruction="", summary="PASS";
        void fail(String code){ pass=false; rewriteRequired=true; failures.add(code); }
    }

    public static Check inspect(Context c,String userText,String response,ClinicalDecisionRC7 d){
        Check x=new Check();
        String u=userText==null?"":userText.trim();
        String r=response==null?"":response.trim();
        JSONObject s=CentralTherapyProfile.loadSessionState(c);
        JSONObject f=CentralTherapyProfile.loadFormulation(c);

        String prevAssistant=s.optString("last_assistant_response","");
        String prevMove=s.optString("last_move","");
        String prevTarget=s.optString("last_question_target","");
        String prevIntervention=s.optString("last_intervention_id","");
        String move=d==null?"":safe(d.move);
        String target=d==null?"":safe(d.target);

        if(!prevTarget.isEmpty() && userAnsweredTarget(prevTarget,u)
                && "ASK".equals(move) && prevTarget.equals(target))
            x.fail("REASKS_JUST_ANSWERED_TARGET");

        if("ASK".equals(move) && similarQuestion(extractQuestion(prevAssistant),extractQuestion(r)))
            x.fail("REPEATED_ADJACENT_QUESTION");

        String correction=f.optString("latest_user_correction","");
        if(!correction.isEmpty() && contradictsCorrection(correction,r))
            x.fail("DROPS_RECENT_CORRECTION");

        boolean outcome=containsAny(u,"도움","해봤","별로","안 됐","괜찮","효과","더 나빠","못 했","안 해봤");
        if("INTERVENE".equals(prevMove) && !prevIntervention.isEmpty() && !outcome
                && "INTERVENE".equals(move) && d!=null
                && !prevIntervention.equals(d.selectedInterventionId))
            x.fail("SWITCHES_INTERVENTION_WITHOUT_REVIEW");

        String central=f.optString("central_insight","");
        if(!central.isEmpty() && "FORMULATE".equals(move) && !prevAssistant.isEmpty()
                && sharesToken(central,prevAssistant) && !sharesToken(central,r)
                && !f.optBoolean("formulation_reopened",false))
            x.fail("DROPS_ESTABLISHED_CENTRAL_INSIGHT");

        if(f.optBoolean("formulation_reopened",false)
                && containsAny(r,"역시 처음부터 맞았어","결론은 그대로야","이미 확실히 알고 있듯"))
            x.fail("IGNORES_FORMULATION_REOPEN");

        if(!prevAssistant.isEmpty() && stanceReversal(prevAssistant,r)
                && !containsAny(r,"새로 말해준","방금 말한","그 정보가 들어오면","정정하면","다시 보면"))
            x.fail("UNACKNOWLEDGED_STANCE_REVERSAL");

        if(containsAny(u,"그건 아니야","아니 그게 아니라","정정할게","내 말은 그게 아니고","그렇게 말한 게 아니야")
                && !containsAny(first(r,220),"알겠어","그건 아니었네","정정하면","내가 잘못 이해","그 부분은 수정","그렇게 본 건 아니네"))
            x.fail("USER_CORRECTION_NOT_ACKNOWLEDGED");

        if(s.optInt("turn_count",0)>=6 && "ASK".equals(move)
                && containsAny(r,"무슨 일이 있었어?","처음부터 말해줄래?","요즘 가장 힘든 게 뭐야?","어떤 문제로 상담하고 싶어?"))
            x.fail("RESTARTS_INTAKE_MID_SESSION");

        String trigger=f.optString("trigger","");
        if(!trigger.isEmpty() && "FORMULATE".equals(move) && r.length()>120
                && !sharesToken(trigger,r) && !f.optBoolean("formulation_reopened",false))
            x.fail("DROPS_ACTIVE_TRIGGER_CONTEXT");

        if(!x.pass) x.instruction=instruction(x,d,prevMove,prevTarget,prevIntervention);
        x.summary=x.pass?"PASS":"FAIL "+x.failures;
        return x;
    }

    public static void persistTurn(Context c,String userText,String assistantText,ClinicalDecisionRC7 d){
        if(c==null)return;
        JSONObject s=CentralTherapyProfile.loadSessionState(c);
        try{
            s.put("last_user_message",compact(userText,600));
            s.put("last_assistant_response",compact(assistantText,900));
            s.put("last_turn_at",System.currentTimeMillis());
            if(d!=null){
                s.put("last_move",safe(d.move));
                s.put("last_question_target","ASK".equals(d.move)?safe(d.target):"");
                if("INTERVENE".equals(d.move)) s.put("last_intervention_id",safe(d.selectedInterventionId));
            }
            s.put("turn_count",s.optInt("turn_count",0)+1);
            CentralTherapyProfile.replaceSessionState(c,s);
        }catch(Exception ignored){}
    }

    private static String instruction(Check x,ClinicalDecisionRC7 d,String pm,String pt,String pi){
        return "RESPONSE_CONTINUITY_GUARD_FAIL=true. 직전 턴의 답변·질문·정정·개입과 연속되게 다시 쓴다. "
                +"방금 답한 target은 다시 묻지 않고, 개입 변경 전에는 이전 개입 결과를 확인한다. "
                +"결론이 바뀌면 새 evidence 때문에 바뀌었다고 설명한다. previous_move="+pm
                +", previous_target="+pt+", previous_intervention="+pi
                +", current_move="+(d==null?"":safe(d.move))+", failures="+x.failures;
    }

    private static boolean userAnsweredTarget(String t,String u){
        if(t.contains("baseline")) return containsAny(u,"원래","예전","최근","전부터","갑자기");
        if(t.contains("conflict")) return containsAny(u,"싸","갈등","다툼","없었","없어");
        if(t.contains("evaluation")) return containsAny(u,"평가","실수","무능","보일까","상사");
        if(t.contains("relief")) return containsAny(u,"편해","안도","피하고","당장은");
        if(t.contains("episode")) return u.length()>60||containsAny(u,"어제","오늘","그때","최근");
        return u.length()>20;
    }

    private static String extractQuestion(String s){
        if(s==null)return "";
        int q=s.lastIndexOf('?'); if(q<0)return "";
        int a=Math.max(s.lastIndexOf('.',q),s.lastIndexOf('\n',q));
        return s.substring(Math.max(0,a+1),q+1).trim();
    }

    private static boolean similarQuestion(String a,String b){
        if(a.isEmpty()||b.isEmpty())return false;
        String aa=a.replaceAll("[^가-힣A-Za-z0-9]",""), bb=b.replaceAll("[^가-힣A-Za-z0-9]","");
        if(aa.equals(bb))return true;
        Set<String> sa=tokens(a), sb=tokens(b), in=new HashSet<>(sa), un=new HashSet<>(sa);
        in.retainAll(sb); un.addAll(sb);
        return !un.isEmpty() && ((double)in.size()/un.size())>=0.60;
    }

    private static Set<String> tokens(String s){
        Set<String> o=new HashSet<>();
        for(String x:s.replaceAll("[^가-힣A-Za-z0-9 ]"," ").split("\\s+")) if(x.length()>=2)o.add(x);
        return o;
    }

    private static boolean contradictsCorrection(String c,String r){
        if(c.contains("갈등")&&c.contains("없")&&containsAny(r,"실제 갈등이","싸운 게 핵심"))return true;
        if(c.contains("원래")&&c.contains("느려")&&containsAny(r,"최근 갑자기 느려진","최근 관계 변화가 핵심"))return true;
        return false;
    }

    private static boolean stanceReversal(String p,String r){
        boolean established=containsAny(p,"아직","잠정","확정할 수","가능성","핵심은","가까워 보여","가장 가능");
        return established&&containsAny(r,"아니야","오히려 반대","전혀 다른");
    }

    private static boolean sharesToken(String a,String b){
        if(a==null||b==null)return false;
        for(String x:a.replaceAll("[^가-힣A-Za-z0-9 ]"," ").split("\\s+"))
            if(x.length()>=2&&!stop(x)&&b.contains(x))return true;
        return false;
    }
    private static boolean stop(String x){ return Arrays.asList("그냥","근데","나는","내가","그게","이거","저거","진짜","너무","같아").contains(x); }
    private static String first(String s,int n){ return s==null?"":(s.length()<=n?s:s.substring(0,n)); }
    private static boolean containsAny(String s,String... xs){ if(s==null)return false; for(String x:xs)if(s.contains(x))return true; return false; }
    private static String compact(String s,int n){ s=s==null?"":s.trim(); return s.length()<=n?s:s.substring(0,n); }
    private static String safe(String s){ return s==null?"":s; }
}
