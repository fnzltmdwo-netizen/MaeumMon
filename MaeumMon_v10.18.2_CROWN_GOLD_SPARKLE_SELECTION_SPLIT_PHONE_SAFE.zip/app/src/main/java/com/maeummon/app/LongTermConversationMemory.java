package com.maeummon.app;

import android.content.Context;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

/**
 * 전체 상담 원문은 로컬에 오래 보관하되 API에는 필요한 기억만 압축해서 전달한다.
 * 사용자 직접 발화만 장기 사실 후보로 사용하여 화자 혼동을 줄인다.
 */
public final class LongTermConversationMemory {
    private LongTermConversationMemory() {}

    private static final class Hit {
        final int index; final int score; final String time; final String text;
        Hit(int i,int s,String t,String x){index=i;score=s;time=t;text=x;}
    }

    public static String build(Context c, String currentMessage) {
        JSONArray all = ChatStorage.getMessages(c);
        if (all.length() == 0) return "";
        String q = currentMessage == null ? "" : currentMessage.trim();
        Set<String> qTokens = tokens(q);
        ArrayList<Hit> hits = new ArrayList<>();
        int recentBoundary = Math.max(0, all.length() - 24);
        for (int i = 0; i < recentBoundary; i++) {
            JSONObject o = all.optJSONObject(i);
            if (o == null || !"user".equals(o.optString("role"))) continue;
            String text = o.optString("text", "").trim();
            if (text.isEmpty()) continue;
            int score = overlap(qTokens, tokens(text));
            if (q.length() >= 4 && text.contains(q)) score += 6;
            // 관련 단어가 없어도 오래된 최근 사용자 발화를 일부 남겨 연속성을 보강한다.
            if (i >= recentBoundary - 80) score += 1;
            if (score > 0) hits.add(new Hit(i, score, o.optString("time", ""), shorten(text, 260)));
        }
        Collections.sort(hits, new Comparator<Hit>() {
            @Override public int compare(Hit a, Hit b) {
                if (a.score != b.score) return Integer.compare(b.score, a.score);
                return Integer.compare(b.index, a.index);
            }
        });
        StringBuilder sb = new StringBuilder();
        int n = Math.min(12, hits.size());
        for (int i=0;i<n;i++) {
            Hit h=hits.get(i);
            sb.append("- 승재가 말함");
            if (!h.time.isEmpty()) sb.append(" (").append(h.time).append(")");
            sb.append(": ").append(h.text).append('\n');
        }
        if (sb.length()==0) return "";
        return "[과거 상담 원문에서 찾은 사용자 직접 발화 — 화자 보존 필수]\n"
                + "아래 문장은 모두 승재가 직접 말한 내용이다. 상대방/제3자가 한 행동으로 적힌 내용은 절대 승재의 행동으로 바꾸지 말 것. 현재 대화와 충돌하면 현재 발화를 우선한다.\n"
                + sb.toString().trim();
    }

    private static Set<String> tokens(String s) {
        HashSet<String> out = new HashSet<>();
        if (s == null) return out;
        String x=s.toLowerCase(Locale.KOREA).replaceAll("[^0-9a-zA-Z가-힣 ]", " ");
        for(String w:x.split("\\s+")) if(w.length()>=2) out.add(w);
        return out;
    }
    private static int overlap(Set<String>a,Set<String>b){int n=0;for(String x:a)if(b.contains(x))n++;return n;}
    private static String shorten(String s,int n){return s.length()<=n?s:s.substring(0,n)+"…";}
}
