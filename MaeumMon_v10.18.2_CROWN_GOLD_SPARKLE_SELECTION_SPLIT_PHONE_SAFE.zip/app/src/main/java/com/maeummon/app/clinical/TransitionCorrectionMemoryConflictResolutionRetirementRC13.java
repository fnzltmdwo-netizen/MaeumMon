package com.maeummon.app.clinical;

import android.content.Context;
import org.json.*;
import java.util.*;

public final class TransitionCorrectionMemoryConflictResolutionRetirementRC13 {
    private TransitionCorrectionMemoryConflictResolutionRetirementRC13(){}

    public enum State {
        NONE,
        STABLE,
        CONFLICTED,
        REPLACEMENT_PENDING,
        REPLACED,
        RETIRED
    }

    public static final class Result {
        public boolean evaluated=false;
        public boolean conflicted=false;
        public boolean replacementPending=false;
        public boolean replaced=false;
        public boolean retired=false;
        public State state=State.NONE;
        public String transitionKey="";
        public String incumbentCause="";
        public String challengerCause="";
        public int incumbentCount=0;
        public int challengerCount=0;
        public int distinctCauseCount=0;
        public String activeCause="";
        public String activeReason="";
        public String reason="";
        public String summary="";
    }

    public static Result resolve(Context c,ClinicalDecisionRC7 d){
        Result r=new Result();

        if(c==null||d==null){
            r.summary="NONE | MISSING_INPUT";
            return r;
        }

        r.evaluated=true;

        JSONObject p=CentralTherapyProfile.loadProfile(c);
        JSONObject f=CentralTherapyProfile.loadFormulation(c);

        String context=f.optString("current_context_scope","UNKNOWN");
        r.transitionKey=
                safe(d.decisionTransitionFromState)
                +"->"
                +safe(d.decisionTransitionToState)
                +"::"
                +context;

        JSONArray history=
                p.optJSONArray("transition_correction_revalidation_history");

        if(history==null||history.length()==0){
            r.reason="NO_REVALIDATION_HISTORY";
            return finish(r);
        }

        LinkedHashMap<String,Integer> counts=new LinkedHashMap<>();
        LinkedHashMap<String,String> reasons=new LinkedHashMap<>();

        for(int i=0;i<history.length();i++){
            JSONObject x=history.optJSONObject(i);
            if(x==null)continue;

            if(!r.transitionKey.equals(
                    x.optString("transition_key","")))
                continue;

            String cause=x.optString("corrected_cause","");
            if(cause.isEmpty())continue;

            counts.put(cause,counts.getOrDefault(cause,0)+1);
            if(!reasons.containsKey(cause))
                reasons.put(cause,x.optString("corrected_reason",""));
        }

        r.distinctCauseCount=counts.size();

        if(counts.isEmpty()){
            r.reason="NO_CAUSE_FOR_TRANSITION_KEY";
            return finish(r);
        }

        ArrayList<Map.Entry<String,Integer>> ranked=
                new ArrayList<>(counts.entrySet());

        ranked.sort((a,b)->Integer.compare(
                b.getValue(),a.getValue()));

        Map.Entry<String,Integer> top=ranked.get(0);
        r.incumbentCause=top.getKey();
        r.incumbentCount=top.getValue();

        if(ranked.size()==1){
            r.state=State.STABLE;
            r.activeCause=r.incumbentCause;
            r.activeReason=reasons.getOrDefault(
                    r.activeCause,"");
            r.reason="SINGLE_CAUSE_HISTORY";
            persist(c,p,r);
            return finish(r);
        }

        Map.Entry<String,Integer> second=ranked.get(1);
        r.challengerCause=second.getKey();
        r.challengerCount=second.getValue();
        r.conflicted=true;

        // Tie or near-tie: do not reuse any explanation memory.
        if(r.incumbentCount==r.challengerCount
                ||r.incumbentCount-r.challengerCount<=1){

            // v7.0.0 lifecycle ordering integrity:

            // persistent near-tie conflict must retire before ordinary conflict return.

            int totalEvidence=r.incumbentCount+r.challengerCount;
            int lead=r.incumbentCount-r.challengerCount;

            if(totalEvidence>=6 && r.distinctCauseCount>=2 && lead<=1){

                r.state=State.RETIRED;
                r.retired=true;

                r.activeCause="";

                r.reason="PERSISTENT_CONFLICT_RETIRED";

                
    
                persist(c,p,r);
                return finish(r);

            }

            r.state=State.CONFLICTED;
            r.reason="CAUSE_COUNTS_TOO_CLOSE";
            persist(c,p,r);
            return finish(r);
        }

        // A challenger needs at least 3 confirmations and must exceed incumbent
        // by >=2 to replace an older active cause.
        String previousActive=
                p.optString(
                        "transition_correction_conflict_active_cause_"
                        +keyHash(r.transitionKey),"");

        if(!previousActive.isEmpty()
                &&!previousActive.equals(r.incumbentCause)){

            if(r.incumbentCount>=3
                    &&r.incumbentCount-r.challengerCount>=2){
                r.state=State.REPLACED;
                r.replaced=true;
                r.activeCause=r.incumbentCause;
                r.activeReason=reasons.getOrDefault(
                        r.activeCause,"");
                r.reason="CHALLENGER_WON_WITH_REPEATED_CONFIRMATION";
                persist(c,p,r);
                return finish(r);
            }

            r.state=State.REPLACEMENT_PENDING;
            r.replacementPending=true;
            r.reason="NEW_CAUSE_NOT_YET_STRONG_ENOUGH";
            persist(c,p,r);
            return finish(r);
        }

        // Persistent conflict with many samples and no clear winner -> retire.
        int total=0;
        for(Integer v:counts.values()) total+=v;

        if(total>=6
                &&r.distinctCauseCount>=2
                &&r.incumbentCount-r.challengerCount<2){
            r.state=State.RETIRED;
            r.retired=true;
            r.reason="PERSISTENT_UNRESOLVED_CONFLICT";
            persist(c,p,r);
            return finish(r);
        }

        r.state=State.STABLE;
        r.activeCause=r.incumbentCause;
        r.activeReason=reasons.getOrDefault(
                r.activeCause,"");
        r.reason="CLEAR_CURRENT_WINNER";
        persist(c,p,r);
        return finish(r);
    }

    public static boolean reusable(Result r){
        return r!=null
                &&(r.state==State.STABLE
                    ||r.state==State.REPLACED)
                &&!r.activeCause.isEmpty();
    }

    public static boolean mustBlock(Result r){
        return r!=null
                &&(r.state==State.CONFLICTED
                    ||r.state==State.REPLACEMENT_PENDING
                    ||r.state==State.RETIRED);
    }

    public static String instruction(Result r){
        if(r==null||!r.evaluated)return "";

        if(r.state==State.CONFLICTED)
            return "CORRECTION_MEMORY_CONFLICT=CONFLICTED. 같은 전환에서 서로 다른 사용자 교정이 비슷한 빈도로 확인되어 과거 correction memory를 이번 설명에 사용하지 않는다.";

        if(r.state==State.REPLACEMENT_PENDING)
            return "CORRECTION_MEMORY_CONFLICT=REPLACEMENT_PENDING. 새 교정이 이전 기억과 충돌하지만 아직 충분히 반복 확인되지 않아 어느 쪽도 자동 확정하지 않는다.";

        if(r.state==State.REPLACED)
            return "CORRECTION_MEMORY_CONFLICT=REPLACED. 새 교정이 같은 전환/맥락에서 반복 확인되어 이전 correction memory를 대체했다.";

        if(r.state==State.RETIRED)
            return "CORRECTION_MEMORY_CONFLICT=RETIRED. 같은 전환의 교정들이 지속적으로 충돌해 해당 correction memory를 자동 설명 prior에서 퇴역시킨다.";

        if(r.state==State.STABLE)
            return "CORRECTION_MEMORY_CONFLICT=STABLE. 현재 correction memory는 동일 전환/맥락 안에서 모순 없이 유지되고 있다.";

        return "";
    }

    private static void persist(
            Context c,
            JSONObject p,
            Result r){

        try{
            String h=keyHash(r.transitionKey);

            p.put("transition_correction_conflict_state_"+h,
                    r.state.name());
            p.put("transition_correction_conflict_active_cause_"+h,
                    r.activeCause);
            p.put("transition_correction_conflict_incumbent_"+h,
                    r.incumbentCause);
            p.put("transition_correction_conflict_challenger_"+h,
                    r.challengerCause);
            p.put("transition_correction_conflict_reason_"+h,
                    r.reason);
            p.put("transition_correction_conflict_updated_at_"+h,
                    System.currentTimeMillis());

            CentralTherapyProfile.replaceProfile(c,p);
        }catch(Exception ignored){}
    }

    private static String keyHash(String s){
        return Integer.toHexString(
                safe(s).hashCode());
    }

    private static Result finish(Result r){
        r.summary=r.state.name()
                +" | key="+r.transitionKey
                +" | incumbent="+r.incumbentCause
                +"("+r.incumbentCount+")"
                +" | challenger="+r.challengerCause
                +"("+r.challengerCount+")"
                +" | distinct="+r.distinctCauseCount
                +" | active="+r.activeCause
                +" | reason="+r.reason;
        return r;
    }

    private static String safe(String s){
        return s==null?"":s;
    }
}
