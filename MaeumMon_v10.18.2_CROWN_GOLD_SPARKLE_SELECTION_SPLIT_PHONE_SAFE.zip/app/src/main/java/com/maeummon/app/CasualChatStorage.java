package com.maeummon.app;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * 상담 기록과 완전히 분리된 일상대화 저장소.
 * 사소한 잡담이 상담 패턴/감정 분석에 자동으로 섞이지 않도록 별도 키를 사용한다.
 */
public final class CasualChatStorage {
    private static final String KEY = "casual_chat_messages_v1";
    private static final int MAX_MESSAGES = 300;

    private CasualChatStorage() {}

    public static synchronized void addMessage(Context context, String role, String text) {
        if (context == null || text == null || text.trim().isEmpty()) return;
        try {
            SharedPreferences prefs = context.getSharedPreferences(AppPrefs.PREFS, Context.MODE_PRIVATE);
            JSONArray arr = new JSONArray(prefs.getString(KEY, "[]"));
            JSONObject o = new JSONObject();
            o.put("role", "assistant".equals(role) ? "assistant" : "user");
            o.put("text", text.trim());
            o.put("time", new SimpleDateFormat("yyyy.MM.dd HH:mm", Locale.KOREA).format(new Date()));
            arr.put(o);

            if (arr.length() > MAX_MESSAGES) {
                JSONArray trimmed = new JSONArray();
                int start = Math.max(0, arr.length() - MAX_MESSAGES);
                for (int i = start; i < arr.length(); i++) trimmed.put(arr.optJSONObject(i));
                arr = trimmed;
            }
            prefs.edit().putString(KEY, arr.toString()).apply();
        } catch (Exception ignored) {}
    }

    public static JSONArray getMessages(Context context) {
        try {
            SharedPreferences prefs = context.getSharedPreferences(AppPrefs.PREFS, Context.MODE_PRIVATE);
            return new JSONArray(prefs.getString(KEY, "[]"));
        } catch (Exception e) {
            return new JSONArray();
        }
    }

    public static JSONArray getRecentForApi(Context context, int max) {
        JSONArray all = getMessages(context);
        JSONArray out = new JSONArray();
        int start = Math.max(0, all.length() - Math.max(1, max));
        for (int i = start; i < all.length(); i++) {
            JSONObject src = all.optJSONObject(i);
            if (src == null) continue;
            JSONObject item = new JSONObject();
            try {
                item.put("role", src.optString("role", "user"));
                item.put("text", src.optString("text", ""));
                out.put(item);
            } catch (Exception ignored) {}
        }
        return out;
    }

    /**
     * 상담 탭이 참고할 수 있는 최근 일상 맥락.
     * 단순 잡담을 진단/패턴으로 확정하지 말고 "최근 생활 맥락"으로만 사용한다.
     */
    public static String getRecentUserContext(Context context, int maxUserMessages) {
        JSONArray all = getMessages(context);
        StringBuilder sb = new StringBuilder();
        int count = 0;
        for (int i = all.length() - 1; i >= 0 && count < Math.max(1, maxUserMessages); i--) {
            JSONObject o = all.optJSONObject(i);
            if (o == null || !"user".equals(o.optString("role"))) continue;
            String text = o.optString("text", "").trim();
            if (text.isEmpty()) continue;
            String time = o.optString("time", "");
            sb.insert(0, "- " + (time.isEmpty() ? "" : time + " · ") + shorten(text, 220) + "\n");
            count++;
        }
        if (sb.length() == 0) return "";
        return "[최근 일상대화 참고 — 사용자가 실제로 말한 생활 맥락이며, 심리적 원인/패턴으로 자동 확정하지 말 것]\n" + sb.toString().trim();
    }

    private static String shorten(String s, int max) {
        if (s == null) return "";
        return s.length() <= max ? s : s.substring(0, max) + "…";
    }

    public static void clear(Context context) {
        context.getSharedPreferences(AppPrefs.PREFS, Context.MODE_PRIVATE)
                .edit().remove(KEY).apply();
    }
}
