package com.maeummon.app.clinical;

import android.content.Context;
import org.json.*;
import java.util.*;

public final class InterventionOutcomeLearningRC8 {
    private InterventionOutcomeLearningRC8(){}

    public static final class Review {
        public boolean outcomeMentioned=false;
        public String interventionId="";
        public String outcome="UNKNOWN"; // HELPED / PARTIAL / NOT_HELPED / WORSE / NOT_TRIED
        public double confidenceDelta=0.0;
        public String nextMove="";
        public String note="";
    }

    public static Review review(Context c,String userText){
        Review r=new Review();
        if(c==null)return r;
        JSONObject f=CentralTherapyProfile.loadFormulation(c);
        JSONObject p=CentralTherapyProfile.loadProcessState(c);
        String t=userText==null?"":userText;

        r.interventionId=f.optString("last_intervention_id","");
        if(r.interventionId.isEmpty())return r;

        if(containsAny(t,"해봤어","해보니까","했는데","써봤어","말해봤어","연락해봤어","쉬어봤어","피하지 않고")){
            r.outcomeMentioned=true;
        }else if(containsAny(t,"아직 안 했","못 해봤","안 해봤","해보진 못")){
            r.outcomeMentioned=true;
            r.outcome="NOT_TRIED";
            r.nextMove="REVIEW";
            r.note="intervention not tried yet";
            return r;
        }else{
            return r;
        }

        if(containsAny(t,"도움 됐","좀 나아","괜찮아졌","효과 있었","생각보다 괜찮","불안이 줄")){
            r.outcome="HELPED";
            r.confidenceDelta=+0.10;
            r.nextMove="REINFORCE";
            r.note="reported improvement after intervention";
        }else if(containsAny(t,"조금 도움","약간 나아","반반","일부는","조금은")){
            r.outcome="PARTIAL";
            r.confidenceDelta=+0.04;
            r.nextMove="ADJUST";
            r.note="partial benefit";
        }else if(containsAny(t,"더 힘들","악화","더 불안","더 안 좋아","오히려 힘들")){
            r.outcome="WORSE";
            r.confidenceDelta=-0.16;
            r.nextMove="CHANGE";
            r.note="intervention worsened experience";
        }else if(containsAny(t,"효과 없","별로였","도움 안","똑같아","변한 게 없")){
            r.outcome="NOT_HELPED";
            r.confidenceDelta=-0.10;
            r.nextMove="CHANGE";
            r.note="no meaningful benefit";
        }else{
            r.outcome="UNKNOWN";
            r.nextMove="REVIEW";
            r.note="outcome mentioned but unclear";
        }

        return r;
    }

    public static void apply(Context c,Review r){
        if(c==null||r==null||!r.outcomeMentioned)return;
        try{
            JSONObject f=CentralTherapyProfile.loadFormulation(c);
            JSONObject process=CentralTherapyProfile.loadProcessState(c);
            JSONArray history=f.optJSONArray("intervention_history");
            if(history==null)history=new JSONArray();

            JSONObject item=new JSONObject();
            item.put("intervention_id",r.interventionId);
            item.put("outcome",r.outcome);
            item.put("confidence_delta",r.confidenceDelta);
            item.put("next_move",r.nextMove);
            item.put("note",r.note);
            item.put("time",System.currentTimeMillis());
            history.put(item);
            f.put("intervention_history",tail(history,20));
            f.put("last_intervention_outcome",r.outcome);
            f.put("last_intervention_review_note",r.note);

            // A positive/negative outcome gently updates leading hypothesis confidence.
            JSONArray hs=f.optJSONArray("alternative_hypotheses");
            String leading=f.optString("leading_hypothesis","");
            if(hs!=null&&!leading.isEmpty()&&Math.abs(r.confidenceDelta)>0){
                double sum=0;
                for(int i=0;i<hs.length();i++){
                    JSONObject h=hs.optJSONObject(i); if(h==null)continue;
                    double conf=h.optDouble("confidence",0);
                    if(leading.equals(h.optString("id",""))){
                        conf=clamp(conf+r.confidenceDelta);
                        h.put("confidence",conf);
                    }
                    sum+=h.optDouble("confidence",0);
                }
                if(sum>0){
                    for(int i=0;i<hs.length();i++){
                        JSONObject h=hs.optJSONObject(i); if(h==null)continue;
                        h.put("confidence",round(h.optDouble("confidence",0)/sum));
                    }
                }
                f.put("alternative_hypotheses",hs);
            }

            process.put("last_intervention_outcome",r.outcome);
            process.put("last_intervention_next_move",r.nextMove);
            process.put("updated_at",System.currentTimeMillis());

            CentralTherapyProfile.replaceFormulation(c,f);
            CentralTherapyProfile.replaceProcessState(c,process);
        }catch(Exception ignored){}
    }

    public static String reviewInstruction(Review r){
        if(r==null||!r.outcomeMentioned)return "";
        if("HELPED".equals(r.outcome)){
            return "사용자가 개입 효과를 보고했다. 무엇이 도움이 됐는지 한 문장으로 강화하고, 같은 전략을 유지할지 짧게 확인한다.";
        }
        if("PARTIAL".equals(r.outcome)){
            return "부분 효과다. 잘 된 부분은 유지하고, 걸린 지점 하나만 조정한다. 새 개입을 여러 개 추가하지 않는다.";
        }
        if("NOT_HELPED".equals(r.outcome)||"WORSE".equals(r.outcome)){
            return "기존 개입을 고집하지 않는다. 왜 안 맞았는지 짧게 검토하고 intervention 또는 formulation을 수정한다.";
        }
        if("NOT_TRIED".equals(r.outcome)){
            return "실행하지 못한 이유를 비난 없이 확인하고, 개입의 크기를 더 작게 줄이거나 보류한다.";
        }
        return "개입 결과가 불명확하다. 효과/부담/실행가능성 중 하나만 짧게 확인한다.";
    }

    private static JSONArray tail(JSONArray src,int max){
        JSONArray out=new JSONArray();
        int start=Math.max(0,src.length()-max);
        for(int i=start;i<src.length();i++)out.put(src.opt(i));
        return out;
    }
    private static boolean containsAny(String s,String... xs){
        for(String x:xs)if(s.contains(x))return true;
        return false;
    }
    private static double clamp(double x){return Math.max(0.02,Math.min(0.95,x));}
    private static double round(double x){return Math.round(x*1000.0)/1000.0;}
}
