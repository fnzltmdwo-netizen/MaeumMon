package com.maeummon.app.clinical;

import android.content.Context;
import org.json.*;
import java.util.*;

public final class ResponseAttunementValidationCalibrationGuardRC9 {
    private ResponseAttunementValidationCalibrationGuardRC9(){}

    public static final class Check {
        public boolean pass=true;
        public boolean rewriteRequired=false;
        public final List<String> failures=new ArrayList<>();
        public String instruction="";
        public String summary="PASS";

        void fail(String code){
            pass=false;
            rewriteRequired=true;
            failures.add(code);
        }
    }

    public static Check inspect(
            Context c,String userText,String response,ClinicalDecisionRC7 d){

        Check x=new Check();
        String u=userText==null?"":userText.trim();
        String r=response==null?"":response.trim();
        JSONObject f=CentralTherapyProfile.loadFormulation(c);

        String move=d==null?"":safe(d.move);
        String pacing=d==null?"":safe(d.therapeuticPacing);
        String need=f.optString("response_need","");
        String emotion=f.optString("emotion","");
        boolean safety=d!=null&&d.safetyOverride;
        boolean rupture=d!=null&&d.allianceRupture;

        boolean userEmotionallyLoaded=containsAny(u,
                "무서","불안","속상","화나","짜증","괴로","힘들","서운",
                "울고","답답","외로","지쳐","벅차","두려","상처");

        boolean responseAcknowledgesEmotion=containsAny(r,
                "불안","무서","속상","서운","화","지쳐","힘들","상처",
                "그 마음","그 상황이면","그럴 만","부담","두려움",
                emotion);

        // 1. Cold analysis: emotionally loaded user + no attunement at all.
        if(userEmotionallyLoaded
                && !responseAcknowledgesEmotion
                && !"ASK".equals(move)
                && !safety){
            x.fail("COLD_ANALYSIS_WITHOUT_ATTUNEMENT");
        }

        // 2. Overvalidation of interpretation as fact.
        if(containsAny(u,
                "나 싫어하는 거 같","날 무시하는 거 같","나 버리려는 거 같",
                "내가 만만한가","나를 싫어하나")
                && containsAny(r,
                    "맞아, 널 싫어하는 거야",
                    "맞아, 무시하는 거야",
                    "그건 너를 만만하게 보는 거야",
                    "분명 버리려는 거야")){
            x.fail("VALIDATES_INTERPRETATION_AS_FACT");
        }

        // 3. Emotion validation should not become agreement with all beliefs.
        if(containsAny(r,
                "네 생각이 다 맞아","네 해석이 맞아","네가 느낀 게 사실이야",
                "그렇게 느꼈으니 실제로 그런 거야")){
            x.fail("VALIDATION_BECOMES_AGREEMENT");
        }

        // 4. Excessive empathy can bury the central answer.
        int empathyCount=countMarkers(r,new String[]{
                "힘들었겠다","속상했겠다","그럴 수 있어","이해해",
                "그 마음","쉽지 않았","많이 지쳤","상처였겠다"
        });
        if(empathyCount>=4){
            x.fail("EMPATHY_OVERLOAD");
        }

        // 5. UNDERSTANDING need expects some recognition before intervention.
        if("UNDERSTANDING".equalsIgnoreCase(need)
                && "INTERVENE".equals(move)
                && !responseAcknowledgesEmotion
                && !containsAny(r,"핵심","지금 보면","정리하면")){
            x.fail("UNDERSTANDING_NEED_NOT_MET");
        }

        // 6. GENTLE/SLOW pacing should avoid sharp contrast language.
        if(("GENTLE".equals(pacing)||"SLOW".equals(pacing))
                && containsAny(r,
                    "근데 네가 틀렸어","그건 네 착각이야","사실은 반대야",
                    "냉정하게 말하면","현실적으로 네 문제야")){
            x.fail("ATTUNEMENT_BREAKS_PACING");
        }

        // 7. Alliance repair must name the mismatch, not just apologize generically.
        if(rupture && !safety){
            boolean namesMismatch=containsAny(r,
                    "해결책보다","질문이 많았","너무 단정","너무 길었",
                    "네가 원한 건","내가 방향을","내 답변이");
            if(!namesMismatch){
                x.fail("ALLIANCE_REPAIR_TOO_GENERIC");
            }
        }

        // 8. Safety turn should not sound emotionally detached.
        if(safety
                && !containsAny(r,
                    "지금 안전","위험","혼자 버티","지금은","곁에",
                    "도움","함께")){
            x.fail("SAFETY_RESPONSE_TOO_DETACHED");
        }

        // 9. Avoid performative certainty about empathy.
        if(containsAny(r,
                "완전히 이해해","정확히 알아","네 마음을 다 알아",
                "100% 이해해")){
            x.fail("OVERCLAIMED_EMPATHY");
        }

        // 10. Keep validation targeted: emotion yes, unverified cause no.
        if(responseAcknowledgesEmotion
                && containsAny(r,
                    "그러니까 상대가 잘못한 게 확실해",
                    "그러니 네 해석이 맞아",
                    "그래서 상대가 나쁜 사람인 거야")){
            x.fail("VALIDATION_EXTENDS_TO_CAUSAL_JUDGMENT");
        }

        if(!x.pass){
            x.instruction=buildRewriteInstruction(x,d,need);
        }
        x.summary=x.pass?"PASS":"FAIL "+x.failures.toString();
        return x;
    }

    public static String buildRewriteInstruction(
            Check x,ClinicalDecisionRC7 d,String need){

        String move=d==null?"":safe(d.move);
        String pacing=d==null?"":safe(d.therapeuticPacing);

        return "RESPONSE_ATTUNEMENT_GUARD_FAIL=true. 응답을 다시 쓸 때 "
                +"감정은 짧고 구체적으로 인정하되, 사용자의 해석/상대 의도까지 사실로 확인하지 않는다. "
                +"공감 문장은 1~2개면 충분하고 그 뒤 핵심 이해나 다음 move로 넘어간다. "
                +"현재 move="+move+", pacing="+pacing+", response_need="+need+". "
                +"차갑게 분석만 하지 말고, 반대로 과잉동조도 하지 않는다. failures="+x.failures;
    }

    private static int countMarkers(String s,String[] xs){
        int n=0;
        if(s==null)return 0;
        for(String x:xs)if(s.contains(x))n++;
        return n;
    }

    private static boolean containsAny(String s,String... xs){
        if(s==null)return false;
        for(String x:xs){
            if(x!=null&&!x.isEmpty()&&s.contains(x))return true;
        }
        return false;
    }

    private static String safe(String s){return s==null?"":s;}
}
