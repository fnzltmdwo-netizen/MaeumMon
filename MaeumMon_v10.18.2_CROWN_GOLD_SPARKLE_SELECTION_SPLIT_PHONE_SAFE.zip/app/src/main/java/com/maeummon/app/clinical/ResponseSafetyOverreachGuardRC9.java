package com.maeummon.app.clinical;

import android.content.Context;
import org.json.*;
import java.util.*;

public final class ResponseSafetyOverreachGuardRC9 {
    private ResponseSafetyOverreachGuardRC9(){}

    public static final class Check {
        public boolean pass=true;
        public boolean rewriteRequired=false;
        public final List<String> failures=new ArrayList<>();
        public String instruction="";
        public String summary="PASS";

        void fail(String code){
            pass=false;
            rewriteRequired=true;
            failures.add(code);
        }
    }

    public static Check inspect(
            Context c,String userText,String response,ClinicalDecisionRC7 d){

        Check x=new Check();
        String u=userText==null?"":userText.trim();
        String r=response==null?"":response.trim();

        JSONObject f=CentralTherapyProfile.loadFormulation(c);
        String need=f.optString("response_need","");
        String phase=d==null?"":safe(d.sessionPhase);
        String pacing=d==null?"":safe(d.therapeuticPacing);
        boolean safety=d!=null&&d.safetyOverride;
        boolean rupture=d!=null&&d.allianceRupture;

        // 1. Coercive / commanding tone.
        if(containsAny(r,
                "무조건 해야 해","반드시 해야 해","그냥 해","당장 연락해",
                "지금 바로 보내","생각하지 말고 해","시키는 대로 해")){
            x.fail("COERCIVE_DIRECTIVE");
        }

        // 2. Shame / blame / moralizing.
        if(containsAny(r,
                "네가 문제야","너무 이기적이야","그건 잘못된 거야",
                "왜 그렇게밖에 못 해","정신 차려","그건 네 책임이야",
                "유난이야","예민해서 그래")){
            x.fail("SHAMING_OR_MORALIZING");
        }

        // 3. Premature confrontation when pacing is slow/gentle.
        if(("SLOW".equals(pacing)||"GENTLE".equals(pacing))
                && containsAny(r,
                "회피하고 있는 거야","인정해야 해","네가 피하는 게 문제야",
                "결국 네가 만들어낸 문제야","현실을 봐")){
            x.fail("CONFRONTATION_TOO_STRONG_FOR_PACING");
        }

        // 4. Action overload: too many behavioral directives in one reply.
        int actionMarkers=countActionMarkers(r);
        if(actionMarkers>=4){
            x.fail("ACTION_OVERLOAD");
        }

        // 5. UNDERSTANDING/VENTING need should not be hijacked by action plans.
        if(("UNDERSTANDING".equalsIgnoreCase(need)
                ||"VENTING".equalsIgnoreCase(need))
                && actionMarkers>=2){
            x.fail("RESPONSE_NEED_OVERRIDDEN_BY_ACTION");
        }

        // 6. Early phases must not jump to intense intervention.
        if(("ORIENT".equals(phase)||"UNDERSTAND".equals(phase))
                && containsAny(r,
                "이번 주 매일","노출 훈련","행동실험을 해","즉시 경계를 세워",
                "관계를 끊어","직장을 그만둬")){
            x.fail("INTERVENTION_TOO_INTENSE_FOR_PHASE");
        }

        // 7. No high-stakes life decisions stated as recommendations.
        if(containsAny(r,
                "헤어지는 게 맞아","친구를 끊어","퇴사해야 해",
                "가족과 연락 끊어","이혼해야 해","약을 끊어",
                "약을 늘려","병원 갈 필요 없어")){
            x.fail("HIGH_STAKES_DIRECTIVE");
        }

        // 8. Medication/medical overreach.
        if(containsAny(r,
                "약 때문이 확실해","약을 줄이면 돼","복용량을 올려",
                "약 끊어도 돼","진료 안 받아도 돼")){
            x.fail("MEDICAL_OVERREACH");
        }

        // 9. Safety turns should be calm and focused, not argumentative/action-heavy.
        if(safety){
            if(actionMarkers>=2
                    || containsAny(r,"따져봐","연락해서 확인해","행동실험","관계 정리")){
                x.fail("SAFETY_TURN_OVERREACH");
            }
        }

        // 10. Alliance repair should acknowledge mismatch before advice.
        if(rupture && !safety){
            boolean acknowledges=containsAny(r,
                    "내가 너무","내 답이","네가 원한 건","해결책보다",
                    "내가 방향을 잘못","그렇게 느낄 만");
            if(!acknowledges && actionMarkers>0){
                x.fail("ALLIANCE_REPAIR_SKIPPED");
            }
        }

        // 11. Avoid excessive certainty about what user "must" feel.
        if(containsAny(r,
                "너는 사실 화난 거야","네 진짜 감정은","너는 분명 상처받은 거야",
                "사실 네가 원하는 건","너도 알고 있잖아")){
            x.fail("EMOTION_MINDREADING");
        }

        // 12. Avoid invalidating reassurance.
        if(containsAny(r,
                "걱정할 필요 없어","별일 아니야","신경 쓰지 마",
                "그냥 잊어","아무 문제 없어")){
            x.fail("INVALIDATING_REASSURANCE");
        }

        if(!x.pass){
            x.instruction=buildRewriteInstruction(x,d);
        }
        x.summary=x.pass?"PASS":"FAIL "+x.failures.toString();
        return x;
    }

    public static String buildRewriteInstruction(Check x,ClinicalDecisionRC7 d){
        String phase=d==null?"":safe(d.sessionPhase);
        String pacing=d==null?"":safe(d.therapeuticPacing);

        return "RESPONSE_OVERREACH_GUARD_FAIL=true. 응답을 다시 쓸 때 "
                +"명령/수치심/도덕판단/감정 단정/고위험 의사결정 지시를 제거한다. "
                +"한 번에 개입 하나만 유지하고, 현재 session_phase="+phase
                +", pacing="+pacing+" 수준에 맞춘다. "
                +"사용자 자율성을 보존하고 선택 가능한 제안 형태로 표현한다. failures="
                +x.failures;
    }

    private static int countActionMarkers(String r){
        int n=0;
        String[] xs={
                "해봐","해보자","해야","보내","말해","연락","적어",
                "기록","연습","시도","정리해","끊어","거절해",
                "확인해","설명해","쉬어","줄여"
        };
        for(String x:xs)if(r.contains(x))n++;
        return n;
    }

    private static boolean containsAny(String s,String... xs){
        if(s==null)return false;
        for(String x:xs)if(s.contains(x))return true;
        return false;
    }

    private static String safe(String s){return s==null?"":s;}
}
