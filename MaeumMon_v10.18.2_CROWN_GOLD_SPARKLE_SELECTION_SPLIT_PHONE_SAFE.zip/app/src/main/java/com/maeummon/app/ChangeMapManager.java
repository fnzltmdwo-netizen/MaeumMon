package com.maeummon.app;

import android.content.Context;
import android.content.SharedPreferences;

/** 승재의 장기 변화지도. 점수는 진단/검사가 아니라 상담에서 관찰된 행동 변화 신호의 누적값이다. */
public final class ChangeMapManager {
    private static final String PREF = "maeummon_change_map";
    private static final String[] KEYS = {"self_trust","boundary","ambiguity","recovery","self_compassion","values"};
    private static final String[] LABELS = {"자기신뢰","경계설정","불확실성 견디기","불안 후 회복","자기자비","내 욕구·가치 선택"};
    private ChangeMapManager() {}

    private static SharedPreferences p(Context c){ return c.getSharedPreferences(PREF, Context.MODE_PRIVATE); }
    public static int score(Context c, String key){ return p(c).getInt("score_"+key, 50); }
    public static String[] keys(){ return KEYS.clone(); }
    public static String[] labels(){ return LABELS.clone(); }
    public static String lastApproach(Context c){ return p(c).getString("last_approach", "아직 상담을 시작하는 중"); }
    public static String lastReason(Context c){ return p(c).getString("last_reason", "오늘의 이야기에 맞춰 필요한 접근을 고를게."); }

    public static synchronized void apply(Context c, OpenAiClient.CounselingResult r){
        if(r==null) return;
        SharedPreferences.Editor e=p(c).edit();
        int[] deltas={r.deltaSelfTrust,r.deltaBoundary,r.deltaAmbiguity,r.deltaRecovery,r.deltaSelfCompassion,r.deltaValues};
        for(int i=0;i<KEYS.length;i++){
            int d=Math.max(-2,Math.min(2,deltas[i]));
            int next=Math.max(0,Math.min(100,score(c,KEYS[i])+d));
            e.putInt("score_"+KEYS[i],next);
        }
        if(!r.approach.trim().isEmpty()) e.putString("last_approach",r.approach.trim());
        if(!r.approachReason.trim().isEmpty()) e.putString("last_reason",r.approachReason.trim());
        e.putLong("updated_at",System.currentTimeMillis()).apply();
    }

    public static String compact(Context c){
        StringBuilder sb=new StringBuilder("[승재의 변화지도 - 진단점수가 아닌 상담 변화 신호]\n");
        for(int i=0;i<KEYS.length;i++) sb.append(LABELS[i]).append(": ").append(score(c,KEYS[i])).append("/100\n");
        sb.append("직전 턴 접근: ").append(lastApproach(c)).append('\n');
        return sb.toString();
    }
}
