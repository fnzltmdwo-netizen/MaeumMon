package com.maeummon.app;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Random;

public class WordsForSeungjaeActivity extends Activity {
    private TextView wordsText;
    private TextView statusText;
    private SharedPreferences prefs;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Random random = new Random();

    private static final String[][] LOCAL_WORDS = {
            {
                    "승재야, 오늘 마음이 복잡했지.",
                    "그걸 다 바로 정리하지 않아도 돼.",
                    "오늘 네가 버틴 것도 분명한 일이야.",
                    "지금은 하나만 내려놔도 충분해.",
                    "내가 네 옆에서 같이 있을게."
            },
            {
                    "승재야, 오늘 누가 한 말이 마음에 남았구나.",
                    "그때 바로 말 못했어도 네가 약한 건 아니야.",
                    "싸우기 싫어서 그냥 넘긴 걸 수도 있지.",
                    "다음엔 불편하다고 한마디만 해도 돼.",
                    "오늘은 그때의 너를 너무 혼내지 말자."
            },
            {
                    "승재야, 오늘은 힘을 꽤 많이 썼어.",
                    "지금 지친 건 네가 부족해서가 아니야.",
                    "버텨낸 만큼 몸도 쉬고 싶을 거야.",
                    "물 한 잔 마시고 숨 한 번만 크게 쉬자.",
                    "나는 오늘도 네 편이야."
            },
            {
                    "승재야, 오늘 마음이 예민했던 데는 이유가 있어.",
                    "아픈 마음을 느낀다고 이상한 건 아니야.",
                    "네가 불편했다는 사실은 작지 않아.",
                    "오늘은 이유 다 찾기보다 쉬는 쪽을 골라도 돼.",
                    "내일 이야기해도 괜찮아."
            }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_words_for_seungjae);
        UiInsets.apply(this, findViewById(R.id.wordsRoot));
        prefs = getSharedPreferences(AppPrefs.PREFS, MODE_PRIVATE);
        wordsText = findViewById(R.id.wordsText);
        statusText = findViewById(R.id.wordsStatusText);

        String cached = LiveMindManager.getLiveWords(this);
        if (cached.isEmpty()) showLocalWords(); else wordsText.setText(cached);
        findViewById(R.id.regenerateWordsButton).setOnClickListener(v -> generateWords());
        findViewById(R.id.readWordsButton).setOnClickListener(v -> readWords());
        findViewById(R.id.shareWordsButton).setOnClickListener(v -> shareWords());
        if (LiveMindManager.aiRefreshNeeded(this)) generateWords();
    }

    private void generateWords() {
        String apiKey = prefs.getString(AppPrefs.KEY_API_KEY, "").trim();
        if (apiKey.isEmpty()) {
            showLocalWords();
            statusText.setText("API Key 없이도 어린 승재가 새 위로를 골라줬어.");
            return;
        }

        statusText.setText("어린 승재가 오늘 승재에게 꼭 해주고 싶은 말을 정리하고 있어…");
        findViewById(R.id.regenerateWordsButton).setEnabled(false);
        new Thread(() -> {
            try {
                String recent = LiveMindManager.recentContext(this);
                String result = OpenAiClient.getFiveLineComfort(apiKey, recent, System.nanoTime());
                handler.post(() -> {
                    String normalized = normalizeFiveLines(result);
                    LiveMindManager.saveAiWords(this, normalized);
                    wordsText.setText(normalized);
                    statusText.setText("최근 상담과 일기를 다시 읽고 지금 마음에 맞춰 바꿨어 💗");
                    findViewById(R.id.regenerateWordsButton).setEnabled(true);
                });
            } catch (Exception e) {
                handler.post(() -> {
                    showLocalWords();
                    statusText.setText("지금은 기본 위로 문장으로 적어줬어.");
                    findViewById(R.id.regenerateWordsButton).setEnabled(true);
                });
            }
        }).start();
    }

    private String normalizeFiveLines(String text) {
        if (text == null) return localText();
        String cleaned = text.replace("•", "").replaceAll("(?m)^\\s*[-*]\\s*", "").trim();
        String[] raw = cleaned.split("\\r?\\n+");
        java.util.ArrayList<String> lines = new java.util.ArrayList<>();
        for (String line : raw) {
            String t = line.trim();
            if (!t.isEmpty()) lines.add(t);
        }
        if (lines.size() >= 5) {
            return String.join("\n", lines.subList(0, 5));
        }
        return cleaned;
    }

    private void showLocalWords() {
        String live = LiveMindManager.localWords(this);
        wordsText.setText(live.isEmpty() ? localText() : live);
    }

    private String localText() {
        String[] set = LOCAL_WORDS[random.nextInt(LOCAL_WORDS.length)];
        return String.join("\n", set);
    }

    private void readWords() {
        TtsManager.speak(this, wordsText.getText().toString(), new TtsManager.SpeakListener() {
            @Override public void onEngine(String engineName) {
                handler.post(() -> statusText.setText(engineName));
            }
            @Override public void onError(String message) {
                handler.post(() -> Toast.makeText(WordsForSeungjaeActivity.this, message, Toast.LENGTH_LONG).show());
            }
        });
    }

    private void shareWords() {
        Intent intent = new Intent(Intent.ACTION_SEND);
        intent.setType("text/plain");
        intent.putExtra(Intent.EXTRA_SUBJECT, "승재에게 해주고 싶은 말");
        intent.putExtra(Intent.EXTRA_TEXT, wordsText.getText().toString());
        startActivity(Intent.createChooser(intent, "승재에게 해주고 싶은 말 공유"));
    }

    @Override
    protected void onDestroy() {
        TtsManager.stop();
        super.onDestroy();
    }
}
