package com.maeummon.app.clinical;

import android.content.Context;
import org.json.*;
import java.util.*;

public final class ResponseSpecificityEvidenceAnchoringGuardRC9 {
    private ResponseSpecificityEvidenceAnchoringGuardRC9(){}

    public static final class Check {
        public boolean pass=true;
        public boolean rewriteRequired=false;
        public final List<String> failures=new ArrayList<>();
        public String instruction="";
        public String summary="PASS";
        public String anchorUsed="";

        void fail(String code){
            pass=false;
            rewriteRequired=true;
            failures.add(code);
        }
    }

    public static Check inspect(
            Context c,String userText,String response,ClinicalDecisionRC7 d){

        Check x=new Check();
        String u=userText==null?"":userText.trim();
        String r=response==null?"":response.trim();
        JSONObject f=CentralTherapyProfile.loadFormulation(c);

        String move=d==null?"":safe(d.move);
        String centralEvidence=f.optString("central_evidence_anchor","");
        JSONArray ledger=f.optJSONArray("evidence_ledger");

        boolean directAnchor=sharesMeaningfulToken(u,r);
        boolean centralAnchor=!centralEvidence.isEmpty() && sharesMeaningfulToken(centralEvidence,r);
        boolean ledgerAnchor=hasLedgerAnchor(ledger,r);

        if(directAnchor)x.anchorUsed="USER_TEXT";
        else if(centralAnchor)x.anchorUsed="CENTRAL_EVIDENCE";
        else if(ledgerAnchor)x.anchorUsed="EVIDENCE_LEDGER";

        // 1. FORMULATE / INTERVENE should be tied to at least one concrete anchor.
        if(("FORMULATE".equals(move)||"INTERVENE".equals(move))
                && !directAnchor && !centralAnchor && !ledgerAnchor){
            x.fail("NO_CONCRETE_EVIDENCE_ANCHOR");
        }

        // 2. Avoid generic relationship language when concrete episode exists.
        if(hasConcreteEpisode(u)
                && containsAny(r,
                    "관계에서 불안이 생길 수 있어",
                    "사람마다 다를 수 있어",
                    "대인관계에서는 이런 일이 있을 수 있어")
                && !directAnchor){
            x.fail("GENERIC_RESPONSE_IGNORES_EPISODE");
        }

        // 3. If central insight is usable, its evidence anchor should not disappear entirely.
        if(f.optBoolean("central_insight_usable",false)
                && !centralEvidence.isEmpty()
                && ("FORMULATE".equals(move)||"INTERVENE".equals(move))
                && !centralAnchor && !directAnchor){
            x.fail("CENTRAL_EVIDENCE_NOT_REFLECTED");
        }

        // 4. Do not claim "repeated pattern" without anchored repeated evidence.
        if(containsAny(r,"반복되는 패턴","계속 반복","늘 이런 식","자꾸 같은 일이")
                && !hasRepeatedAdmittedEvidence(ledger)){
            x.fail("PATTERN_CLAIM_WITHOUT_REPEATED_EVIDENCE");
        }

        // 5. Intervention must be attached to the user's actual trigger/context.
        if("INTERVENE".equals(move)
                && containsAny(r,"해봐","시도해","연습해","기록해")
                && !containsContextCue(u,r)){
            x.fail("INTERVENTION_NOT_CONTEXTUALIZED");
        }

        // 6. ASK should target a missing variable, not ask a generic emotional question
        // when a specific discriminator exists.
        if("ASK".equals(move)
                && d!=null
                && d.target!=null
                && !d.target.trim().isEmpty()
                && containsAny(r,
                    "좀 더 말해줄래?",
                    "어떤 기분이었어?",
                    "무슨 생각이 들었어?")
                && !mentionsTargetCue(d.target,r)){
            x.fail("ASK_NOT_ANCHORED_TO_TARGET");
        }

        // 7. Avoid vague pronoun-only replies after long concrete user message.
        if(u.length()>180 && vaguePronounRatio(r)>=0.45){
            x.fail("VAGUE_PRONOUN_HEAVY_RESPONSE");
        }

        // 8. When user cites time/change, response should preserve temporal distinction.
        if(containsAny(u,"최근","요즘","예전엔","원래","갑자기")
                && ("FORMULATE".equals(move)||"INTERVENE".equals(move))
                && !containsAny(r,"최근","요즘","예전","원래","갑자기","전보다","변화")){
            x.fail("TEMPORAL_CONTEXT_DROPPED");
        }

        // 9. When user contrasts people/settings, response should preserve selectivity.
        if(containsAny(u,"나한테만","다른 사람한텐","단톡에서는","개인톡은","회사에서는","친구한테는")
                && !containsAny(r,"나한테","다른 사람","단톡","개인톡","회사","친구","선택적")){
            x.fail("SELECTIVE_CONTEXT_DROPPED");
        }

        // 10. Avoid template-like response that could fit almost anyone.
        if(isTemplateLike(r) && !directAnchor && !centralAnchor){
            x.fail("TEMPLATE_LIKE_LOW_SPECIFICITY");
        }

        if(!x.pass){
            x.instruction=buildRewriteInstruction(x,d,centralEvidence);
        }
        x.summary=x.pass?"PASS":"FAIL "+x.failures.toString()+" anchor="+x.anchorUsed;
        return x;
    }

    public static String buildRewriteInstruction(
            Check x,ClinicalDecisionRC7 d,String centralEvidence){
        String move=d==null?"":safe(d.move);
        String target=d==null?"":safe(d.target);

        return "RESPONSE_SPECIFICITY_GUARD_FAIL=true. 응답을 다시 쓸 때 "
                +"사용자의 직전 발화나 admitted evidence에서 구체적 사실 1개를 반드시 반영한다. "
                +"시간 변화, 특정 사람/상황, 실제 행동 차이를 가능한 그대로 유지한다. "
                +"current_move="+move+", target="+target
                +", preferred_anchor="+compact(centralEvidence,120)+". "
                +"뻔한 상담문장 대신 '무엇이 실제로 있었고 그것을 어떻게 해석했는지'에 연결한다. failures="
                +x.failures;
    }

    private static boolean hasLedgerAnchor(JSONArray a,String r){
        if(a==null||r==null)return false;
        for(int i=a.length()-1;i>=0;i--){
            JSONObject o=a.optJSONObject(i);
            if(o==null)continue;
            String status=o.optString("admission_status","");
            if(!("ADMIT".equals(status)||"PROMOTE".equals(status)))continue;
            String text=o.optString("text","");
            if(!text.isEmpty()&&sharesMeaningfulToken(text,r))return true;
        }
        return false;
    }

    private static boolean hasRepeatedAdmittedEvidence(JSONArray a){
        if(a==null)return false;
        int n=0;
        for(int i=0;i<a.length();i++){
            JSONObject o=a.optJSONObject(i);
            if(o==null)continue;
            String status=o.optString("admission_status","");
            if(("ADMIT".equals(status)||"PROMOTE".equals(status))
                    && o.optInt("repetition_count",0)>=2)n++;
        }
        return n>0;
    }

    private static boolean containsContextCue(String u,String r){
        String[] cues={"친구","애인","회사","직장","상사","동료","가족","엄마","아빠",
                "답장","연락","단톡","개인톡","약속","업무","평가","거절"};
        for(String c:cues){
            if(u.contains(c)&&r.contains(c))return true;
        }
        return false;
    }

    private static boolean mentionsTargetCue(String target,String r){
        if(target==null||target.isEmpty())return false;
        if(r.contains(target))return true;
        if(target.contains("conflict")&&containsAny(r,"싸","갈등","다툼"))return true;
        if(target.contains("baseline")&&containsAny(r,"원래","예전","최근","전보다"))return true;
        if(target.contains("evaluation")&&containsAny(r,"평가","무능","실수","보일까"))return true;
        if(target.contains("relief")&&containsAny(r,"피하고 나서","당장은 편","안도"))return true;
        if(target.contains("episode")&&containsAny(r,"가장 최근","구체적인 상황","언제"))return true;
        return false;
    }

    private static boolean hasConcreteEpisode(String u){
        return u.length()>80 || containsAny(u,"어제","오늘","최근","그때","단톡","개인톡","회사","친구","애인");
    }

    private static double vaguePronounRatio(String r){
        if(r==null||r.isEmpty())return 0.0;
        String[] words=r.replaceAll("[^가-힣A-Za-z0-9 ]"," ").split("\\s+");
        int valid=0,vague=0;
        for(String w:words){
            if(w.length()<2)continue;
            valid++;
            if(containsAny(w,"그거","그게","그런","그렇게","이런","이렇게","그 사람","그 상황"))vague++;
        }
        return valid==0?0.0:(double)vague/(double)valid;
    }

    private static boolean isTemplateLike(String r){
        if(r==null)return false;
        return containsAny(r,
                "자신의 감정을 알아차리는 것이 중요해",
                "스스로를 돌보는 시간을 가져봐",
                "천천히 생각해보는 것도 도움이 될 수 있어",
                "너 자신에게 집중해보는 게 좋아",
                "감정을 인정하고 받아들이는 것이 중요해");
    }

    private static boolean sharesMeaningfulToken(String a,String b){
        if(a==null||b==null)return false;
        String[] xs=a.replaceAll("[^가-힣A-Za-z0-9 ]"," ").split("\\s+");
        for(String x:xs){
            if(x.length()<2||isStopword(x))continue;
            if(b.contains(x))return true;
        }
        return false;
    }

    private static boolean isStopword(String x){
        return "그냥".equals(x)||"근데".equals(x)||"나는".equals(x)||"내가".equals(x)
                ||"그게".equals(x)||"이거".equals(x)||"저거".equals(x)
                ||"진짜".equals(x)||"너무".equals(x)||"같아".equals(x);
    }

    private static boolean containsAny(String s,String... xs){
        if(s==null)return false;
        for(String x:xs)if(x!=null&&!x.isEmpty()&&s.contains(x))return true;
        return false;
    }

    private static String compact(String s,int max){
        s=s==null?"":s.trim();
        return s.length()<=max?s:s.substring(0,max);
    }

    private static String safe(String s){return s==null?"":s;}
}
