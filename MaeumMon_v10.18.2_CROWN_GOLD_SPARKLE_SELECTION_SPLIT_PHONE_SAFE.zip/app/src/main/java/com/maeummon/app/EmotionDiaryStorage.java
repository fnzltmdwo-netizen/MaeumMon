package com.maeummon.app;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

public class EmotionDiaryStorage {

    public static final String DATE_FORMAT = "yyyy.MM.dd";

    public static String today() {
        return new SimpleDateFormat(DATE_FORMAT, Locale.KOREA).format(new Date());
    }

    public static JSONArray getEntries(Context context) {
        try {
            SharedPreferences prefs = context.getSharedPreferences(AppPrefs.PREFS, Context.MODE_PRIVATE);
            return new JSONArray(prefs.getString(AppPrefs.KEY_EMOTION_DIARY, "[]"));
        } catch (Exception e) {
            return new JSONArray();
        }
    }

    public static JSONObject getEntryByDate(Context context, String date) {
        JSONArray arr = getEntries(context);
        for (int i = 0; i < arr.length(); i++) {
            JSONObject obj = arr.optJSONObject(i);
            if (obj != null && date.equals(obj.optString("date"))) return obj;
        }
        return null;
    }

    public static void saveOrUpdate(Context context, String date, String sticker, String label, String text) {
        JSONObject old = getEntryByDate(context, date);
        saveOrUpdate(context, date, sticker, label, text,
                old == null ? "" : old.optString("cause", ""),
                old == null ? "" : old.optString("tags", ""),
                old == null ? "" : old.optString("photoUri", ""));
    }

    public static void saveOrUpdate(Context context, String date, String sticker, String label,
                                    String text, String cause, String tags, String photoUri) {
        try {
            JSONArray arr = getEntries(context);
            JSONArray out = new JSONArray();
            boolean updated = false;

            for (int i = 0; i < arr.length(); i++) {
                JSONObject obj = arr.optJSONObject(i);
                if (obj == null) continue;
                if (date.equals(obj.optString("date"))) {
                    fill(obj, date, sticker, label, text, cause, tags, photoUri);
                    out.put(obj);
                    updated = true;
                } else out.put(obj);
            }

            if (!updated) {
                JSONObject obj = new JSONObject();
                fill(obj, date, sticker, label, text, cause, tags, photoUri);
                out.put(obj);
            }

            context.getSharedPreferences(AppPrefs.PREFS, Context.MODE_PRIVATE)
                    .edit().putString(AppPrefs.KEY_EMOTION_DIARY, out.toString()).apply();
            LiveMindManager.onMindChanged(context);
            DailyMoodInsightManager.invalidate(context, date);
        } catch (Exception ignored) {}
    }

    private static void fill(JSONObject obj, String date, String sticker, String label,
                             String text, String cause, String tags, String photoUri) throws Exception {
        obj.put("date", date);
        obj.put("sticker", sticker);
        obj.put("label", label);
        obj.put("text", text);
        obj.put("cause", cause == null ? "" : cause);
        obj.put("tags", normalizeTags(tags, text));
        obj.put("photoUri", photoUri == null ? "" : photoUri);
    }

    public static String normalizeTags(String manualTags, String text) {
        Set<String> tags = new LinkedHashSet<>();
        if (manualTags != null) {
            for (String part : manualTags.split("[,#\\s]+")) {
                String v = part.trim();
                if (!v.isEmpty()) tags.add(v);
            }
        }
        String t = text == null ? "" : text;
        addIfContains(tags, t, "회사", "업무", "일", "출근");
        addIfContains(tags, t, "친구", "사람", "관계", "연락");
        addIfContains(tags, t, "피곤", "잠", "수면", "졸");
        addIfContains(tags, t, "불안", "걱정", "긴장");
        addIfContains(tags, t, "행복", "좋았", "즐거", "기분좋");
        addIfContains(tags, t, "휴식", "쉬", "산책", "카페");
        StringBuilder sb = new StringBuilder();
        int count = 0;
        for (String tag : tags) {
            if (count >= 8) break;
            if (sb.length() > 0) sb.append(",");
            sb.append(tag);
            count++;
        }
        return sb.toString();
    }

    private static void addIfContains(Set<String> tags, String text, String tag, String... keywords) {
        for (String keyword : keywords) {
            if (text.contains(keyword)) { tags.add(tag); return; }
        }
    }

    public static Date parseDate(String date) {
        try { return new SimpleDateFormat(DATE_FORMAT, Locale.KOREA).parse(date); }
        catch (ParseException e) { return new Date(); }
    }

    public static String recentPreview(Context context) {
        JSONArray arr = getEntries(context);
        if (arr.length() == 0) return "아직 적은 속마음 일기가 없어.";
        StringBuilder sb = new StringBuilder();
        int start = Math.max(0, arr.length() - 5);
        for (int i = arr.length() - 1; i >= start; i--) {
            JSONObject obj = arr.optJSONObject(i);
            if (obj == null) continue;
            sb.append(obj.optString("date", "")).append("  ")
              .append(obj.optString("sticker", "🙂")).append(" ")
              .append(obj.optString("label", ""));
            String cause = obj.optString("cause", "");
            if (!cause.isEmpty()) sb.append(" · ").append(cause);
            sb.append("\n");
            String text = obj.optString("text", "");
            if (text.length() > 34) text = text.substring(0, 34) + "...";
            sb.append(text);
            String tags = obj.optString("tags", "");
            if (!tags.isEmpty()) sb.append("\n#").append(tags.replace(",", " #"));
            sb.append("\n\n");
        }
        return sb.toString().trim();
    }

    public static JSONArray getEntriesForMonth(Context context, int year, int monthZeroBased) {
        JSONArray src = getEntries(context); JSONArray out = new JSONArray();
        for (int i=0;i<src.length();i++) {
            JSONObject obj=src.optJSONObject(i); if(obj==null) continue;
            Date d=parseDate(obj.optString("date","")); java.util.Calendar c=java.util.Calendar.getInstance(); c.setTime(d);
            if(c.get(java.util.Calendar.YEAR)==year && c.get(java.util.Calendar.MONTH)==monthZeroBased) out.put(obj);
        }
        return out;
    }

    public static JSONArray getLastSevenEntries(Context context) {
        JSONArray src=getEntries(context); ArrayList<JSONObject> items=new ArrayList<>();
        for(int i=0;i<src.length();i++){JSONObject o=src.optJSONObject(i); if(o!=null) items.add(o);}
        items.sort((a,b)->parseDate(a.optString("date","")).compareTo(parseDate(b.optString("date",""))));
        JSONArray out=new JSONArray(); int start=Math.max(0,items.size()-7); for(int i=start;i<items.size();i++) out.put(items.get(i)); return out;
    }

    public static Map<String,Integer> countLabels(JSONArray arr){LinkedHashMap<String,Integer> map=new LinkedHashMap<>(); for(int i=0;i<arr.length();i++){JSONObject o=arr.optJSONObject(i);if(o==null)continue;String v=o.optString("label","잔잔");map.put(v,map.containsKey(v)?map.get(v)+1:1);}return map;}
    public static Map<String,Integer> countCauses(JSONArray arr){LinkedHashMap<String,Integer> map=new LinkedHashMap<>(); for(int i=0;i<arr.length();i++){JSONObject o=arr.optJSONObject(i);if(o==null)continue;String v=o.optString("cause","").trim();if(v.isEmpty())continue;map.put(v,map.containsKey(v)?map.get(v)+1:1);}return map;}
    public static Map<String,Integer> countTags(JSONArray arr){LinkedHashMap<String,Integer> map=new LinkedHashMap<>();for(int i=0;i<arr.length();i++){JSONObject o=arr.optJSONObject(i);if(o==null)continue;String raw=o.optString("tags","");for(String p:raw.split(",")){String v=p.trim();if(v.isEmpty())continue;map.put(v,map.containsKey(v)?map.get(v)+1:1);}}return map;}

    public static String topKey(Map<String,Integer> map){String top="-";int n=0;for(Map.Entry<String,Integer> e:map.entrySet()){if(e.getValue()>n){top=e.getKey();n=e.getValue();}}return top;}

    public static String monthSummary(Context context,int year,int month){
        JSONArray arr=getEntriesForMonth(context,year,month);
        if(arr.length()==0) return "이번 달 기록이 아직 없어. 마음 한 줄만 쌓여도 흐름을 보기 시작할 수 있어.";
        Map<String,Integer> feelings=countLabels(arr);
        Map<String,Integer> causes=countCauses(arr);
        return "이번 달엔 "+arr.length()+"일 기록했어. 가장 자주 나온 마음은 '"+topKey(feelings)+"'이고, 자주 겹친 이유는 '"+topKey(causes)+"'였어.";
    }

    public static String weeklyPatternSummary(Context context) {
        JSONArray arr = getLastSevenEntries(context);
        if (arr.length() == 0) return "최근 7일 기록이 아직 없어. 하루 한 줄만 쌓여도 뭐 때문에 흔들리는지 보기 쉬워져.";
        Map<String, Integer> feelings = countLabels(arr);
        Map<String, Integer> causes = countCauses(arr);
        Map<String, Integer> tags = countTags(arr);
        return "최근 7일 기록 " + arr.length() + "일\n"
                + "가장 자주 나온 마음: " + topKey(feelings) + "\n"
                + "자주 겹친 상황: " + topKey(causes) + "\n"
                + "자주 남긴 키워드: " + topKey(tags) + "\n\n"
                + "중요한 건 감정 이름보다, 어떤 상황에서 그 감정이 반복됐는지 보는 거야.";
    }

    public static String weeklyLetter(Context context){
        JSONArray arr=getLastSevenEntries(context);
        if(arr.length()==0) return "승재야, 아직 기록이 적어도 괜찮아. 한 줄씩만 쌓여도 네 마음을 훨씬 더 정확히 볼 수 있어.";
        String feeling=topKey(countLabels(arr));
        String cause=topKey(countCauses(arr));
        return "승재야, 이번 주 기록을 보니 '"+feeling+"' 마음이 자주 보였고, '"+cause+"' 때문에 흔들린 날이 많았어. 이건 네가 약해서가 아니라, 그 상황이 너를 힘들게 했다는 뜻이야. 다음 주에는 그 상황에서 나를 덜 힘들게 할 한 가지를 정해보자. 예를 들면 바로 답하지 않기, 해야 할 일 하나 줄이기처럼 작게 가도 돼. - 어린 승재";
    }

    public static String weeklyList(Context context){JSONArray arr=getLastSevenEntries(context);if(arr.length()==0)return "최근 7일 기록이 아직 없어.";StringBuilder sb=new StringBuilder();for(int i=arr.length()-1;i>=0;i--){JSONObject o=arr.optJSONObject(i);if(o==null)continue;sb.append(o.optString("date","")).append("  ").append(o.optString("sticker","🙂")).append(" ").append(o.optString("label","")).append("\n");String cause=o.optString("cause","");if(!cause.isEmpty())sb.append("원인: ").append(cause).append("\n");String tags=o.optString("tags","");if(!tags.isEmpty())sb.append("태그: #").append(tags.replace(","," #")).append("\n");sb.append(o.optString("text","")).append("\n\n");}return sb.toString().trim();}

    public static String exportAllText(Context context){StringBuilder sb=new StringBuilder("마음몬 전체 속마음 일기 백업\n=================================\n\n");JSONArray arr=getEntries(context);if(arr.length()==0)return sb.append("기록 없음").toString();for(int i=0;i<arr.length();i++){JSONObject o=arr.optJSONObject(i);if(o==null)continue;sb.append(o.optString("date","")).append("\n").append(o.optString("sticker","🙂")).append(" ").append(o.optString("label","")).append("\n원인: ").append(o.optString("cause","-")).append("\n태그: ").append(o.optString("tags","-")).append("\n사진: ").append(o.optString("photoUri","-")).append("\n").append(o.optString("text","")).append("\n---------------------------------\n");}return sb.toString();}
    public static String weeklyReportExportText(Context context){return "마음몬 주간 리포트\n============================\n\n"+weeklyPatternSummary(context)+"\n\n어린 승재의 주간 편지\n----------------------------\n"+weeklyLetter(context)+"\n\n최근 7일 기록\n----------------------------\n"+weeklyList(context);}
}
