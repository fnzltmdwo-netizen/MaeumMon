package com.maeummon.app;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;

public class V10GrowthActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_v10_growth);
        UiInsets.apply(this, findViewById(R.id.v10GrowthRoot));
        findViewById(R.id.openWeeklyGrowthButton).setOnClickListener(v -> startActivity(new Intent(this, WeeklyReportActivity.class)));
        findViewById(R.id.openMonthlyGrowthButton).setOnClickListener(v -> startActivity(new Intent(this, MonthlyStatsActivity.class)));
        findViewById(R.id.openMoodHistoryButton).setOnClickListener(v -> startActivity(new Intent(this, MoodCalendarActivity.class)));
    }
}
