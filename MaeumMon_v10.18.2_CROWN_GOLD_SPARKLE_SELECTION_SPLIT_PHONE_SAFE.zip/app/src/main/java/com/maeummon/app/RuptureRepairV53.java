package com.maeummon.app;

import java.util.Locale;

/** Repairs misattunement instead of defending the counselor's old interpretation. */
public final class RuptureRepairV53 {
    private RuptureRepairV53() {}

    public static String buildContext(String userMessage) {
        String t = userMessage == null ? "" : userMessage.toLowerCase(Locale.KOREA);
        boolean correction = has(t, "아니 그게", "그 뜻이 아니", "내 말은", "잘못 이해", "오해", "그게 아니라", "아닌데", "답답", "왜 자꾸");
        boolean alienated = has(t, "내 말 안 듣", "기계 같", "상담 같지", "공감 안", "결론부터", "질문만", "똑같은 말");
        return "[RUPTURE REPAIR v5.3]\n"
                + "rupture_signal=" + (correction || alienated) + ".\n"
                + "- 사용자가 '아니/그게 아니라/잘못 이해했어/답답해'처럼 수정 신호를 보내면 상담자의 이전 해석을 방어하지 않는다.\n"
                + "- 먼저 짧게 인정한다: '내가 너무 빨리 X로 이해했네.' 그 다음 사용자의 수정 내용을 자기 말로 1문장 확인하고, 필요할 때만 질문 하나로 재정렬한다.\n"
                + "- 사과를 길게 해서 사용자가 상담자를 달래게 만들지 않는다. 관계 복구의 목표는 정확도 회복이지 상담자의 죄책감 해소가 아니다.\n"
                + "- 이전 formulation과 충돌하면 TURNING_POINT로 기록하고 새 증거를 우선한다. 같은 해석을 표현만 바꿔 반복하지 않는다.\n"
                + "- 사용자가 단지 다른 의견을 말한 것과 rupture를 구분한다. 실제 오해/소외 신호가 없으면 과잉 사과하지 않는다.";
    }

    public static String prompt() {
        return "[RUPTURE REPAIR v5.3] 사용자가 상담자의 해석을 수정하거나 '내 말이 그게 아니다'라는 신호를 보내면 이전 formulation을 방어하지 말고, 오해를 짧게 인정→사용자 의미 재확인→가설 수정 순서로 복구한다. 과잉 사과와 같은 해석 반복을 피한다.";
    }

    private static boolean has(String t, String... xs) {
        for (String x : xs) if (t.contains(x.toLowerCase(Locale.KOREA))) return true;
        return false;
    }
}
