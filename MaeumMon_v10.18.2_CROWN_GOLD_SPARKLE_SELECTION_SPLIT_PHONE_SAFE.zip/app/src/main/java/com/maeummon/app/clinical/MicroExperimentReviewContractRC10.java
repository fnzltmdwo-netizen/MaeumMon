package com.maeummon.app.clinical;

import android.content.Context;
import org.json.*;

public final class MicroExperimentReviewContractRC10 {
    private MicroExperimentReviewContractRC10(){}

    public static final class Result {
        public boolean ready=false;
        public String experimentId="";
        public String action="";
        public String reviewCriterion="";
        public String stopCondition="";
        public String mode="";
        public String dose="";
        public int maxMinutes=0;
        public String rationale="";
        public String summary="";
    }

    public static Result build(Context c,ClinicalDecisionRC7 d){
        Result r=new Result();
        if(d==null){
            r.summary="NOT_READY | NO_DECISION";
            return r;
        }

        if(!d.isIntervene()){
            r.summary="NOT_READY | NOT_INTERVENE";
            return r;
        }

        if("NONE".equals(d.interventionDose)){
            r.summary="NOT_READY | DOSE_NONE";
            return r;
        }

        if(d.safetyOverride){
            r.summary="NOT_READY | SAFETY";
            return r;
        }

        if(d.allianceRupture){
            r.summary="NOT_READY | ALLIANCE";
            return r;
        }

        if(d.interventionAdaptationReopen){
            r.summary="NOT_READY | FORMULATION_REOPEN";
            return r;
        }

        String intervention=safe(d.selectedInterventionId);
        String target=safe(d.selectedInterventionTarget);
        String mode=safe(d.interventionPreferenceMode);
        String dose=safe(d.interventionDose);

        r.mode=mode;
        r.dose=dose;
        r.maxMinutes=Math.max(0,d.interventionExerciseMinutes);
        r.experimentId=buildExperimentId(intervention,target,mode);

        r.action=buildAction(intervention,target,mode,dose,r.maxMinutes);
        r.reviewCriterion=buildReviewCriterion(intervention,target);
        r.stopCondition=buildStopCondition(dose);

        r.ready=!r.action.isEmpty()&&!r.reviewCriterion.isEmpty();
        r.rationale=r.ready
                ?"선택된 intervention의 기전을 유지하면서 한 번에 하나의 관찰 가능한 행동실험과 리뷰 기준을 묶었다."
                :"action/review criterion 생성에 필요한 정보가 부족하다.";

        r.summary=r.ready
                ?"READY | "+r.experimentId+" | "+dose+" | "+mode
                :"NOT_READY";
        return r;
    }

    public static String instruction(Result r){
        if(r==null||!r.ready)return "";

        return "MICRO_EXPERIMENT_READY=true. 사용자에게 개입을 설명할 때 "
                +"행동실험은 정확히 1개만 제시한다. "
                +"실험="+r.action+" "
                +"다음 review 기준="+r.reviewCriterion+" "
                +"중단 조건="+r.stopCondition+" "
                +"내부 experiment ID나 dose/mode 이름은 노출하지 않는다.";
    }

    private static String buildAction(
            String intervention,String target,String mode,
            String dose,int maxMinutes){

        String core=coreAction(intervention,target);
        if(core.isEmpty())return "";

        if("ULTRA_SHORT".equals(mode))
            return core;

        if("SCRIPT".equals(mode))
            return scriptAction(intervention,target);

        if("WRITING".equals(mode))
            return writingAction(intervention,target);

        if("OBSERVATION".equals(mode))
            return observationAction(intervention,target);

        if("VERBAL".equals(mode))
            return verbalAction(intervention,target);

        if("BEHAVIOR".equals(mode))
            return behaviorAction(intervention,target);

        if("DEEP".equals(dose)&&maxMinutes>0)
            return core+" 최대 "+maxMinutes+"분까지만 해본다.";

        return core;
    }

    private static String coreAction(String intervention,String target){
        if("REALITY_TEST".equals(intervention)
                ||target.contains("interpretation_not_fact"))
            return "가장 최근 사건 하나에서 '확인된 사실' 1개와 '내 해석' 1개를 나눈다.";

        if("AMBIGUITY_TOLERANCE".equals(intervention)
                ||target.contains("tolerate_uncertainty"))
            return "애매한 상황 하나를 바로 결론내리지 않고 '아직 모름'으로 한 번 남겨둔다.";

        if("COMMUNICATION_SCRIPT".equals(intervention)
                ||target.contains("clarify_relationship_change"))
            return "상대에게 공격 없이 변화 여부를 확인하는 문장 하나를 만들어본다.";

        if("REPAIR_OR_BOUNDARY".equals(intervention)
                ||target.contains("repair_or_boundary"))
            return "이번 상황에서 '관계를 수리할 부분'과 '내가 지킬 경계' 중 하나를 고른다.";

        if("FACT_VS_EVALUATION".equals(intervention)
                ||target.contains("global_self_judgment"))
            return "실제 실수/피드백 사실과 '나는 무능하다' 같은 자기평가를 한 번 분리한다.";

        if("LOAD_REDUCTION".equals(intervention)
                ||target.contains("task_load"))
            return "오늘 해야 할 것 중 하나를 줄이거나 미룬다.";

        if("WORK_BOUNDARY_SCRIPT".equals(intervention)
                ||target.contains("threat_exposure"))
            return "업무상 한 가지 경계 문장을 준비한다.";

        if("RECOVERY_FIRST".equals(intervention)
                ||target.contains("regulation_capacity"))
            return "문제해결 전에 짧은 회복 행동 하나를 먼저 한다.";

        if("GRADED_APPROACH".equals(intervention)
                ||target.contains("small_approach"))
            return "피하고 싶은 상황의 가장 작은 접근 행동 하나만 한다.";

        return "";
    }

    private static String writingAction(String intervention,String target){
        String core=coreAction(intervention,target);
        return core.isEmpty()?"":core+" 메모는 1~3줄만 쓴다.";
    }

    private static String scriptAction(String intervention,String target){
        if("COMMUNICATION_SCRIPT".equals(intervention)
                ||target.contains("clarify_relationship_change"))
            return "\"요즘 예전이랑 반응이 조금 다른 것 같아서 내가 오해하는 건지 궁금했어.\"처럼 확인 문장 하나만 만든다.";

        if("WORK_BOUNDARY_SCRIPT".equals(intervention)
                ||target.contains("threat_exposure"))
            return "\"지금 바로 답하기보다 확인하고 다시 말씀드릴게요.\" 같은 경계 문장 하나만 만든다.";

        return coreAction(intervention,target);
    }

    private static String observationAction(String intervention,String target){
        if(target.contains("interpretation_not_fact")
                ||"REALITY_TEST".equals(intervention))
            return "행동을 바꾸지 말고 다음 한 번의 사건에서 사실과 해석이 갈리는 지점만 관찰한다.";

        return "당장 바꾸려 하지 말고 다음 한 번의 상황에서 핵심 반응만 관찰한다.";
    }

    private static String verbalAction(String intervention,String target){
        if(target.contains("interpretation_not_fact")
                ||"REALITY_TEST".equals(intervention))
            return "말로 '사실은 ___, 내가 붙인 해석은 ___' 한 번만 말해본다.";

        return "이 행동을 글 대신 말로 한 번 정리한다: "+coreAction(intervention,target);
    }

    private static String behaviorAction(String intervention,String target){
        return coreAction(intervention,target);
    }

    private static String buildReviewCriterion(String intervention,String target){
        if("REALITY_TEST".equals(intervention)
                ||target.contains("interpretation_not_fact"))
            return "다음 비슷한 상황에서 해석을 사실처럼 확정하는 속도가 조금이라도 느려졌는지 본다.";

        if("AMBIGUITY_TOLERANCE".equals(intervention)
                ||target.contains("tolerate_uncertainty"))
            return "애매함을 견디는 동안 불안이 바로 행동으로 번졌는지 아닌지 본다.";

        if("COMMUNICATION_SCRIPT".equals(intervention)
                ||target.contains("clarify_relationship_change"))
            return "대화를 한 뒤 추측보다 실제 정보가 늘었는지 본다.";

        if("REPAIR_OR_BOUNDARY".equals(intervention)
                ||target.contains("repair_or_boundary"))
            return "관계 수리와 자기보호 중 무엇이 필요한지 전보다 선명해졌는지 본다.";

        if("FACT_VS_EVALUATION".equals(intervention)
                ||target.contains("global_self_judgment"))
            return "실수 하나가 자기 전체 평가로 번지는 정도가 줄었는지 본다.";

        if("LOAD_REDUCTION".equals(intervention)
                ||target.contains("task_load"))
            return "부담 하나를 줄인 뒤 압도감/피로가 조금이라도 내려갔는지 본다.";

        if("WORK_BOUNDARY_SCRIPT".equals(intervention)
                ||target.contains("threat_exposure"))
            return "경계 문장을 쓴 뒤 위협감이나 과잉대응이 줄었는지 본다.";

        if("RECOVERY_FIRST".equals(intervention)
                ||target.contains("regulation_capacity"))
            return "회복 행동 뒤 문제를 보는 여력이 조금이라도 돌아왔는지 본다.";

        if("GRADED_APPROACH".equals(intervention)
                ||target.contains("small_approach"))
            return "작은 접근 뒤 회피 충동과 실제 감당 가능성이 어떻게 달랐는지 본다.";

        return "해본 뒤 이전과 달라진 점이 있었는지 하나만 본다.";
    }

    private static String buildStopCondition(String dose){
        if("MICRO".equals(dose)||"LIGHT".equals(dose))
            return "불편감이 확 커지면 더 밀지 않고 중단하고 다음 턴에 알려준다.";

        if("STANDARD".equals(dose)||"DEEP".equals(dose))
            return "불편감이 뚜렷하게 악화되거나 압도되면 중단하고 강도를 낮춘다.";

        return "불편감이 커지면 중단한다.";
    }

    private static String buildExperimentId(
            String intervention,String target,String mode){
        String a=intervention.isEmpty()?"GENERIC":intervention;
        String b=target.isEmpty()?"TARGET":target;
        String c=mode.isEmpty()?"DEFAULT":mode;
        return (a+"__"+b+"__"+c).replaceAll("[^A-Za-z0-9_]+","_");
    }

    private static String safe(String s){
        return s==null?"":s;
    }
}
