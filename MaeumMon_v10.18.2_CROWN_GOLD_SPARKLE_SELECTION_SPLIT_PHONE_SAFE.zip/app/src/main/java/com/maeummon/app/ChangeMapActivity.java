package com.maeummon.app;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;

public class ChangeMapActivity extends Activity {
    private int dp(int v){ return (int)(v*getResources().getDisplayMetrics().density+0.5f); }
    private TextView text(String s,float sp,int color,boolean bold){
        TextView t=new TextView(this); t.setText(s); t.setTextSize(sp); t.setTextColor(color); t.setPadding(0,dp(3),0,dp(3));
        if(bold)t.setTypeface(t.getTypeface(),android.graphics.Typeface.BOLD); return t;
    }
    @Override protected void onCreate(Bundle b){ super.onCreate(b);
        ScrollView sc=new ScrollView(this); LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(dp(18),dp(22),dp(18),dp(30)); root.setBackgroundColor(Color.rgb(249,247,255)); sc.addView(root);
        root.addView(text("🗺️ 승재의 변화지도",28,Color.rgb(74,69,92),true));
        root.addView(text("진단검사 점수가 아니라, 상담에서 실제로 드러난 선택과 회복의 변화를 천천히 누적해 보는 지도야.",14,Color.rgb(108,104,125),false));
        LinearLayout approach=new LinearLayout(this); approach.setOrientation(LinearLayout.VERTICAL); approach.setPadding(dp(14),dp(12),dp(14),dp(12)); approach.setBackgroundResource(R.drawable.bg_card_mint); LinearLayout.LayoutParams ap=new LinearLayout.LayoutParams(-1,-2); ap.setMargins(0,dp(14),0,dp(12)); root.addView(approach,ap);
        approach.addView(text("직전 턴에서 유연하게 선택한 접근",15,Color.rgb(80,87,92),true));
        approach.addView(text(ChangeMapManager.lastApproach(this),17,Color.rgb(74,92,90),true));
        approach.addView(text(ChangeMapManager.lastReason(this),13,Color.rgb(105,111,120),false));
        String[] keys=ChangeMapManager.keys(), labels=ChangeMapManager.labels();
        for(int i=0;i<keys.length;i++){
            LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(dp(14),dp(11),dp(14),dp(11)); box.setBackgroundResource(R.drawable.bg_card); LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(-1,-2); bp.setMargins(0,dp(5),0,dp(5)); root.addView(box,bp);
            int score=ChangeMapManager.score(this,keys[i]);
            TextView title=text(labels[i]+"   "+score,15,Color.rgb(83,79,101),true); box.addView(title);
            ProgressBar bar=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal); bar.setMax(100); bar.setProgress(score); LinearLayout.LayoutParams pp=new LinearLayout.LayoutParams(-1,dp(12)); pp.setMargins(0,dp(7),0,dp(4)); box.addView(bar,pp);
            String hint=score<45?"지금은 이 부분을 보호하고 연습하는 시기":score<65?"작은 변화가 쌓이는 중":"반복 가능한 힘으로 자리 잡아가는 중";
            box.addView(text(hint,12,Color.rgb(118,114,132),false));
        }
        root.addView(text("점수가 내려가도 실패가 아니야. 힘든 사건이 있었거나 이전보다 더 솔직하게 알아차린 결과일 수도 있어. 숫자보다 실제 생활에서 무엇을 다르게 했는지를 더 중요하게 볼게.",12,Color.rgb(126,120,138),false));
        setContentView(sc);
    }
}
