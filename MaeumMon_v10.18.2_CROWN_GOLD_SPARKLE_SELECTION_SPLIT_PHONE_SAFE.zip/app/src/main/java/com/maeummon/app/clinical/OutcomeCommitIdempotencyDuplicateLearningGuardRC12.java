package com.maeummon.app.clinical;

import android.content.Context;
import org.json.*;
import java.security.MessageDigest;

public final class OutcomeCommitIdempotencyDuplicateLearningGuardRC12 {
    private OutcomeCommitIdempotencyDuplicateLearningGuardRC12(){}

    public enum State {
        NOT_APPLICABLE,
        NEW_COMMIT,
        DUPLICATE_SUPPRESSED,
        CONFLICTING_DUPLICATE_BLOCKED
    }

    public static final class Result {
        public boolean evaluated=false;
        public boolean allowLearning=true;
        public boolean duplicate=false;
        public boolean conflictingDuplicate=false;
        public State state=State.NOT_APPLICABLE;
        public String commitKey="";
        public String experimentId="";
        public String outcome="";
        public String priorOutcome="";
        public String reason="";
        public String summary="";
    }

    public static Result evaluate(
            Context c,
            ClinicalDecisionRC7 d,
            String userText){

        Result r=new Result();

        if(c==null||d==null){
            r.allowLearning=false;
            r.summary="NOT_APPLICABLE | NO_CONTEXT_OR_DECISION";
            return r;
        }

        if(!"COMMIT".equals(d.outcomeCommitState)){
            r.state=State.NOT_APPLICABLE;
            r.allowLearning=true;
            r.summary="NOT_APPLICABLE | NO_COMMIT";
            return r;
        }

        r.evaluated=true;
        r.experimentId=safe(d.outcomeCommitExperimentId);
        if(r.experimentId.isEmpty())
            r.experimentId=safe(d.microExperimentId);

        r.outcome=safe(d.outcomeCommitValue);
        r.commitKey=buildCommitKey(
                r.experimentId,
                r.outcome,
                safe(d.outcomeCommitResolution),
                compact(userText,240));

        JSONObject s=CentralTherapyProfile.loadSessionState(c);
        JSONObject p=CentralTherapyProfile.loadProfile(c);

        JSONArray history=p.optJSONArray("outcome_commit_idempotency_history");
        if(history==null)history=new JSONArray();

        JSONObject sameKey=findByKey(history,r.commitKey);

        if(sameKey!=null){
            r.duplicate=true;
            r.allowLearning=false;
            r.state=State.DUPLICATE_SUPPRESSED;
            r.priorOutcome=sameKey.optString("outcome","");
            r.reason="IDENTICAL_COMMIT_ALREADY_PROCESSED";
            persistLastState(c,s,p,r,false);
            return finish(r);
        }

        JSONObject sameExperiment=findLatestByExperiment(
                history,r.experimentId);

        if(sameExperiment!=null){
            String prior=sameExperiment.optString("outcome","");
            r.priorOutcome=prior;

            if(!prior.isEmpty()
                    && !r.outcome.isEmpty()
                    && !prior.equals(r.outcome)){

                r.duplicate=true;
                r.conflictingDuplicate=true;
                r.allowLearning=false;
                r.state=State.CONFLICTING_DUPLICATE_BLOCKED;
                r.reason="SAME_EXPERIMENT_ALREADY_COMMITTED_DIFFERENT_OUTCOME";
                persistLastState(c,s,p,r,false);
                return finish(r);
            }

            r.duplicate=true;
            r.allowLearning=false;
            r.state=State.DUPLICATE_SUPPRESSED;
            r.reason="SAME_EXPERIMENT_ALREADY_COMMITTED";
            persistLastState(c,s,p,r,false);
            return finish(r);
        }

        r.state=State.NEW_COMMIT;
        r.allowLearning=true;
        r.reason="FIRST_COMMIT_FOR_EXPERIMENT";

        JSONObject item=new JSONObject();
        try{
            item.put("commit_key",r.commitKey);
            item.put("experiment_id",r.experimentId);
            item.put("outcome",r.outcome);
            item.put("resolution",safe(d.outcomeCommitResolution));
            item.put("user_evidence",compact(userText,240));
            item.put("time",System.currentTimeMillis());
            history.put(item);

            JSONArray trimmed=new JSONArray();
            int start=Math.max(0,history.length()-60);
            for(int i=start;i<history.length();i++)
                trimmed.put(history.opt(i));

            p.put("outcome_commit_idempotency_history",trimmed);
            p.put("last_outcome_commit_key",r.commitKey);
            p.put("last_outcome_commit_experiment_id",r.experimentId);
            p.put("last_outcome_commit_idempotency_state",r.state.name());

            s.put("last_outcome_commit_key",r.commitKey);
            s.put("last_outcome_commit_experiment_id",r.experimentId);
            s.put("last_outcome_commit_idempotency_state",r.state.name());

            CentralTherapyProfile.replaceProfile(c,p);
            CentralTherapyProfile.replaceSessionState(c,s);
        }catch(Exception ignored){}

        return finish(r);
    }

    public static String instruction(Result r){
        if(r==null||!r.evaluated)return "";

        if(r.state==State.DUPLICATE_SUPPRESSED){
            return "OUTCOME_COMMIT_IDEMPOTENCY=DUPLICATE_SUPPRESSED. 같은 experiment outcome이 이미 반영되었으므로 이번 turn에서는 outcome/policy learning을 다시 증가시키지 않는다.";
        }

        if(r.state==State.CONFLICTING_DUPLICATE_BLOCKED){
            return "OUTCOME_COMMIT_IDEMPOTENCY=CONFLICT_BLOCKED. 같은 experiment에 서로 다른 outcome이 중복 기록되려 하므로 자동 학습을 중단하고 기존 commit을 보존한다.";
        }

        if(r.state==State.NEW_COMMIT){
            return "OUTCOME_COMMIT_IDEMPOTENCY=NEW_COMMIT. 이 experiment의 첫 확정 outcome이므로 한 번만 learning에 반영한다.";
        }

        return "";
    }

    public static boolean shouldAllowLearning(Result r){
        return r==null || !r.evaluated || r.allowLearning;
    }

    private static void persistLastState(
            Context c,JSONObject s,JSONObject p,
            Result r,boolean append){

        try{
            p.put("last_outcome_commit_key",r.commitKey);
            p.put("last_outcome_commit_experiment_id",r.experimentId);
            p.put("last_outcome_commit_idempotency_state",r.state.name());
            p.put("last_outcome_commit_duplicate_reason",r.reason);

            s.put("last_outcome_commit_key",r.commitKey);
            s.put("last_outcome_commit_experiment_id",r.experimentId);
            s.put("last_outcome_commit_idempotency_state",r.state.name());

            CentralTherapyProfile.replaceProfile(c,p);
            CentralTherapyProfile.replaceSessionState(c,s);
        }catch(Exception ignored){}
    }

    private static JSONObject findByKey(JSONArray a,String key){
        if(a==null||key==null||key.isEmpty())return null;

        for(int i=a.length()-1;i>=0;i--){
            JSONObject x=a.optJSONObject(i);
            if(x!=null&&key.equals(x.optString("commit_key","")))
                return x;
        }
        return null;
    }

    private static JSONObject findLatestByExperiment(
            JSONArray a,String experimentId){

        if(a==null||experimentId==null||experimentId.isEmpty())
            return null;

        for(int i=a.length()-1;i>=0;i--){
            JSONObject x=a.optJSONObject(i);
            if(x!=null
                    &&experimentId.equals(
                            x.optString("experiment_id","")))
                return x;
        }
        return null;
    }

    private static String buildCommitKey(
            String experimentId,
            String outcome,
            String resolution,
            String evidence){

        String raw=safe(experimentId)+"|"
                +safe(outcome)+"|"
                +safe(resolution)+"|"
                +normalizeEvidence(evidence);

        try{
            MessageDigest md=MessageDigest.getInstance("SHA-256");
            byte[] b=md.digest(raw.getBytes("UTF-8"));
            StringBuilder sb=new StringBuilder();
            for(byte x:b)
                sb.append(String.format("%02x",x));
            return sb.toString();
        }catch(Exception e){
            return Integer.toHexString(raw.hashCode());
        }
    }

    private static String normalizeEvidence(String s){
        if(s==null)return "";
        return s.trim()
                .replaceAll("\\s+"," ")
                .toLowerCase();
    }

    private static String compact(String s,int max){
        s=s==null?"":s.trim();
        return s.length()<=max?s:s.substring(0,max);
    }

    private static Result finish(Result r){
        r.summary=r.state.name()
                +" | allowLearning="+r.allowLearning
                +" | duplicate="+r.duplicate
                +" | conflicting="+r.conflictingDuplicate
                +" | experiment="+r.experimentId
                +" | outcome="+r.outcome
                +" | prior="+r.priorOutcome
                +" | reason="+r.reason;
        return r;
    }

    private static String safe(String s){
        return s==null?"":s;
    }
}
