package com.maeummon.app;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import java.util.ArrayList;
import java.util.List;
import java.util.LinkedHashSet;
import java.util.Set;
import java.security.MessageDigest;
import java.nio.charset.StandardCharsets;

public class MindTrainingStore {
    public static class CounselingSyncSession {
        public long id;
        public String title = "";
        public String status = "ACTIVE";
        public long createdAt;
        public long updatedAt;
        public int chunkCount;
        public int charCount;
    }

    public static class CounselingSyncChunk {
        public long id;
        public long sessionId;
        public String speaker = "";
        public String content = "";
        public long createdAt;
    }

    public static class SharedThreadState {
        public long id;
        public String shareUrl = "";
        public String title = "";
        public boolean complete;
        public int turnCount;
        public int charCount;
        public long lastCounselingId = -1;
        public String analysisState = "PENDING";
        public String analysisError = "";
        public int analyzedTurnCount = 0;
        public long analysisUpdatedAt = 0L;
        public String firstTurnHash = "";
        public String lastTurnHash = "";
        public String firstTurnPreview = "";
        public String lastTurnPreview = "";
        public long lastVerifiedAt = 0L;
        public long lastSyncAt = 0L;
        public long createdAt;
        public long updatedAt;
    }

    public static class SharedCorpusState {
        public int threadCount;
        public int turnCount;
        public int charCount;
    }

    public static class SharedTurnMergeResult {
        public long threadId = -1;
        public int existingCount;
        public int addedCount;
        public int addedChars;
        public int totalCount;
        public int totalChars;
        public boolean complete;
        public String deltaText = "";
        public String fullText = "";
    }

    public static class CounselingEntry {
        public long id;
        public String title;
        public String rawText;
        public String currentConcern;
        public String formulation;
        public String priorityDirection;
        public String muscleName;
        public String trainingText;
        public String successCriterion;
        public String caution;
        public long createdAt;
    }

    public static class ProgramSummary {
        public long id;
        public long counselingId;
        public String name = "";
        public String muscleName = "";
        public int priority;
        public String reason = "";
        public int stepCount;
        public int doneSteps;
        public String status = "PENDING";
    }

    private static final String STATE_PREFS = "mind_pt_central_state";
    private static final String PREF_CROWN_PROGRAM_ID = "crown_program_id";
    private static final String PREF_CROWN_COUNSELING_ID = "crown_counseling_id";

    private final MindTrainingDbHelper helper;
    private final Context appContext;

    public MindTrainingStore(Context context) {
        appContext = context.getApplicationContext();
        helper = new MindTrainingDbHelper(appContext);
    }

    public long saveConcern(String rawText, String mode) {
        ContentValues v = new ContentValues();
        v.put("raw_text", rawText);
        v.put("mode", mode);
        v.put("created_at", System.currentTimeMillis());
        return helper.getWritableDatabase().insertOrThrow("concerns", null, v);
    }

    public long saveCounselingImport(String rawText) {
        CounselingImportParser.Parsed p = CounselingImportParser.parse(rawText);
        ContentValues v = new ContentValues();
        v.put("source", "GPT_FULL_COUNSELING");
        v.put("title", emptyTo(p.title, "상담 완전판 기록"));
        v.put("raw_text", rawText == null ? "" : rawText.trim());
        v.put("current_concern", p.currentConcern);
        v.put("formulation", p.formulation);
        v.put("priority_direction", p.priorityDirection);
        v.put("muscle_name", p.muscleName);
        v.put("training_text", p.trainingText);
        v.put("success_criterion", p.successCriterion);
        v.put("caution", p.caution);
        v.put("created_at", System.currentTimeMillis());
        return helper.getWritableDatabase().insertOrThrow("counseling_entries", null, v);
    }

    public CounselingEntry latestCounseling() {
        Cursor c = helper.getReadableDatabase().rawQuery(
                "SELECT id,title,raw_text,current_concern,formulation,priority_direction,muscle_name,training_text,success_criterion,caution,created_at " +
                        "FROM counseling_entries ORDER BY created_at DESC LIMIT 1", null);
        try {
            return c.moveToFirst() ? readCounseling(c) : null;
        } finally {
            c.close();
        }
    }

    public CounselingEntry counselingById(long id) {
        if (id < 0) return null;
        Cursor c = helper.getReadableDatabase().rawQuery(
                "SELECT id,title,raw_text,current_concern,formulation,priority_direction,muscle_name,training_text,success_criterion,caution,created_at " +
                        "FROM counseling_entries WHERE id=? LIMIT 1", new String[]{String.valueOf(id)});
        try {
            return c.moveToFirst() ? readCounseling(c) : null;
        } finally {
            c.close();
        }
    }

    public List<CounselingEntry> counselingHistory(int limit) {
        List<CounselingEntry> out = new ArrayList<>();
        Cursor c = helper.getReadableDatabase().rawQuery(
                "SELECT id,title,raw_text,current_concern,formulation,priority_direction,muscle_name,training_text,success_criterion,caution,created_at " +
                        "FROM counseling_entries ORDER BY created_at DESC LIMIT " + Math.max(1, Math.min(100, limit)), null);
        try {
            while (c.moveToNext()) out.add(readCounseling(c));
        } finally {
            c.close();
        }
        return out;
    }

    private CounselingEntry readCounseling(Cursor c) {
        CounselingEntry e = new CounselingEntry();
        e.id = c.getLong(0);
        e.title = safe(c.getString(1));
        e.rawText = safe(c.getString(2));
        e.currentConcern = safe(c.getString(3));
        e.formulation = safe(c.getString(4));
        e.priorityDirection = safe(c.getString(5));
        e.muscleName = safe(c.getString(6));
        e.trainingText = safe(c.getString(7));
        e.successCriterion = safe(c.getString(8));
        e.caution = safe(c.getString(9));
        e.createdAt = c.getLong(10);
        return e;
    }

    public long getOrCreateMuscle(String name, String mechanism) {
        SQLiteDatabase db = helper.getWritableDatabase();
        Cursor c = db.rawQuery("SELECT id FROM mind_muscles WHERE name=?", new String[]{name});
        try {
            if (c.moveToFirst()) return c.getLong(0);
        } finally {
            c.close();
        }
        long now = System.currentTimeMillis();
        ContentValues v = new ContentValues();
        v.put("name", name);
        v.put("mechanism", mechanism);
        v.put("created_at", now);
        v.put("updated_at", now);
        return db.insertOrThrow("mind_muscles", null, v);
    }

    public long saveTraining(long concernId, long muscleId, TrainingRecommendationEngine.Recommendation r) {
        return saveTraining(concernId, muscleId, r, -1);
    }

    public long saveTraining(long concernId, long muscleId, TrainingRecommendationEngine.Recommendation r, long programStepId) {
        ContentValues v = new ContentValues();
        v.put("concern_id", concernId);
        v.put("muscle_id", muscleId);
        v.put("mode", r.mode);
        v.put("exercise_type", r.exerciseType);
        v.put("exercise_text", r.exerciseText);
        v.put("difficulty", r.difficulty);
        v.put("success_criterion", r.successCriterion);
        v.put("rationale", r.rationale);
        v.put("created_at", System.currentTimeMillis());
        if (programStepId > 0) v.put("program_step_id", programStepId);
        return helper.getWritableDatabase().insertOrThrow("training_sessions", null, v);
    }

    public void saveOutcome(long trainingId, String attemptStatus, String effect, String reflection) {
        ContentValues v = new ContentValues();
        v.put("training_id", trainingId);
        v.put("attempt_status", attemptStatus);
        v.put("effect", effect);
        v.put("reflection", reflection == null ? "" : reflection);
        v.put("created_at", System.currentTimeMillis());
        SQLiteDatabase db = helper.getWritableDatabase();
        db.insertOrThrow("training_outcomes", null, v);
        ContentValues done = new ContentValues();
        done.put("completed_at", System.currentTimeMillis());
        db.update("training_sessions", done, "id=?", new String[]{String.valueOf(trainingId)});
    }

    public String latestEffectForMuscle(String muscleName) {
        SQLiteDatabase db = helper.getReadableDatabase();
        Cursor c = db.rawQuery(
                "SELECT o.effect FROM training_outcomes o " +
                        "JOIN training_sessions t ON t.id=o.training_id " +
                        "JOIN mind_muscles m ON m.id=t.muscle_id " +
                        "WHERE m.name=? ORDER BY o.created_at DESC LIMIT 1",
                new String[]{muscleName});
        try {
            return c.moveToFirst() ? c.getString(0) : "UNKNOWN";
        } finally {
            c.close();
        }
    }

    public int latestDifficultyForMuscle(String muscleName) {
        SQLiteDatabase db = helper.getReadableDatabase();
        Cursor c = db.rawQuery(
                "SELECT t.difficulty FROM training_sessions t JOIN mind_muscles m ON m.id=t.muscle_id " +
                        "WHERE m.name=? ORDER BY t.created_at DESC LIMIT 1",
                new String[]{muscleName});
        try {
            return c.moveToFirst() ? c.getInt(0) : 1;
        } finally {
            c.close();
        }
    }


    public long saveAnalyzedCounseling(String rawText, CounselingProgramAnalyzer.Analysis analysis) {
        SQLiteDatabase db = helper.getWritableDatabase();
        db.beginTransaction();
        try {
            CounselingProgramAnalyzer.Program top = analysis.programs.isEmpty() ? null : analysis.programs.get(0);
            if (top != null) {
                for (CounselingProgramAnalyzer.Program p : analysis.programs) if (p.priority > top.priority) top = p;
            }
            ContentValues v = new ContentValues();
            v.put("source", "GPT_SHARED_LINK");
            v.put("title", emptyTo(analysis.title, "상담 완전판 공유링크"));
            v.put("raw_text", rawText == null ? "" : rawText.trim());
            v.put("current_concern", analysis.currentConcern);
            v.put("formulation", analysis.formulation);
            v.put("priority_direction", analysis.priorityDirection);
            v.put("muscle_name", top == null ? "" : top.muscleName);
            v.put("training_text", top == null || top.steps.isEmpty() ? "" : top.steps.get(0).exerciseText);
            v.put("success_criterion", top == null || top.steps.isEmpty() ? "" : top.steps.get(0).successCriterion);
            v.put("caution", analysis.caution);
            v.put("created_at", System.currentTimeMillis());
            long counselingId = db.insertOrThrow("counseling_entries", null, v);
            long now = System.currentTimeMillis();
            LinkedHashSet<String> savedMuscles = new LinkedHashSet<>();
            for (CounselingProgramAnalyzer.Program p : analysis.programs) {
                String muscleKey = normalizeMuscleKey(p == null ? "" : p.muscleName);
                if (muscleKey.isEmpty() || !savedMuscles.add(muscleKey)) continue;
                ContentValues pv = new ContentValues();
                pv.put("counseling_id", counselingId);
                pv.put("name", p.name);
                pv.put("mechanism", p.mechanism);
                pv.put("muscle_name", p.muscleName);
                pv.put("priority", p.priority);
                pv.put("reason", p.reason);
                pv.put("status", "PENDING");
                pv.put("created_at", now);
                long programId = db.insertOrThrow("counseling_programs", null, pv);
                for (CounselingProgramAnalyzer.Step st : p.steps) {
                    ContentValues sv = new ContentValues();
                    sv.put("program_id", programId);
                    sv.put("step_order", st.order);
                    sv.put("mode", st.mode);
                    sv.put("exercise_type", st.exerciseType);
                    sv.put("exercise_text", st.exerciseText);
                    sv.put("success_criterion", st.successCriterion);
                    sv.put("rationale", st.rationale);
                    sv.put("difficulty", st.difficulty);
                    sv.put("status", "PENDING");
                    sv.put("created_at", now);
                    db.insertOrThrow("counseling_program_steps", null, sv);
                }
            }
            db.setTransactionSuccessful();
            return counselingId;
        } finally {
            db.endTransaction();
        }
    }

    public List<ProgramSummary> programsForCounseling(long counselingId) {
        cleanupExactDuplicatePrograms(counselingId);
        ensureCrownProgramId(counselingId);
        List<ProgramSummary> out = new ArrayList<>();
        Cursor c = helper.getReadableDatabase().rawQuery(
                "SELECT p.id,p.counseling_id,p.name,p.muscle_name,p.priority,p.reason,p.status,COUNT(s.id)," +
                        "SUM(CASE WHEN s.status='DONE' THEN 1 ELSE 0 END) " +
                        "FROM counseling_programs p LEFT JOIN counseling_program_steps s ON s.program_id=p.id " +
                        "WHERE p.counseling_id=? AND p.status!='MERGED' GROUP BY p.id ORDER BY p.priority DESC,p.id ASC",
                new String[]{String.valueOf(counselingId)});
        try {
            while (c.moveToNext()) {
                ProgramSummary x = new ProgramSummary();
                x.id = c.getLong(0); x.counselingId = c.getLong(1); x.name = safe(c.getString(2));
                x.muscleName = safe(c.getString(3)); x.priority = c.getInt(4); x.reason = safe(c.getString(5));
                x.status = safe(c.getString(6)); x.stepCount = c.getInt(7); x.doneSteps = c.isNull(8) ? 0 : c.getInt(8); out.add(x);
            }
        } finally { c.close(); }
        return out;
    }

    public long programIdForTraining(long trainingId) {
        if (trainingId <= 0) return -1;
        Cursor c = helper.getReadableDatabase().rawQuery(
                "SELECT s.program_id FROM training_sessions t " +
                        "JOIN counseling_program_steps s ON s.id=t.program_step_id WHERE t.id=? LIMIT 1",
                new String[]{String.valueOf(trainingId)});
        try { return c.moveToFirst() ? c.getLong(0) : -1; } finally { c.close(); }
    }

    public long activateProgramStep(long programId, boolean supersedeCurrent) {
        SQLiteDatabase db = helper.getWritableDatabase();
        if (supersedeCurrent) {
            ContentValues stop = new ContentValues();
            stop.put("superseded_at", System.currentTimeMillis());
            db.update("training_sessions", stop, "completed_at IS NULL AND superseded_at IS NULL", null);
        }
        Cursor c = db.rawQuery(
                "SELECT s.id,p.id,p.muscle_name,p.mechanism,s.mode,s.exercise_type,s.exercise_text,s.success_criterion,s.rationale,s.difficulty " +
                        "FROM counseling_programs p JOIN counseling_program_steps s ON s.program_id=p.id " +
                        "WHERE p.id=? AND s.status IN ('PENDING','RETRY','ACTIVE') " +
                        "ORDER BY CASE s.status WHEN 'ACTIVE' THEN 0 WHEN 'RETRY' THEN 1 ELSE 2 END,s.step_order ASC LIMIT 1",
                new String[]{String.valueOf(programId)});
        try {
            if (!c.moveToFirst()) return -1;
            long stepId = c.getLong(0);
            TrainingRecommendationEngine.Recommendation r = new TrainingRecommendationEngine.Recommendation();
            r.mode = safe(c.getString(4)); r.muscleName = safe(c.getString(2)); r.mechanism = safe(c.getString(3));
            r.exerciseType = safe(c.getString(5)); r.exerciseText = safe(c.getString(6));
            r.successCriterion = safe(c.getString(7)); r.rationale = safe(c.getString(8)); r.difficulty = c.getInt(9); r.fromCounseling = true;
            long concernId = saveConcern("[선택한 상담 마음 PT] " + r.muscleName, r.mode);
            long muscleId = getOrCreateMuscle(r.muscleName, r.mechanism);
            long trainingId = saveTraining(concernId, muscleId, r, stepId);
            ContentValues su = new ContentValues(); su.put("status", "ACTIVE");
            db.update("counseling_program_steps", su, "id=?", new String[]{String.valueOf(stepId)});
            ContentValues pu = new ContentValues(); pu.put("status", "ACTIVE");
            db.update("counseling_programs", pu, "id=?", new String[]{String.valueOf(programId)});
            return trainingId;
        } finally { c.close(); }
    }

    public long activateFirstProgramStep(long counselingId, boolean supersedeCurrent) {
        SQLiteDatabase db = helper.getWritableDatabase();
        if (supersedeCurrent) {
            ContentValues stop = new ContentValues();
            stop.put("superseded_at", System.currentTimeMillis());
            db.update("training_sessions", stop, "completed_at IS NULL AND superseded_at IS NULL", null);
        }
        Cursor c = db.rawQuery(
                "SELECT s.id,p.id,p.muscle_name,p.mechanism,s.mode,s.exercise_type,s.exercise_text,s.success_criterion,s.rationale,s.difficulty " +
                        "FROM counseling_programs p JOIN counseling_program_steps s ON s.program_id=p.id " +
                        "WHERE p.counseling_id=? AND s.status='PENDING' " +
                        "ORDER BY p.priority DESC,s.step_order ASC,p.id ASC LIMIT 1",
                new String[]{String.valueOf(counselingId)});
        try {
            if (!c.moveToFirst()) return -1;
            long stepId = c.getLong(0); long programId = c.getLong(1);
            TrainingRecommendationEngine.Recommendation r = new TrainingRecommendationEngine.Recommendation();
            r.mode = safe(c.getString(4)); r.muscleName = safe(c.getString(2)); r.mechanism = safe(c.getString(3));
            r.exerciseType = safe(c.getString(5)); r.exerciseText = safe(c.getString(6));
            r.successCriterion = safe(c.getString(7)); r.rationale = safe(c.getString(8)); r.difficulty = c.getInt(9); r.fromCounseling = true;
            long concernId = saveConcern("[상담 완전판 프로그램] " + r.muscleName, r.mode);
            long muscleId = getOrCreateMuscle(r.muscleName, r.mechanism);
            long trainingId = saveTraining(concernId, muscleId, r, stepId);
            ContentValues su = new ContentValues(); su.put("status", "ACTIVE");
            db.update("counseling_program_steps", su, "id=?", new String[]{String.valueOf(stepId)});
            ContentValues pu = new ContentValues(); pu.put("status", "ACTIVE");
            db.update("counseling_programs", pu, "id=?", new String[]{String.valueOf(programId)});
            return trainingId;
        } finally { c.close(); }
    }

    public long advanceProgramAfterOutcome(long trainingId, String effect) {
        SQLiteDatabase db = helper.getWritableDatabase();
        Cursor c = db.rawQuery("SELECT program_step_id FROM training_sessions WHERE id=?", new String[]{String.valueOf(trainingId)});
        long stepId = -1;
        try { if (c.moveToFirst() && !c.isNull(0)) stepId = c.getLong(0); } finally { c.close(); }
        if (stepId < 0) return -1;
        Cursor s = db.rawQuery("SELECT s.program_id,s.step_order,s.mode,s.exercise_type,s.exercise_text,s.success_criterion,s.rationale,s.difficulty,p.counseling_id " +
                "FROM counseling_program_steps s JOIN counseling_programs p ON p.id=s.program_id WHERE s.id=?", new String[]{String.valueOf(stepId)});
        long programId; long counselingId; int order; int difficulty; String mode, type, exercise, criterion, rationale;
        try {
            if (!s.moveToFirst()) return -1;
            programId=s.getLong(0); order=s.getInt(1); mode=safe(s.getString(2)); type=safe(s.getString(3)); exercise=safe(s.getString(4)); criterion=safe(s.getString(5)); rationale=safe(s.getString(6)); difficulty=s.getInt(7); counselingId=s.getLong(8);
        } finally { s.close(); }
        ContentValues done = new ContentValues();
        if ("HELPED".equals(effect)) done.put("status", "DONE");
        else done.put("status", "RETRY");
        db.update("counseling_program_steps", done, "id=?", new String[]{String.valueOf(stepId)});

        if (!"HELPED".equals(effect)) {
            Cursor p = db.rawQuery("SELECT muscle_name,mechanism FROM counseling_programs WHERE id=?", new String[]{String.valueOf(programId)});
            try {
                if (!p.moveToFirst()) return -1;
                TrainingRecommendationEngine.Recommendation r = new TrainingRecommendationEngine.Recommendation();
                r.mode=mode; r.muscleName=safe(p.getString(0)); r.mechanism=safe(p.getString(1)); r.exerciseType=type;
                r.exerciseText=exercise; r.successCriterion=criterion; r.difficulty=difficulty; r.fromCounseling=true;
                if ("NO_OPPORTUNITY".equals(effect)) {
                    r.rationale="연습할 상황이 없었던 거라 실패로 세지 않고 같은 단계를 그대로 유지해. 다음에 비슷한 장면이 생길 때 다시 이어가면 돼." + (rationale.isEmpty()?"":" " + rationale);
                } else if ("PARTIAL".equals(effect)) {
                    r.difficulty=Math.max(1, difficulty);
                    r.exerciseText="이번에는 원래 훈련을 전부 해내려 하지 말고, 첫 행동 하나만 해보기. " + exercise;
                    r.successCriterion="원래 훈련의 첫 행동 하나를 실제 상황에서 한 번이라도 시도했다.";
                    r.rationale="조금 해낸 건 이미 중요한 성공 신호야. 난이도를 올리지 않고 같은 핵심을 더 작은 단위로 한 번 더 익숙하게 만들어볼게." + (rationale.isEmpty()?"":" " + rationale);
                } else if ("WORSE".equals(effect)) {
                    r.mode="STABILIZE";
                    r.exerciseType="LOWER_DOSE_STABILIZE";
                    r.difficulty=1;
                    r.exerciseText="이 훈련은 지금 더 밀지 말고, 몸과 감정의 강도를 0~10으로 한 번 확인한 뒤 10분 동안 자극에서 떨어져 쉬기. 관계·결정·확인행동은 안정된 뒤 다시 판단하기.";
                    r.successCriterion="훈련을 더 밀지 않고 10분 쉬거나 안전하고 편한 공간으로 이동했고, 되돌리기 어려운 행동은 보류했다.";
                    r.rationale="지난 시도에서 더 힘들어졌기 때문에 같은 강도로 반복하지 않고 먼저 안정화해. 악화된 방법을 그대로 반복하지 않는 것도 훈련의 일부야.";
                } else {
                    r.difficulty=Math.max(1, difficulty-1);
                    r.exerciseText="원래 훈련의 목표는 유지하되 행동 크기를 절반 이하로 줄여 시작하기. " + exercise;
                    r.successCriterion="완벽히 해내지 않아도, 줄인 행동을 시작하거나 2분 이상 유지했다.";
                    r.rationale="아직 실행이 어려웠던 단계라 실패로 보지 않고 행동 크기를 줄였어. 같은 핵심을 더 작은 성공 경험으로 다시 연습해." + (rationale.isEmpty()?"":" " + rationale);
                }
                long concernId=saveConcern("[상담 프로그램 재연습] " + r.muscleName,r.mode);
                long muscleId=getOrCreateMuscle(r.muscleName,r.mechanism);
                long retryId = saveTraining(concernId,muscleId,r,stepId);
                ContentValues retry = new ContentValues(); retry.put("status", "ACTIVE");
                db.update("counseling_program_steps", retry, "id=?", new String[]{String.valueOf(stepId)});
                return retryId;
            } finally { p.close(); }
        }

        Cursor next = db.rawQuery(
                "SELECT s.id,p.id,p.muscle_name,p.mechanism,s.mode,s.exercise_type,s.exercise_text,s.success_criterion,s.rationale,s.difficulty " +
                        "FROM counseling_program_steps s JOIN counseling_programs p ON p.id=s.program_id " +
                        "WHERE s.program_id=? AND s.step_order>? AND s.status='PENDING' ORDER BY s.step_order ASC LIMIT 1",
                new String[]{String.valueOf(programId),String.valueOf(order)});
        try {
            if (next.moveToFirst()) return activateStepFromCursor(db,next);
        } finally { next.close(); }

        ContentValues pc = new ContentValues(); pc.put("status", "DONE"); db.update("counseling_programs", pc, "id=?", new String[]{String.valueOf(programId)});
        Cursor other = db.rawQuery(
                "SELECT s.id,p.id,p.muscle_name,p.mechanism,s.mode,s.exercise_type,s.exercise_text,s.success_criterion,s.rationale,s.difficulty " +
                        "FROM counseling_programs p JOIN counseling_program_steps s ON s.program_id=p.id " +
                        "WHERE p.counseling_id=? AND p.status!='DONE' AND s.status='PENDING' ORDER BY p.priority DESC,s.step_order ASC LIMIT 1",
                new String[]{String.valueOf(counselingId)});
        try { return other.moveToFirst() ? activateStepFromCursor(db,other) : -1; } finally { other.close(); }
    }

    private long activateStepFromCursor(SQLiteDatabase db, Cursor c) {
        long stepId=c.getLong(0), programId=c.getLong(1);
        TrainingRecommendationEngine.Recommendation r = new TrainingRecommendationEngine.Recommendation();
        r.muscleName=safe(c.getString(2)); r.mechanism=safe(c.getString(3)); r.mode=safe(c.getString(4)); r.exerciseType=safe(c.getString(5));
        r.exerciseText=safe(c.getString(6)); r.successCriterion=safe(c.getString(7)); r.rationale=safe(c.getString(8)); r.difficulty=c.getInt(9); r.fromCounseling=true;
        long concernId=saveConcern("[상담 프로그램 다음 단계] " + r.muscleName,r.mode);
        long muscleId=getOrCreateMuscle(r.muscleName,r.mechanism);
        long trainingId=saveTraining(concernId,muscleId,r,stepId);
        ContentValues su=new ContentValues(); su.put("status","ACTIVE"); db.update("counseling_program_steps",su,"id=?",new String[]{String.valueOf(stepId)});
        ContentValues pu=new ContentValues(); pu.put("status","ACTIVE"); db.update("counseling_programs",pu,"id=?",new String[]{String.valueOf(programId)});
        return trainingId;
    }


    public SharedThreadState sharedThreadByUrl(String shareUrl) {
        if (shareUrl == null || shareUrl.trim().isEmpty()) return null;
        Cursor c = helper.getReadableDatabase().rawQuery(
                "SELECT id,share_url,title,is_complete,turn_count,char_count,last_counseling_id,analysis_state,analysis_error,analyzed_turn_count,analysis_updated_at,first_turn_hash,last_turn_hash,first_turn_preview,last_turn_preview,last_verified_at,last_sync_at,created_at,updated_at " +
                        "FROM shared_counseling_threads WHERE share_url=? LIMIT 1", new String[]{shareUrl.trim()});
        try {
            if (!c.moveToFirst()) return null;
            SharedThreadState x = new SharedThreadState();
            x.id=c.getLong(0); x.shareUrl=safe(c.getString(1)); x.title=safe(c.getString(2));
            x.complete=c.getInt(3)==1; x.turnCount=c.getInt(4); x.charCount=c.getInt(5);
            x.lastCounselingId=c.isNull(6)?-1:c.getLong(6);
            x.analysisState=safe(c.getString(7)); if (x.analysisState.isEmpty()) x.analysisState="PENDING";
            x.analysisError=safe(c.getString(8)); x.analyzedTurnCount=c.getInt(9); x.analysisUpdatedAt=c.isNull(10)?0L:c.getLong(10);
            x.firstTurnHash=safe(c.getString(11)); x.lastTurnHash=safe(c.getString(12));
            x.firstTurnPreview=safe(c.getString(13)); x.lastTurnPreview=safe(c.getString(14));
            x.lastVerifiedAt=c.isNull(15)?0L:c.getLong(15); x.lastSyncAt=c.isNull(16)?0L:c.getLong(16);
            x.createdAt=c.getLong(17); x.updatedAt=c.getLong(18);
            return x;
        } finally { c.close(); }
    }

    /** Central corpus across every imported shared counseling link.
     *  Turns are de-duplicated globally by the same role+content SHA-256 fingerprint,
     *  so importing another share URL never replaces the older counseling history. */
    public SharedCorpusState sharedCorpusState() {
        SharedCorpusState out = new SharedCorpusState();
        SQLiteDatabase db = helper.getReadableDatabase();
        Cursor tc = db.rawQuery("SELECT COUNT(*) FROM shared_counseling_threads WHERE turn_count>0", null);
        try { if (tc.moveToFirst()) out.threadCount = tc.getInt(0); } finally { tc.close(); }
        LinkedHashSet<String> seen = new LinkedHashSet<>();
        Cursor c = db.rawQuery(
                "SELECT v.content_hash,v.content FROM shared_counseling_turns v " +
                        "JOIN shared_counseling_threads t ON t.id=v.thread_id " +
                        "ORDER BY t.created_at ASC,t.id ASC,v.turn_order ASC", null);
        try {
            while (c.moveToNext()) {
                String h = safe(c.getString(0));
                if (!seen.add(h)) continue;
                String content = safe(c.getString(1));
                out.turnCount++;
                out.charCount += content.length();
            }
        } finally { c.close(); }
        return out;
    }

    public String sharedCorpusTranscript() {
        StringBuilder b = new StringBuilder();
        LinkedHashSet<String> seen = new LinkedHashSet<>();
        SQLiteDatabase db = helper.getReadableDatabase();
        Cursor c = db.rawQuery(
                "SELECT t.id,v.speaker,v.content,v.content_hash FROM shared_counseling_turns v " +
                        "JOIN shared_counseling_threads t ON t.id=v.thread_id " +
                        "ORDER BY t.created_at ASC,t.id ASC,v.turn_order ASC", null);
        long lastThread = -1; int session = 0;
        try {
            while (c.moveToNext()) {
                String hash = safe(c.getString(3));
                if (!seen.add(hash)) continue;
                long threadId = c.getLong(0);
                if (threadId != lastThread) {
                    session++; lastThread = threadId;
                    if (b.length() > 0) b.append("\n\n");
                    b.append("=== 누적 상담 기록 ").append(session).append(" ===\n");
                } else if (b.length() > 0) {
                    b.append("\n\n");
                }
                b.append("USER".equals(safe(c.getString(1))) ? "나의 말: " : "ChatGPT의 말: ")
                        .append(safe(c.getString(2)));
            }
        } finally { c.close(); }
        return b.toString().trim();
    }

    /** Latest central PT record created from shared-link counseling. */
    public long latestSharedCounselingId() {
        Cursor c = helper.getReadableDatabase().rawQuery(
                "SELECT id FROM counseling_entries WHERE source='GPT_SHARED_LINK' ORDER BY created_at DESC,id DESC LIMIT 1", null);
        try { return c.moveToFirst() ? c.getLong(0) : -1; } finally { c.close(); }
    }

    public void bindAllSharedThreadsCounseling(long counselingId) {
        if (counselingId < 0) return;
        ContentValues u = new ContentValues();
        u.put("last_counseling_id", counselingId);
        u.put("updated_at", System.currentTimeMillis());
        helper.getWritableDatabase().update("shared_counseling_threads", u, "turn_count>0", null);
    }

    public Set<String> sharedTurnHashes(String shareUrl) {
        LinkedHashSet<String> out = new LinkedHashSet<>();
        SharedThreadState st = sharedThreadByUrl(shareUrl);
        if (st == null) return out;
        Cursor c = helper.getReadableDatabase().rawQuery(
                "SELECT content_hash FROM shared_counseling_turns WHERE thread_id=? ORDER BY turn_order ASC",
                new String[]{String.valueOf(st.id)});
        try { while(c.moveToNext()) out.add(safe(c.getString(0))); } finally { c.close(); }
        return out;
    }

    public SharedTurnMergeResult mergeSharedTurnBlocks(String shareUrl, List<String> blocks, boolean markComplete) {
        SharedTurnMergeResult result = new SharedTurnMergeResult();
        if (shareUrl == null || shareUrl.trim().isEmpty()) return result;
        SQLiteDatabase db = helper.getWritableDatabase();
        db.beginTransaction();
        try {
            long now=System.currentTimeMillis();
            SharedThreadState current=sharedThreadByUrl(shareUrl);
            long threadId;
            if (current == null) {
                ContentValues tv=new ContentValues();
                tv.put("share_url", shareUrl.trim()); tv.put("title","상담 완전판 공유링크");
                tv.put("is_complete",0); tv.put("turn_count",0); tv.put("char_count",0);
                tv.put("analysis_state","PENDING"); tv.put("analysis_error",""); tv.put("analyzed_turn_count",0); tv.put("analysis_updated_at",now);
                tv.put("first_turn_hash",""); tv.put("last_turn_hash",""); tv.put("first_turn_preview",""); tv.put("last_turn_preview","");
                tv.put("last_sync_at",now);
                tv.put("created_at",now); tv.put("updated_at",now);
                threadId=db.insertOrThrow("shared_counseling_threads",null,tv);
                result.existingCount=0;
            } else { threadId=current.id; result.existingCount=current.turnCount; }
            result.threadId=threadId;

            int nextOrder=0;
            Cursor mc=db.rawQuery("SELECT COALESCE(MAX(turn_order),-1)+1 FROM shared_counseling_turns WHERE thread_id=?", new String[]{String.valueOf(threadId)});
            try { if(mc.moveToFirst()) nextOrder=mc.getInt(0); } finally { mc.close(); }

            StringBuilder delta=new StringBuilder();
            if (blocks != null) {
                for (String rawBlock : blocks) {
                    ParsedSharedBlock pb=parseSharedBlock(rawBlock);
                    if (pb.content.isEmpty()) continue;
                    String h=sharedTurnHash(pb.speaker,pb.content);
                    ContentValues v=new ContentValues();
                    v.put("thread_id",threadId); v.put("turn_order",nextOrder); v.put("speaker",pb.speaker);
                    v.put("content",pb.content); v.put("content_hash",h); v.put("created_at",now);
                    long id=db.insertWithOnConflict("shared_counseling_turns",null,v,SQLiteDatabase.CONFLICT_IGNORE);
                    if(id!=-1){
                        nextOrder++; result.addedCount++; result.addedChars+=pb.content.length();
                        if(delta.length()>0) delta.append("\n\n");
                        delta.append("USER".equals(pb.speaker)?"나의 말: ":"ChatGPT의 말: ").append(pb.content);
                    }
                }
            }
            Cursor totals=db.rawQuery("SELECT COUNT(*),COALESCE(SUM(LENGTH(content)),0) FROM shared_counseling_turns WHERE thread_id=?",new String[]{String.valueOf(threadId)});
            try { if(totals.moveToFirst()){result.totalCount=totals.getInt(0); result.totalChars=totals.getInt(1);} } finally { totals.close(); }
            ContentValues u=new ContentValues();
            if(markComplete) { u.put("is_complete",1); u.put("last_verified_at",now); }
            if(result.addedCount>0){ u.put("analysis_state","PENDING"); u.put("analysis_error",""); u.put("analysis_updated_at",now); }
            Cursor edge=db.rawQuery("SELECT content_hash,content FROM shared_counseling_turns WHERE thread_id=? ORDER BY turn_order ASC LIMIT 1",new String[]{String.valueOf(threadId)});
            try { if(edge.moveToFirst()){u.put("first_turn_hash",safe(edge.getString(0)));u.put("first_turn_preview",previewTurn(safe(edge.getString(1))));} } finally { edge.close(); }
            edge=db.rawQuery("SELECT content_hash,content FROM shared_counseling_turns WHERE thread_id=? ORDER BY turn_order DESC LIMIT 1",new String[]{String.valueOf(threadId)});
            try { if(edge.moveToFirst()){u.put("last_turn_hash",safe(edge.getString(0)));u.put("last_turn_preview",previewTurn(safe(edge.getString(1))));} } finally { edge.close(); }
            u.put("last_sync_at",now);
            u.put("turn_count",result.totalCount); u.put("char_count",result.totalChars); u.put("updated_at",now);
            db.update("shared_counseling_threads",u,"id=?",new String[]{String.valueOf(threadId)});
            result.complete=markComplete || (current!=null && current.complete);
            result.deltaText=delta.toString();
            result.fullText=sharedThreadTranscriptById(db,threadId);
            db.setTransactionSuccessful();
            return result;
        } finally { db.endTransaction(); }
    }

    public String sharedThreadTranscript(String shareUrl) {
        SharedThreadState st=sharedThreadByUrl(shareUrl);
        return st==null?"":sharedThreadTranscriptById(helper.getReadableDatabase(),st.id);
    }

    private String sharedThreadTranscriptById(SQLiteDatabase db,long threadId){
        StringBuilder b=new StringBuilder();
        Cursor c=db.rawQuery("SELECT speaker,content FROM shared_counseling_turns WHERE thread_id=? ORDER BY turn_order ASC",new String[]{String.valueOf(threadId)});
        try { while(c.moveToNext()){
            if(b.length()>0)b.append("\n\n");
            b.append("USER".equals(safe(c.getString(0)))?"나의 말: ":"ChatGPT의 말: ");
            b.append(safe(c.getString(1)));
        }} finally {c.close();}
        return b.toString();
    }

    public String sharedPendingAnalysisText(String shareUrl) {
        SharedThreadState st=sharedThreadByUrl(shareUrl);
        if(st==null)return "";
        StringBuilder b=new StringBuilder();
        Cursor c=helper.getReadableDatabase().rawQuery(
                "SELECT speaker,content FROM shared_counseling_turns WHERE thread_id=? AND turn_order>=? ORDER BY turn_order ASC",
                new String[]{String.valueOf(st.id),String.valueOf(Math.max(0,st.analyzedTurnCount))});
        try{while(c.moveToNext()){
            if(b.length()>0)b.append("\n\n");
            b.append("USER".equals(safe(c.getString(0)))?"나의 말: ":"ChatGPT의 말: ").append(safe(c.getString(1)));
        }}finally{c.close();}
        return b.toString();
    }

    public void markSharedThreadAnalysisState(String shareUrl,String state,String error) {
        SharedThreadState st=sharedThreadByUrl(shareUrl); if(st==null)return;
        ContentValues u=new ContentValues(); u.put("analysis_state",safe(state)); u.put("analysis_error",safe(error));
        u.put("analysis_updated_at",System.currentTimeMillis()); u.put("updated_at",System.currentTimeMillis());
        helper.getWritableDatabase().update("shared_counseling_threads",u,"id=?",new String[]{String.valueOf(st.id)});
    }

    public void markSharedThreadAnalysisComplete(String shareUrl) {
        SharedThreadState st=sharedThreadByUrl(shareUrl); if(st==null)return;
        ContentValues u=new ContentValues(); u.put("analysis_state","COMPLETE"); u.put("analysis_error","");
        u.put("analyzed_turn_count",st.turnCount); u.put("analysis_updated_at",System.currentTimeMillis()); u.put("updated_at",System.currentTimeMillis());
        helper.getWritableDatabase().update("shared_counseling_threads",u,"id=?",new String[]{String.valueOf(st.id)});
    }

    public void bindSharedThreadCounseling(String shareUrl,long counselingId){
        SharedThreadState st=sharedThreadByUrl(shareUrl); if(st==null||counselingId<0)return;
        ContentValues u=new ContentValues();u.put("last_counseling_id",counselingId);u.put("updated_at",System.currentTimeMillis());
        helper.getWritableDatabase().update("shared_counseling_threads",u,"id=?",new String[]{String.valueOf(st.id)});
    }

    public String existingProgramContext(long counselingId){
        if(counselingId<0)return "";
        StringBuilder b=new StringBuilder();
        Cursor c=helper.getReadableDatabase().rawQuery("SELECT id,muscle_name,mechanism,priority,reason,status FROM counseling_programs WHERE counseling_id=? ORDER BY priority DESC,id ASC",new String[]{String.valueOf(counselingId)});
        try{while(c.moveToNext()){
            if(b.length()>0)b.append("\n");
            long programId=c.getLong(0);
            b.append("- program_id=").append(programId).append(" | muscle_name=").append(safe(c.getString(1))).append(" | mechanism=").append(safe(c.getString(2)))
                    .append(" | priority=").append(c.getInt(3)).append(" | status=").append(safe(c.getString(5)))
                    .append(" | reason=").append(safe(c.getString(4)))
                    .append(" | outcome_history=").append(programOutcomeContext(programId))
                    .append(" | learning_state=").append(programLearningState(programId));
        }}finally{c.close();}
        return b.toString();
    }


    /** v10.17.4: Compact outcome history for one PT. This is fed back into later analysis/crown decisions. */
    public String programOutcomeContext(long programId){
        if(programId<=0) return "attempts=0";
        SQLiteDatabase db=helper.getReadableDatabase();
        int attempts=0, helped=0, partial=0, noChange=0, worse=0, noOpportunity=0;
        String latest="UNKNOWN"; long latestAt=-1L;
        Cursor c=db.rawQuery(
                "SELECT o.effect,o.created_at FROM training_outcomes o " +
                        "JOIN training_sessions t ON t.id=o.training_id " +
                        "JOIN counseling_program_steps s ON s.id=t.program_step_id " +
                        "WHERE s.program_id=? ORDER BY o.created_at ASC",
                new String[]{String.valueOf(programId)});
        try{
            while(c.moveToNext()){
                String e=safe(c.getString(0)); long at=c.getLong(1); attempts++;
                if("HELPED".equals(e)) helped++;
                else if("PARTIAL".equals(e)) partial++;
                else if("NO_CHANGE".equals(e)) noChange++;
                else if("WORSE".equals(e)) worse++;
                else if("NO_OPPORTUNITY".equals(e)) noOpportunity++;
                if(at>=latestAt){ latestAt=at; latest=e.isEmpty()?"UNKNOWN":e; }
            }
        }finally{c.close();}
        return "attempts="+attempts+",HELPED="+helped+",PARTIAL="+partial+",NO_CHANGE="+noChange+",WORSE="+worse+",NO_OPPORTUNITY="+noOpportunity+",latest="+latest;
    }

    /** v10.17.5: Derived long-term PT learning state. NO_OPPORTUNITY is neutral.
     * This deliberately does not rewrite user history or force DONE; it is a learning signal for UI/crown/next-step decisions. */
    public String programLearningState(long programId){
        if(programId<=0) return "NEW";
        int helped=0, partial=0, noChange=0, worse=0, meaningful=0;
        java.util.ArrayList<String> recent=new java.util.ArrayList<>();
        Cursor c=helper.getReadableDatabase().rawQuery(
                "SELECT o.effect FROM training_outcomes o " +
                        "JOIN training_sessions t ON t.id=o.training_id " +
                        "JOIN counseling_program_steps s ON s.id=t.program_step_id " +
                        "WHERE s.program_id=? ORDER BY o.created_at DESC",
                new String[]{String.valueOf(programId)});
        try{
            while(c.moveToNext()){
                String e=safe(c.getString(0));
                if("NO_OPPORTUNITY".equals(e)) continue;
                meaningful++;
                if(recent.size()<3) recent.add(e);
                if("HELPED".equals(e)) helped++;
                else if("PARTIAL".equals(e)) partial++;
                else if("NO_CHANGE".equals(e)) noChange++;
                else if("WORSE".equals(e)) worse++;
            }
        }finally{c.close();}
        if(meaningful==0) return "NEW";
        if(!recent.isEmpty() && "WORSE".equals(recent.get(0))) return "NEEDS_GENTLER";
        if(worse>=2 && worse>=helped) return "NEEDS_GENTLER";
        boolean recentStable = recent.size()>=2 && "HELPED".equals(recent.get(0)) && "HELPED".equals(recent.get(1));
        if(helped>=3 && recentStable && worse==0 && helped>=partial+noChange+2) return "MASTERY_CANDIDATE";
        if(helped>=2 && helped>partial+noChange+worse) return "STABILIZING";
        if(partial>=2 || helped+partial>=2) return "LEARNING";
        if(noChange>=2) return "NEEDS_REDESIGN";
        return "LEARNING";
    }

    public String programLearningStateDisplay(long programId){
        String s=programLearningState(programId);
        if("MASTERY_CANDIDATE".equals(s)) return "🎓 졸업 후보 · 여러 번 도움됐고 최근에도 안정적으로 해냈어";
        if("STABILIZING".equals(s)) return "🌿 익숙해지는 중 · 도움이 된 경험이 쌓이고 있어";
        if("NEEDS_GENTLER".equals(s)) return "🫶 강도 낮추기 · 최근엔 더 힘들어진 기록을 우선 반영해";
        if("NEEDS_REDESIGN".equals(s)) return "🧩 방식 바꾸기 · 같은 방식 반복보다 과제 재설계가 필요해";
        if("LEARNING".equals(s)) return "🌱 배우는 중 · 아직 연습 근거를 더 쌓는 단계야";
        return "🌱 시작 단계 · 아직 충분한 결과 기록이 없어";
    }

    /** User-facing short outcome summary for PT cards/details. */
    public String programOutcomeDisplay(long programId){
        String raw=programOutcomeContext(programId);
        if(raw.startsWith("attempts=0")) return "";
        java.util.Map<String,String> m=new java.util.LinkedHashMap<>();
        for(String part:raw.split(",")){ int i=part.indexOf('='); if(i>0)m.put(part.substring(0,i),part.substring(i+1)); }
        int attempts=parseIntSafe(m.get("attempts"));
        int helped=parseIntSafe(m.get("HELPED"));
        int partial=parseIntSafe(m.get("PARTIAL"));
        int noChange=parseIntSafe(m.get("NO_CHANGE"));
        int worse=parseIntSafe(m.get("WORSE"));
        int noOpportunity=parseIntSafe(m.get("NO_OPPORTUNITY"));
        String latest=safe(m.get("latest"));
        String latestKo="UNKNOWN".equals(latest)?"아직 없음":"HELPED".equals(latest)?"도움됨":"PARTIAL".equals(latest)?"부분 도움":"NO_CHANGE".equals(latest)?"변화 없음":"WORSE".equals(latest)?"더 힘들어짐":"NO_OPPORTUNITY".equals(latest)?"기회 없음":latest;
        return "총 "+attempts+"회 · 도움 "+helped+" · 부분 "+partial+" · 변화없음 "+noChange+" · 악화 "+worse+" · 기회없음 "+noOpportunity+" · 최근 "+latestKo +
                "\n" + programLearningStateDisplay(programId);
    }

    private int parseIntSafe(String x){ try{return Integer.parseInt(x==null?"0":x);}catch(Exception ignored){return 0;} }

    public void updateCounselingRawText(long counselingId,String fullText,CounselingProgramAnalyzer.Analysis a){
        if(counselingId<0)return;
        ContentValues v=new ContentValues(); v.put("raw_text",safe(fullText));
        if(a!=null){v.put("title",emptyTo(a.title,"상담 완전판 공유링크"));v.put("current_concern",a.currentConcern);v.put("formulation",a.formulation);v.put("priority_direction",a.priorityDirection);v.put("caution",a.caution);}
        helper.getWritableDatabase().update("counseling_entries",v,"id=?",new String[]{String.valueOf(counselingId)});
    }



    /** v10.16.4: Set one canonical crown by stable program ID without asking the model to rewrite all priorities. */
    public int setCrownProgramById(long counselingId, long crownProgramId){
        if(counselingId<0 || crownProgramId<=0 || !isUsableProgram(crownProgramId,counselingId)) return 0;
        SQLiteDatabase db=helper.getWritableDatabase(); int changed=0;
        db.beginTransaction();
        try{
            ContentValues lower=new ContentValues(); lower.put("priority",99);
            changed += db.update("counseling_programs",lower,"counseling_id=? AND status!='MERGED' AND id<>? AND priority>=100",new String[]{String.valueOf(counselingId),String.valueOf(crownProgramId)});
            ContentValues crown=new ContentValues(); crown.put("priority",100);
            changed += db.update("counseling_programs",crown,"id=? AND counseling_id=? AND status!='MERGED'",new String[]{String.valueOf(crownProgramId),String.valueOf(counselingId)});
            db.setTransactionSuccessful();
        }finally{db.endTransaction();}
        appContext.getSharedPreferences(STATE_PREFS, Context.MODE_PRIVATE).edit()
                .putLong(PREF_CROWN_PROGRAM_ID,crownProgramId).putLong(PREF_CROWN_COUNSELING_ID,counselingId).apply();
        syncCrownProgramId(counselingId);
        return changed;
    }

    /** v10.16.3: Apply crown-only priorities by stable program ID. PT content and steps are untouched. */
    public int applyProgramPrioritiesById(long counselingId, java.util.Map<Long,Integer> priorities, long crownProgramId){
        if(counselingId<0 || priorities==null || priorities.isEmpty()) return 0;
        SQLiteDatabase db=helper.getWritableDatabase(); int changed=0;
        db.beginTransaction();
        try{
            for(java.util.Map.Entry<Long,Integer> e:priorities.entrySet()){
                long id=e.getKey()==null?-1L:e.getKey(); if(id<=0) continue;
                int score=Math.max(1,Math.min(100,e.getValue()==null?50:e.getValue()));
                // Keep crown unique even if the model returned a tie.
                if(id==crownProgramId) score=100; else if(score>=100) score=99;
                ContentValues u=new ContentValues(); u.put("priority",score);
                changed += db.update("counseling_programs",u,"id=? AND counseling_id=? AND status!='MERGED'",new String[]{String.valueOf(id),String.valueOf(counselingId)});
            }
            db.setTransactionSuccessful();
        }finally{db.endTransaction();}
        cleanupExactDuplicatePrograms(counselingId);
        syncCrownProgramId(counselingId);
        return changed;
    }

    /** v10.12.1: Apply crown re-ranking without modifying PT contents or steps. */
    public int applyProgramPriorities(long counselingId, java.util.Map<String,Integer> priorities){
        if(counselingId<0 || priorities==null || priorities.isEmpty()) return 0;
        SQLiteDatabase db=helper.getWritableDatabase(); int changed=0;
        for(java.util.Map.Entry<String,Integer> e:priorities.entrySet()){
            String muscle=safe(e.getKey()).trim(); if(muscle.isEmpty()) continue;
            ContentValues u=new ContentValues(); u.put("priority", Math.max(1,Math.min(100,e.getValue()==null?50:e.getValue())));
            changed += db.update("counseling_programs",u,"counseling_id=? AND status!='MERGED' AND lower(trim(muscle_name))=lower(trim(?))",new String[]{String.valueOf(counselingId),muscle});
        }
        cleanupExactDuplicatePrograms(counselingId);
        syncCrownProgramId(counselingId);
        return changed;
    }


    /** v10.15.2: apply crown priorities and merge semantic-duplicate PT cards into one canonical learning axis. */
    public int applyProgramPrioritiesAndSemanticMerges(long counselingId, java.util.Map<String,Integer> priorities, java.util.Map<String,String> mergeInto){
        int changed=applyProgramPriorities(counselingId, priorities);
        if(counselingId<0 || mergeInto==null || mergeInto.isEmpty()) return changed;
        SQLiteDatabase db=helper.getWritableDatabase(); int merged=0;
        for(java.util.Map.Entry<String,String> e:mergeInto.entrySet()){
            String source=safe(e.getKey()).trim(), target=safe(e.getValue()).trim();
            if(source.isEmpty()||target.isEmpty()||source.equalsIgnoreCase(target)) continue;
            long sourceId=findProgramIdByMuscle(db,counselingId,source);
            long targetId=findProgramIdByMuscle(db,counselingId,target);
            if(sourceId<=0||targetId<=0||sourceId==targetId) continue;
            absorbOneDistinctStep(db,sourceId,targetId);
            markProgramMerged(db,sourceId);
            merged++;
        }
        cleanupExactDuplicatePrograms(counselingId);
        syncCrownProgramId(counselingId);
        return changed+merged;
    }

    private long findProgramIdByMuscle(SQLiteDatabase db,long counselingId,String muscle){
        Cursor c=db.rawQuery("SELECT id FROM counseling_programs WHERE counseling_id=? AND status!='MERGED' AND lower(trim(muscle_name))=lower(trim(?)) ORDER BY priority DESC,id ASC LIMIT 1",new String[]{String.valueOf(counselingId),muscle});
        try{return c.moveToFirst()?c.getLong(0):-1;}finally{c.close();}
    }

    private void absorbOneDistinctStep(SQLiteDatabase db,long sourceId,long targetId){
        int targetCount=0,maxOrder=0;
        Cursor tc=db.rawQuery("SELECT COUNT(*),COALESCE(MAX(step_order),0) FROM counseling_program_steps WHERE program_id=?",new String[]{String.valueOf(targetId)});
        try{if(tc.moveToFirst()){targetCount=tc.getInt(0);maxOrder=tc.getInt(1);}}finally{tc.close();}
        if(targetCount>=3)return;
        Cursor sc=db.rawQuery("SELECT mode,exercise_type,exercise_text,success_criterion,rationale,difficulty FROM counseling_program_steps WHERE program_id=? ORDER BY step_order ASC",new String[]{String.valueOf(sourceId)});
        try{
            while(sc.moveToNext()){
                String ex=safe(sc.getString(2)); if(ex.trim().isEmpty()) continue;
                Cursor dup=db.rawQuery("SELECT 1 FROM counseling_program_steps WHERE program_id=? AND lower(trim(exercise_text))=lower(trim(?)) LIMIT 1",new String[]{String.valueOf(targetId),ex});
                boolean exists; try{exists=dup.moveToFirst();}finally{dup.close();}
                if(exists) continue;
                ContentValues v=new ContentValues();
                v.put("program_id",targetId); v.put("step_order",Math.min(3,maxOrder+1)); v.put("mode",safe(sc.getString(0))); v.put("exercise_type",safe(sc.getString(1)));
                v.put("exercise_text",ex); v.put("success_criterion",safe(sc.getString(3))); v.put("rationale",safe(sc.getString(4))); v.put("difficulty",sc.getInt(5));
                v.put("status","PENDING"); v.put("created_at",System.currentTimeMillis()); db.insert("counseling_program_steps",null,v); break;
            }
        }finally{sc.close();}
    }

    public int mergeIncrementalPrograms(long counselingId, CounselingProgramAnalyzer.Analysis analysis){
        if(counselingId<0||analysis==null)return 0;
        SQLiteDatabase db=helper.getWritableDatabase(); int changed=0; long now=System.currentTimeMillis();
        for(CounselingProgramAnalyzer.Program p:analysis.programs){
            long existingId=-1;
            Cursor c=db.rawQuery("SELECT id FROM counseling_programs WHERE counseling_id=? AND status!='MERGED' AND lower(trim(muscle_name))=lower(trim(?)) LIMIT 1",new String[]{String.valueOf(counselingId),safe(p.muscleName)});
            try{if(c.moveToFirst())existingId=c.getLong(0);}finally{c.close();}
            if(existingId>0){
                ContentValues u=new ContentValues();u.put("name",p.name);u.put("mechanism",p.mechanism);u.put("priority",p.priority);u.put("reason",p.reason);
                db.update("counseling_programs",u,"id=?",new String[]{String.valueOf(existingId)}); changed++;
            }else{
                ContentValues pv=new ContentValues();pv.put("counseling_id",counselingId);pv.put("name",p.name);pv.put("mechanism",p.mechanism);pv.put("muscle_name",p.muscleName);pv.put("priority",p.priority);pv.put("reason",p.reason);pv.put("status","PENDING");pv.put("created_at",now);
                long pid=db.insertOrThrow("counseling_programs",null,pv);
                for(CounselingProgramAnalyzer.Step st:p.steps){ContentValues sv=new ContentValues();sv.put("program_id",pid);sv.put("step_order",st.order);sv.put("mode",st.mode);sv.put("exercise_type",st.exerciseType);sv.put("exercise_text",st.exerciseText);sv.put("success_criterion",st.successCriterion);sv.put("rationale",st.rationale);sv.put("difficulty",st.difficulty);sv.put("status","PENDING");sv.put("created_at",now);db.insertOrThrow("counseling_program_steps",null,sv);} changed++;
            }
        }
        cleanupExactDuplicatePrograms(counselingId);
        syncCrownProgramId(counselingId);
        return changed;
    }

    /** v10.16.2: refine step text/criteria in place so ACTIVE/DONE progress is preserved. */
    public int applyProgramStepRefinements(long counselingId, CounselingProgramAnalyzer.Analysis refinement){
        if(counselingId<0 || refinement==null || refinement.programs==null || refinement.programs.isEmpty()) return 0;
        SQLiteDatabase db=helper.getWritableDatabase(); int changed=0; long now=System.currentTimeMillis();
        for(CounselingProgramAnalyzer.Program p:refinement.programs){
            if(p==null || safe(p.muscleName).trim().isEmpty() || p.steps==null || p.steps.isEmpty()) continue;
            long programId=findProgramIdByMuscle(db,counselingId,safe(p.muscleName));
            if(programId<=0) continue;
            ContentValues pu=new ContentValues();
            if(!safe(p.name).trim().isEmpty()) pu.put("name",p.name);
            if(!safe(p.mechanism).trim().isEmpty()) pu.put("mechanism",p.mechanism);
            if(!safe(p.reason).trim().isEmpty()) pu.put("reason",p.reason);
            if(pu.size()>0) db.update("counseling_programs",pu,"id=?",new String[]{String.valueOf(programId)});
            java.util.HashSet<Integer> seen=new java.util.HashSet<>();
            for(CounselingProgramAnalyzer.Step st:p.steps){
                if(st==null) continue; int ord=Math.max(1,Math.min(4,st.order)); if(!seen.add(ord)) continue;
                Cursor c=db.rawQuery("SELECT id,status FROM counseling_program_steps WHERE program_id=? AND step_order=? ORDER BY id ASC LIMIT 1",new String[]{String.valueOf(programId),String.valueOf(ord)});
                long stepId=-1; String status="PENDING"; try{if(c.moveToFirst()){stepId=c.getLong(0);status=safe(c.getString(1));}}finally{c.close();}
                ContentValues sv=new ContentValues();
                sv.put("mode",safe(st.mode)); sv.put("exercise_type",safe(st.exerciseType)); sv.put("exercise_text",safe(st.exerciseText));
                sv.put("success_criterion",safe(st.successCriterion)); sv.put("rationale",safe(st.rationale)); sv.put("difficulty",Math.max(1,Math.min(3,st.difficulty)));
                if(stepId>0){
                    // Never reset progress status. Only improve the content shown for the same numbered step.
                    changed += db.update("counseling_program_steps",sv,"id=?",new String[]{String.valueOf(stepId)});
                }else{
                    sv.put("program_id",programId); sv.put("step_order",ord); sv.put("status",status.isEmpty()?"PENDING":status); sv.put("created_at",now);
                    if(db.insert("counseling_program_steps",null,sv)>0) changed++;
                }
            }
        }
        syncCrownProgramId(counselingId);
        return changed;
    }


    /** v10.17.2: Long-form roadmap so the user can see how the same PT deepens across steps. */
    public String programRoadmap(long programId) {
        if (programId <= 0) return "";
        Cursor c = helper.getReadableDatabase().rawQuery(
                "SELECT step_order,status,exercise_text,success_criterion,rationale,difficulty FROM counseling_program_steps WHERE program_id=? ORDER BY step_order ASC,id ASC",
                new String[]{String.valueOf(programId)});
        StringBuilder b = new StringBuilder();
        try {
            while (c.moveToNext()) {
                int order = c.getInt(0);
                String status = safe(c.getString(1));
                String exercise = safe(c.getString(2)).trim();
                String criterion = safe(c.getString(3)).trim();
                String rationale = safe(c.getString(4)).trim();
                int difficulty = c.isNull(5) ? order : c.getInt(5);
                if (exercise.isEmpty()) continue;
                if (b.length() > 0) b.append("\n\n");
                String icon = "DONE".equals(status) ? "✅" : ("ACTIVE".equals(status) || "RETRY".equals(status) ? "👉" : "▫️");
                b.append(icon).append(" ").append(order).append("단계");
                if (difficulty > 0) b.append(" · 난이도 ").append(Math.max(1, Math.min(3, difficulty)));
                b.append("\n").append(exercise);
                if (!criterion.isEmpty()) b.append("\n성공 기준: ").append(criterion);
                if (!rationale.isEmpty()) b.append("\n왜 다음으로 이어져? ").append(rationale);
            }
        } finally { c.close(); }
        return b.toString();
    }

    /** v10.15.1: exact duplicate cleanup + one canonical crown PT id. */
    public long crownProgramId(long counselingId) {
        if (counselingId < 0) return -1;
        long storedCounseling = appContext.getSharedPreferences(STATE_PREFS, Context.MODE_PRIVATE)
                .getLong(PREF_CROWN_COUNSELING_ID, -1L);
        long storedProgram = appContext.getSharedPreferences(STATE_PREFS, Context.MODE_PRIVATE)
                .getLong(PREF_CROWN_PROGRAM_ID, -1L);
        if (storedCounseling == counselingId && isUsableProgram(storedProgram, counselingId)) return storedProgram;
        return syncCrownProgramId(counselingId);
    }

    private boolean isUsableProgram(long programId, long counselingId) {
        if (programId <= 0) return false;
        Cursor c = helper.getReadableDatabase().rawQuery(
                "SELECT 1 FROM counseling_programs WHERE id=? AND counseling_id=? AND status!='MERGED' LIMIT 1",
                new String[]{String.valueOf(programId), String.valueOf(counselingId)});
        try { return c.moveToFirst(); } finally { c.close(); }
    }

    public long syncCrownProgramId(long counselingId) {
        if (counselingId < 0) return -1;
        cleanupExactDuplicatePrograms(counselingId);
        SQLiteDatabase db = helper.getWritableDatabase();
        Cursor c = db.rawQuery(
                "SELECT p.id,p.muscle_name,p.priority,s.exercise_text,s.success_criterion " +
                        "FROM counseling_programs p LEFT JOIN counseling_program_steps s " +
                        "ON s.program_id=p.id AND s.step_order=(SELECT MIN(s2.step_order) FROM counseling_program_steps s2 WHERE s2.program_id=p.id) " +
                        "WHERE p.counseling_id=? AND p.status!='MERGED' " +
                        "ORDER BY p.priority DESC,p.id ASC LIMIT 1",
                new String[]{String.valueOf(counselingId)});
        try {
            if (!c.moveToFirst()) return -1;
            long id = c.getLong(0);
            String muscle = safe(c.getString(1));
            String exercise = c.isNull(3) ? "" : safe(c.getString(3));
            String criterion = c.isNull(4) ? "" : safe(c.getString(4));
            appContext.getSharedPreferences(STATE_PREFS, Context.MODE_PRIVATE).edit()
                    .putLong(PREF_CROWN_PROGRAM_ID, id)
                    .putLong(PREF_CROWN_COUNSELING_ID, counselingId)
                    .apply();
            ContentValues entry = new ContentValues();
            entry.put("muscle_name", muscle);
            entry.put("training_text", exercise);
            entry.put("success_criterion", criterion);
            db.update("counseling_entries", entry, "id=?", new String[]{String.valueOf(counselingId)});
            return id;
        } finally { c.close(); }
    }

    private long ensureCrownProgramId(long counselingId) {
        return crownProgramId(counselingId);
    }

    public int cleanupExactDuplicatePrograms(long counselingId) {
        if (counselingId < 0) return 0;
        SQLiteDatabase db = helper.getWritableDatabase();
        long activeProgramId = -1;
        Cursor active = db.rawQuery(
                "SELECT s.program_id FROM training_sessions t JOIN counseling_program_steps s ON s.id=t.program_step_id " +
                        "WHERE t.completed_at IS NULL AND t.superseded_at IS NULL ORDER BY t.created_at DESC LIMIT 1", null);
        try { if (active.moveToFirst()) activeProgramId = active.getLong(0); } finally { active.close(); }

        java.util.LinkedHashMap<String, Long> canonical = new java.util.LinkedHashMap<>();
        java.util.LinkedHashMap<String, Integer> canonicalPriority = new java.util.LinkedHashMap<>();
        int merged = 0;
        Cursor c = db.rawQuery(
                "SELECT id,muscle_name,priority FROM counseling_programs WHERE counseling_id=? AND status!='MERGED' ORDER BY priority DESC,id ASC",
                new String[]{String.valueOf(counselingId)});
        try {
            while (c.moveToNext()) {
                long id = c.getLong(0);
                String key = normalizeMuscleKey(c.getString(1));
                int priority = c.getInt(2);
                if (key.isEmpty()) key = "id:" + id;
                Long keep = canonical.get(key);
                if (keep == null) { canonical.put(key, id); canonicalPriority.put(key, priority); continue; }
                long keepId = keep;
                if (id == activeProgramId && keepId != activeProgramId) {
                    markProgramMerged(db, keepId);
                    canonical.put(key, id);
                    canonicalPriority.put(key, priority);
                    merged++;
                } else {
                    markProgramMerged(db, id);
                    merged++;
                }
            }
        } finally { c.close(); }
        return merged;
    }

    private static void markProgramMerged(SQLiteDatabase db, long id) {
        ContentValues u = new ContentValues();
        u.put("status", "MERGED");
        db.update("counseling_programs", u, "id=?", new String[]{String.valueOf(id)});
    }

    public static String sharedTurnHashForBlock(String rawBlock){ParsedSharedBlock pb=parseSharedBlock(rawBlock);return sharedTurnHash(pb.speaker,pb.content);}
    private static final class ParsedSharedBlock{String speaker="ASSISTANT";String content="";}
    private static ParsedSharedBlock parseSharedBlock(String raw){
        ParsedSharedBlock p=new ParsedSharedBlock(); String x=raw==null?"":raw.trim(); if(x.isEmpty())return p;
        int nl=x.indexOf('\n'); String role=nl>=0?x.substring(0,nl).trim().toLowerCase():""; String content=nl>=0?x.substring(nl+1).trim():x;
        if("user".equals(role)||"나".equals(role)||"USER".equals(role))p.speaker="USER"; else p.speaker="ASSISTANT";
        p.content=content; return p;
    }
    private static String sharedTurnHash(String speaker,String content){
        String normalized=(safeStatic(speaker)+"\n"+safeStatic(content).replace("\r","").replaceAll("[ \\t]+"," ").replaceAll("\\n{3,}","\\n\\n").trim());
        try{MessageDigest md=MessageDigest.getInstance("SHA-256");byte[] d=md.digest(normalized.getBytes(StandardCharsets.UTF_8));StringBuilder b=new StringBuilder();for(byte z:d)b.append(String.format("%02x",z&0xff));return b.toString();}catch(Exception e){return Integer.toHexString(normalized.hashCode())+":"+normalized.length();}
    }
    private static String normalizeMuscleKey(String s) {
        String x = safeStatic(s).toLowerCase(java.util.Locale.KOREA).replaceAll("[^0-9a-z가-힣]", "");
        return x.replace("마음pt", "").replace("pt", "").trim();
    }

    private static String safeStatic(String s){return s==null?"":s;}


    public CounselingSyncSession activeSyncSession() {
        SQLiteDatabase db = helper.getReadableDatabase();
        Cursor c = db.rawQuery(
                "SELECT s.id,s.title,s.status,s.created_at,s.updated_at," +
                        "COUNT(c.id),COALESCE(SUM(LENGTH(c.content)),0) " +
                        "FROM counseling_sync_sessions s LEFT JOIN counseling_sync_chunks c ON c.session_id=s.id " +
                        "WHERE s.status='ACTIVE' GROUP BY s.id ORDER BY s.updated_at DESC LIMIT 1", null);
        try {
            if (!c.moveToFirst()) return null;
            CounselingSyncSession out = new CounselingSyncSession();
            out.id = c.getLong(0);
            out.title = safe(c.getString(1));
            out.status = safe(c.getString(2));
            out.createdAt = c.getLong(3);
            out.updatedAt = c.getLong(4);
            out.chunkCount = c.getInt(5);
            out.charCount = c.getInt(6);
            return out;
        } finally { c.close(); }
    }

    public long getOrCreateActiveSyncSession() {
        CounselingSyncSession current = activeSyncSession();
        if (current != null) return current.id;
        long now = System.currentTimeMillis();
        ContentValues v = new ContentValues();
        v.put("title", "상담 완전판 · 진행 중");
        v.put("status", "ACTIVE");
        v.put("created_at", now);
        v.put("updated_at", now);
        return helper.getWritableDatabase().insertOrThrow("counseling_sync_sessions", null, v);
    }

    public boolean appendSyncChunk(long sessionId, String speaker, String content) {
        String cleanContent = content == null ? "" : content.trim();
        if (sessionId < 0 || cleanContent.isEmpty()) return false;
        String cleanSpeaker = "USER".equals(speaker) ? "USER" : "ASSISTANT";
        String key = Integer.toHexString(cleanContent.hashCode()) + ":" + cleanContent.length();
        SQLiteDatabase db = helper.getWritableDatabase();
        ContentValues v = new ContentValues();
        v.put("session_id", sessionId);
        v.put("speaker", cleanSpeaker);
        v.put("content", cleanContent);
        v.put("content_key", key);
        v.put("created_at", System.currentTimeMillis());
        long id = db.insertWithOnConflict("counseling_sync_chunks", null, v, SQLiteDatabase.CONFLICT_IGNORE);
        if (id == -1) return false;
        ContentValues u = new ContentValues();
        u.put("updated_at", System.currentTimeMillis());
        db.update("counseling_sync_sessions", u, "id=?", new String[]{String.valueOf(sessionId)});
        return true;
    }

    public List<CounselingSyncChunk> syncChunks(long sessionId) {
        List<CounselingSyncChunk> out = new ArrayList<>();
        Cursor c = helper.getReadableDatabase().rawQuery(
                "SELECT id,session_id,speaker,content,created_at FROM counseling_sync_chunks WHERE session_id=? ORDER BY id ASC",
                new String[]{String.valueOf(sessionId)});
        try {
            while (c.moveToNext()) {
                CounselingSyncChunk x = new CounselingSyncChunk();
                x.id = c.getLong(0); x.sessionId = c.getLong(1); x.speaker = safe(c.getString(2));
                x.content = safe(c.getString(3)); x.createdAt = c.getLong(4); out.add(x);
            }
        } finally { c.close(); }
        return out;
    }

    public long finalizeActiveSyncSession() {
        CounselingSyncSession session = activeSyncSession();
        if (session == null || session.chunkCount <= 0) return -1;
        List<CounselingSyncChunk> chunks = syncChunks(session.id);
        StringBuilder raw = new StringBuilder();
        for (CounselingSyncChunk chunk : chunks) {
            if (raw.length() > 0) raw.append("\n\n");
            raw.append("USER".equals(chunk.speaker) ? "나의 말: " : "ChatGPT의 말: ");
            raw.append(chunk.content);
        }
        long counselingId = saveCounselingImport(raw.toString());
        ContentValues u = new ContentValues();
        u.put("status", "COMPLETED");
        u.put("updated_at", System.currentTimeMillis());
        u.put("completed_at", System.currentTimeMillis());
        helper.getWritableDatabase().update("counseling_sync_sessions", u, "id=?", new String[]{String.valueOf(session.id)});
        return counselingId;
    }

    public void discardActiveSyncSession() {
        CounselingSyncSession session = activeSyncSession();
        if (session == null) return;
        SQLiteDatabase db = helper.getWritableDatabase();
        db.delete("counseling_sync_chunks", "session_id=?", new String[]{String.valueOf(session.id)});
        db.delete("counseling_sync_sessions", "id=?", new String[]{String.valueOf(session.id)});
    }

    private static String previewTurn(String s) {
        String x=safe(s).replace('\n',' ').replace('\r',' ').trim();
        if (x.length() <= 96) return x;
        return x.substring(0, 95).trim() + "…";
    }

    private static String safe(String s) { return s == null ? "" : s; }
    private static String emptyTo(String s, String fallback) { return s == null || s.trim().isEmpty() ? fallback : s.trim(); }
}
