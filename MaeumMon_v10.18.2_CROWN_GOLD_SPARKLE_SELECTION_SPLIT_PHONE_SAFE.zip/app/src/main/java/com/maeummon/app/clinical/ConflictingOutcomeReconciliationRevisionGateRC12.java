package com.maeummon.app.clinical;

import android.content.Context;
import org.json.*;

public final class ConflictingOutcomeReconciliationRevisionGateRC12 {
    private ConflictingOutcomeReconciliationRevisionGateRC12(){}

    public enum State {
        NONE,
        REVIEW_REQUIRED,
        REVISION_PENDING_CONFIRMATION,
        REVISION_APPLIED,
        REVISION_REJECTED
    }

    public static final class Result {
        public boolean evaluated=false;
        public boolean reviewRequired=false;
        public boolean revisionApplied=false;
        public boolean revisionRejected=false;
        public State state=State.NONE;
        public String experimentId="";
        public String priorOutcome="";
        public String proposedOutcome="";
        public String finalOutcome="";
        public String question="";
        public String reason="";
        public String summary="";
    }

    public static Result evaluate(
            Context c,
            ClinicalDecisionRC7 d,
            String userText){

        Result r=new Result();
        if(c==null||d==null){
            r.summary="NONE | NO_CONTEXT_OR_DECISION";
            return r;
        }

        JSONObject s=CentralTherapyProfile.loadSessionState(c);
        JSONObject p=CentralTherapyProfile.loadProfile(c);

        // Continue an already pending revision first.
        if(s.optBoolean("pending_outcome_revision_confirmation",false)){
            return resolvePending(c,d,userText,s,p);
        }

        if(!d.outcomeCommitConflictingDuplicate
                || !"CONFLICTING_DUPLICATE_BLOCKED"
                        .equals(d.outcomeCommitIdempotencyState)){

            r.summary="NONE | NO_CONFLICTING_DUPLICATE";
            return r;
        }

        r.evaluated=true;
        r.reviewRequired=true;
        r.state=State.REVIEW_REQUIRED;
        r.experimentId=safe(d.outcomeCommitExperimentId);
        r.proposedOutcome=safe(d.outcomeCommitValue);
        r.priorOutcome=findPriorOutcome(
                p.optJSONArray("outcome_commit_idempotency_history"),
                r.experimentId);

        r.finalOutcome=r.priorOutcome;
        r.question=buildReviewQuestion(
                r.priorOutcome,r.proposedOutcome);

        r.reason="SAME_EXPERIMENT_CONFLICT_REQUIRES_EXPLICIT_REVISION_REVIEW";

        try{
            s.put("pending_outcome_revision_confirmation",true);
            s.put("pending_outcome_revision_experiment_id",r.experimentId);
            s.put("pending_outcome_revision_prior",r.priorOutcome);
            s.put("pending_outcome_revision_proposed",r.proposedOutcome);
            s.put("pending_outcome_revision_question",r.question);
            s.put("pending_outcome_revision_started_at",
                    System.currentTimeMillis());
            CentralTherapyProfile.replaceSessionState(c,s);
        }catch(Exception ignored){}

        return finish(r);
    }

    private static Result resolvePending(
            Context c,
            ClinicalDecisionRC7 d,
            String userText,
            JSONObject s,
            JSONObject p){

        Result r=new Result();
        r.evaluated=true;
        r.experimentId=s.optString(
                "pending_outcome_revision_experiment_id","");
        r.priorOutcome=s.optString(
                "pending_outcome_revision_prior","");
        r.proposedOutcome=s.optString(
                "pending_outcome_revision_proposed","");
        r.finalOutcome=r.priorOutcome;

        String resolution=detectResolution(userText);

        if("CONFIRM_REVISION".equals(resolution)){
            r.state=State.REVISION_APPLIED;
            r.revisionApplied=true;
            r.finalOutcome=r.proposedOutcome;
            r.reason="USER_CONFIRMED_OUTCOME_REVISION";

            appendRevisionHistory(c,p,r,userText);
            clearPending(c,s,"APPLIED");
            markFormulationReopen(c,d,r);
            return finish(r);
        }

        if("KEEP_PRIOR".equals(resolution)){
            r.state=State.REVISION_REJECTED;
            r.revisionRejected=true;
            r.finalOutcome=r.priorOutcome;
            r.reason="USER_REJECTED_REVISION_KEEP_PRIOR";

            appendRevisionHistory(c,p,r,userText);
            clearPending(c,s,"REJECTED");
            return finish(r);
        }

        r.state=State.REVISION_PENDING_CONFIRMATION;
        r.reviewRequired=true;
        r.question=buildReviewQuestion(
                r.priorOutcome,r.proposedOutcome);
        r.reason="REVISION_CONFIRMATION_STILL_NEEDED";
        return finish(r);
    }

    public static String instruction(Result r){
        if(r==null||!r.evaluated)return "";

        if(r.state==State.REVIEW_REQUIRED
                ||r.state==State.REVISION_PENDING_CONFIRMATION){

            return "OUTCOME_REVISION_REVIEW_REQUIRED=true. 새로운 intervention을 시작하지 말고 아래 확인 질문 1개만 한다: "
                    +r.question
                    +" 확인 전에는 기존 outcome commit과 policy learning을 수정하지 않는다.";
        }

        if(r.state==State.REVISION_APPLIED){
            return "OUTCOME_REVISION=APPLIED. 기존 commit을 삭제하지 않고 revision history를 남긴 채 새 outcome을 현재 기준으로 채택하고 formulation을 다시 연다.";
        }

        if(r.state==State.REVISION_REJECTED){
            return "OUTCOME_REVISION=REJECTED. 기존 outcome commit을 유지하고 새 conflicting outcome은 학습하지 않는다.";
        }

        return "";
    }

    public static boolean shouldForceReview(Result r){
        return r!=null
                && r.evaluated
                && (r.state==State.REVIEW_REQUIRED
                    ||r.state==State.REVISION_PENDING_CONFIRMATION);
    }

    public static boolean shouldReopenFormulation(Result r){
        return r!=null
                && r.state==State.REVISION_APPLIED;
    }

    private static String buildReviewQuestion(
            String prior,String proposed){

        return "같은 실험을 두고 전에 '"+label(prior)
                +"'라고 했는데 지금은 '"+label(proposed)
                +"' 쪽으로 들려. 이전 평가를 수정하는 게 맞아?";
    }

    private static String detectResolution(String userText){
        String u=userText==null?"":userText.trim();

        if(containsAny(u,
                "응 수정","맞아 수정","수정하는 게 맞",
                "지금 평가가 맞","전보다 지금이 맞",
                "아까는 잘못 말","이전 평가 바꿔"))
            return "CONFIRM_REVISION";

        if(containsAny(u,
                "아니 수정 아니","기존이 맞","전 평가가 맞",
                "그대로 둬","바꾸지 마","지금 말은 다른 얘기"))
            return "KEEP_PRIOR";

        return "";
    }

    private static String findPriorOutcome(
            JSONArray h,String experimentId){

        if(h==null||experimentId==null||experimentId.isEmpty())
            return "UNKNOWN";

        for(int i=h.length()-1;i>=0;i--){
            JSONObject x=h.optJSONObject(i);
            if(x==null)continue;

            if(experimentId.equals(
                    x.optString("experiment_id","")))
                return x.optString("outcome","UNKNOWN");
        }

        return "UNKNOWN";
    }

    private static void appendRevisionHistory(
            Context c,
            JSONObject p,
            Result r,
            String userText){

        try{
            JSONArray h=p.optJSONArray(
                    "outcome_commit_revision_history");
            if(h==null)h=new JSONArray();

            JSONObject item=new JSONObject();
            item.put("experiment_id",r.experimentId);
            item.put("prior_outcome",r.priorOutcome);
            item.put("proposed_outcome",r.proposedOutcome);
            item.put("final_outcome",r.finalOutcome);
            item.put("state",r.state.name());
            item.put("evidence",compact(userText,300));
            item.put("time",System.currentTimeMillis());
            h.put(item);

            JSONArray trimmed=new JSONArray();
            int start=Math.max(0,h.length()-30);
            for(int i=start;i<h.length();i++)
                trimmed.put(h.opt(i));

            p.put("outcome_commit_revision_history",trimmed);
            p.put("last_outcome_revision_experiment_id",r.experimentId);
            p.put("last_outcome_revision_state",r.state.name());
            p.put("last_outcome_revision_final",r.finalOutcome);
            p.put("last_outcome_revision_at",
                    System.currentTimeMillis());

            CentralTherapyProfile.replaceProfile(c,p);
        }catch(Exception ignored){}
    }

    private static void clearPending(
            Context c,
            JSONObject s,
            String resolution){

        try{
            s.put("pending_outcome_revision_confirmation",false);
            s.put("last_outcome_revision_resolution",resolution);
            s.put("last_outcome_revision_resolution_at",
                    System.currentTimeMillis());
            s.remove("pending_outcome_revision_experiment_id");
            s.remove("pending_outcome_revision_prior");
            s.remove("pending_outcome_revision_proposed");
            s.remove("pending_outcome_revision_question");
            CentralTherapyProfile.replaceSessionState(c,s);
        }catch(Exception ignored){}
    }

    private static void markFormulationReopen(
            Context c,
            ClinicalDecisionRC7 d,
            Result r){

        try{
            JSONObject f=CentralTherapyProfile.loadFormulation(c);
            f.put("formulation_reopened",true);
            f.put("formulation_reopen_reason",
                    "OUTCOME_COMMIT_REVISION");
            f.put("outcome_revision_experiment_id",
                    r.experimentId);
            f.put("outcome_revision_prior",
                    r.priorOutcome);
            f.put("outcome_revision_final",
                    r.finalOutcome);
            f.put("outcome_revision_at",
                    System.currentTimeMillis());
            CentralTherapyProfile.replaceFormulation(c,f);
        }catch(Exception ignored){}
    }

    private static String label(String o){
        if("HELPED".equals(o))return "도움됐어";
        if("PARTIAL".equals(o))return "조금 도움됐어";
        if("NO_CHANGE".equals(o))return "변화 없었어";
        if("WORSE".equals(o))return "더 안 좋아졌어";
        if("NOT_TRIED".equals(o))return "아직 안 해봤어";
        return "잘 모르겠어";
    }

    private static boolean containsAny(String s,String... xs){
        if(s==null)return false;
        for(String x:xs)
            if(x!=null&&!x.isEmpty()&&s.contains(x))
                return true;
        return false;
    }

    private static String compact(String s,int max){
        s=s==null?"":s.trim();
        return s.length()<=max?s:s.substring(0,max);
    }

    private static Result finish(Result r){
        r.summary=r.state.name()
                +" | experiment="+r.experimentId
                +" | prior="+r.priorOutcome
                +" | proposed="+r.proposedOutcome
                +" | final="+r.finalOutcome
                +" | reviewRequired="+r.reviewRequired
                +" | reason="+r.reason;
        return r;
    }

    private static String safe(String s){
        return s==null?"":s;
    }
}
