package com.maeummon.app.clinical;

import android.content.Context;
import org.json.*;

public final class PolicyMemoryDecayContradictionDemotionRC11 {
    private PolicyMemoryDecayContradictionDemotionRC11(){}

    public enum Status {
        ACTIVE,
        DEMOTED,
        RETIRED
    }

    public static final class Result {
        public boolean evaluated=false;
        public boolean changed=false;
        public Status status=Status.ACTIVE;
        public String oldConfidence="NONE";
        public String newConfidence="NONE";
        public int recentPositive=0;
        public int recentNegative=0;
        public long ageDays=0;
        public boolean stale=false;
        public boolean contradicted=false;
        public String reason="";
        public String summary="";
    }

    public static Result evaluate(
            Context c,ClinicalDecisionRC7 d){

        Result r=new Result();
        if(c==null||d==null){
            r.summary="NO_EVALUATION | NO_CONTEXT_OR_DECISION";
            return r;
        }

        JSONObject p=CentralTherapyProfile.loadProfile(c);
        JSONArray policies=p.optJSONArray("intervention_policy_memory");
        if(policies==null||policies.length()==0){
            r.summary="NO_EVALUATION | NO_POLICY_MEMORY";
            return r;
        }

        String key=safe(d.policyRetrievalKey);
        if(key.isEmpty())
            key=p.optString("last_intervention_policy_key","");

        if(key.isEmpty()){
            r.summary="NO_EVALUATION | NO_POLICY_KEY";
            return r;
        }

        JSONObject policy=null;
        int policyIndex=-1;
        for(int i=0;i<policies.length();i++){
            JSONObject x=policies.optJSONObject(i);
            if(x!=null&&key.equals(x.optString("key",""))){
                policy=x;
                policyIndex=i;
                break;
            }
        }

        if(policy==null){
            r.summary="NO_EVALUATION | POLICY_NOT_FOUND";
            return r;
        }

        r.evaluated=true;
        r.oldConfidence=policy.optString("confidence","LOW");
        r.newConfidence=r.oldConfidence;

        long now=System.currentTimeMillis();
        long updatedAt=policy.optLong("updated_at",now);
        long ageMs=Math.max(0,now-updatedAt);
        r.ageDays=ageMs/(1000L*60L*60L*24L);

        // Product heuristic: policy gets stale after 90d without reconfirmation.
        r.stale=r.ageDays>=90;

        // Inspect recent committed outcomes for this intervention.
        String intervention=policy.optString("intervention_id","");
        JSONArray commits=p.optJSONArray("micro_experiment_outcome_commit_history");

        if(commits!=null){
            int seen=0;
            for(int i=commits.length()-1;i>=0 && seen<6;i--){
                JSONObject item=commits.optJSONObject(i);
                if(item==null)continue;
                if(!"COMMIT".equals(item.optString("commit_state","")))continue;

                String exp=item.optString("experiment_id","");
                if(!intervention.isEmpty()&&!exp.contains(intervention))
                    continue;

                seen++;
                String o=item.optString("outcome","UNKNOWN");
                if("HELPED".equals(o)||"PARTIAL".equals(o))
                    r.recentPositive++;
                else if("NO_CHANGE".equals(o)||"WORSE".equals(o))
                    r.recentNegative++;
            }
        }

        r.contradicted=
                r.recentNegative>=2
                && r.recentNegative>r.recentPositive;

        // Demotion logic: conservative and one-way per evaluation.
        if(r.contradicted){
            if("HIGH".equals(r.oldConfidence))
                r.newConfidence="MEDIUM";
            else if("MEDIUM".equals(r.oldConfidence))
                r.newConfidence="LOW";
            else
                r.newConfidence="LOW";

            r.status=Status.DEMOTED;
            r.reason="RECENT_NEGATIVE_CONTRADICTION";
        }else if(r.stale){
            if("HIGH".equals(r.oldConfidence))
                r.newConfidence="MEDIUM";
            else if("MEDIUM".equals(r.oldConfidence))
                r.newConfidence="LOW";
            else
                r.newConfidence="LOW";

            r.status=Status.DEMOTED;
            r.reason="STALE_POLICY";
        }else{
            r.status=Status.ACTIVE;
            r.reason="NO_DEMOTION";
        }

        // Strong repeated contradiction can retire a LOW policy.
        if("LOW".equals(r.oldConfidence)
                && r.recentNegative>=3
                && r.recentPositive==0){
            r.status=Status.RETIRED;
            r.newConfidence="NONE";
            r.reason="REPEATED_CONTRADICTION_RETIRE";
        }

        r.changed=
                !r.newConfidence.equals(r.oldConfidence)
                || r.status!=Status.ACTIVE;

        if(r.changed){
            try{
                policy.put("confidence",r.newConfidence);
                policy.put("policy_status",r.status.name());
                policy.put("demotion_reason",r.reason);
                policy.put("last_decay_evaluation_at",now);
                policy.put("recent_positive_commits",r.recentPositive);
                policy.put("recent_negative_commits",r.recentNegative);

                p.put("last_policy_decay_key",key);
                p.put("last_policy_decay_status",r.status.name());
                p.put("last_policy_decay_reason",r.reason);
                p.put("last_policy_decay_at",now);

                CentralTherapyProfile.replaceProfile(c,p);
            }catch(Exception ignored){}
        }

        r.summary=(r.changed?"CHANGED":"UNCHANGED")
                +" | status="+r.status.name()
                +" | confidence="+r.oldConfidence+"->"+r.newConfidence
                +" | pos="+r.recentPositive
                +" | neg="+r.recentNegative
                +" | ageDays="+r.ageDays
                +" | reason="+r.reason;
        return r;
    }

    public static String instruction(Result r){
        if(r==null||!r.evaluated)return "";

        if(r.status==Status.RETIRED){
            return "POLICY_MEMORY_STATUS=RETIRED. 과거 policy가 최근 반복된 반대 evidence와 충돌하므로 더 이상 prior로 사용하지 않는다.";
        }

        if(r.status==Status.DEMOTED){
            return "POLICY_MEMORY_STATUS=DEMOTED. 과거 policy의 confidence를 낮추고 현재 evidence를 더 우선한다.";
        }

        return "";
    }

    public static boolean isPolicyUsable(JSONObject policy){
        if(policy==null)return false;
        String status=policy.optString("policy_status","ACTIVE");
        String confidence=policy.optString("confidence","LOW");
        if("RETIRED".equals(status))return false;
        return "MEDIUM".equals(confidence)||"HIGH".equals(confidence);
    }

    private static String safe(String s){
        return s==null?"":s;
    }
}
