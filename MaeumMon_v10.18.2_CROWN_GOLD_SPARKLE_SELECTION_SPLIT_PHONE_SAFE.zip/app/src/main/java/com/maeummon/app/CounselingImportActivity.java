package com.maeummon.app;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class CounselingImportActivity extends Activity {
    private EditText importText;
    private TextView countText, sessionStatus, sessionPreview;
    private MindTrainingStore store;
    private long sessionId = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_counseling_import);
        UiInsets.apply(this, findViewById(R.id.counselingImportRoot));
        store = new MindTrainingStore(this);
        importText = findViewById(R.id.counselingImportText);
        countText = findViewById(R.id.counselingImportCount);
        sessionStatus = findViewById(R.id.counselingSyncStatus);
        sessionPreview = findViewById(R.id.counselingSyncPreview);
        sessionId = store.getOrCreateActiveSyncSession();

        String shared = getIntent().getStringExtra(Intent.EXTRA_TEXT);
        if (shared != null && !shared.trim().isEmpty()) importText.setText(shared.trim());
        updateCount();
        refreshSession();

        importText.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) { updateCount(); }
            @Override public void afterTextChanged(Editable s) {}
        });

        findViewById(R.id.addAsUserButton).setOnClickListener(v -> append("USER"));
        findViewById(R.id.addAsAssistantButton).setOnClickListener(v -> append("ASSISTANT"));
        findViewById(R.id.addClipboardButton).setOnClickListener(v -> pasteClipboard());
        findViewById(R.id.completeCounselingSyncButton).setOnClickListener(v -> completeSession());
        findViewById(R.id.discardCounselingSyncButton).setOnClickListener(v -> discardSession());
        findViewById(R.id.cancelCounselingImportButton).setOnClickListener(v -> finish());
    }

    private void updateCount() {
        String raw = importText.getText().toString();
        int chars = raw.length();
        int lines = raw.isEmpty() ? 0 : raw.split("\\n", -1).length;
        countText.setText(chars + "자 · " + lines + "줄");
    }

    private void pasteClipboard() {
        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        if (cm == null || !cm.hasPrimaryClip()) {
            Toast.makeText(this, "클립보드에 복사된 텍스트가 없어.", Toast.LENGTH_SHORT).show();
            return;
        }
        ClipData clip = cm.getPrimaryClip();
        if (clip == null || clip.getItemCount() == 0) return;
        CharSequence text = clip.getItemAt(0).coerceToText(this);
        if (text == null || text.toString().trim().isEmpty()) {
            Toast.makeText(this, "복사된 텍스트가 비어 있어.", Toast.LENGTH_SHORT).show();
            return;
        }
        importText.setText(text.toString().trim());
        importText.setSelection(importText.length());
    }

    private void append(String speaker) {
        String raw = importText.getText().toString().trim();
        if (raw.isEmpty()) {
            Toast.makeText(this, "먼저 ChatGPT 말풍선 하나를 복사해서 붙여넣어줘.", Toast.LENGTH_SHORT).show();
            return;
        }
        boolean added = store.appendSyncChunk(sessionId, speaker, raw);
        if (!added) {
            Toast.makeText(this, "이미 이 상담에 저장된 같은 내용이야. 중복 추가는 안 했어.", Toast.LENGTH_LONG).show();
            return;
        }
        importText.setText("");
        Toast.makeText(this, "USER".equals(speaker) ? "내 말로 이어붙였어." : "GPT 답변으로 이어붙였어.", Toast.LENGTH_SHORT).show();
        refreshSession();
    }

    private void refreshSession() {
        MindTrainingStore.CounselingSyncSession session = store.activeSyncSession();
        if (session == null) {
            sessionId = store.getOrCreateActiveSyncSession();
            session = store.activeSyncSession();
        }
        if (session == null) return;
        sessionId = session.id;
        sessionStatus.setText("진행 중 · " + session.chunkCount + "개 말풍선 · " + session.charCount + "자");
        java.util.List<MindTrainingStore.CounselingSyncChunk> chunks = store.syncChunks(session.id);
        if (chunks.isEmpty()) {
            sessionPreview.setText("아직 추가된 대화가 없어. ChatGPT에서 말풍선 하나씩 복사해서 여기로 가져오면 돼.");
            return;
        }
        StringBuilder b = new StringBuilder();
        int start = Math.max(0, chunks.size() - 4);
        for (int i = start; i < chunks.size(); i++) {
            MindTrainingStore.CounselingSyncChunk c = chunks.get(i);
            if (b.length() > 0) b.append("\n\n");
            b.append("USER".equals(c.speaker) ? "나: " : "GPT: ");
            String one = c.content.replace('\n', ' ').trim();
            b.append(one.length() > 90 ? one.substring(0, 90) + "…" : one);
        }
        sessionPreview.setText(b.toString());
    }

    private void completeSession() {
        MindTrainingStore.CounselingSyncSession session = store.activeSyncSession();
        if (session == null || session.chunkCount <= 0) {
            Toast.makeText(this, "아직 저장된 상담 말풍선이 없어.", Toast.LENGTH_SHORT).show();
            return;
        }
        long id = store.finalizeActiveSyncSession();
        if (id < 0) {
            Toast.makeText(this, "상담 완료 저장에 실패했어.", Toast.LENGTH_SHORT).show();
            return;
        }
        Toast.makeText(this, "상담 원문을 하나로 이어서 상담책장에 저장했어. 다음 마음 PT가 이 상담을 우선 참고해.", Toast.LENGTH_LONG).show();
        setResult(RESULT_OK);
        finish();
    }

    private void discardSession() {
        MindTrainingStore.CounselingSyncSession session = store.activeSyncSession();
        if (session == null || session.chunkCount == 0) {
            finish();
            return;
        }
        store.discardActiveSyncSession();
        sessionId = store.getOrCreateActiveSyncSession();
        importText.setText("");
        refreshSession();
        Toast.makeText(this, "진행 중이던 동기화 조각만 비웠어. 완료된 상담책장 기록은 건드리지 않았어.", Toast.LENGTH_LONG).show();
    }
}
