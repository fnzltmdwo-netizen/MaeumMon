package com.maeummon.app.clinical;

import android.content.Context;
import org.json.JSONObject;

public final class DecisionTransitionSnapshotContinuityRC13 {
    private DecisionTransitionSnapshotContinuityRC13(){}

    public static final class Snapshot {
        public boolean loaded=false;
        public boolean hasPrevious=false;
        public String previousMove="";
        public String previousIntervention="";
        public String previousTarget="";
        public String previousMechanism="";
        public String previousContext="";
        public long previousTurn=0L;
        public String summary="";
    }

    public static Snapshot loadPrevious(Context c){
        Snapshot s=new Snapshot();
        if(c==null){ s.summary="NO_CONTEXT"; return s; }

        JSONObject session=CentralTherapyProfile.loadSessionState(c);
        s.loaded=true;
        s.previousMove=session.optString("decision_snapshot_move","");
        s.previousIntervention=session.optString("decision_snapshot_intervention","");
        s.previousTarget=session.optString("decision_snapshot_target","");
        s.previousMechanism=session.optString("decision_snapshot_mechanism","");
        s.previousContext=session.optString("decision_snapshot_context","");
        s.previousTurn=session.optLong("decision_snapshot_turn",0L);
        s.hasPrevious=!s.previousMove.isEmpty()
                ||!s.previousIntervention.isEmpty()
                ||!s.previousTarget.isEmpty();

        s.summary="loaded="+s.loaded
                +" | hasPrevious="+s.hasPrevious
                +" | move="+s.previousMove
                +" | intervention="+s.previousIntervention
                +" | target="+s.previousTarget
                +" | mechanism="+s.previousMechanism
                +" | context="+s.previousContext
                +" | turn="+s.previousTurn;
        return s;
    }

    public static void applyPreviousToDecision(ClinicalDecisionRC7 d,Snapshot s){
        if(d==null||s==null||!s.loaded)return;
        d.lastMove=s.previousMove;
        d.lastInterventionId=s.previousIntervention;
        d.lastTargetVariable=s.previousTarget;
        d.lastCentralMechanism=s.previousMechanism;
        d.lastContextScope=s.previousContext;
        d.lastDecisionSnapshotTurn=s.previousTurn;
        d.hasPreviousDecisionSnapshot=s.hasPrevious;
    }

    public static void persistCurrent(Context c,ClinicalDecisionRC7 d){
        if(c==null||d==null)return;
        JSONObject session=CentralTherapyProfile.loadSessionState(c);
        JSONObject formulation=CentralTherapyProfile.loadFormulation(c);
        try{
            session.put("decision_snapshot_move",safe(d.move));
            session.put("decision_snapshot_intervention",safe(d.selectedInterventionId));
            session.put("decision_snapshot_target",safe(d.targetVariable));
            session.put("decision_snapshot_mechanism",safe(d.centralMechanism));
            session.put("decision_snapshot_context",
                    formulation.optString("current_context_scope","UNKNOWN"));
            session.put("decision_snapshot_turn",session.optLong("turn_count",0L));
            session.put("decision_snapshot_at",System.currentTimeMillis());
            session.put("decision_snapshot_schema","6.8.0");
            CentralTherapyProfile.replaceSessionState(c,session);
        }catch(Exception ignored){}
    }

    public static boolean meaningfulMoveTransition(ClinicalDecisionRC7 d){
        return d!=null
                &&d.hasPreviousDecisionSnapshot
                &&!safe(d.move).isEmpty()
                &&!safe(d.lastMove).isEmpty()
                &&!safe(d.move).equals(safe(d.lastMove));
    }

    public static boolean meaningfulInterventionTransition(ClinicalDecisionRC7 d){
        return d!=null
                &&d.hasPreviousDecisionSnapshot
                &&"INTERVENE".equals(safe(d.move))
                &&!safe(d.selectedInterventionId).isEmpty()
                &&!safe(d.lastInterventionId).isEmpty()
                &&!safe(d.selectedInterventionId).equals(safe(d.lastInterventionId));
    }

    public static boolean meaningfulTargetTransition(ClinicalDecisionRC7 d){
        return d!=null
                &&d.hasPreviousDecisionSnapshot
                &&"ASK".equals(safe(d.move))
                &&!safe(d.targetVariable).isEmpty()
                &&!safe(d.lastTargetVariable).isEmpty()
                &&!safe(d.targetVariable).equals(safe(d.lastTargetVariable));
    }

    public static String transitionSummary(ClinicalDecisionRC7 d){
        if(d==null)return "";
        return "hasPrevious="+d.hasPreviousDecisionSnapshot
                +" | move="+safe(d.lastMove)+"->"+safe(d.move)
                +" | intervention="+safe(d.lastInterventionId)+"->"+safe(d.selectedInterventionId)
                +" | target="+safe(d.lastTargetVariable)+"->"+safe(d.targetVariable)
                +" | mechanism="+safe(d.lastCentralMechanism)+"->"+safe(d.centralMechanism)
                +" | context="+safe(d.lastContextScope);
    }

    private static String safe(String s){ return s==null?"":s; }
}
