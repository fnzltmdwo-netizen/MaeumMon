package com.maeummon.app.clinical;

import android.content.Context;
import org.json.*;
import java.security.MessageDigest;

public final class ExplicitCorrectionCommitProvenanceIdentityRC13 {
    private ExplicitCorrectionCommitProvenanceIdentityRC13(){}

    public enum State {
        NONE,
        PROVENANCE_READY,
        PROVENANCE_COMMITTED,
        PROVENANCE_BLOCKED,
        DUPLICATE_PROVENANCE
    }

    public static final class Result {
        public boolean evaluated=false;
        public boolean ready=false;
        public boolean committed=false;
        public boolean blocked=false;
        public boolean duplicate=false;
        public State state=State.NONE;
        public String evidenceId="";
        public String canonicalCommitKey="";
        public String transitionKey="";
        public String contextScope="";
        public String userEvidence="";
        public String correctedCause="";
        public String correctedReason="";
        public String reason="";
        public String summary="";
    }

    public static Result prepare(
            Context c,
            ClinicalDecisionRC7 d,
            String userText){

        Result r=new Result();

        if(c==null||d==null){
            r.summary="NONE | MISSING_INPUT";
            return r;
        }

        r.evaluated=true;

        if(!d.transitionCorrectionCommitAllowed
                ||d.transitionCorrectionCommitBlocked
                ||!d.transitionExplanationCorrectionApplied){
            r.blocked=true;
            r.state=State.PROVENANCE_BLOCKED;
            r.reason="CORRECTION_COMMIT_NOT_ALLOWED";
            return finish(r);
        }

        JSONObject f=CentralTherapyProfile.loadFormulation(c);

        r.contextScope=
                f.optString("current_context_scope","UNKNOWN");

        r.transitionKey=
                safe(d.decisionTransitionFromState)
                +"->"
                +safe(d.decisionTransitionToState)
                +"::"
                +r.contextScope;

        r.userEvidence=normalize(userText);
        r.correctedCause=safe(
                d.transitionExplanationCorrectedCause);
        r.correctedReason=safe(
                d.transitionExplanationCorrectedReason);

        if(r.userEvidence.isEmpty()
                ||r.correctedCause.isEmpty()){
            r.blocked=true;
            r.state=State.PROVENANCE_BLOCKED;
            r.reason="MISSING_EXPLICIT_USER_EVIDENCE";
            return finish(r);
        }

        r.evidenceId=sha256(
                r.userEvidence);

        r.canonicalCommitKey=sha256(
                r.transitionKey
                +"::"
                +r.correctedCause
                +"::"
                +r.evidenceId);

        JSONObject p=CentralTherapyProfile.loadProfile(c);
        JSONArray h=p.optJSONArray(
                "transition_correction_commit_provenance_history");

        if(h==null)h=new JSONArray();

        for(int i=0;i<h.length();i++){
            JSONObject x=h.optJSONObject(i);
            if(x==null)continue;

            if(r.canonicalCommitKey.equals(
                    x.optString("canonical_commit_key",""))){
                r.duplicate=true;
                r.state=State.DUPLICATE_PROVENANCE;
                r.reason="CANONICAL_COMMIT_ALREADY_EXISTS";
                return finish(r);
            }
        }

        r.ready=true;
        r.state=State.PROVENANCE_READY;
        r.reason="EXPLICIT_USER_EVIDENCE_BOUND";
        return finish(r);
    }

    public static void commit(
            Context c,
            ClinicalDecisionRC7 d,
            Result r){

        if(c==null||d==null||r==null||!r.ready)return;

        JSONObject p=CentralTherapyProfile.loadProfile(c);
        JSONArray h=p.optJSONArray(
                "transition_correction_commit_provenance_history");

        if(h==null)h=new JSONArray();

        try{
            JSONObject item=new JSONObject();

            item.put("canonical_commit_key",
                    r.canonicalCommitKey);
            item.put("user_evidence_id",
                    r.evidenceId);
            item.put("user_evidence_text",
                    r.userEvidence);
            item.put("transition_key",
                    r.transitionKey);
            item.put("context_scope",
                    r.contextScope);
            item.put("decision_transition_from",
                    safe(d.decisionTransitionFromState));
            item.put("decision_transition_to",
                    safe(d.decisionTransitionToState));
            item.put("corrected_cause",
                    r.correctedCause);
            item.put("corrected_reason",
                    r.correctedReason);
            item.put("mechanism",
                    safe(d.centralMechanism));
            item.put("intervention_id",
                    safe(d.selectedInterventionId));
            item.put("commit_identity_v688",
                    safe(d.transitionCorrectionCommitIdentity));
            item.put("source_type",
                    "EXPLICIT_USER_CORRECTION");
            item.put("schema_version",
                    "6.8.9");
            item.put("time",
                    System.currentTimeMillis());

            h.put(item);
        }catch(Exception e){
            r.blocked=true;
            r.state=State.PROVENANCE_BLOCKED;
            r.reason="PROVENANCE_ITEM_BUILD_FAILED";
            finish(r);
            return;
        }

        JSONArray trimmed=new JSONArray();
        int start=Math.max(0,h.length()-40);
        for(int i=start;i<h.length();i++)
            trimmed.put(h.opt(i));

        try{
            p.put("transition_correction_commit_provenance_history",
                    trimmed);
            p.put("last_transition_correction_provenance_key",
                    r.canonicalCommitKey);
            p.put("last_transition_correction_evidence_id",
                    r.evidenceId);
            p.put("last_transition_correction_provenance_at",
                    System.currentTimeMillis());

            CentralTherapyProfile.replaceProfile(c,p);

            r.committed=true;
            r.state=State.PROVENANCE_COMMITTED;
            r.reason="PROVENANCE_COMMIT_SUCCESS";
            finish(r);

        }catch(Exception e){
            r.blocked=true;
            r.state=State.PROVENANCE_BLOCKED;
            r.reason="PROVENANCE_COMMIT_FAILED";
            finish(r);
        }
    }

    public static boolean rowHasValidExplicitProvenance(
            JSONObject row){

        if(row==null)return false;

        return "EXPLICIT_USER_CORRECTION".equals(
                    row.optString("source_type",""))
                &&!row.optString(
                    "canonical_commit_key","").isEmpty()
                &&!row.optString(
                    "user_evidence_id","").isEmpty()
                &&!row.optString(
                    "transition_key","").isEmpty()
                &&!row.optString(
                    "corrected_cause","").isEmpty();
    }

    public static String instruction(Result r){
        if(r==null||!r.evaluated)return "";

        if(r.state==State.PROVENANCE_COMMITTED)
            return "CORRECTION_COMMIT_PROVENANCE=COMMITTED. 이 correction memory는 사용자의 명시적 교정 발화와 transition/context에 출처가 연결되어 있다.";

        if(r.state==State.DUPLICATE_PROVENANCE)
            return "CORRECTION_COMMIT_PROVENANCE=DUPLICATE. 동일 사용자 근거의 동일 correction commit은 새 memory로 중복 저장하지 않는다.";

        if(r.state==State.PROVENANCE_BLOCKED)
            return "CORRECTION_COMMIT_PROVENANCE=BLOCKED. 출처가 불충분하거나 commit 자격이 없어 correction memory provenance를 만들지 않는다.";

        return "";
    }

    private static String normalize(String s){
        if(s==null)return "";
        return s.trim()
                .replaceAll("\\s+"," ")
                .toLowerCase();
    }

    private static String sha256(String s){
        try{
            MessageDigest md=
                    MessageDigest.getInstance("SHA-256");
            byte[] b=md.digest(
                    safe(s).getBytes("UTF-8"));

            StringBuilder out=
                    new StringBuilder();

            for(byte x:b)
                out.append(
                        String.format("%02x",x));

            return out.toString();
        }catch(Exception e){
            return Integer.toHexString(
                    safe(s).hashCode());
        }
    }

    private static Result finish(Result r){
        r.summary=r.state.name()
                +" | ready="+r.ready
                +" | committed="+r.committed
                +" | blocked="+r.blocked
                +" | duplicate="+r.duplicate
                +" | transition="+r.transitionKey
                +" | cause="+r.correctedCause
                +" | evidenceId="+r.evidenceId
                +" | key="+r.canonicalCommitKey
                +" | reason="+r.reason;

        return r;
    }

    private static String safe(String s){
        return s==null?"":s;
    }
}
