package com.maeummon.app.clinical;

import android.content.Context;
import org.json.*;
import java.text.SimpleDateFormat;
import java.util.*;

public final class CooldownEvidenceTemporalDiversityMultiDayRC14 {
    private CooldownEvidenceTemporalDiversityMultiDayRC14(){}

    public enum State {
        NONE,
        NO_ELIGIBLE_EVIDENCE,
        SAME_DAY_ONLY,
        MULTI_DAY_ACCUMULATING,
        MULTI_DAY_THRESHOLD_MET
    }

    public static final class Result {
        public boolean evaluated=false;
        public boolean thresholdMet=false;
        public int cleanEvidenceCount=0;
        public int distinctDayCount=0;
        public State state=State.NONE;
        public String transitionKey="";
        public String quarantinedCause="";
        public String reason="";
        public String summary="";
    }

    public static Result evaluate(
            Context c,
            String transitionKey,
            String quarantinedCause){

        Result r=new Result();

        if(c==null){
            r.reason="NO_CONTEXT";
            return finish(r);
        }

        r.evaluated=true;
        r.transitionKey=safe(transitionKey);
        r.quarantinedCause=safe(quarantinedCause);

        if(r.transitionKey.isEmpty()
                ||r.quarantinedCause.isEmpty()){
            r.reason="MISSING_TRANSITION_OR_CAUSE";
            return finish(r);
        }

        JSONObject p=
                CentralTherapyProfile.loadProfile(c);

        JSONArray ledger=
                p.optJSONArray(
                    "requarantine_cooldown_evidence_ledger");

        if(ledger==null||ledger.length()==0){
            r.state=State.NO_ELIGIBLE_EVIDENCE;
            r.reason="NO_LEDGER";
            return finish(r);
        }

        HashSet<String> seenEvidence=
                new HashSet<>();

        HashSet<String> distinctDays=
                new HashSet<>();

        for(int i=0;i<ledger.length();i++){
            JSONObject row=
                    ledger.optJSONObject(i);

            if(row==null)continue;

            if(!CooldownEvidenceLedgerIntegrityAntiSyntheticRC14
                    .rowEligible(row))
                continue;

            if(!r.transitionKey.equals(
                    row.optString("transition_key","")))
                continue;

            if(!r.quarantinedCause.equals(
                    row.optString("quarantined_cause","")))
                continue;

            if(!row.optBoolean(
                    "clean_confirmation",
                    false))
                continue;

            String evidenceId=
                    row.optString(
                        "user_evidence_id",
                        "");

            if(evidenceId.isEmpty()
                    ||seenEvidence.contains(evidenceId))
                continue;

            long at=row.optLong("time",0L);

            if(at<=0L)
                continue;

            seenEvidence.add(evidenceId);
            r.cleanEvidenceCount++;

            distinctDays.add(
                    localDayKey(at));
        }

        r.distinctDayCount=
                distinctDays.size();

        if(r.cleanEvidenceCount==0){
            r.state=State.NO_ELIGIBLE_EVIDENCE;
            r.reason="NO_CLEAN_ELIGIBLE_EVIDENCE";

        }else if(r.distinctDayCount<=1){
            r.state=State.SAME_DAY_ONLY;
            r.reason="CLEAN_EVIDENCE_NOT_DISTRIBUTED_ACROSS_DAYS";

        }else if(r.distinctDayCount<3){
            r.state=State.MULTI_DAY_ACCUMULATING;
            r.reason="WAITING_FOR_THIRD_DISTINCT_EVIDENCE_DAY";

        }else{
            r.thresholdMet=true;
            r.state=State.MULTI_DAY_THRESHOLD_MET;
            r.reason="THREE_DISTINCT_EVIDENCE_DAYS_MET";
        }

        try{
            p.put(
                "last_cooldown_temporal_diversity_state",
                r.state.name());

            p.put(
                "last_cooldown_temporal_diversity_days",
                r.distinctDayCount);

            p.put(
                "last_cooldown_temporal_diversity_clean_evidence",
                r.cleanEvidenceCount);

            p.put(
                "last_cooldown_temporal_diversity_transition",
                r.transitionKey);

            p.put(
                "last_cooldown_temporal_diversity_at",
                System.currentTimeMillis());

            CentralTherapyProfile.replaceProfile(c,p);
        }catch(Exception ignored){}

        return finish(r);
    }

    public static boolean releaseEligible(Result r){
        return r!=null
                &&r.thresholdMet
                &&r.state==State.MULTI_DAY_THRESHOLD_MET;
    }

    public static String instruction(Result r){
        if(r==null||!r.evaluated)return "";

        if(r.state==State.SAME_DAY_ONLY)
            return "COOLDOWN_EVIDENCE_TEMPORAL_DIVERSITY=SAME_DAY_ONLY. 같은 날짜에 몰린 clean confirmation은 cooldown release용 독립 근거 분포로 인정하지 않는다.";

        if(r.state==State.MULTI_DAY_ACCUMULATING)
            return "COOLDOWN_EVIDENCE_TEMPORAL_DIVERSITY=ACCUMULATING. 서로 다른 날짜의 사용자 근거가 쌓이고 있지만 아직 3개 날짜 기준을 충족하지 않았다.";

        if(r.state==State.MULTI_DAY_THRESHOLD_MET)
            return "COOLDOWN_EVIDENCE_TEMPORAL_DIVERSITY=THRESHOLD_MET. clean evidence가 3개 이상의 서로 다른 날짜에 분포해 release의 시간적 다양성 기준을 충족했다.";

        return "";
    }

    private static String localDayKey(long time){
        SimpleDateFormat f=
                new SimpleDateFormat(
                    "yyyy-MM-dd",
                    Locale.US);

        return f.format(
                new Date(time));
    }

    private static Result finish(Result r){
        r.summary=
                r.state.name()
                +" | transition="+r.transitionKey
                +" | cause="+r.quarantinedCause
                +" | cleanEvidence="+r.cleanEvidenceCount
                +" | distinctDays="+r.distinctDayCount
                +" | thresholdMet="+r.thresholdMet
                +" | reason="+r.reason;

        return r;
    }

    private static String safe(String s){
        return s==null?"":s;
    }
}
