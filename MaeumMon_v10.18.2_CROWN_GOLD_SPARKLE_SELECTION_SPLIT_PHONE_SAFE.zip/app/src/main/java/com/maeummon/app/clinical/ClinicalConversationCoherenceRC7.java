package com.maeummon.app.clinical;

import java.util.*;
import java.util.regex.*;

public final class ClinicalConversationCoherenceRC7 {
    private ClinicalConversationCoherenceRC7(){}

    public static final class Result {
        public final int score;
        public final List<String> issues;
        public Result(int score,List<String> issues){
            this.score=Math.max(0,Math.min(100,score));
            this.issues=issues==null?new ArrayList<>():issues;
        }
    }

    public static Result evaluate(
            String recentConversation,
            String userText,
            String candidateReply,
            String route,
            String target
    ){
        String ctx=safe(recentConversation);
        String user=safe(userText);
        String reply=safe(candidateReply);
        int score=100;
        List<String> issues=new ArrayList<>();

        // 1) Don't re-ask known information.
        if("ASK".equals(route)){
            Set<String> qTokens=salientTokens(reply);
            Set<String> ctxTokens=salientTokens(ctx);
            if(!qTokens.isEmpty()){
                int overlap=0;
                for(String t:qTokens)if(ctxTokens.contains(t))overlap++;
                double ratio=(double)overlap/(double)qTokens.size();
                if(ratio>=0.70){
                    score-=35;
                    issues.add("LIKELY_REASK_KNOWN_INFO");
                }
            }
        }

        // 2) Detect explicit goal changes in recent context.
        boolean wantsUnderstanding=containsAny(ctx,
                "해결책 말고 이해","이해받고 싶","그냥 들어줬으면","조언 말고");
        boolean wantsAction=containsAny(ctx,
                "어떻게 해야","방법 알려","뭘 하면","해결책","행동");
        if(wantsUnderstanding && containsAny(reply,
                "해보자","하세요","해봐","방법은","우선 ","먼저 ")){
            score-=30;
            issues.add("GOAL_DRIFT_TO_ACTION");
        }
        if(wantsAction && "ASK".equals(route) && reply.length()>220){
            score-=15;
            issues.add("ACTION_REQUEST_DELAYED_BY_EXPLORATION");
        }

        // 3) Alliance repair should not fall back to content interrogation immediately.
        if("ALLIANCE_REPAIR".equals(route)){
            if(!(containsAny(reply,"맞","어긋","원한","방향","질문","이해"))){
                score-=25;
                issues.add("REPAIR_LOST_TO_CONTENT");
            }
        }

        // 4) Contradiction markers: user explicitly states X, reply assumes opposite.
        if(containsAny(user,"원래도 느려","원래 느린","늘 그랬") &&
                containsAny(reply,"최근에 달라진","갑자기 달라")){
            score-=35;
            issues.add("BASELINE_CONTRADICTION");
        }
        if(containsAny(user,"싸운 일은 없어","갈등은 없어","다툰 건 없어") &&
                containsAny(reply,"최근 갈등이 있었","싸운 일이 있었")){
            score-=35;
            issues.add("CONFLICT_CONTRADICTION");
        }
        if(containsAny(user,"죽고 싶은 건 아니","자살할 생각은 없") &&
                "STABILIZE".equals(route) &&
                containsAny(reply,"즉시 위험","지금 자살 위험","당장 위험")){
            score-=30;
            issues.add("NEGATION_IGNORED");
        }

        // 5) Topic-switch coherence.
        String lastTopic=guessTopic(user);
        String replyTopic=guessTopic(reply);
        if(!lastTopic.isEmpty() && !replyTopic.isEmpty() &&
                !lastTopic.equals(replyTopic) &&
                !containsAny(reply,"아까","다시","돌아가","잠깐")){
            score-=18;
            issues.add("TOPIC_DRIFT");
        }

        // 6) Avoid restarting intake after substantial context.
        int turns=approxTurns(ctx);
        if(turns>=8 && containsAny(reply,
                "처음부터","상황을 자세히","어떤 일이 있었는지 말해","무슨 일이 있었어?")){
            score-=25;
            issues.add("INTAKE_RESTART");
        }

        return new Result(score,issues);
    }

    public static boolean acceptable(Result r){
        return r!=null && r.score>=65;
    }

    private static int approxTurns(String ctx){
        if(ctx.isEmpty())return 0;
        int n=0;
        for(String line:ctx.split("\\n"))if(!line.trim().isEmpty())n++;
        return n/2;
    }

    private static String guessTopic(String s){
        if(containsAny(s,"친구","답장","카톡","연락"))return "relationship";
        if(containsAny(s,"회사","직장","상사","업무","일"))return "work";
        if(containsAny(s,"불안","공황","숨","심장"))return "anxiety";
        if(containsAny(s,"약속","회피","피하고"))return "avoidance";
        return "";
    }

    private static boolean containsAny(String s,String... xs){
        for(String x:xs)if(s.contains(x))return true;
        return false;
    }

    private static Set<String> salientTokens(String text){
        Set<String> out=new LinkedHashSet<>();
        Matcher m=Pattern.compile("[가-힣]{2,}").matcher(text);
        Set<String> stop=new HashSet<>(Arrays.asList(
                "그냥","근데","그래서","그리고","나는","내가","너무","정말","조금","같아",
                "지금","오늘","어떻게","무슨","어떤","있는","없는","그런","이런"));
        while(m.find()){
            String x=m.group();
            if(!stop.contains(x))out.add(x);
            if(out.size()>=14)break;
        }
        return out;
    }
    private static String safe(String s){return s==null?"":s;}
}
