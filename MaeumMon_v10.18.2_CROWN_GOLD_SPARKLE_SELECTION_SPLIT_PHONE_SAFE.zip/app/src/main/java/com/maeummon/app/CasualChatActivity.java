package com.maeummon.app;

import android.app.Activity;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.Locale;

/**
 * 상담 모드와 분리된 시시콜콜한 일상대화 화면.
 * 이 화면은 상담 세션과 분리되지만 공통 장기맥락을 참고하고, 상담 탭에는 최근 생활 맥락만 참고자료로 연결한다.
 */
public class CasualChatActivity extends Activity {
    private ScrollView historyScroll;
    private LinearLayout chatContainer;
    private EditText input;
    private Button sendButton;
    private TextView statusText;
    private SharedPreferences prefs;
    private volatile boolean sending = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_casual_chat);
        UiInsets.apply(this, findViewById(R.id.casualRoot));

        prefs = getSharedPreferences(AppPrefs.PREFS, MODE_PRIVATE);
        historyScroll = findViewById(R.id.casualHistoryScroll);
        chatContainer = findViewById(R.id.casualChatContainer);
        input = findViewById(R.id.casualInput);
        sendButton = findViewById(R.id.casualSendButton);
        statusText = findViewById(R.id.casualStatus);

        findViewById(R.id.casualBackButton).setOnClickListener(v -> finish());
        findViewById(R.id.casualClearButton).setOnClickListener(v -> {
            CasualChatStorage.clear(this);
            renderHistory();
            statusText.setText("대화를 비웠어. 다시 아무 얘기나 해줘 ㅋㅋ");
        });
        sendButton.setOnClickListener(v -> sendMessage());

        input.setOnEditorActionListener((v, actionId, event) -> {
            if (event != null && event.getKeyCode() == android.view.KeyEvent.KEYCODE_ENTER
                    && !event.isShiftPressed()) {
                sendMessage();
                return true;
            }
            return false;
        });

        renderHistory();
        if (CasualChatStorage.getMessages(this).length() == 0) {
            addBubble("assistant", "승재야 ㅋㅋ 여긴 상담 말고 그냥 아무 얘기나 하는 데야. 오늘 뭐 있었어?");
        }
        scrollToBottom(false);
    }

    private void renderHistory() {
        chatContainer.removeAllViews();
        JSONArray arr = CasualChatStorage.getMessages(this);
        for (int i = 0; i < arr.length(); i++) {
            JSONObject o = arr.optJSONObject(i);
            if (o == null) continue;
            addBubble(o.optString("role", "user"), o.optString("text", ""));
        }
        scrollToBottom(false);
    }

    private void sendMessage() {
        if (sending) return;
        String text = input.getText().toString().trim();
        if (text.isEmpty()) return;

        CasualChatStorage.addMessage(this, "user", text);
        addBubble("user", text);
        input.setText("");
        scrollToBottom(true);

        final String apiKey = prefs.getString(AppPrefs.KEY_API_KEY, "").trim();
        if (apiKey.isEmpty()) {
            String fallback = localFallback(text);
            CasualChatStorage.addMessage(this, "assistant", fallback);
            addBubble("assistant", fallback);
            statusText.setText("API Key가 없어서 가벼운 기본대화로 답했어.");
            scrollToBottom(true);
            return;
        }

        sending = true;
        sendButton.setEnabled(false);
        sendButton.setAlpha(0.55f);
        statusText.setText("마음몬이 답장 쓰는 중... 💬");

        final JSONArray history = CasualChatStorage.getRecentForApi(this, 28);
        final String sharedContext = buildSharedContext();
        new Thread(() -> {
            try {
                String reply = OpenAiClient.getCasualReply(apiKey, history, text, sharedContext);
                if (reply == null || reply.trim().isEmpty()) throw new RuntimeException("empty reply");
                String finalReply = reply.trim();
                CasualChatStorage.addMessage(this, "assistant", finalReply);
                runOnUiThread(() -> {
                    addBubble("assistant", finalReply);
                    statusText.setText("그냥 편하게 이어서 말해줘 ㅋㅋ");
                    finishSending();
                    scrollToBottom(true);
                });
            } catch (Exception e) {
                String fallback = localFallback(text);
                CasualChatStorage.addMessage(this, "assistant", fallback);
                runOnUiThread(() -> {
                    addBubble("assistant", fallback);
                    statusText.setText("네트워크가 잠깐 말썽이라 기본대화로 이어갔어.");
                    finishSending();
                    scrollToBottom(true);
                });
            }
        }).start();
    }

    private String buildSharedContext() {
        StringBuilder sb = new StringBuilder();
        sb.append("[공통 장기 맥락]\n");
        sb.append(PersonalTherapyProfile.baselineContext()).append("\n\n");

        String therapy = TherapyMemoryManager.compactForLiveMind(this);
        if (!therapy.trim().isEmpty()) {
            sb.append("[최근 상담의 핵심만 참고]\n").append(therapy).append("\n\n");
        }

        String cards = MemoryManager.preview(this);
        if (cards != null && !cards.trim().isEmpty() && !cards.contains("아직 저장된")) {
            sb.append("[최근 기억 카드]\n").append(cards).append("\n\n");
        }

        sb.append("사용자의 방금 말과 현재 일상대화가 언제나 최우선이다. ")
          .append("과거 상담 맥락을 억지로 끌어오거나 사소한 잡담을 심리분석하지 않는다. ")
          .append("다만 사용자가 전에 말한 사람·사건·취향·근황이 관련되면 자연스럽게 기억한 듯 이어서 말한다.");
        String out = sb.toString().trim();
        if (out.length() > 9000) out = out.substring(0, 9000);
        return out;
    }

    private void finishSending() {
        sending = false;
        sendButton.setEnabled(true);
        sendButton.setAlpha(1f);
    }

    private void addBubble(String role, String text) {
        if (TextUtils.isEmpty(text)) return;
        boolean user = "user".equals(role);

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(user ? Gravity.END : Gravity.START);
        row.setPadding(dp(8), dp(4), dp(8), dp(4));

        TextView bubble = new TextView(this);
        bubble.setText(text);
        bubble.setTextSize(16f);
        bubble.setTextColor(Color.rgb(83, 83, 101));
        bubble.setLineSpacing(0f, 1.12f);
        // One UI/Android 기본 길게누르기/드래그 선택/복사를 사용한다.
        bubble.setTextIsSelectable(true);
        bubble.setLongClickable(true);
        bubble.setPadding(dp(15), dp(12), dp(15), dp(12));
        bubble.setBackgroundResource(user ? R.drawable.bg_chat_user : R.drawable.bg_chat_ai);

        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT);
        bp.weight = 0.86f;
        if (user) bp.leftMargin = dp(42); else bp.rightMargin = dp(42);
        bubble.setLayoutParams(bp);
        row.addView(bubble);
        chatContainer.addView(row);
    }

    private void scrollToBottom(boolean delayed) {
        Runnable r = () -> historyScroll.fullScroll(View.FOCUS_DOWN);
        historyScroll.postDelayed(r, delayed ? 80 : 10);
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private String localFallback(String userText) {
        String t = userText.toLowerCase(Locale.KOREA);
        if (t.contains("ㅋㅋ") || t.contains("웃") || t.contains("개웃") || t.contains("웃겨")) {
            return "ㅋㅋㅋㅋ 아니 그건 나도 들으면서 좀 웃긴데? 계속 말해봐.";
        }
        if (t.contains("피곤") || t.contains("졸려") || t.contains("귀찮")) {
            return "아 그 상태면 진짜 아무것도 하기 싫지 ㅋㅋ 오늘 뭐가 제일 귀찮았어?";
        }
        if (t.contains("먹") || t.contains("점심") || t.contains("저녁") || t.contains("배고")) {
            return "오 먹는 얘기 좋지 ㅋㅋ 지금 당기는 거 뭐야?";
        }
        if (t.contains("무서") || t.contains("불안") || t.contains("힘들")) {
            return "아 그건 가볍게 넘길 얘기는 아니네. 지금은 그냥 여기서 말해도 되고, 좀 제대로 풀어보고 싶으면 상담 탭으로 같이 넘어가도 돼.";
        }
        return "응응 ㅋㅋ 듣고 있어. 그 다음은 어떻게 됐어?";
    }
}
