package com.maeummon.app;

import com.maeummon.app.clinical.TherapySurfaceContext;

import com.maeummon.app.clinical.CentralTherapyProfile;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;

public class WeeklyReportActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (DiarySecurity.redirectToUnlockIfNeeded(this)) return;
        setContentView(R.layout.activity_weekly_report);
        UiInsets.apply(this, findViewById(R.id.reportRoot));

        TextView rangeText = findViewById(R.id.reportDateRangeText);
        TextView patternText = findViewById(R.id.patternSummaryText);
        TextView letterText = findViewById(R.id.weeklyLetterText);
        TextView weeklyListText = findViewById(R.id.weeklyListText);
        TextView summaryCountText = findViewById(R.id.summaryCountText);
        TextView summaryTopEmotionText = findViewById(R.id.summaryTopEmotionText);
        TextView summaryAffectionText = findViewById(R.id.summaryAffectionText);

        Calendar end = Calendar.getInstance();
        Calendar start = Calendar.getInstance();
        start.add(Calendar.DAY_OF_MONTH, -6);

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy.MM.dd", Locale.KOREA);
        rangeText.setText(sdf.format(start.getTime()) + " ~ " + sdf.format(end.getTime()));

        JSONArray weekEntries = EmotionDiaryStorage.getLastSevenEntries(this);
        String centralWeeklyHint = CentralTherapyProfile.reportHint(this, "주간");
        patternText.setText(
                EmotionDiaryStorage.weeklyPatternSummary(this)
                        + "\n\n" + UnifiedTherapyProfile.reportFocus(this)
                        + (centralWeeklyHint.isEmpty() ? "" : "\n\n" + centralWeeklyHint));
        letterText.setText(
                EmotionDiaryStorage.weeklyLetter(this)
                        + "\n\n" + UnifiedTherapyProfile.mascotLine(this));
        weeklyListText.setText(EmotionDiaryStorage.weeklyList(this));

        summaryCountText.setText("기록 " + weekEntries.length() + "일");
        summaryTopEmotionText.setText("대표 감정 " + findTopEmotion(weekEntries));
        int affection = CompanionProfile.getAffection(this);
        summaryAffectionText.setText("친밀도 Lv." + CompanionProfile.level(affection));

        findViewById(R.id.shareReportButton).setOnClickListener(v ->
                shareText("마음몬 주간 리포트", EmotionDiaryStorage.weeklyReportExportText(this))
        );

        findViewById(R.id.exportAllButton).setOnClickListener(v ->
                shareText("마음몬 전체 기록 백업", EmotionDiaryStorage.exportAllText(this))
        );
    }

    private String findTopEmotion(JSONArray arr) {
        if (arr == null || arr.length() == 0) return "-";

        Map<String, Integer> counts = new LinkedHashMap<>();
        for (int i = 0; i < arr.length(); i++) {
            JSONObject obj = arr.optJSONObject(i);
            if (obj == null) continue;
            String label = obj.optString("label", "잔잔");
            counts.put(label, counts.containsKey(label) ? counts.get(label) + 1 : 1);
        }

        String top = "-";
        int max = 0;
        for (Map.Entry<String, Integer> entry : counts.entrySet()) {
            if (entry.getValue() > max) {
                max = entry.getValue();
                top = entry.getKey();
            }
        }
        return top;
    }

    private void shareText(String title, String text) {
        Intent intent = new Intent(Intent.ACTION_SEND);
        intent.setType("text/plain");
        intent.putExtra(Intent.EXTRA_SUBJECT, title);
        intent.putExtra(Intent.EXTRA_TEXT, text);
        startActivity(Intent.createChooser(intent, title));
    }
}
