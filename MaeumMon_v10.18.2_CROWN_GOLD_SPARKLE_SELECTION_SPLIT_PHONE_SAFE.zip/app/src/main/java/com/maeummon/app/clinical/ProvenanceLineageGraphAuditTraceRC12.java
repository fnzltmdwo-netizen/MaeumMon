package com.maeummon.app.clinical;

import android.content.Context;
import org.json.*;

public final class ProvenanceLineageGraphAuditTraceRC12 {
    private ProvenanceLineageGraphAuditTraceRC12(){}

    public static final class Result {
        public boolean evaluated=false;
        public boolean updated=false;
        public int nodesAdded=0;
        public int edgesAdded=0;
        public String activeExperimentId="";
        public String activePolicyKey="";
        public String lineageRootKey="";
        public String reason="";
        public String summary="";
    }

    public static Result update(Context c,ClinicalDecisionRC7 d){
        Result r=new Result();
        if(c==null||d==null){
            r.summary="NO_EVALUATION | NO_CONTEXT_OR_DECISION";
            return r;
        }

        JSONObject p=CentralTherapyProfile.loadProfile(c);
        JSONObject f=CentralTherapyProfile.loadFormulation(c);

        r.evaluated=true;
        r.activeExperimentId=firstNonEmpty(
                safe(d.outcomeCommitExperimentId),
                safe(d.microExperimentId));

        r.activePolicyKey=firstNonEmpty(
                safe(d.policySelectionEffectiveKey),
                safe(d.policyRetrievalKey));

        String mechanism=safe(d.centralMechanism);
        String intervention=safe(d.selectedInterventionId);
        String context=f.optString("current_context_scope","UNKNOWN");

        r.lineageRootKey=mechanism+"::"+intervention+"::"+context;

        JSONObject graph=p.optJSONObject("provenance_lineage_graph");
        if(graph==null)graph=new JSONObject();

        JSONArray nodes=graph.optJSONArray("nodes");
        if(nodes==null)nodes=new JSONArray();

        JSONArray edges=graph.optJSONArray("edges");
        if(edges==null)edges=new JSONArray();

        String experimentNode="EXP::"+r.activeExperimentId;
        String commitNode="COMMIT::"+safe(d.outcomeCommitIdempotencyKey);
        String policyNode="POLICY::"+r.activePolicyKey;
        String revisionNode="REV::"+safe(d.outcomeRevisionExperimentId);
        String canonicalNode="CANON::"+safe(d.structuredProvenanceCanonicalKey);

        if(!r.activeExperimentId.isEmpty()){
            r.nodesAdded+=addNode(nodes,
                    experimentNode,
                    "EXPERIMENT",
                    r.activeExperimentId,
                    mechanism,intervention,context);
        }

        if("COMMIT".equals(d.outcomeCommitState)
                && !safe(d.outcomeCommitIdempotencyKey).isEmpty()){

            r.nodesAdded+=addNode(nodes,
                    commitNode,
                    "OUTCOME_COMMIT",
                    safe(d.outcomeCommitValue),
                    mechanism,intervention,context);

            if(!r.activeExperimentId.isEmpty())
                r.edgesAdded+=addEdge(edges,
                        experimentNode,
                        commitNode,
                        "PRODUCED_COMMIT");
        }

        if(!safe(d.structuredProvenanceCanonicalKey).isEmpty()){
            r.nodesAdded+=addNode(nodes,
                    canonicalNode,
                    "CANONICAL_LEARNING_IDENTITY",
                    safe(d.structuredProvenanceCanonicalKey),
                    mechanism,intervention,context);

            if(!r.activeExperimentId.isEmpty())
                r.edgesAdded+=addEdge(edges,
                        experimentNode,
                        canonicalNode,
                        "IDENTIFIED_AS");

            if("COMMIT".equals(d.outcomeCommitState)
                    && !safe(d.outcomeCommitIdempotencyKey).isEmpty())
                r.edgesAdded+=addEdge(edges,
                        commitNode,
                        canonicalNode,
                        "COMMIT_MAPPED_TO");
        }

        if(d.outcomeRevisionApplied
                && !safe(d.outcomeRevisionExperimentId).isEmpty()){

            r.nodesAdded+=addNode(nodes,
                    revisionNode,
                    "OUTCOME_REVISION",
                    safe(d.outcomeRevisionPrior)
                            +"->"
                            +safe(d.outcomeRevisionFinal),
                    mechanism,intervention,context);

            if(!r.activeExperimentId.isEmpty())
                r.edgesAdded+=addEdge(edges,
                        experimentNode,
                        revisionNode,
                        "REVISED_BY");

            if(!safe(d.structuredProvenanceCanonicalKey).isEmpty())
                r.edgesAdded+=addEdge(edges,
                        revisionNode,
                        canonicalNode,
                        "RECOMPUTED_CANONICAL_STATE");
        }

        if(!r.activePolicyKey.isEmpty()){
            r.nodesAdded+=addNode(nodes,
                    policyNode,
                    "POLICY",
                    r.activePolicyKey,
                    mechanism,intervention,context);

            if(!safe(d.structuredProvenanceCanonicalKey).isEmpty())
                r.edgesAdded+=addEdge(edges,
                        canonicalNode,
                        policyNode,
                        "CONTRIBUTED_TO_POLICY");

            if(d.outcomeRevisionPropagationRecomputed)
                r.edgesAdded+=addEdge(edges,
                        revisionNode,
                        policyNode,
                        "TRIGGERED_POLICY_RECOMPUTE");
        }

        if(d.policyTransferEvaluated
                && !safe(d.policyTransferSourceContext).isEmpty()
                && !safe(d.policyTransferTargetContext).isEmpty()){

            String source="CTX::"+d.policyTransferSourceContext;
            String target="CTX::"+d.policyTransferTargetContext;

            r.nodesAdded+=addNode(nodes,source,"CONTEXT",
                    d.policyTransferSourceContext,
                    mechanism,intervention,d.policyTransferSourceContext);

            r.nodesAdded+=addNode(nodes,target,"CONTEXT",
                    d.policyTransferTargetContext,
                    mechanism,intervention,d.policyTransferTargetContext);

            r.edgesAdded+=addEdge(edges,
                    source,target,
                    "POLICY_TRANSFER_"+safe(d.policyTransferState));

            if(!r.activePolicyKey.isEmpty())
                r.edgesAdded+=addEdge(edges,
                        policyNode,target,
                        "POLICY_APPLIED_IN_CONTEXT");
        }

        try{
            graph.put("nodes",trim(nodes,120));
            graph.put("edges",trim(edges,180));
            graph.put("updated_at",System.currentTimeMillis());
            graph.put("schema_version","6.7.6");

            p.put("provenance_lineage_graph",graph);
            p.put("last_provenance_lineage_root",r.lineageRootKey);
            p.put("last_provenance_lineage_experiment",r.activeExperimentId);
            p.put("last_provenance_lineage_policy",r.activePolicyKey);
            p.put("last_provenance_lineage_at",System.currentTimeMillis());

            CentralTherapyProfile.replaceProfile(c,p);
        }catch(Exception ignored){}

        r.updated=r.nodesAdded>0||r.edgesAdded>0;
        r.reason=r.updated
                ?"LINEAGE_GRAPH_UPDATED"
                :"NO_NEW_LINEAGE_RELATION";
        r.summary="updated="+r.updated
                +" | nodesAdded="+r.nodesAdded
                +" | edgesAdded="+r.edgesAdded
                +" | experiment="+r.activeExperimentId
                +" | policy="+r.activePolicyKey
                +" | root="+r.lineageRootKey
                +" | reason="+r.reason;

        return r;
    }

    public static String tracePolicy(Context c,String policyKey){
        if(c==null||policyKey==null||policyKey.isEmpty())
            return "";

        JSONObject p=CentralTherapyProfile.loadProfile(c);
        JSONObject graph=p.optJSONObject("provenance_lineage_graph");
        if(graph==null)return "";

        JSONArray nodes=graph.optJSONArray("nodes");
        JSONArray edges=graph.optJSONArray("edges");

        String target="POLICY::"+policyKey;
        StringBuilder sb=new StringBuilder();
        sb.append("POLICY=").append(policyKey);

        if(edges!=null){
            int shown=0;
            for(int i=edges.length()-1;i>=0&&shown<12;i--){
                JSONObject e=edges.optJSONObject(i);
                if(e==null)continue;

                String from=e.optString("from","");
                String to=e.optString("to","");
                if(target.equals(to)||target.equals(from)){
                    sb.append("\n")
                      .append(from)
                      .append(" --")
                      .append(e.optString("relation",""))
                      .append("--> ")
                      .append(to);
                    shown++;
                }
            }
        }

        return sb.toString();
    }

    public static String instruction(Result r){
        if(r==null||!r.evaluated)return "";
        if(r.updated)
            return "PROVENANCE_LINEAGE=UPDATED. 현재 learning/policy 결정은 experiment→commit→canonical identity→revision/recompute→policy/context transfer의 감사 추적 그래프에 연결되어 있다.";
        return "";
    }

    private static int addNode(
            JSONArray nodes,
            String id,
            String type,
            String label,
            String mechanism,
            String intervention,
            String context){

        if(id==null||id.endsWith("::"))return 0;
        if(findNode(nodes,id)!=null)return 0;

        try{
            JSONObject n=new JSONObject();
            n.put("id",id);
            n.put("type",type);
            n.put("label",label);
            n.put("mechanism",mechanism);
            n.put("intervention_id",intervention);
            n.put("context_scope",context);
            n.put("created_at",System.currentTimeMillis());
            nodes.put(n);
            return 1;
        }catch(Exception e){
            return 0;
        }
    }

    private static int addEdge(
            JSONArray edges,
            String from,
            String to,
            String relation){

        if(from==null||to==null
                ||from.endsWith("::")
                ||to.endsWith("::"))
            return 0;

        for(int i=0;i<edges.length();i++){
            JSONObject e=edges.optJSONObject(i);
            if(e==null)continue;

            if(from.equals(e.optString("from",""))
                    &&to.equals(e.optString("to",""))
                    &&relation.equals(e.optString("relation","")))
                return 0;
        }

        try{
            JSONObject e=new JSONObject();
            e.put("from",from);
            e.put("to",to);
            e.put("relation",relation);
            e.put("created_at",System.currentTimeMillis());
            edges.put(e);
            return 1;
        }catch(Exception ex){
            return 0;
        }
    }

    private static JSONObject findNode(JSONArray nodes,String id){
        if(nodes==null)return null;
        for(int i=0;i<nodes.length();i++){
            JSONObject n=nodes.optJSONObject(i);
            if(n!=null&&id.equals(n.optString("id","")))
                return n;
        }
        return null;
    }

    private static JSONArray trim(JSONArray a,int max){
        JSONArray out=new JSONArray();
        int start=Math.max(0,a.length()-max);
        for(int i=start;i<a.length();i++)
            out.put(a.opt(i));
        return out;
    }

    private static String firstNonEmpty(String a,String b){
        return a!=null&&!a.isEmpty()?a:(b==null?"":b);
    }

    private static String safe(String s){
        return s==null?"":s;
    }
}
