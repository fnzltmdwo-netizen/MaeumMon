package com.maeummon.app;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;

public class DiarySecurity {

    public static boolean isEnabled(Context context) {
        SharedPreferences prefs = context.getSharedPreferences(AppPrefs.PREFS, Context.MODE_PRIVATE);
        return !prefs.getString(AppPrefs.KEY_DIARY_PIN_HASH, "").isEmpty();
    }

    public static boolean isUnlocked(Context context) {
        SharedPreferences prefs = context.getSharedPreferences(AppPrefs.PREFS, Context.MODE_PRIVATE);
        return System.currentTimeMillis() < prefs.getLong(AppPrefs.KEY_DIARY_UNLOCK_UNTIL, 0L);
    }

    public static void unlockForFiveMinutes(Context context) {
        context.getSharedPreferences(AppPrefs.PREFS, Context.MODE_PRIVATE)
                .edit()
                .putLong(AppPrefs.KEY_DIARY_UNLOCK_UNTIL, System.currentTimeMillis() + 5 * 60 * 1000L)
                .apply();
    }

    public static void lockNow(Context context) {
        context.getSharedPreferences(AppPrefs.PREFS, Context.MODE_PRIVATE)
                .edit()
                .putLong(AppPrefs.KEY_DIARY_UNLOCK_UNTIL, 0L)
                .apply();
    }

    public static void setPin(Context context, String pin) {
        context.getSharedPreferences(AppPrefs.PREFS, Context.MODE_PRIVATE)
                .edit()
                .putString(AppPrefs.KEY_DIARY_PIN_HASH, sha256(pin))
                .putLong(AppPrefs.KEY_DIARY_UNLOCK_UNTIL, 0L)
                .apply();
    }

    public static void clearPin(Context context) {
        context.getSharedPreferences(AppPrefs.PREFS, Context.MODE_PRIVATE)
                .edit()
                .remove(AppPrefs.KEY_DIARY_PIN_HASH)
                .putLong(AppPrefs.KEY_DIARY_UNLOCK_UNTIL, 0L)
                .apply();
    }

    public static boolean verify(Context context, String pin) {
        String saved = context.getSharedPreferences(AppPrefs.PREFS, Context.MODE_PRIVATE)
                .getString(AppPrefs.KEY_DIARY_PIN_HASH, "");
        return !saved.isEmpty() && saved.equals(sha256(pin));
    }

    public static boolean redirectToUnlockIfNeeded(android.app.Activity activity) {
        if (!isEnabled(activity) || isUnlocked(activity)) return false;

        Intent intent = new Intent(activity, DiaryUnlockActivity.class);
        intent.putExtra("target", activity.getClass().getName());
        activity.startActivity(intent);
        activity.finish();
        return true;
    }

    private static String sha256(String input) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] bytes = digest.digest(input.getBytes(StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            for (byte b : bytes) sb.append(String.format("%02x", b));
            return sb.toString();
        } catch (Exception e) {
            return input;
        }
    }
}
