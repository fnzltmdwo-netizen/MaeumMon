package com.maeummon.app.clinical;

import android.content.Context;
import org.json.*;
import java.util.*;

public final class ResponsePrecisionDirectnessGuardRC9 {
    private ResponsePrecisionDirectnessGuardRC9(){}

    public static final class Check {
        public boolean pass=true;
        public boolean rewriteRequired=false;
        public final List<String> failures=new ArrayList<>();
        public String instruction="";
        public String summary="PASS";

        void fail(String code){
            pass=false;
            rewriteRequired=true;
            failures.add(code);
        }
    }

    public static Check inspect(
            Context c,String userText,String response,ClinicalDecisionRC7 d){

        Check x=new Check();
        String u=userText==null?"":userText.trim();
        String r=response==null?"":response.trim();
        JSONObject f=CentralTherapyProfile.loadFormulation(c);

        String move=d==null?"":safe(d.move);
        String need=f.optString("response_need","");
        boolean centralUsable=f.optBoolean("central_insight_usable",false);

        // 1. Excessive hedging that hides the central answer.
        int hedgeCount=countMarkers(r,new String[]{
                "일 수도","일수도","가능성도 있고","그럴 수도",
                "아닐 수도","어쩌면","어느 정도","한편으로는",
                "또 다른 가능성","단정할 수는 없지만"
        });
        if(hedgeCount>=4){
            x.fail("EXCESSIVE_HEDGING");
        }

        // 2. Central answer appears too late.
        if(("FORMULATE".equals(move)||"INTERVENE".equals(move))
                && centralUsable
                && r.length()>500
                && !containsCoreCue(firstChunk(r,240))){
            x.fail("CORE_INSIGHT_TOO_LATE");
        }

        // 3. Generic throat-clearing before answer.
        if(startsWithAny(r,
                "우선 이 상황을 여러 관점에서 볼 수 있어",
                "이 문제는 복합적이어서 한 가지로 말하기 어렵지만",
                "여러 가능성을 종합적으로 고려해보면",
                "조금 길게 설명해보자면")
                && r.length()>360){
            x.fail("THROAT_CLEARING");
        }

        // 4. User asks a direct yes/no-ish question but answer never takes a position.
        if(containsAny(u,
                "내가 잘못한 거야","이게 이상한 거야","내가 너무 예민한 거야",
                "이게 공황이야","이게 거절이야","내가 이기적인 거야")
                && !containsAny(firstChunk(r,260),
                    "아니","그렇다고 보기","지금 정보로는","맞다고 보긴",
                    "핵심은","가깝","단정할 수"))
            x.fail("DIRECT_QUESTION_NOT_DIRECTLY_ADDRESSED");

        // 5. FORMULATE should not present more than 2 competing possibilities by default.
        if("FORMULATE".equals(move)){
            int branchMarkers=countMarkers(r,new String[]{
                    "첫째","둘째","셋째","한편","또 다른 가능성",
                    "가능성 A","가능성 B","가능성 C"
            });
            if(branchMarkers>=3){
                x.fail("TOO_MANY_USER_FACING_HYPOTHESES");
            }
        }

        // 6. Repeated qualifications around same claim.
        if(containsAny(r,
                "확실하진 않지만 단정할 수는 없고",
                "가능성이 있어 보이지만 아닐 수도 있고",
                "그럴 수도 있지만 꼭 그렇다는 건 아니고")){
            x.fail("REDUNDANT_QUALIFICATION");
        }

        // 7. INTERVENE should name the one next step clearly.
        if("INTERVENE".equals(move)
                && !containsAny(firstChunk(r,420),
                    "먼저","한 가지","지금 해볼 건","이번에는","다음 행동은","추천하는 건"))
            x.fail("INTERVENTION_NEXT_STEP_UNCLEAR");

        // 8. ASK should end with the actual discriminator question.
        if("ASK".equals(move)){
            String last=lastSentence(r);
            if(!last.contains("?")){
                x.fail("ASK_NOT_ENDING_IN_QUESTION");
            }
        }

        // 9. Excessive abstract nouns / counseling jargon in user-facing prose.
        int abstractCount=countMarkers(r,new String[]{
                "인지적 해석","정서적 반응","유지기제","상호작용 패턴",
                "내적 신념","핵심 신념","조건부 규칙","행동적 회피",
                "정서조절 역량","대인관계 역동"
        });
        if(abstractCount>=3){
            x.fail("ABSTRACT_LANGUAGE_OVERLOAD");
        }

        // 10. If user wants understanding, answer should include a concise "because" structure.
        if("UNDERSTANDING".equalsIgnoreCase(need)
                && containsAny(u,"왜","이유")
                && !containsAny(r,"왜냐하면","때문이야","때문에","핵심은","그래서")){
            x.fail("UNDERSTANDING_WITHOUT_CAUSAL_EXPLANATION");
        }

        if(!x.pass){
            x.instruction=buildRewriteInstruction(x,d);
        }
        x.summary=x.pass?"PASS":"FAIL "+x.failures.toString();
        return x;
    }

    public static String buildRewriteInstruction(Check x,ClinicalDecisionRC7 d){
        String move=d==null?"":safe(d.move);
        return "RESPONSE_PRECISION_GUARD_FAIL=true. 응답을 다시 쓸 때 "
                +"첫 1~2문장 안에 결론 또는 핵심 구조를 먼저 말한다. "
                +"불확실성은 한 문장만 남기고 중복 완곡표현을 줄인다. "
                +"FORMULATE는 핵심 설명 1개, INTERVENE는 다음 행동 1개, ASK는 마지막에 질문 1개로 끝낸다. "
                +"추상적인 상담용어보다 사용자가 쓴 말과 일상어를 사용한다. current_move="+move
                +", failures="+x.failures;
    }

    private static boolean containsCoreCue(String s){
        return containsAny(s,
                "핵심은","지금 보면","정리하면","가까워 보여",
                "중요한 건","문제의 중심은","지금은","먼저");
    }

    private static String firstChunk(String s,int max){
        if(s==null)return "";
        return s.length()<=max?s:s.substring(0,max);
    }

    private static String lastSentence(String s){
        if(s==null)return "";
        String[] xs=s.split("(?<=[.!?])\\s+|\\n+");
        for(int i=xs.length-1;i>=0;i--){
            String x=xs[i].trim();
            if(!x.isEmpty())return x;
        }
        return s.trim();
    }

    private static int countMarkers(String s,String[] xs){
        int n=0;
        if(s==null)return 0;
        for(String x:xs)if(s.contains(x))n++;
        return n;
    }

    private static boolean startsWithAny(String s,String... xs){
        if(s==null)return false;
        String t=s.trim();
        for(String x:xs)if(t.startsWith(x))return true;
        return false;
    }

    private static boolean containsAny(String s,String... xs){
        if(s==null)return false;
        for(String x:xs){
            if(x!=null&&!x.isEmpty()&&s.contains(x))return true;
        }
        return false;
    }

    private static String safe(String s){return s==null?"":s;}
}
