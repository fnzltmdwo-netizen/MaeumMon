package com.maeummon.app.clinical;

import android.content.Context;
import org.json.*;
import java.util.*;

public final class EvidenceProvenanceTraceabilityRC8 {
    private EvidenceProvenanceTraceabilityRC8(){}

    public static final String USER_DIRECT="USER_DIRECT";
    public static final String USER_CORRECTION="USER_CORRECTION";
    public static final String SESSION_INFERENCE="SESSION_INFERENCE";
    public static final String STABLE_MEMORY="STABLE_MEMORY";
    public static final String CHECKIN="CHECKIN";
    public static final String DIARY="DIARY";
    public static final String INTERVENTION_OUTCOME="INTERVENTION_OUTCOME";
    public static final String UNKNOWN="UNKNOWN";

    public static final class TraceResult {
        public int total=0;
        public int direct=0;
        public int inferred=0;
        public int unknown=0;
        public int stale=0;
        public String summary="";
    }

    public static TraceResult trace(Context c,String userText){
        TraceResult r=new TraceResult();
        if(c==null)return r;

        JSONObject f=CentralTherapyProfile.loadFormulation(c);
        JSONObject p=CentralTherapyProfile.loadProfile(c);
        JSONArray ledger=f.optJSONArray("evidence_ledger");
        if(ledger==null)ledger=new JSONArray();

        // Current direct user evidence
        if(userText!=null&&!userText.trim().isEmpty()){
            JSONObject e=new JSONObject();
            try{
                e.put("text",compact(userText,260));
                e.put("source_type",detectCurrentSource(userText));
                e.put("source_surface","COUNSELING");
                e.put("explicit",true);
                e.put("time",System.currentTimeMillis());
                e.put("confidence",0.95);
                e.put("active",true);
                ledger.put(e);
            }catch(Exception ignored){}
        }

        // Stable profile evidence references
        JSONArray stable=p.optJSONArray("stable_profile");
        if(stable!=null){
            int start=Math.max(0,stable.length()-4);
            for(int i=start;i<stable.length();i++){
                JSONObject s=stable.optJSONObject(i);
                if(s==null)continue;
                String text=s.optString("text","");
                if(text.isEmpty())continue;
                putIfMissing(ledger,text,STABLE_MEMORY,"CENTRAL_PROFILE",
                        s.optDouble("confidence",0.70),s.optLong("time",0));
            }
        }

        // Check-in evidence references
        JSONArray checkins=p.optJSONArray("checkin_history");
        if(checkins!=null&&checkins.length()>0){
            JSONObject x=checkins.optJSONObject(checkins.length()-1);
            if(x!=null){
                String text="emotion="+x.optString("emotion","")+"; note="+x.optString("note","");
                putIfMissing(ledger,text,CHECKIN,"CHECK_IN",0.72,x.optLong("time",0));
            }
        }

        // Diary evidence references
        JSONArray diaries=p.optJSONArray("diary_insights");
        if(diaries!=null&&diaries.length()>0){
            JSONObject x=diaries.optJSONObject(diaries.length()-1);
            if(x!=null){
                putIfMissing(ledger,x.optString("text",""),DIARY,
                        x.optString("source","DIARY"),0.70,x.optLong("time",0));
            }
        }

        // Intervention outcome as evidence
        String outcome=f.optString("last_intervention_outcome","");
        if(!outcome.isEmpty()){
            putIfMissing(ledger,"intervention_outcome="+outcome,
                    INTERVENTION_OUTCOME,"REVIEW",0.78,System.currentTimeMillis());
        }

        ledger=tailAndDedupe(ledger,60);

        long now=System.currentTimeMillis();
        for(int i=0;i<ledger.length();i++){
            JSONObject e=ledger.optJSONObject(i);
            if(e==null)continue;
            r.total++;
            String source=e.optString("source_type",UNKNOWN);
            if(USER_DIRECT.equals(source)||USER_CORRECTION.equals(source))r.direct++;
            else if(SESSION_INFERENCE.equals(source))r.inferred++;
            else if(UNKNOWN.equals(source))r.unknown++;

            long time=e.optLong("time",0);
            if(time>0){
                long days=Math.max(0,(now-time)/(24L*60L*60L*1000L));
                if(days>90)r.stale++;
            }
        }

        try{
            f.put("evidence_ledger",ledger);
            f.put("evidence_provenance_summary",
                    "total="+r.total+", direct="+r.direct+", inferred="+r.inferred
                            +", unknown="+r.unknown+", stale="+r.stale);
            f.put("evidence_provenance_updated_at",System.currentTimeMillis());
            CentralTherapyProfile.replaceFormulation(c,f);
        }catch(Exception ignored){}

        r.summary="total="+r.total+", direct="+r.direct+", inferred="+r.inferred
                +", unknown="+r.unknown+", stale="+r.stale;
        return r;
    }

    public static String instruction(TraceResult r){
        if(r==null||r.total==0)return "";
        StringBuilder b=new StringBuilder();
        b.append("EVIDENCE_PROVENANCE=true. ");
        b.append("근거를 사용할 때 source_type을 구분한다. 직접 사용자 발화/정정은 사실 근거로, ");
        b.append("SESSION_INFERENCE는 잠정 해석으로만 다룬다. UNKNOWN 근거를 핵심 formulation의 확정 근거로 쓰지 않는다. ");
        if(r.stale>0)b.append("90일 초과 evidence는 현재 상황에 그대로 일반화하지 않는다. ");
        b.append(r.summary);
        return b.toString();
    }

    public static String currentSourceSummary(Context c){
        JSONObject f=CentralTherapyProfile.loadFormulation(c);
        return f.optString("evidence_provenance_summary","");
    }

    private static String detectCurrentSource(String t){
        if(has(t,"정정할게","아까 잘못 말","그건 아니야","다시 생각해보니"))
            return USER_CORRECTION;
        return USER_DIRECT;
    }

    private static void putIfMissing(JSONArray ledger,String text,String source,
                                     String surface,double confidence,long time){
        if(text==null||text.trim().isEmpty())return;
        String compact=compact(text,260);
        for(int i=0;i<ledger.length();i++){
            JSONObject o=ledger.optJSONObject(i);
            if(o!=null&&compact.equals(o.optString("text",""))
                    &&source.equals(o.optString("source_type","")))return;
        }
        JSONObject e=new JSONObject();
        try{
            e.put("text",compact);
            e.put("source_type",source);
            e.put("source_surface",surface);
            e.put("explicit",USER_DIRECT.equals(source)||USER_CORRECTION.equals(source));
            e.put("confidence",confidence);
            e.put("time",time);
            e.put("active",true);
            ledger.put(e);
        }catch(Exception ignored){}
    }

    private static JSONArray tailAndDedupe(JSONArray src,int max){
        LinkedHashMap<String,JSONObject> map=new LinkedHashMap<>();
        for(int i=0;i<src.length();i++){
            JSONObject o=src.optJSONObject(i);
            if(o==null)continue;
            String key=o.optString("source_type",UNKNOWN)+"|"+o.optString("text","");
            map.put(key,o);
        }
        List<JSONObject> vals=new ArrayList<>(map.values());
        int start=Math.max(0,vals.size()-max);
        JSONArray out=new JSONArray();
        for(int i=start;i<vals.size();i++)out.put(vals.get(i));
        return out;
    }

    private static boolean has(String s,String... xs){
        if(s==null)return false;
        for(String x:xs)if(s.contains(x))return true;
        return false;
    }

    private static String compact(String s,int max){
        s=s==null?"":s.trim();
        return s.length()<=max?s:s.substring(0,max);
    }
}
