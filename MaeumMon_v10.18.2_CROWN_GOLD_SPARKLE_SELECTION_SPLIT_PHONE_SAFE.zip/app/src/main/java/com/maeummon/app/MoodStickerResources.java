package com.maeummon.app;

public final class MoodStickerResources {
    private MoodStickerResources() {}

    public static int imageForLabel(String label) {
        if ("좋음".equals(label)) return R.drawable.mood_good;
        if ("잔잔".equals(label)) return R.drawable.mood_calm;
        if ("지침".equals(label)) return R.drawable.mood_tired;
        if ("슬픔".equals(label)) return R.drawable.mood_sad;
        if ("불안".equals(label)) return R.drawable.mood_anxious;
        if ("화남".equals(label)) return R.drawable.mood_angry;
        if ("위로".equals(label)) return R.drawable.mood_comfort;
        if ("잠옴".equals(label)) return R.drawable.mood_sleepy;
        return R.drawable.mood_calm;
    }
}
