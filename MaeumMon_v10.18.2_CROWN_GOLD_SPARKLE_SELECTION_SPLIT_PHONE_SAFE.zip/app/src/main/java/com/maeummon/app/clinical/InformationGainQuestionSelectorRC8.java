package com.maeummon.app.clinical;

import android.content.Context;
import org.json.*;
import java.util.*;

public final class InformationGainQuestionSelectorRC8 {
    private InformationGainQuestionSelectorRC8(){}

    public static final class Selection {
        public String target="";
        public ClinicalKnowledgeRC7.Unit unit;
        public double informationGain=0.0;
        public String rationale="";
    }

    private static final class TargetModel {
        final String target;
        final Map<String,Double> impacts=new LinkedHashMap<>();
        final double baseUtility;
        TargetModel(String target,double baseUtility){
            this.target=target; this.baseUtility=baseUtility;
        }
        TargetModel impact(String hypothesis,double value){
            impacts.put(hypothesis,value); return this;
        }
    }

    public static Selection select(
            Context c,
            ClinicalDecisionRC7 d,
            Set<String> askedIds,
            String history
    ){
        Selection best=new Selection();
        JSONObject formulation=CentralTherapyProfile.loadFormulation(c);
        JSONArray hypotheses=formulation.optJSONArray("alternative_hypotheses");

        List<TargetModel> models=modelsFor(d,hypotheses);
        Set<String> known=new HashSet<>(d.known);
        JSONArray storedKnown=formulation.optJSONArray("known_variables");
        if(storedKnown!=null){
            for(int i=0;i<storedKnown.length();i++){
                String x=storedKnown.optString(i,"");
                if(!x.isEmpty())known.add(x);
            }
        }

        double currentEntropy=entropy(hypotheses);
        for(TargetModel model:models){
            if(known.contains(model.target))continue;

            ClinicalKnowledgeRC7.Unit q=bestUnitForTarget(c,model.target,askedIds,history);
            if(q==null)continue;

            double separation=expectedSeparation(hypotheses,model);
            double uncertaintyBonus=currentEntropy*0.22;
            double missingBonus=d.missing.contains(model.target)?0.12:0.0;
            double evidenceBonus=Math.max(0.0,Math.min(0.12,(q.weight-0.5)*0.24));
            double repeatPenalty=(history!=null && !q.question.isEmpty() && history.contains(q.question))?0.45:0.0;

            double gain=separation + uncertaintyBonus + missingBonus
                    + model.baseUtility + evidenceBonus - repeatPenalty;

            if(gain>best.informationGain){
                best.target=model.target;
                best.unit=q;
                best.informationGain=gain;
                best.rationale=buildRationale(model,separation,currentEntropy,missingBonus);
            }
        }

        // Generic fallback: still rank actual QDUs if domain-specific model has no usable question.
        if(best.unit==null){
            for(ClinicalKnowledgeRC7.Unit u:ClinicalKnowledgeRC7.all(c)){
                if(!"QDU".equals(u.type)||u.question.isEmpty()||askedIds.contains(u.id))continue;
                if(known.contains(u.target))continue;
                int overlap=0;
                for(String s:u.signals)if(d.signals.contains(s))overlap++;
                if(overlap==0)continue;
                double gain=(u.weight*0.35)+(overlap*0.12)+(d.missing.contains(u.target)?0.15:0);
                if(history!=null&&history.contains(u.question))gain-=0.45;
                if(gain>best.informationGain){
                    best.target=u.target; best.unit=u; best.informationGain=gain;
                    best.rationale="generic evidence-weighted fallback";
                }
            }
        }
        return best;
    }

    private static List<TargetModel> modelsFor(ClinicalDecisionRC7 d,JSONArray hypotheses){
        List<TargetModel> out=new ArrayList<>();
        Set<String> ids=hypothesisIds(hypotheses);

        if(ids.contains("normal_response_variation")
                || ids.contains("relationship_distance_change")
                || d.signals.contains("reply_delay")){
            out.add(new TargetModel("baseline_relationship_change",0.18)
                    .impact("normal_response_variation",+1.0)
                    .impact("relationship_distance_change",-0.9)
                    .impact("rejection_interpretation_amplification",0.0)
                    .impact("actual_rejection_or_conflict",-0.2));

            out.add(new TargetModel("recent_conflict",0.16)
                    .impact("normal_response_variation",-0.2)
                    .impact("relationship_distance_change",+0.45)
                    .impact("rejection_interpretation_amplification",-0.15)
                    .impact("actual_rejection_or_conflict",+1.0));

            out.add(new TargetModel("selective_change",0.14)
                    .impact("normal_response_variation",-0.8)
                    .impact("relationship_distance_change",+1.0)
                    .impact("rejection_interpretation_amplification",+0.1)
                    .impact("actual_rejection_or_conflict",+0.45));

            out.add(new TargetModel("meaning_attribution",0.12)
                    .impact("normal_response_variation",-0.1)
                    .impact("relationship_distance_change",0.0)
                    .impact("rejection_interpretation_amplification",+1.0)
                    .impact("actual_rejection_or_conflict",+0.05));
        }

        if(ids.contains("evaluation_threat")||d.signals.contains("work_stress")){
            out.add(new TargetModel("evaluation_meaning",0.18)
                    .impact("evaluation_threat",+1.0)
                    .impact("workload_stress",-0.35)
                    .impact("interpersonal_work_stress",+0.1)
                    .impact("exhaustion_or_burnout",-0.15));

            out.add(new TargetModel("workload_vs_relationship",0.17)
                    .impact("evaluation_threat",0.0)
                    .impact("workload_stress",+0.9)
                    .impact("interpersonal_work_stress",-0.9)
                    .impact("exhaustion_or_burnout",+0.15));

            out.add(new TargetModel("recent_specific_episode",0.11)
                    .impact("evaluation_threat",+0.25)
                    .impact("workload_stress",+0.2)
                    .impact("interpersonal_work_stress",+0.25)
                    .impact("exhaustion_or_burnout",0.0));
        }

        if(ids.contains("avoidance_negative_reinforcement")
                || d.signals.contains("avoidance")){
            out.add(new TargetModel("short_term_relief",0.20)
                    .impact("avoidance_negative_reinforcement",+1.0)
                    .impact("insufficient_information",-0.55));
            out.add(new TargetModel("consequence",0.15)
                    .impact("avoidance_negative_reinforcement",+0.75)
                    .impact("insufficient_information",-0.25));
            out.add(new TargetModel("values",0.12)
                    .impact("avoidance_negative_reinforcement",+0.2)
                    .impact("insufficient_information",0.0));
        }

        if(d.signals.contains("anxiety")){
            out.add(new TargetModel("body_activation",0.13));
            out.add(new TargetModel("emotion_differentiation",0.12));
        }

        // Existing missing-information targets remain candidates.
        for(String target:d.missing){
            boolean already=false;
            for(TargetModel m:out)if(target.equals(m.target)){already=true;break;}
            if(!already)out.add(new TargetModel(target,0.08));
        }
        return out;
    }

    private static double expectedSeparation(JSONArray hypotheses,TargetModel m){
        if(hypotheses==null||hypotheses.length()<2)return 0.08;

        double weightedMean=0, weightSum=0;
        for(int i=0;i<hypotheses.length();i++){
            JSONObject h=hypotheses.optJSONObject(i); if(h==null)continue;
            double p=h.optDouble("confidence",0);
            double impact=m.impacts.containsKey(h.optString("id",""))
                    ?m.impacts.get(h.optString("id","")):0.0;
            weightedMean+=p*impact; weightSum+=p;
        }
        if(weightSum<=0)return 0.08;
        weightedMean/=weightSum;

        double variance=0;
        for(int i=0;i<hypotheses.length();i++){
            JSONObject h=hypotheses.optJSONObject(i); if(h==null)continue;
            double p=h.optDouble("confidence",0)/weightSum;
            double impact=m.impacts.containsKey(h.optString("id",""))
                    ?m.impacts.get(h.optString("id","")):0.0;
            variance+=p*Math.pow(impact-weightedMean,2);
        }
        return Math.min(0.55,Math.sqrt(variance)*0.42);
    }

    private static double entropy(JSONArray hypotheses){
        if(hypotheses==null||hypotheses.length()==0)return 0;
        double h=0,sum=0;
        for(int i=0;i<hypotheses.length();i++){
            JSONObject o=hypotheses.optJSONObject(i); if(o!=null)sum+=o.optDouble("confidence",0);
        }
        if(sum<=0)return 0;
        for(int i=0;i<hypotheses.length();i++){
            JSONObject o=hypotheses.optJSONObject(i); if(o==null)continue;
            double p=o.optDouble("confidence",0)/sum;
            if(p>0)h-=p*Math.log(p);
        }
        double max=Math.log(Math.max(2,hypotheses.length()));
        return max<=0?0:Math.min(1.0,h/max);
    }

    private static ClinicalKnowledgeRC7.Unit bestUnitForTarget(
            Context c,String target,Set<String> asked,String history){
        ClinicalKnowledgeRC7.Unit best=null;
        double score=-999;
        for(ClinicalKnowledgeRC7.Unit u:ClinicalKnowledgeRC7.all(c)){
            if(!"QDU".equals(u.type)||!target.equals(u.target)||u.question.isEmpty())continue;
            if(asked.contains(u.id))continue;
            double s=u.weight;
            if(history!=null&&history.contains(u.question))s-=1.0;
            if(s>score){score=s;best=u;}
        }
        if(best==null){
            ClinicalKnowledgeRC7.Unit fallback=ClinicalKnowledgeRC7.fallbackForTarget(target);
            if(fallback!=null&&!asked.contains(fallback.id))best=fallback;
        }
        return best;
    }

    private static String buildRationale(
            TargetModel model,double separation,double entropy,double missingBonus){
        return "target="+model.target
                +", separation="+round(separation)
                +", hypothesis_uncertainty="+round(entropy)
                +", missing_bonus="+round(missingBonus);
    }

    private static Set<String> hypothesisIds(JSONArray a){
        Set<String> out=new HashSet<>();
        if(a!=null)for(int i=0;i<a.length();i++){
            JSONObject o=a.optJSONObject(i);
            if(o!=null)out.add(o.optString("id",""));
        }
        return out;
    }

    private static double round(double x){return Math.round(x*1000.0)/1000.0;}
}
