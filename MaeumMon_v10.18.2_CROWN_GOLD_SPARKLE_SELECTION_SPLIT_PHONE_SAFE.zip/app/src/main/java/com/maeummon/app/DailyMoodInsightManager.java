package com.maeummon.app;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * 상담/속마음 기록을 날짜별로 모아 감정 아이콘과 하루 요약을 자동 생성한다.
 * 캘린더 아이콘은 네트워크 없이 즉시 추정하고, 상세 문구는 GPT 결과를 캐시한다.
 */
public final class DailyMoodInsightManager {
    private static final String KEY_CACHE = "auto_daily_mood_insight_cache_v1";
    private DailyMoodInsightManager() {}

    public static final class Insight {
        public String label = "잔잔";
        public String status = "아직 기록이 많지 않아서 오늘 마음을 천천히 보는 중이야.";
        public String summary = "이 날의 기록이 쌓이면 뭐가 힘들었고 뭐가 필요했는지 같이 정리해줄게.";
        public String prescription = "오늘 있었던 일 한 장면만 떠올리고, 그때 마음이 어땠는지만 먼저 봐도 돼.";
        public String trigger = "아직 딱 하나로 말하긴 어려워";
        public String need = "조금 덜 불안한 시간";
        public String strength = "내 마음을 그냥 넘기지 않은 점";
        public boolean generatedByAi = false;
    }

    public static String today() {
        return new SimpleDateFormat("yyyy.MM.dd", Locale.KOREA).format(new Date());
    }

    public static String contextForDate(Context context, String date) {
        StringBuilder sb = new StringBuilder();
        JSONArray records = ChatStorage.getDiaryRecords(context);
        for (int i = records.length() - 1; i >= 0; i--) {
            JSONObject r = records.optJSONObject(i);
            if (r == null) continue;
            String time = r.optString("time", "");
            if (!time.startsWith(date)) continue;
            String text = clean(r.optString("text", ""));
            if (!text.isEmpty()) sb.append("승재: ").append(text).append("\n");
        }

        JSONArray timeline = ChatStorage.getCounselingTimeline(context);
        for (int i = 0; i < timeline.length(); i++) {
            JSONObject r = timeline.optJSONObject(i);
            if (r == null || !r.optString("time", "").startsWith(date)) continue;
            String text = clean(r.optString("text", ""));
            if (text.isEmpty()) continue;
            String role = "assistant".equals(r.optString("role")) ? "어린 승재 상담사" : "승재";
            String line = role + ": " + text;
            if (sb.indexOf(line) < 0) sb.append(line).append("\n");
        }

        JSONObject diary = EmotionDiaryStorage.getEntryByDate(context, date);
        if (diary != null) {
            String text = clean(diary.optString("text", ""));
            if (!text.isEmpty()) sb.append("감정일기: ").append(text).append("\n");
        }
        String out = sb.toString().trim();
        if (out.length() > 7000) out = out.substring(out.length() - 7000);
        return out;
    }


    /**
     * 날짜별로 사용자가 실제로 말한 상담 기록만 모아 수동으로 넘겨볼 수 있게 반환한다.
     * 같은 문장이 diary/timeline 양쪽에 저장되는 경우 timeline을 우선 사용한다.
     */
    public static JSONArray userRecordsForDate(Context context, String date) {
        JSONArray out = new JSONArray();
        JSONArray timeline = ChatStorage.getCounselingTimeline(context);
        for (int i = 0; i < timeline.length(); i++) {
            JSONObject r = timeline.optJSONObject(i);
            if (r == null) continue;
            if (!r.optString("time", "").startsWith(date)) continue;
            if (!"user".equals(r.optString("role", "user"))) continue;
            String text = clean(r.optString("text", ""));
            if (text.isEmpty()) continue;
            JSONObject item = new JSONObject();
            try {
                item.put("time", r.optString("time", ""));
                item.put("text", text);
                out.put(item);
            } catch (Exception ignored) {}
        }
        if (out.length() > 0) return out;

        // 아주 오래된 버전에서 timeline이 없던 기록은 diary 쪽으로 보완한다.
        JSONArray records = ChatStorage.getDiaryRecords(context);
        for (int i = records.length() - 1; i >= 0; i--) {
            JSONObject r = records.optJSONObject(i);
            if (r == null || !r.optString("time", "").startsWith(date)) continue;
            String text = clean(r.optString("text", ""));
            if (text.isEmpty()) continue;
            JSONObject item = new JSONObject();
            try {
                item.put("time", r.optString("time", ""));
                item.put("text", text);
                out.put(item);
            } catch (Exception ignored) {}
        }
        return out;
    }

    public static boolean hasRecords(Context context, String date) {
        return !contextForDate(context, date).trim().isEmpty();
    }

    public static Insight localInsight(Context context, String date) {
        String text = contextForDate(context, date);
        Insight i = new Insight();
        if (text.isEmpty()) return i;
        String t = text.toLowerCase(Locale.KOREA);

        int anxious = score(t, "불안", "걱정", "초조", "무서", "긴장", "패닉", "두렵", "심장", "숨", "떨");
        int sad = score(t, "슬프", "우울", "눈물", "외롭", "허무", "무기력", "속상", "서운", "힘들");
        int angry = score(t, "화나", "짜증", "분노", "열받", "억울", "싫어", "답답");
        int tired = score(t, "피곤", "지쳐", "지침", "졸려", "잠", "기운 없", "번아웃", "쉬고 싶", "아무것도");
        int good = score(t, "좋아", "행복", "기뻐", "즐거", "뿌듯", "편안", "괜찮아졌", "잘했", "신나");
        int comfort = score(t, "위로", "안심", "다독", "부드럽", "자기자비", "나를 사랑", "내 편");

        int max = Math.max(Math.max(Math.max(anxious, sad), Math.max(angry, tired)), Math.max(good, comfort));
        if (max == 0) i.label = "잔잔";
        else if (max == anxious) i.label = "불안";
        else if (max == sad) i.label = "슬픔";
        else if (max == angry) i.label = "화남";
        else if (max == tired) i.label = "지침";
        else if (max == good) i.label = "좋음";
        else i.label = "위로";

        String shortLine = firstMeaningfulUserLine(text);
        i.status = localStatus(i.label);
        i.summary = shortLine.isEmpty() ? localSummary(i.label) : "이 날에는 ‘" + trim(shortLine, 54) + "’라는 마음이 크게 남아 있었어. " + localSummary(i.label);
        i.prescription = localPrescription(i.label);
        i.trigger = inferTrigger(t);
        i.need = inferNeed(i.label);
        i.strength = inferStrength(t);
        return i;
    }

    public static Insight cachedOrLocal(Context context, String date) {
        Insight cached = getCached(context, date);
        return cached != null ? cached : localInsight(context, date);
    }

    public static Insight getCached(Context context, String date) {
        try {
            SharedPreferences p = context.getSharedPreferences(AppPrefs.PREFS, Context.MODE_PRIVATE);
            JSONObject all = new JSONObject(p.getString(KEY_CACHE, "{}"));
            JSONObject o = all.optJSONObject(date);
            if (o == null) return null;
            return fromJson(o, true);
        } catch (Exception e) { return null; }
    }

    public static void saveCached(Context context, String date, JSONObject o) {
        try {
            SharedPreferences p = context.getSharedPreferences(AppPrefs.PREFS, Context.MODE_PRIVATE);
            JSONObject all = new JSONObject(p.getString(KEY_CACHE, "{}"));
            o.put("savedAt", System.currentTimeMillis());
            all.put(date, o);
            p.edit().putString(KEY_CACHE, all.toString()).apply();
        } catch (Exception ignored) {}
    }

    public static void invalidateToday(Context context) {
        invalidate(context, today());
    }

    public static void invalidate(Context context, String date) {
        try {
            SharedPreferences p = context.getSharedPreferences(AppPrefs.PREFS, Context.MODE_PRIVATE);
            JSONObject all = new JSONObject(p.getString(KEY_CACHE, "{}"));
            all.remove(date);
            p.edit().putString(KEY_CACHE, all.toString()).apply();
        } catch (Exception ignored) {}
    }

    public static Insight fromJson(JSONObject o, boolean ai) {
        Insight i = new Insight();
        i.label = normalizeLabel(o.optString("label", "잔잔"));
        i.status = clean(o.optString("status", i.status));
        i.summary = clean(o.optString("summary", i.summary));
        i.prescription = clean(o.optString("prescription", i.prescription));
        i.trigger = clean(o.optString("trigger", i.trigger));
        i.need = clean(o.optString("need", i.need));
        i.strength = clean(o.optString("strength", i.strength));
        i.generatedByAi = ai;
        return i;
    }

    public static String normalizeLabel(String label) {
        for (String x : new String[]{"좋음","잔잔","지침","슬픔","불안","화남","위로","잠옴"}) if (x.equals(label)) return x;
        if (label.contains("기쁨") || label.contains("행복")) return "좋음";
        if (label.contains("흐림") || label.contains("피곤")) return "지침";
        return "잔잔";
    }

    private static int score(String t, String... words) { int n=0; for(String w:words){int p=0;while((p=t.indexOf(w,p))>=0){n++;p+=w.length();}}return n; }
    private static String clean(String s){return s==null?"":s.replaceAll("\\s+"," ").trim();}
    private static String trim(String s,int n){return s.length()<=n?s:s.substring(0,n)+"…";}
    private static String firstMeaningfulUserLine(String text){for(String line:text.split("\\n")){if(line.startsWith("승재: ")){String x=line.substring(4).trim();if(x.length()>4)return x;}}return "";}
    private static String localStatus(String l){switch(l){case"불안":return"마음이 바짝 긴장했던 날";case"슬픔":return"마음이 축 처지고 위로가 필요했던 날";case"화남":return"선 넘었다고 느껴 마음이 올라온 날";case"지침":return"몸과 마음이 함께 지친 날";case"좋음":return"조금 숨통이 트였던 날";case"위로":return"누군가 내 편이 되어주길 바랐던 날";default:return"크게 흔들리기보다 무난히 흘러간 날";}}
    private static String localSummary(String l){switch(l){case"불안":return"오늘은 답을 빨리 찾으려 할수록 마음이 더 급해질 수 있어. 먼저 마음을 진정시키는 쪽이 도움이 돼.";case"슬픔":return"오늘은 문제를 빨리 풀기보다, 상처받은 마음을 먼저 봐주는 게 더 중요해.";case"화남":return"오늘 올라온 화는 괜한 게 아니라, 네가 불편했다는 신호일 수 있어.";case"지침":return"오늘은 더 밀어붙이면 더 지칠 수 있어. 회복이 먼저인 날로 보는 게 맞아.";case"좋음":return"오늘 괜찮았던 이유를 하나라도 알아두면 다음에도 비슷하게 챙기기 쉬워.";case"위로":return"오늘은 스스로를 몰아붙이기보다, 힘들었던 이유를 알아주는 쪽이 더 필요해.";default:return"조용히 지나간 날도 중요한 기록이야. 이런 날이 쌓이면 내 마음 리듬이 보여.";}}
    private static String localPrescription(String l){switch(l){case"불안":return"지금 확실한 것 한 가지만 적고, 나머지 걱정은 잠깐 미뤄두자.";case"슬픔":return"오늘 해야 할 일 하나를 줄이고, 조용히 쉬는 시간을 20분만 만들어보자.";case"화남":return"무엇이 불편했는지 한 문장으로 적어보고, 필요하면 그 말만 짧게 꺼내보자.";case"지침":return"물, 밥, 쉬기, 잠 중에서 지금 제일 비어 있는 것 하나부터 채우자.";case"좋음":return"오늘 괜찮았던 장면 하나를 적어두고, 내일도 비슷하게 챙겨보자.";case"위로":return"오늘의 나에게 너무 심한 말은 멈추고, 이해하는 문장 하나만 건네보자.";default:return"오늘 나를 덜 힘들게 한 작은 습관 하나를 떠올려보고 그대로 반복해보자.";}}
    private static String inferTrigger(String t){if(t.contains("회사")||t.contains("업무")||t.contains("일 "))return"업무·성과 압박";if(t.contains("사람")||t.contains("친구")||t.contains("연락")||t.contains("관계"))return"사람관계와 상대 반응";if(t.contains("몸")||t.contains("배")||t.contains("통증")||t.contains("피곤"))return"몸의 불편감과 피로";if(t.contains("돈")||t.contains("대출"))return"경제적 부담";return"여러 상황이 겹친 복합적인 부담";}
    private static String inferNeed(String l){switch(l){case"불안":return"마음을 조금 진정시키는 시간";case"슬픔":return"마음을 알아봐주는 위로";case"화남":return"불편하다고 말할 수 있는 힘";case"지침":return"휴식과 에너지 채우기";case"좋음":return"좋은 흐름 이어가기";default:return"내 편이 되어주는 시선";}}
    private static String inferStrength(String t){if(t.contains("말")||t.contains("상담")||t.contains("생각"))return"속마음을 말로 꺼내본 점";return"내 상태를 그냥 넘기지 않고 남겨둔 점";}
}
