package com.maeummon.app;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.LinkedHashSet;
import java.util.Set;

public class YoungSeungjaeHome {


    public static String getOutfit(Context context) {
        SharedPreferences prefs = context.getSharedPreferences(AppPrefs.PREFS, Context.MODE_PRIVATE);
        return "hoodie";
    }

    public static void setOutfit(Context context, String outfit) {
        // outfit customization removed
    }

    public static String getOutfitName(Context context) {
        return getOutfitName(getOutfit(context));
    }

    public static String getOutfitName(String outfit) {
        return "민트 후드";
    }

    public static int getOutfitPreviewRes(Context context) {
        return R.drawable.young_seungjae_wave;
    }

    public static int getOutfitPreviewResByName(String outfit) {
        return R.drawable.young_seungjae_wave;
    }

    public static boolean canUseOutfit(Context context, String outfit) {
        int level = CompanionProfile.level(CompanionProfile.getAffection(context));
        return true;
    }

    public static String getUnlockHint(String outfit) {
        return "";
    }


    public static JSONArray getTodayTodos(Context context) {
        SharedPreferences prefs = context.getSharedPreferences(AppPrefs.PREFS, Context.MODE_PRIVATE);
        String today = EmotionDiaryStorage.today();
        try {
            JSONObject root = new JSONObject(prefs.getString(AppPrefs.KEY_TODAY_TODOS, "{}"));
            if (!today.equals(root.optString("date"))) {
                return createDefaultTodos(context);
            }
            JSONArray items = root.optJSONArray("items");
            if (items == null || items.length() != 3) return createDefaultTodos(context);
            return items;
        } catch (Exception e) {
            return createDefaultTodos(context);
        }
    }

    private static JSONArray createDefaultTodos(Context context) {
        JSONArray items = new JSONArray();
        for (int i = 0; i < 3; i++) {
            JSONObject obj = new JSONObject();
            try {
                obj.put("text", "");
                obj.put("done", false);
            } catch (Exception ignored) {}
            items.put(obj);
        }
        saveTodos(context, items);
        return items;
    }

    public static void saveTodos(Context context, JSONArray items) {
        try {
            JSONObject root = new JSONObject();
            root.put("date", EmotionDiaryStorage.today());
            root.put("items", items);
            context.getSharedPreferences(AppPrefs.PREFS, Context.MODE_PRIVATE)
                    .edit().putString(AppPrefs.KEY_TODAY_TODOS, root.toString()).apply();
        } catch (Exception ignored) {}
    }

    public static void saveTodos(Context context, String[] texts, boolean[] dones) {
        JSONArray items = new JSONArray();
        for (int i = 0; i < 3; i++) {
            JSONObject obj = new JSONObject();
            try {
                obj.put("text", texts[i] == null ? "" : texts[i].trim());
                obj.put("done", dones[i]);
            } catch (Exception ignored) {}
            items.put(obj);
        }
        saveTodos(context, items);
    }

    public static int countNonEmptyTodos(Context context) {
        JSONArray items = getTodayTodos(context);
        int count = 0;
        for (int i = 0; i < items.length(); i++) {
            JSONObject obj = items.optJSONObject(i);
            if (obj != null && !obj.optString("text").trim().isEmpty()) count++;
        }
        return count;
    }

    public static int countDoneTodos(Context context) {
        JSONArray items = getTodayTodos(context);
        int count = 0;
        for (int i = 0; i < items.length(); i++) {
            JSONObject obj = items.optJSONObject(i);
            if (obj != null && obj.optBoolean("done")) count++;
        }
        return count;
    }

    public static boolean rewardIfAllDone(Context context) {
        SharedPreferences prefs = context.getSharedPreferences(AppPrefs.PREFS, Context.MODE_PRIVATE);
        String today = EmotionDiaryStorage.today();
        if (today.equals(prefs.getString(AppPrefs.KEY_TODO_REWARD_DATE, ""))) return false;

        if (countNonEmptyTodos(context) > 0 && countDoneTodos(context) == countNonEmptyTodos(context)) {
            CompanionProfile.addAffection(context, 3);
            prefs.edit().putString(AppPrefs.KEY_TODO_REWARD_DATE, today).apply();
            return true;
        }
        return false;
    }

    public static String getTodoSummary(Context context) {
        int total = countNonEmptyTodos(context);
        int done = countDoneTodos(context);
        if (total == 0) return "오늘 할 일 3개를 정해보자.";
        return "오늘 할 일 " + total + "개 중 " + done + "개 완료";
    }

    public static String getDailyLetter(Context context) {
        SharedPreferences prefs = context.getSharedPreferences(AppPrefs.PREFS, Context.MODE_PRIVATE);
        String today = EmotionDiaryStorage.today();
        if (today.equals(prefs.getString(AppPrefs.KEY_DAILY_LETTER_DATE, ""))) {
            String cached = prefs.getString(AppPrefs.KEY_DAILY_LETTER_TEXT, "");
            if (!cached.isEmpty()) {
                String cleaned = sanitizeLegacyLetter(cached);
                if (!cleaned.equals(cached)) {
                    prefs.edit().putString(AppPrefs.KEY_DAILY_LETTER_TEXT, cleaned).apply();
                }
                return cleaned;
            }
        }
        return regenerateDailyLetter(context);
    }

    public static String regenerateDailyLetter(Context context) {
        SharedPreferences prefs = context.getSharedPreferences(AppPrefs.PREFS, Context.MODE_PRIVATE);
        String today = EmotionDiaryStorage.today();
        JSONObject diary = EmotionDiaryStorage.getEntryByDate(context, today);
        int affection = CompanionProfile.getAffection(context);
        int score = prefs.getInt(AppPrefs.KEY_LAST_CHECKIN_SCORE, 0);
        String previous = prefs.getString(AppPrefs.KEY_DAILY_LETTER_TEXT, "");

        String[] highScoreIntros = {
                "승재야, 오늘은 그래도 버틸 힘이 조금 남아 있었던 것 같아. ",
                "승재야, 오늘은 마음이 완전히 무너지진 않았던 것 같아. 그 점은 그냥 지나치지 말자. ",
                "오늘의 승재는 생각보다 잘 버텨줬어. 괜찮았던 순간 하나쯤은 기억해두자. ",
                "승재야, 오늘 마음에 작은 여유가 있었던 것 같아. 그 여유를 오늘 네 편으로 써도 돼. "
        };
        String[] midScoreIntros = {
                "승재야, 오늘은 꽤 애쓴 하루였지. ",
                "오늘은 마음이 좀 무거웠지. 그래도 여기까지 온 건 분명해. ",
                "승재야, 오늘은 힘을 꽤 많이 쓴 날 같아. 이제는 조금 덜 해도 돼. ",
                "오늘 마음이 편하진 않았지. 그래도 하루를 넘긴 건 분명해. "
        };
        String[] noScoreIntros = {
                "승재야, 오늘 하루를 천천히 떠올려보자. ",
                "아직 오늘 마음점수는 없지만, 지금 네 마음부터 조용히 보자. ",
                "승재야, 오늘을 꼭 점수로 정리하지 않아도 돼. 그냥 지금 마음부터 보면 돼. ",
                "오늘은 하루 전체를 다 보지 말고, 기억나는 한 장면부터 떠올려보자. "
        };

        String[] emptyDiaryLines = {
                "아직 오늘 일기는 비어 있지만, 마음이 없다는 뜻은 아니야. 쓰고 싶을 때 한 줄만 남겨도 돼. ",
                "오늘 일기는 아직 비어 있네. 억지로 채우지 않아도 돼. 마음이 움직일 때 적으면 돼. ",
                "아직 글로 남긴 마음은 없지만, 말로 잘 안 나오는 날도 있지. ",
                "오늘 일기 칸이 비어 있어도 괜찮아. 기록보다 네가 지금 조금 편해지는 게 먼저야. "
        };

        String[] closeWarm = {
                "나는 네 마음을 조금씩 더 알아가고 있어. 오늘도 완벽해지기보다 네 편이 되어보자. - 어린 승재",
                "오늘 잘한 것과 힘들었던 것 둘 다 네 하루야. 한쪽만 보고 오늘을 정하지 말자. - 어린 승재",
                "내일의 승재에게 오늘 문제를 전부 넘기지 말고, 오늘은 여기까지만 하자. - 어린 승재",
                "괜찮은 척하지 않아도 돼. 네가 실제로 느낀 하루를 그대로 봐주자. - 어린 승재"
        };
        String[] closeGrowing = {
                "지금은 하나씩 쌓아가는 중이야. 내일도 내가 먼저 물어볼게. - 어린 승재",
                "오늘 마음을 정확히 설명하지 못해도 괜찮아. 같이 조금씩 알아가면 돼. - 어린 승재",
                "내일은 내일의 마음이 또 있을 거야. 오늘 것은 오늘 여기까지만 내려놓자. - 어린 승재",
                "오늘을 잘 보낸다는 게 꼭 많이 해내는 건 아니야. 오늘도 여기까지 온 걸로 충분해. - 어린 승재"
        };

        java.util.Random random = new java.util.Random(System.nanoTime());
        String letter = previous;

        for (int attempt = 0; attempt < 8; attempt++) {
            String intro;
            if (score >= 4) {
                intro = highScoreIntros[random.nextInt(highScoreIntros.length)];
            } else if (score > 0) {
                intro = midScoreIntros[random.nextInt(midScoreIntros.length)];
            } else {
                intro = noScoreIntros[random.nextInt(noScoreIntros.length)];
            }

            String diaryLine;
            if (diary != null) {
                String label = diary.optString("label", "잔잔");
                String diaryText = diary.optString("text", "").trim();
                if (diaryText.length() > 42) diaryText = diaryText.substring(0, 42) + "...";

                if (!diaryText.isEmpty()) {
                    String[] variants = {
                            "오늘 일기에는 '" + label + "' 마음과 함께, \"" + diaryText + "\"라는 이야기가 남아 있었어. ",
                            "네가 오늘 적은 마음은 '" + label + "' 쪽에 가까웠고, 특히 \"" + diaryText + "\"가 눈에 들어왔어. ",
                            "오늘 기록을 다시 보니까 '" + label + "'이라는 기분과 \"" + diaryText + "\"라는 말이 같이 남아 있네. ",
                            "오늘 네가 적어준 \"" + diaryText + "\"라는 말은 그냥 지나치지 말고 기억해둘 만해. 기분은 '" + label + "'에 가까웠고. "
                    };
                    diaryLine = variants[random.nextInt(variants.length)];
                } else {
                    String[] variants = {
                            "오늘은 '" + label + "' 쪽 마음이었구나. 말이 길지 않아도 그 기분 자체가 기록이야. ",
                            "오늘은 '" + label + "'이라는 마음을 골랐네. 이유를 길게 말하지 않아도 충분히 중요해. ",
                            "오늘 마음은 '" + label + "' 쪽이었구나. 그 느낌을 알아차린 것만으로도 이미 잘 본 거야. "
                    };
                    diaryLine = variants[random.nextInt(variants.length)];
                }
            } else {
                diaryLine = emptyDiaryLines[random.nextInt(emptyDiaryLines.length)];
            }

            String[] transitionLines = {
                    "지금은 급하게 결론 내리지 않아도 돼. ",
                    "한 장면만 보고 오늘 전체를 판단하지 말자. ",
                    "몸이 피곤하면 생각도 더 무겁게 느껴질 수 있어. ",
                    "지금 네게 필요한 게 답 찾기인지 쉬는 건지 한 번만 나눠보자. ",
                    "마음이 복잡하면 오늘은 이유를 다 찾지 않아도 돼. "
            };
            String transition = transitionLines[random.nextInt(transitionLines.length)];
            String closing = affection >= 55
                    ? closeWarm[random.nextInt(closeWarm.length)]
                    : closeGrowing[random.nextInt(closeGrowing.length)];

            letter = intro + diaryLine + transition + closing;
            if (!letter.equals(previous)) break;
        }

        letter = sanitizeLegacyLetter(letter);
        String sharedPractice = UnifiedTherapyProfile.currentPractice(context);
        if (!sharedPractice.isEmpty() && !letter.contains(sharedPractice)) {
            letter = letter + "\n\n그리고 요즘 우리 같이 연습하던 것도 잊지 말자. " + sharedPractice;
        }

        prefs.edit()
                .putString(AppPrefs.KEY_DAILY_LETTER_DATE, today)
                .putString(AppPrefs.KEY_DAILY_LETTER_TEXT, letter)
                .apply();
        return letter;
    }



    private static String sanitizeLegacyLetter(String text) {
        if (text == null || text.isEmpty()) return "";
        String cleaned = text;
        // 과거 방 꾸미기 버전에서 저장된 캐시 문장을 제거한다.
        cleaned = cleaned.replaceAll("지금\\s*우리\\s*방은[^.!?。]*(?:[.!?。]|$)\\s*", "");
        cleaned = cleaned.replaceAll("우리\\s*방은[^.!?。]*(?:[.!?。]|$)\\s*", "");
        cleaned = cleaned.replaceAll("하늘방\\s*[·ㆍ|/]\\s*민트\\s*후드\\s*[·ㆍ|/]\\s*없음으로\\s*꾸며져\\s*있어\\.?\\s*", "");
        // 삭제된 '오늘 할 일 3개' 기능의 오래된 편지 문장도 제거한다.
        cleaned = cleaned.replaceAll("오늘\\s*할\\s*일[^.!?。]*(?:[.!?。]|$)\\s*", "");
        return cleaned.replaceAll("\\s{2,}", " ").trim();
    }

}
