package com.maeummon.app.clinical;

import org.json.*;
import java.util.*;

public final class CompetingFormulationEngineRC8 {
    private CompetingFormulationEngineRC8(){}

    public static final class Hypothesis {
        public final String id;
        public final String label;
        public double confidence;
        public final JSONArray evidenceFor=new JSONArray();
        public final JSONArray evidenceAgainst=new JSONArray();
        public boolean active=true;

        public Hypothesis(String id,String label,double confidence){
            this.id=id; this.label=label; this.confidence=confidence;
        }

        public JSONObject toJson(){
            JSONObject o=new JSONObject();
            try{
                o.put("id",id);
                o.put("label",label);
                o.put("confidence",round(confidence));
                o.put("evidence_for",evidenceFor);
                o.put("evidence_against",evidenceAgainst);
                o.put("active",active);
            }catch(Exception ignored){}
            return o;
        }
    }

    public static JSONArray update(
            JSONArray existing,
            String userText,
            JSONArray knownVariables,
            JSONArray sessionSummary
    ){
        List<Hypothesis> hs = fromJson(existing);
        if(hs.isEmpty()){
            hs = seed(userText);
        }

        String t=safe(userText);
        Set<String> known=jsonSet(knownVariables);

        // Relationship/rejection domain
        apply(hs,"normal_response_variation",
                containsAny(t,"원래도 느려","원래 답장이 느","늘 그랬"), +0.28,
                "baseline suggests normal variation");
        applyAgainst(hs,"relationship_distance_change",
                containsAny(t,"원래도 느려","늘 그랬"), -0.22,
                "no recent change");

        apply(hs,"relationship_distance_change",
                containsAny(t,"최근부터 느려","갑자기 느려","예전이랑 달라","나한테만 늦"), +0.24,
                "recent/selective change");
        applyAgainst(hs,"normal_response_variation",
                containsAny(t,"최근부터 느려","갑자기 느려","예전이랑 달라"), -0.18,
                "recent change contradicts stable baseline");

        apply(hs,"actual_rejection_or_conflict",
                containsAny(t,"싸웠","갈등이 있었","차갑게 말","피하는 것 같"), +0.22,
                "conflict/rejection evidence");
        applyAgainst(hs,"actual_rejection_or_conflict",
                containsAny(t,"싸운 일은 없어","갈등은 없어","다툰 건 없어"), -0.26,
                "explicit absence of recent conflict");

        apply(hs,"rejection_interpretation_amplification",
                containsAny(t,"나 싫어하나","버려질까","미워할까","무시당한 것 같"), +0.20,
                "rejection meaning attribution");
        apply(hs,"rejection_interpretation_amplification",
                containsAny(t,"예전에도 비슷","여러 관계에서","항상 이런"), +0.18,
                "cross-relationship pattern");

        // Work/evaluation domain
        apply(hs,"evaluation_threat",
                containsAny(t,"무능","일 못하는","평가할까","능력이 의심"), +0.30,
                "evaluation meaning explicit");
        apply(hs,"workload_stress",
                containsAny(t,"일이 너무 많","업무량","야근","할 일이 많"), +0.28,
                "workload evidence");
        apply(hs,"interpersonal_work_stress",
                containsAny(t,"상사","동료","눈치","사람 때문에"), +0.22,
                "interpersonal workplace evidence");
        apply(hs,"exhaustion_or_burnout",
                containsAny(t,"지쳐","번아웃","아무것도 하기 싫","기운이 없"), +0.24,
                "exhaustion evidence");

        // Avoidance / regulation domain
        apply(hs,"avoidance_negative_reinforcement",
                containsAny(t,"피하면 편","회피하면 편","안 만나면 편"), +0.32,
                "short-term relief after avoidance");
        applyAgainst(hs,"avoidance_negative_reinforcement",
                containsAny(t,"피해도 더 불안","회피해도 안 편"), -0.18,
                "avoidance not relieving");

        // Explicit correction should weaken mismatched hypotheses globally.
        if(containsAny(t,"아까 잘못 말","정정할게","다시 생각해보니","그건 아니야")){
            for(Hypothesis h:hs){
                if(h.confidence>0.55)h.confidence-=0.08;
            }
        }

        // Normalize, prune, and keep 2-4 active hypotheses.
        normalize(hs);
        Collections.sort(hs,(a,b)->Double.compare(b.confidence,a.confidence));

        int kept=0;
        for(Hypothesis h:hs){
            if(kept<4 && h.confidence>=0.12){
                h.active=true; kept++;
            }else h.active=false;
        }
        if(kept<2){
            for(Hypothesis h:hs){
                if(!h.active && kept<2){h.active=true;kept++;}
            }
        }

        JSONArray out=new JSONArray();
        for(Hypothesis h:hs)if(h.active)out.put(h.toJson());
        return out;
    }

    public static String bestHypothesisId(JSONArray arr){
        JSONObject best=null;
        double bestC=-1;
        for(int i=0;i<arr.length();i++){
            JSONObject o=arr.optJSONObject(i);
            if(o==null)continue;
            double c=o.optDouble("confidence",0);
            if(c>bestC){best=o;bestC=c;}
        }
        return best==null?"":best.optString("id","");
    }

    public static String confidenceBand(JSONArray arr){
        double top=0, second=0;
        for(int i=0;i<arr.length();i++){
            JSONObject o=arr.optJSONObject(i);
            if(o==null)continue;
            double c=o.optDouble("confidence",0);
            if(c>top){second=top;top=c;}
            else if(c>second)second=c;
        }
        if(top>=0.72 && top-second>=0.18)return "HIGH";
        if(top>=0.48)return "MEDIUM";
        return "LOW";
    }

    private static List<Hypothesis> seed(String text){
        String t=safe(text);
        List<Hypothesis> hs=new ArrayList<>();
        if(containsAny(t,"답장","카톡","연락","친구","무시")){
            hs.add(new Hypothesis("normal_response_variation","평소 반응 변동",0.28));
            hs.add(new Hypothesis("relationship_distance_change","관계 거리 변화",0.24));
            hs.add(new Hypothesis("rejection_interpretation_amplification","거절 의미 증폭",0.28));
            hs.add(new Hypothesis("actual_rejection_or_conflict","실제 갈등/거절",0.20));
        }else if(containsAny(t,"회사","직장","상사","업무")){
            hs.add(new Hypothesis("evaluation_threat","평가 위협",0.28));
            hs.add(new Hypothesis("workload_stress","업무량 스트레스",0.24));
            hs.add(new Hypothesis("interpersonal_work_stress","직장 대인 스트레스",0.24));
            hs.add(new Hypothesis("exhaustion_or_burnout","소진/피로",0.24));
        }else if(containsAny(t,"피해","회피","도망","약속을 피")){
            hs.add(new Hypothesis("avoidance_negative_reinforcement","회피의 단기 안도 강화",0.62));
            hs.add(new Hypothesis("insufficient_information","정보 부족",0.38));
        }else{
            hs.add(new Hypothesis("insufficient_information","정보 부족",0.55));
            hs.add(new Hypothesis("situational_stress","상황 스트레스",0.45));
        }
        return hs;
    }

    private static List<Hypothesis> fromJson(JSONArray a){
        List<Hypothesis> out=new ArrayList<>();
        if(a==null)return out;
        for(int i=0;i<a.length();i++){
            JSONObject o=a.optJSONObject(i);
            if(o==null)continue;
            Hypothesis h=new Hypothesis(
                    o.optString("id",""),
                    o.optString("label",""),
                    o.optDouble("confidence",0.25));
            JSONArray ef=o.optJSONArray("evidence_for");
            JSONArray ea=o.optJSONArray("evidence_against");
            copy(ef,h.evidenceFor); copy(ea,h.evidenceAgainst);
            h.active=o.optBoolean("active",true);
            out.add(h);
        }
        return out;
    }

    private static void apply(List<Hypothesis> hs,String id,boolean cond,double delta,String ev){
        if(!cond)return;
        Hypothesis h=find(hs,id);
        if(h==null)return;
        h.confidence=clamp(h.confidence+delta);
        putUnique(h.evidenceFor,ev);
    }

    private static void applyAgainst(List<Hypothesis> hs,String id,boolean cond,double delta,String ev){
        if(!cond)return;
        Hypothesis h=find(hs,id);
        if(h==null)return;
        h.confidence=clamp(h.confidence+delta);
        putUnique(h.evidenceAgainst,ev);
    }

    private static Hypothesis find(List<Hypothesis> hs,String id){
        for(Hypothesis h:hs)if(id.equals(h.id))return h;
        return null;
    }

    private static void normalize(List<Hypothesis> hs){
        double sum=0;
        for(Hypothesis h:hs){
            h.confidence=clamp(h.confidence);
            sum+=h.confidence;
        }
        if(sum<=0)return;
        for(Hypothesis h:hs)h.confidence=h.confidence/sum;
    }

    private static void copy(JSONArray src,JSONArray dst){
        if(src==null)return;
        for(int i=0;i<src.length();i++)dst.put(src.opt(i));
    }
    private static void putUnique(JSONArray a,String s){
        for(int i=0;i<a.length();i++)if(s.equals(a.optString(i)))return;
        a.put(s);
    }
    private static Set<String> jsonSet(JSONArray a){
        Set<String> s=new HashSet<>();
        if(a!=null)for(int i=0;i<a.length();i++)s.add(a.optString(i));
        return s;
    }
    private static boolean containsAny(String s,String... xs){
        for(String x:xs)if(s.contains(x))return true;
        return false;
    }
    private static double clamp(double x){return Math.max(0.02,Math.min(0.95,x));}
    private static double round(double x){return Math.round(x*10000.0)/10000.0;}
    private static String safe(String s){return s==null?"":s;}
}
