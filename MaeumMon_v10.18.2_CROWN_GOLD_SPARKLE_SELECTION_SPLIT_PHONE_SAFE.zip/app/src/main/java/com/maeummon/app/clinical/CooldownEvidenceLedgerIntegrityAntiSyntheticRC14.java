package com.maeummon.app.clinical;

import android.content.Context;
import org.json.*;
import java.security.MessageDigest;

public final class CooldownEvidenceLedgerIntegrityAntiSyntheticRC14 {
    private CooldownEvidenceLedgerIntegrityAntiSyntheticRC14(){}

    public enum RowState {
        VALID,
        REPAIRED,
        QUARANTINED,
        SYNTHETIC_BLOCKED
    }

    public static final class Result {
        public boolean evaluated=false;
        public boolean repaired=false;
        public boolean quarantined=false;
        public boolean syntheticBlocked=false;
        public int rowsChecked=0;
        public int rowsValid=0;
        public int rowsRepaired=0;
        public int rowsQuarantined=0;
        public int rowsSyntheticBlocked=0;
        public String reason="";
        public String summary="";
    }

    public static Result validate(Context c){
        Result r=new Result();

        if(c==null){
            r.summary="NO_EVALUATION | NO_CONTEXT";
            return r;
        }

        r.evaluated=true;

        try{
            JSONObject p=CentralTherapyProfile.loadProfile(c);
            JSONArray ledger=p.optJSONArray(
                    "requarantine_cooldown_evidence_ledger");

            if(ledger==null){
                r.reason="NO_LEDGER";
                return finish(r);
            }

            for(int i=0;i<ledger.length();i++){
                JSONObject row=ledger.optJSONObject(i);
                if(row==null)continue;

                r.rowsChecked++;
                boolean rowRepaired=false;

                String source=row.optString("source_type","");
                String evidenceText=row.optString("user_evidence_text","");
                String evidenceId=row.optString("user_evidence_id","");
                String transitionKey=row.optString("transition_key","");
                String quarantinedCause=row.optString("quarantined_cause","");
                String currentCause=row.optString("current_cause","");
                String ledgerIdentity=row.optString("ledger_identity","");

                // Evidence ledger must always originate from explicit user correction.
                if(!"EXPLICIT_USER_CORRECTION".equals(source)){
                    row.put("cooldown_evidence_integrity_state",
                            RowState.SYNTHETIC_BLOCKED.name());
                    row.put("cooldown_evidence_quarantined",true);
                    row.put("cooldown_evidence_integrity_reason",
                            "NON_EXPLICIT_OR_SYNTHETIC_SOURCE");
                    r.rowsSyntheticBlocked++;
                    r.syntheticBlocked=true;
                    r.rowsQuarantined++;
                    r.quarantined=true;
                    continue;
                }

                if(evidenceText.isEmpty()
                        ||transitionKey.isEmpty()
                        ||currentCause.isEmpty()
                        ||quarantinedCause.isEmpty()){
                    row.put("cooldown_evidence_integrity_state",
                            RowState.QUARANTINED.name());
                    row.put("cooldown_evidence_quarantined",true);
                    row.put("cooldown_evidence_integrity_reason",
                            "INCOMPLETE_LEDGER_PROVENANCE");
                    r.rowsQuarantined++;
                    r.quarantined=true;
                    continue;
                }

                String expectedEvidenceId=
                        sha256(normalize(evidenceText));

                if(!expectedEvidenceId.equals(evidenceId)){
                    if(!evidenceId.isEmpty())
                        row.put("user_evidence_id_before_repair",evidenceId);

                    row.put("user_evidence_id",expectedEvidenceId);
                    evidenceId=expectedEvidenceId;
                    rowRepaired=true;
                }

                String expectedIdentity=
                        sha256(
                            transitionKey
                            +"::"
                            +currentCause
                            +"::"
                            +evidenceId);

                if(!expectedIdentity.equals(ledgerIdentity)){
                    if(!ledgerIdentity.isEmpty())
                        row.put("ledger_identity_before_repair",ledgerIdentity);

                    row.put("ledger_identity",expectedIdentity);
                    ledgerIdentity=expectedIdentity;
                    rowRepaired=true;
                }

                boolean clean=row.optBoolean(
                        "clean_confirmation",false);
                boolean contradiction=row.optBoolean(
                        "contradiction",false);

                boolean expectedClean=
                        quarantinedCause.equals(currentCause);

                if(clean==contradiction){
                    row.put("clean_confirmation",expectedClean);
                    row.put("contradiction",!expectedClean);
                    rowRepaired=true;
                }else if(clean!=expectedClean){
                    row.put("clean_confirmation",expectedClean);
                    row.put("contradiction",!expectedClean);
                    rowRepaired=true;
                }

                row.put("cooldown_evidence_quarantined",false);
                row.put("cooldown_evidence_integrity_schema","6.9.6");

                if(rowRepaired){
                    row.put("cooldown_evidence_integrity_state",
                            RowState.REPAIRED.name());
                    row.put("cooldown_evidence_integrity_reason",
                            "SAFE_CANONICAL_REPAIR");
                    r.rowsRepaired++;
                    r.repaired=true;
                }else{
                    row.put("cooldown_evidence_integrity_state",
                            RowState.VALID.name());
                    row.put("cooldown_evidence_integrity_reason",
                            "VALID_EXPLICIT_USER_EVIDENCE");
                    r.rowsValid++;
                }
            }

            p.put("requarantine_cooldown_evidence_ledger",ledger);
            p.put("last_cooldown_evidence_integrity_checked_at",
                    System.currentTimeMillis());
            p.put("last_cooldown_evidence_integrity_rows_checked",
                    r.rowsChecked);
            p.put("last_cooldown_evidence_integrity_rows_repaired",
                    r.rowsRepaired);
            p.put("last_cooldown_evidence_integrity_rows_quarantined",
                    r.rowsQuarantined);
            p.put("last_cooldown_evidence_integrity_synthetic_blocked",
                    r.rowsSyntheticBlocked);

            CentralTherapyProfile.replaceProfile(c,p);

            if(r.rowsSyntheticBlocked>0)
                r.reason="SYNTHETIC_CONFIRMATION_BLOCKED";
            else if(r.rowsQuarantined>0)
                r.reason="INVALID_LEDGER_ROWS_QUARANTINED";
            else if(r.rowsRepaired>0)
                r.reason="LEDGER_ROWS_REPAIRED";
            else
                r.reason="LEDGER_VALID";

            return finish(r);
        }catch(Exception e){
            r.quarantined=true;
            r.reason="COOLDOWN_LEDGER_INTEGRITY_WRITE_FAILED";
            return finish(r);
        }
    }

    public static boolean rowEligible(JSONObject row){
        if(row==null)return false;

        if(row.optBoolean("cooldown_evidence_quarantined",false))
            return false;

        String state=row.optString(
                "cooldown_evidence_integrity_state","");

        return !RowState.QUARANTINED.name().equals(state)
                &&!RowState.SYNTHETIC_BLOCKED.name().equals(state)
                &&"EXPLICIT_USER_CORRECTION".equals(
                    row.optString("source_type",""))
                &&!row.optString("user_evidence_id","").isEmpty()
                &&!row.optString("transition_key","").isEmpty()
                &&!row.optString("current_cause","").isEmpty();
    }

    public static String instruction(Result r){
        if(r==null||!r.evaluated)return "";

        if(r.syntheticBlocked)
            return "COOLDOWN_LEDGER_INTEGRITY=SYNTHETIC_BLOCKED. 명시적 사용자 발화가 아닌 confirmation은 cooldown 해제 근거에서 제외한다.";

        if(r.quarantined)
            return "COOLDOWN_LEDGER_INTEGRITY=QUARANTINE. provenance가 불완전한 confirmation은 해제 카운트에서 제외한다.";

        if(r.repaired)
            return "COOLDOWN_LEDGER_INTEGRITY=REPAIRED. 안전하게 재구성 가능한 ledger identity만 복구했다.";

        return "COOLDOWN_LEDGER_INTEGRITY=VALID.";
    }

    private static String normalize(String s){
        if(s==null)return "";
        return s.trim().replaceAll("\\s+"," ").toLowerCase();
    }

    private static String sha256(String s){
        try{
            MessageDigest md=MessageDigest.getInstance("SHA-256");
            byte[] b=md.digest((s==null?"":s).getBytes("UTF-8"));
            StringBuilder out=new StringBuilder();
            for(byte x:b)out.append(String.format("%02x",x));
            return out.toString();
        }catch(Exception e){
            return Integer.toHexString((s==null?"":s).hashCode());
        }
    }

    private static Result finish(Result r){
        r.summary="checked="+r.rowsChecked
                +" | valid="+r.rowsValid
                +" | repaired="+r.rowsRepaired
                +" | quarantined="+r.rowsQuarantined
                +" | syntheticBlocked="+r.rowsSyntheticBlocked
                +" | reason="+r.reason;
        return r;
    }
}
