package com.maeummon.app.clinical;

import android.content.Context;
import org.json.JSONObject;

public final class DecisionTransitionCauseAttributionRC13 {
    private DecisionTransitionCauseAttributionRC13(){}

    public enum Cause {
        NONE,
        SAFETY_OVERRIDE,
        ALLIANCE_REPAIR,
        NEW_USER_EVIDENCE,
        TARGET_INFORMATION_GAIN,
        FORMULATION_REOPEN,
        OUTCOME_REVIEW,
        OUTCOME_REVISION,
        INTERVENTION_OUTCOME_ADAPTATION,
        POLICY_MEMORY_SUPPORT,
        SESSION_PHASE_CHANGE,
        GOAL_STATE_CHANGE,
        UNKNOWN
    }

    public static final class Result {
        public boolean evaluated=false;
        public boolean transitionDetected=false;
        public Cause primaryCause=Cause.NONE;
        public String secondaryCause="";
        public String fromState="";
        public String toState="";
        public String humanReason="";
        public String reason="";
        public String summary="";
    }

    public static Result attribute(Context c,ClinicalDecisionRC7 d){
        Result r=new Result();
        if(c==null||d==null){
            r.summary="NO_EVALUATION | NO_CONTEXT_OR_DECISION";
            return r;
        }

        r.evaluated=true;
        JSONObject f=CentralTherapyProfile.loadFormulation(c);

        boolean moveChanged=
                DecisionTransitionSnapshotContinuityRC13
                        .meaningfulMoveTransition(d);
        boolean interventionChanged=
                DecisionTransitionSnapshotContinuityRC13
                        .meaningfulInterventionTransition(d);
        boolean targetChanged=
                DecisionTransitionSnapshotContinuityRC13
                        .meaningfulTargetTransition(d);

        r.transitionDetected=
                moveChanged||interventionChanged||targetChanged
                ||d.outcomeRevisionReviewRequired
                ||d.outcomeRevisionApplied;

        r.fromState=
                safe(d.lastMove)
                +"|"+safe(d.lastInterventionId)
                +"|"+safe(d.lastTargetVariable);

        r.toState=
                safe(d.move)
                +"|"+safe(d.selectedInterventionId)
                +"|"+safe(d.targetVariable);

        if(!r.transitionDetected){
            r.primaryCause=Cause.NONE;
            r.reason="NO_MEANINGFUL_TRANSITION";
            r.humanReason="";
            return finish(r);
        }

        if(d.safetyOverride){
            r.primaryCause=Cause.SAFETY_OVERRIDE;
            r.reason="SAFETY_PRIORITY_CHANGED_DECISION";
            r.humanReason="지금은 다른 판단보다 안전과 안정화를 우선해야 해서 방향을 바꾼 거야.";
            return finish(r);
        }

        if(d.allianceRupture){
            r.primaryCause=Cause.ALLIANCE_REPAIR;
            r.reason="ALLIANCE_REPAIR_CHANGED_DECISION";
            r.humanReason="내가 네 말을 제대로 이해했는지 다시 맞추는 게 먼저라서 상담 방향을 잠깐 바꾼 거야.";
            return finish(r);
        }

        if(d.outcomeRevisionReviewRequired){
            r.primaryCause=Cause.OUTCOME_REVIEW;
            r.reason="CONFLICTING_OUTCOME_REQUIRES_REVIEW";
            r.humanReason="같은 시도에 대한 평가가 달라져서, 새 방법으로 넘어가기 전에 그 변화부터 확인하려고 방향을 바꾼 거야.";
            return finish(r);
        }

        if(d.outcomeRevisionApplied){
            r.primaryCause=Cause.OUTCOME_REVISION;
            r.reason="CONFIRMED_OUTCOME_REVISION_REOPENED_DECISION";
            r.humanReason="직전 시도의 결과를 새롭게 수정했기 때문에, 이전 판단을 그대로 이어가지 않고 다시 맞춰보는 쪽으로 바꾼 거야.";
            return finish(r);
        }

        if(f.optBoolean("formulation_reopened",false)){
            r.primaryCause=Cause.FORMULATION_REOPEN;
            r.reason="FORMULATION_REOPEN_CHANGED_DECISION";
            r.humanReason="새 정보가 기존 해석과 잘 맞지 않아서, 예전 결론을 유지하기보다 다시 확인하는 쪽으로 방향을 바꾼 거야.";
            return finish(r);
        }

        if("REVIEW".equals(safe(d.move))){
            r.primaryCause=Cause.OUTCOME_REVIEW;
            r.reason="INTERVENTION_REVIEW_CHANGED_DECISION";
            r.humanReason="새 방법을 더 얹기보다 방금 해본 방식의 실제 영향을 먼저 확인해야 해서 REVIEW로 바꾼 거야.";
            return finish(r);
        }

        if(targetChanged){
            r.primaryCause=Cause.TARGET_INFORMATION_GAIN;
            r.reason="HIGHER_VALUE_MISSING_INFORMATION";
            r.humanReason="지금은 이전 질문보다 상담 방향을 더 크게 가를 정보가 보여서 확인할 질문의 초점을 바꾼 거야.";
            return finish(r);
        }

        if(interventionChanged){
            if(!safe(d.interventionReviewOutcome).isEmpty()){
                r.primaryCause=Cause.INTERVENTION_OUTCOME_ADAPTATION;
                r.reason="OUTCOME_FEEDBACK_CHANGED_INTERVENTION";
                r.humanReason="직전 방법의 실제 반응을 반영해서, 같은 목표를 더 잘 맞추는 방식으로 개입을 조정한 거야.";
                return finish(r);
            }

            if(d.policyRetrievalApplicable
                    &&!d.policySelectionSuppressed
                    &&!safe(d.policySelectionEffectiveKey).isEmpty()){
                r.primaryCause=Cause.POLICY_MEMORY_SUPPORT;
                r.reason="CURRENT_EVIDENCE_WITH_POLICY_SUPPORT";
                r.humanReason="현재 판단이 바뀐 게 먼저고, 비슷한 상황의 과거 결과도 그 선택과 맞아서 보조 근거로 참고했어.";
                return finish(r);
            }

            r.primaryCause=Cause.NEW_USER_EVIDENCE;
            r.reason="NEW_EVIDENCE_CHANGED_INTERVENTION";
            r.humanReason="방금 나온 정보가 이전보다 다른 대응을 더 잘 맞게 만들어서 개입을 바꾼 거야.";
            return finish(r);
        }

        if(moveChanged){
            String phase=safe(d.sessionPhase);
            String previousPhase=f.optString("previous_session_phase","");

            if(!phase.isEmpty()
                    &&!previousPhase.isEmpty()
                    &&!phase.equals(previousPhase)){
                r.primaryCause=Cause.SESSION_PHASE_CHANGE;
                r.reason="SESSION_PHASE_CHANGED_MOVE";
                r.humanReason="지금 상담 단계가 이해 중심에서 실행·검토 쪽으로 넘어가서 다음 움직임도 같이 바뀐 거야.";
                return finish(r);
            }

            if(d.goalCompleted || d.goalDriftDetected){
                r.primaryCause=Cause.GOAL_STATE_CHANGE;
                r.reason="GOAL_STATE_CHANGED_MOVE";
                r.humanReason="지금 목표 상태가 달라져서 같은 방식으로 계속 가기보다 다음 단계에 맞게 방향을 조정한 거야.";
                return finish(r);
            }

            r.primaryCause=Cause.NEW_USER_EVIDENCE;
            r.reason="NEW_INFORMATION_CHANGED_MOVE";
            r.humanReason="방금 나온 정보가 이전 판단의 우선순위를 바꿔서 다음 움직임을 조정한 거야.";
            return finish(r);
        }

        r.primaryCause=Cause.UNKNOWN;
        r.reason="TRANSITION_CAUSE_NOT_CLASSIFIED";
        r.humanReason="현재 새 정보와 상담 흐름을 반영해서 다음 움직임을 조정했어.";
        return finish(r);
    }

    public static String instruction(Result r){
        if(r==null||!r.evaluated||!r.transitionDetected)return "";

        return "DECISION_TRANSITION_CAUSE="+r.primaryCause.name()
                +". 전환 이유를 설명해야 할 때 다음 문장을 우선 사용한다: "
                +r.humanReason;
    }

    private static Result finish(Result r){
        r.summary="transition="+r.transitionDetected
                +" | cause="+r.primaryCause.name()
                +" | from="+r.fromState
                +" | to="+r.toState
                +" | reason="+r.reason;
        return r;
    }

    private static String safe(String s){
        return s==null?"":s;
    }
}
