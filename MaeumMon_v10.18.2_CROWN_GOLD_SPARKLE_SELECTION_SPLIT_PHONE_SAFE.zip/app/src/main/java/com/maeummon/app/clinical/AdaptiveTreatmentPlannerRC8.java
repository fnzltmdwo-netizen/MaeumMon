package com.maeummon.app.clinical;

import android.content.Context;
import org.json.*;

public final class AdaptiveTreatmentPlannerRC8 {
    private AdaptiveTreatmentPlannerRC8(){}

    public static final class Plan {
        public String action=""; // MAINTAIN / MICRO_ADJUST / SWITCH / REOPEN_FORMULATION / REDUCE_TASK
        public String rationale="";
        public String directive="";
        public boolean reopenFormulation=false;
        public boolean selectNewIntervention=false;
    }

    public static Plan plan(Context c,InterventionOutcomeLearningRC8.Review r){
        Plan p=new Plan();
        if(c==null||r==null||!r.outcomeMentioned){
            p.action="NONE";
            p.rationale="no reviewed intervention outcome";
            return p;
        }

        JSONObject f=CentralTherapyProfile.loadFormulation(c);
        JSONArray hist=f.optJSONArray("intervention_history");
        int repeatedFailures=countRecentFailures(hist,3);
        String leading=f.optString("leading_hypothesis","");
        String confidence=f.optString("confidence","LOW");

        if("HELPED".equals(r.outcome)){
            p.action="MAINTAIN";
            p.rationale="reported benefit; keep mechanism and avoid unnecessary switching";
            p.directive="도움이 된 핵심 요소 하나를 짚고 같은 전략을 유지한다. 난이도만 조금 조절할 수 있다.";
            return p;
        }

        if("PARTIAL".equals(r.outcome)){
            p.action="MICRO_ADJUST";
            p.rationale="partial benefit suggests mechanism may fit but delivery/task size needs adjustment";
            p.directive="잘 된 부분은 유지하고 막힌 지점 하나만 조정한다. 새로운 전략 여러 개를 추가하지 않는다.";
            return p;
        }

        if("NOT_TRIED".equals(r.outcome)){
            p.action="REDUCE_TASK";
            p.rationale="non-execution is not treatment failure; lower friction before changing formulation";
            p.directive="실행 못 한 이유를 짧게 확인하고 같은 개입을 더 작은 단계로 줄인다.";
            return p;
        }

        if("WORSE".equals(r.outcome)){
            p.action="REOPEN_FORMULATION";
            p.rationale="worsening after intervention warrants mechanism re-check before another intervention";
            p.directive="기존 개입을 중단하고 formulation을 다시 연다. 무엇이 악화시켰는지 FACT 중심으로 재평가한다.";
            p.reopenFormulation=true;
            return p;
        }

        if("NOT_HELPED".equals(r.outcome)){
            if(repeatedFailures>=2 || "LOW".equalsIgnoreCase(confidence)){
                p.action="REOPEN_FORMULATION";
                p.rationale="repeated non-response or low formulation confidence";
                p.directive="같은 formulation을 고집하지 않는다. 경쟁 가설을 다시 열고 핵심 정보 한두 개만 재평가한다.";
                p.reopenFormulation=true;
                return p;
            }
            p.action="SWITCH";
            p.rationale="single non-response with still-usable formulation; try a different mechanism-linked intervention";
            p.directive="현재 formulation은 유지하되 같은 개입은 반복하지 않고 다른 개입 하나로 교체한다.";
            p.selectNewIntervention=true;
            return p;
        }

        p.action="REVIEW";
        p.rationale="outcome unclear";
        p.directive="효과와 부담 중 하나만 짧게 확인한다.";
        return p;
    }

    public static void apply(Context c,Plan p){
        if(c==null||p==null)return;
        try{
            JSONObject f=CentralTherapyProfile.loadFormulation(c);
            JSONObject ps=CentralTherapyProfile.loadProcessState(c);

            f.put("adaptive_plan_action",p.action);
            f.put("adaptive_plan_rationale",p.rationale);
            f.put("updated_at",System.currentTimeMillis());

            if(p.reopenFormulation){
                f.put("confidence","LOW");
                f.put("leading_hypothesis","");
                // Keep hypotheses/evidence, but mark all as tentative again.
                JSONArray hs=f.optJSONArray("alternative_hypotheses");
                if(hs!=null){
                    for(int i=0;i<hs.length();i++){
                        JSONObject h=hs.optJSONObject(i);
                        if(h!=null)h.put("active",true);
                    }
                    f.put("alternative_hypotheses",hs);
                }
                f.put("next_clinical_move","ASK");
                f.put("target_variable","");
            }

            ps.put("adaptive_plan_action",p.action);
            ps.put("adaptive_plan_rationale",p.rationale);
            ps.put("updated_at",System.currentTimeMillis());

            CentralTherapyProfile.replaceFormulation(c,f);
            CentralTherapyProfile.replaceProcessState(c,ps);
        }catch(Exception ignored){}
    }

    public static String instruction(Plan p){
        if(p==null)return "";
        return "Adaptive plan="+p.action+". "+p.directive
                +" 한 번에 하나만 조정하고, 이전 실패를 그대로 반복하지 않는다.";
    }

    private static int countRecentFailures(JSONArray hist,int n){
        if(hist==null||hist.length()==0)return 0;
        int failures=0;
        int start=Math.max(0,hist.length()-n);
        for(int i=start;i<hist.length();i++){
            JSONObject o=hist.optJSONObject(i);
            if(o==null)continue;
            String outcome=o.optString("outcome","");
            if("NOT_HELPED".equals(outcome)||"WORSE".equals(outcome))failures++;
        }
        return failures;
    }
}
