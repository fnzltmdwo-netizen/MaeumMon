package com.maeummon.app;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.UnknownHostException;
import java.net.SocketTimeoutException;
import java.net.ConnectException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/**
 * Converts one imported GPT counseling transcript into multiple practical Mind PT tracks.
 * The original transcript is never overwritten by this analysis.
 */
public final class CounselingProgramAnalyzer {
    private CounselingProgramAnalyzer() {}

    public static final class Analysis {
        public String title = "상담 완전판";
        public String currentConcern = "";
        public String formulation = "";
        public String priorityDirection = "";
        public String caution = "";
        public int discoveredCandidateCount = 0;
        public int groundedCandidateCount = 0;
        public final List<Program> programs = new ArrayList<>();
    }

    public static final class Program {
        public String name = "";
        public String mechanism = "";
        public String muscleName = "";
        public int priority = 50;
        public String reason = "";
        public String source = "DIRECT"; // DIRECT=원문/분석에서 직접 확인, EXPANSION=사용자 승인 전 확장 후보
        public final List<Step> steps = new ArrayList<>();
    }

    public static final class Step {
        public int order = 1;
        public String mode = "TRAINING";
        public String exerciseType = "GPT_COUNSELING_PROGRAM";
        public String exerciseText = "";
        public String successCriterion = "";
        public String rationale = "";
        public int difficulty = 1;
    }


    /** v10.12.1: Re-rank only existing PTs against the full saved counseling timeline.
     * Does not create/delete/rename PTs and does not touch steps. */
    public static final class CrownRerankResult {
        public final java.util.Map<String,Integer> priorities = new java.util.LinkedHashMap<>();
        public final java.util.Map<String,String> mergeInto = new java.util.LinkedHashMap<>();
        public String crownMuscle = "";
        public String crownReason = "";
    }

    public static CrownRerankResult rerankExistingPrograms(String apiKey, String model, String transcript, String existingProgramsContext) throws Exception {
        if (apiKey == null || apiKey.trim().isEmpty()) throw new IllegalArgumentException("OpenAI API Key가 비어 있어.");
        String clean = transcript == null ? "" : transcript.trim();
        if (clean.length() < 120) throw new IllegalArgumentException("저장된 상담 원문이 너무 짧아 왕관을 다시 평가하기 어려워.");
        String existing = existingProgramsContext == null ? "" : existingProgramsContext.trim();
        CrownRerankResult result = new CrownRerankResult();
        if (existing.isEmpty()) return result;
        String chosenModel = model == null || model.trim().isEmpty() ? "gpt-4.1-mini" : model.trim();
        String system =
                "너는 마음몬의 왕관 PT 재평가기이자 의미중복 병합 판정기다. 기존 PT를 새로 만들지는 않는다. 다만 이미 있는 PT 둘이 같은 유지기제와 같은 학습목표를 다루고, 한쪽이 다른 쪽의 자연스러운 하위단계/구체연습이면 별도 카드로 둘 이유가 없으므로 merge_into로 병합 대상을 지정한다. " +
                "오직 기존 PT들 사이의 우선순위만 다시 정한다. 전체 상담 원문을 시간축으로 보고 (A) 여러 시기와 장면에서 반복된 장기 중요도, " +
                "(B) 상담 후반/최근에도 실제로 살아 있는 최근 활성도, (C) 이것이 바뀌면 다른 감정·해석·행동 연쇄도 함께 달라지는 유지기제 중심성, " +
                "(D) 이미 충분히 익혔거나 DONE에 가까운지에 따른 미해결도를 함께 비교한다. 최근 한두 턴이 길거나 생생하다는 이유만으로 왕관을 주지 않는다. " +
                "반대로 과거에 중요했어도 최근 약화/해결된 축은 내려라. 가장 높은 priority가 왕관이며 반드시 한 개만 뚜렷한 1순위가 되게 한다. " +
                "crown_reason에는 왜 이 PT가 다른 기존 PT보다 상위인지 전체 반복성/최근 활성/상위 유지기제/미해결 중 핵심 근거를 1~2문장 생활언어로 적는다. " +
                "muscle_name과 merge_into는 입력에 있는 문자열을 글자 하나 바꾸지 말고 그대로 반환한다. merge_into는 병합하지 않을 PT면 빈 문자열이다. 같은 장면이더라도 경계 말하기/요청하기/신체상태 전달처럼 학습목표가 다르면 병합하지 않는다. 반드시 JSON 하나만 출력한다. 마크다운 금지. " +
                "스키마: {\"crown_muscle\":string,\"crown_reason\":string,\"programs\":[{\"muscle_name\":string,\"priority\":1-100,\"merge_into\":string}]}";
        String user = "[현재 저장된 PT]\n" + existing + "\n\n[전체 상담 원문]\n" + clip(clean, 45000);
        String text = callResponses(apiKey, chosenModel, system, user, 1600);
        JSONObject root = new JSONObject(extractJsonObject(text));
        result.crownMuscle = root.optString("crown_muscle", "").trim();
        result.crownReason = root.optString("crown_reason", "").trim();
        JSONArray arr = root.optJSONArray("programs");
        if (arr != null) {
            for (int i=0;i<arr.length();i++) {
                JSONObject o=arr.optJSONObject(i); if(o==null) continue;
                String name=o.optString("muscle_name","").trim(); if(name.isEmpty()) continue;
                result.priorities.put(name, clamp(o.optInt("priority",50),1,100));
                String into=o.optString("merge_into","").trim();
                if(!into.isEmpty() && !into.equals(name)) result.mergeInto.put(name, into);
            }
        }
        return result;
    }


    /** v10.16.4: Crown-only API. This is deliberately independent from every training-program parser/validator.
     * It returns only one existing program_id and a short reason. */
    public static final class CrownOnlyResult {
        public long crownProgramId = -1L;
        public String crownReason = "";
    }

    public static CrownOnlyResult rerankExistingCrownOnly(String apiKey, String model, String transcript, String existingProgramsContext) throws Exception {
        if (apiKey == null || apiKey.trim().isEmpty()) throw new IllegalArgumentException("OpenAI API Key가 비어 있어.");
        String clean = transcript == null ? "" : transcript.trim();
        if (clean.length() < 120) throw new IllegalArgumentException("저장된 상담 원문이 너무 짧아 왕관을 다시 평가하기 어려워.");
        String existing = existingProgramsContext == null ? "" : existingProgramsContext.trim();
        CrownOnlyResult result = new CrownOnlyResult();
        if (existing.isEmpty()) return result;

        java.util.LinkedHashSet<Long> allowedIds = new java.util.LinkedHashSet<>();
        java.util.regex.Matcher matcher = java.util.regex.Pattern.compile("program_id=(\\d+)").matcher(existing);
        while (matcher.find()) {
            try { long id = Long.parseLong(matcher.group(1)); if (id > 0) allowedIds.add(id); } catch (Exception ignored) {}
        }
        if (allowedIds.isEmpty()) throw new IllegalArgumentException("왕관 후보 PT의 program_id를 찾지 못했어.");

        String chosenModel = model == null || model.trim().isEmpty() ? "gpt-4.1-mini" : model.trim();
        String system =
                "너는 마음몬의 왕관 PT 선택 전용 평가기다. 새 PT 생성, 단계 생성, 수정, 삭제, 병합, 우선순위 배열 반환을 절대로 하지 않는다. " +
                "입력에 이미 존재하는 program_id 중 지금 가장 중요한 딱 하나만 선택한다. 전체 상담을 시간축으로 보고 " +
                "(A) 장기 반복성, (B) 최근 활성도, (C) 다른 감정·해석·행동 연쇄를 움직이는 상위 유지기제 중심성, (D) 아직 덜 해결된 정도를 함께 본다. " +
                "최근 한두 턴이 길다는 이유만으로 왕관을 바꾸지 않는다. [왕관 후보 PT]의 outcome_history와 learning_state를 실제 학습근거로 사용한다. MASTERY_CANDIDATE는 중요했던 축이어도 현재 미해결도를 크게 낮춰 왕관에서 자연스럽게 내려올 수 있게 한다. STABILIZING은 아직 일반화가 필요한 축으로 본다. LEARNING은 충분한 연습근거가 쌓이는 중이다. NEEDS_GENTLER/NEEDS_REDESIGN은 문제의 중요성과 별개로 같은 개입 강도나 방식을 반복하면 안 된다는 신호다. 반복 HELPED와 DONE은 미해결도를 낮추고, PARTIAL은 일부 학습됐지만 아직 살아 있는 축으로 본다. NO_CHANGE/WORSE는 아직 해결되지 않았다는 신호일 수 있으나 그 자체만으로 왕관을 주지 않는다. NO_OPPORTUNITY는 성공/실패 어느 쪽으로도 계산하지 않는다. crown_reason은 선택 이유를 생활언어 1~2문장으로 쓴다. " +
                "반드시 입력에 있는 program_id 하나만 반환한다.";
        String user = "[왕관 후보 PT]\n" + existing + "\n\n[누적 상담 원문]\n" + clip(clean, 45000);
        String out = callResponsesJson(apiKey, chosenModel, system, user, 700, "maeummon_crown_only_v2", buildCrownOnlySchema());
        JSONObject root = new JSONObject(out);
        result.crownProgramId = root.optLong("crown_program_id", -1L);
        result.crownReason = root.optString("crown_reason", "").trim();
        if (!allowedIds.contains(result.crownProgramId)) throw new IllegalArgumentException("왕관 응답이 현재 PT에 없는 program_id를 선택했어.");
        return result;
    }

    public static Analysis analyze(String apiKey, String model, String transcript) throws Exception {
        if (apiKey == null || apiKey.trim().isEmpty()) {
            throw new IllegalArgumentException("OpenAI API Key가 비어 있어. 기존 마음몬 설정에서 API Key를 먼저 저장해줘.");
        }
        String clean = transcript == null ? "" : transcript.trim();
        if (clean.length() < 120) throw new IllegalArgumentException("가져온 상담 내용이 너무 짧아. 채팅 상단의 공유로 만든 전체 대화 링크인지 확인해줘.");

        String chosenModel = model == null || model.trim().isEmpty() ? "gpt-4.1-mini" : model.trim();
        // Long counseling transcripts are analyzed in smaller chunks first.
        // This avoids sending 20k+ characters through several large passes, which was causing mobile API read timeouts.
        if (clean.length() > 12000) return analyzeLongTranscript(apiKey, chosenModel, clean);
        String clipped = clip(clean, 45000);

        // PASS 1: 넓게 후보를 찾는다. 이 단계에서는 훈련안을 만들지 않고,
        // 사용자 직접 진술과 GPT 해석을 분리하면서 독립된 반복 장면/유지기제를 수집한다.
        String discoverySystem =
                "너는 마음몬의 1차 상담 구조 탐색기다. 아직 훈련 프로그램을 만들지 마라. " +
                "주어진 ChatGPT 상담 원문에서 사용자가 직접 말한 장면·감정·예상·행동과 GPT의 해석/가설을 엄격히 구분한다. " +
                "사용자가 뒤에서 부정·수정한 해석은 rejected로 표시하고 후보 근거에서 제외한다. 상담 후반의 최신 정정이 우선이다. " +
                "서로 독립적으로 훈련할 가치가 있을 수 있는 반복 장면 또는 유지기제 후보를 넓게 찾되, 같은 현상을 이름만 바꿔 중복하지 마라. " +
                "후보는 최대 8개까지 허용한다. 각 후보에는 반드시 USER_EVIDENCE를 넣고, GPT의 추론만으로 생긴 후보는 evidence_strength를 weak로 둔다. " +
                "특정 문제군이나 고정 PT 이름을 기대하지 마라. 이 상담에서 실제로 반복되거나, 사용자가 동의했거나, 행동원칙으로 받아들인 내용만 뽑는다. " +
                "각 후보에는 다음번 비슷한 상황에서 연습할 수 있는 관찰 가능한 행동 하나를 behavior_target으로 적는다. " +
                "사용자 근거가 없는 심층 믿음, 진단, 상대 의도는 만들지 마라. 안전 신호는 실제 원문에 직접 있을 때만 별도 표시한다. " +
                "반드시 JSON 하나만 출력한다. 마크다운 금지. 스키마: " +
                "{\"user_facts\":[string],\"rejected_or_corrected_hypotheses\":[string],\"safety_signal\":string," +
                "\"candidates\":[{\"label\":string,\"mechanism\":string,\"user_evidence\":[string],\"context\":string," +
                "\"distinct_from\":string,\"behavior_target\":string,\"user_acceptance\":\"accepted|unclear|rejected\"," +
                "\"evidence_strength\":\"strong|moderate|weak\",\"trainability\":\"high|medium|low\"}]}";
        String discoveryUser = "다음 공유 원문을 분석해. 페이지 UI 문구가 섞였을 수 있으니 실제 사용자와 ChatGPT의 상담 대화만 중심으로 봐.\n\n" + clipped;

        String discoveryText = callResponses(apiKey, chosenModel, discoverySystem, discoveryUser, 2200);
        JSONObject discovery = new JSONObject(extractJsonObject(discoveryText));

        // PASS 2: 1차 후보를 서로 비교·병합한 뒤 실제로 분리할 가치가 있는 1~4개만 남기고
        // 각 축을 작은 현실 행동으로 변환한다. 긴 상담을 한 축으로 과도하게 압축하지 않는 대신,
        // 근거가 한 축뿐이면 억지 다중화를 하지 않는다.
        String synthesisSystem =
                "너는 마음몬의 2차 상담→현실훈련 설계기다. 입력으로 원문과 1차 후보 JSON을 받는다. " +
                "먼저 후보끼리 비교해 같은 유지기제의 다른 표현이면 병합하고, 실제로 다른 행동 기술이 필요한 축이면 분리한다. " +
                "최종 프로그램은 기본적으로 3~4개를 제시한다. 숫자를 맞추기 위해 고정된 PT나 익숙한 심리 주제를 끼워 넣지 마라. 이 상담에서 실제로 중요도가 높은 축만 사용한다. " +
                "프로그램 선정 우선순위는 (1) 사용자가 직접 반복해 말한 문제/행동, (2) 사용자가 '맞다/그렇다/필요하다'고 수용한 통찰, (3) 상담에서 구체적인 행동원칙으로 합의된 내용, (4) GPT 제안이지만 원문 장면과 직접 연결되는 확장 훈련 순서다. " +
                "같은 장면에서 여러 행동 기술이 정말 다르면 분리할 수 있지만, 이름만 다르고 실제 행동이 같으면 하나로 합친다. 긴 상담의 서로 다른 핵심 축을 한 주제의 변형 4개로 채우지 마라. " +
                "병합 기준은 이름이나 주제가 비슷한지가 아니라 실제로 같은 상황에서 같은 행동을 연습하는지다. 행동이 다르면 별도 프로그램으로 보존한다. " +
                "weak 후보나 사용자 동의 없는 GPT 추론은 source=EXPANSION으로만 제시하고, DIRECT로 단정하지 마라. " +
                "각 프로그램 reason에는 사용자 직접 발화/장면을 짧게 근거로 적고, 다른 프로그램과 왜 별도인지가 드러나게 한다. " +
                "muscle_name은 사용자 화면에 그대로 보인다. 임상·분류 용어 대신 생활 언어로 짧고 따뜻하게 쓴다. 예: 사실-미확인 정보 구분하기→보이는 것과 추측을 나누는 힘, 불확실성 내성→애매함을 견디는 힘. " +
                "PT 일반화 규칙: PT는 한 사건의 해결책이 아니라 여러 비슷한 상황에서 다시 쓸 수 있는 상위 능력으로 이름 붙인다. 다만 원문 근거 없는 영역까지 과장해 넓히지 않는다. reason에는 실제 사건·관계 장면을 근거로 남기고, muscle_name은 그 장면들을 관통하는 재사용 가능한 능력으로 쓴다. 예를 들어 의료진에게 상태를 말한 장면만 있어도 원문에 연인·친구·직장 등 다른 관계에서 상태/욕구/경계를 전달하려는 근거가 함께 있으면 '의료진에게 말하는 힘'보다 '내 상태를 정확히 전달하는 힘'처럼 상위 능력으로 묶는다. 반대로 의료 장면만 있고 다른 관계 일반화 근거가 전혀 없으면 억지로 넓히지 않는다. 상태·욕구·경계 전달 축 특별 규칙: muscle_name이 '내 상태를 정확히 전달하는 힘'처럼 범용 전달 능력인데 원문에 의료진 외에도 연인·친구·직장 등 최소 1개 이상의 다른 맥락 근거가 있으면, PT의 reason과 단계도 반드시 그 범위를 반영한다. 제목만 넓고 단계는 의료진/약물 기록에만 머무르는 불균형을 만들지 않는다. 이 경우 1단계는 몸·감정·욕구·경계를 스스로 구체화하는 연습, 2단계는 실제 필요한 상대에게 상태와 요청을 전달하는 연습, 3단계는 상대 반응이 기대와 달라도 자신의 상태·욕구·경계를 흐리지 않고 유지·조정하는 연습을 우선 고려한다. 의료 정보 기록은 필요하면 1단계나 하위 예시로 포함할 수 있지만 전체 PT를 의료진 전용으로 축소하지 않는다. " +
                "사용자가 부정하거나 수정한 가설은 절대 훈련 근거로 재사용하지 않는다. 상대 의도·관계 의미·사용자 가치에 대한 추론은 사실처럼 쓰지 않는다. " +
                "프로그램 priority는 1~100이며 가장 먼저 연습할 하나를 명확히 고른다. 단, 최우선(왕관) PT는 단순히 상담 후반에 가장 최근 언급됐거나 이번 대화에서 가장 길게 말한 주제를 고르지 마라. 전체 원문을 시간축으로 보고 (A) 여러 장면/시기에 반복된 장기 중요도, (B) 상담 후반에도 실제로 다시 활성화되는 최근성, (C) 이것이 바뀌면 다른 감정·해석·행동 연쇄도 함께 달라지는 유지기제 중심성, (D) 이미 충분히 익힌/완료된 힘이 아닌 현재 미해결도를 함께 비교한다. 즉 '전체에서 중요하고 최근에도 살아 있는 것'을 1순위로 둔다. 최근 한두 턴의 일시적 이슈만으로 오래 반복된 핵심축을 쉽게 밀어내지 말고, 반대로 과거에 중요했지만 현재 상당히 해결되었거나 최근 더 이상 작동하지 않는 축은 왕관을 유지하지 마라. 보조 프로그램도 DB에 저장될 수 있도록 모두 반환한다. " +
                "각 프로그램은 1~4개의 작은 행동 단계로 만든다. 성공 기준은 감정이 사라졌는지가 아니라 관찰 가능한 행동이다. " +
                "현재 과부하/소진/강한 불안이 핵심이면 RECOVERY 또는 STABILIZE를 우선한다. 이미 NO_CHANGE/WORSE로 확인된 방식은 같은 강도로 반복하지 않는다. 또한 상담 원문에서 사용자가 패닉·강한 불안·과부하 때 방 나가기, 차단, 손절, 장문 따지기, 퇴사처럼 되돌리기 어려운 결정을 충동적으로 하거나 하려 했고, 상담에서 '24시간 보류/결정 미루기/되돌릴 수 있는 거리두기' 같은 행동원칙을 사용자가 수용했다면 이것은 단순한 인지 재해석과 다른 '행동 제동 레버'다. 이런 직접근거가 있을 때는 사실-해석 분리 PT의 하위단계로 흡수하지 말고 독립 PT 후보로 우선 검토한다. 단, 원문에 그런 직접근거가 없으면 절대 억지로 만들지 않는다. " +
                "caution은 실제 안전 신호가 있을 때만 짧게 작성하고 없으면 빈 문자열이다. " +
                "반드시 JSON 하나만 출력한다. 마크다운 금지. 스키마: " +
                "{\"title\":string,\"current_concern\":string,\"formulation\":string,\"priority_direction\":string,\"caution\":string," +
                "\"programs\":[{\"name\":string,\"mechanism\":string,\"muscle_name\":string,\"priority\":1-100,\"reason\":string,\"source\":\"DIRECT|EXPANSION\"," +
                "\"steps\":[{\"order\":1-4,\"mode\":\"TRAINING|RECOVERY|STABILIZE|REVIEW|MAINTENANCE\",\"exercise_type\":string," +
                "\"exercise_text\":string,\"success_criterion\":string,\"rationale\":string,\"difficulty\":1-3}]}]}";
        String synthesisUser = "[상담 원문]\n" + clipped + "\n\n[1차 후보 분석]\n" + discovery.toString();
        String finalText = callResponses(apiKey, chosenModel, synthesisSystem, synthesisUser, 3000);
        JSONObject root = new JSONObject(extractJsonObject(finalText));
        Analysis result = parse(root);

        // 과도한 병합 방지: 1차에 근거 있는 후보가 여러 개인데 2차가 1개로 압축했다면
        // 같은 분석을 그대로 수용하지 않고 후보 보존 전용 재검토를 한 번 더 한다.
        int grounded = groundedCandidateCount(discovery);
        result.discoveredCandidateCount = discovery.optJSONArray("candidates") == null ? 0 : discovery.optJSONArray("candidates").length();
        result.groundedCandidateCount = grounded;
        if (result.programs.size() == 1 && grounded >= 2) {
            String retrySystem =
                    "너는 마음몬의 후보 보존 재검토기다. 앞선 2차 결과가 여러 근거 후보를 하나로 과도하게 병합했는지 검사한다. " +
                    "1차 JSON의 strong/moderate + trainability high/medium 후보를 하나씩 대조한다. 실제로 연습할 행동이 다르면 반드시 별도 프로그램으로 남긴다. " +
                    "예를 들어 '관찰 사실 적기', '결론을 미루기', '확인 행동을 늦추기', '경계를 말하기'는 서로 다른 행동이므로 같은 관계불안이라는 이유만으로 합치지 않는다. " +
                    "반대로 같은 행동을 표현만 바꾼 후보는 병합한다. 숫자를 맞추려고 weak 후보를 만들지 않는다. 최종 2~4개가 타당하면 그렇게 반환하고, 정말 하나뿐이면 1개를 유지한다. " +
                    "muscle_name은 분류명이 아니라 사용자가 바로 이해하는 생활 언어의 '~하는 힘' 형태를 우선한다. " +
                    "사용자가 정정/부정한 GPT 가설은 근거에서 제외한다. 반드시 이전과 동일한 최종 JSON 스키마 하나만 출력한다. 마크다운 금지.";
            String retryUser = "[상담 원문]\n" + clipped + "\n\n[1차 후보]\n" + discovery.toString() +
                    "\n\n[앞선 2차 결과]\n" + root.toString();
            String retryText = callResponses(apiKey, chosenModel, retrySystem, retryUser, 3200);
            Analysis retried = parse(new JSONObject(extractJsonObject(retryText)));
            if (retried.programs.size() > result.programs.size()) result = retried;
        }
        // 구조적 후보 보존: 2차/재검토가 또 후보를 잃어도 1차의 grounded 후보를 앱이 직접 보존한다.
        preserveGroundedCandidates(discovery, result);

        // PASS 3: 고정 PT/키워드 규칙 없이 상담 전체를 다시 훑어 최종 3~4개 구성을 점검한다.
        // 이미 나온 프로그램과 1차 후보를 함께 보고, 상담의 다른 핵심 축이 빠졌을 때만 보완한다.
        result = improveCoverageWithModel(apiKey, chosenModel, clipped, discovery, result);
        // PASS 4: 내용 고정 없이, 최종 프로그램끼리 실제 행동/학습목표가 겹치는지 다시 편집한다.
        // 겹치면 하나의 다단계 PT로 합치고, 빈 자리는 상담 전체에서 '다른 레버'가 있을 때만 보완한다.
        result = diversifyProgramsWithModel(apiKey, chosenModel, clipped, discovery, result);
        // v10.9.7: 최종 편집기가 서로 다른 후보까지 1개로 압축해버리는 것을 코드 레벨에서 막는다.
        // 특정 PT 이름을 하드코딩하지 않고, 1차 후보의 실제 behavior_target이 현재 PT와 충분히 다를 때만 복원한다.
        restoreDistinctDiscoveryCandidates(discovery, result);
        // v10.15.0: surface wording may differ while the maintenance mechanism / learning target is the same.
        // Merge those semantic duplicates into one PT and refill only with a genuinely different grounded lever.
        result = semanticDeduplicateAndRefillWithModel(apiKey, chosenModel, clipped, discovery, result);
        result.discoveredCandidateCount = discovery.optJSONArray("candidates") == null ? 0 : discovery.optJSONArray("candidates").length();
        result.groundedCandidateCount = grounded;
        normalizeDisplayMuscleNames(result);
        deduplicatePrograms(result);
        java.util.Collections.sort(result.programs, (a,b) -> Integer.compare(b.priority, a.priority));
        return result;
    }


    /** Incremental path for an already-synced shared conversation. Only the newly added turns are analyzed. */
    public static Analysis analyzeIncremental(String apiKey, String model, String existingProgramContext, String newTurns) throws Exception {
        if (apiKey == null || apiKey.trim().isEmpty()) throw new IllegalArgumentException("OpenAI API Key가 비어 있어.");
        String delta = newTurns == null ? "" : newTurns.trim();
        if (delta.length() < 20) throw new IllegalArgumentException("새로 추가된 상담 대화가 너무 짧아.");
        String chosenModel = model == null || model.trim().isEmpty() ? "gpt-4.1-mini" : model.trim();
        String system =
                "너는 마음몬의 증분 상담 업데이트 분석기다. 전체 상담을 처음부터 다시 해석하지 말고, 입력의 [기존 마음 PT]와 [새 대화]만 비교한다. " +
                "새 대화가 기존 PT를 지지하면 같은 muscle_name을 유지해 reason/priority를 갱신한다. [기존 마음 PT]에 outcome_history가 있으면 반드시 참고한다. 반복 HELPED는 이미 익힌 축의 미해결도를 낮추고, PARTIAL은 강도를 함부로 올리지 않으며, NO_CHANGE/WORSE는 같은 과제를 같은 강도로 되풀이하지 않는다. NO_OPPORTUNITY는 중립으로 본다. 새 대화가 실제로 다른 행동 기술을 요구하면 새 PT를 추가한다. priority 특히 1순위 왕관은 '전체에서 중요하고 최근에도 살아 있는 핵심'이라는 뜻이다. 기존 PT의 장기 반복성과 현재 status를 존중하고, 새 대화 한두 턴이 길거나 생생하다는 이유만으로 기존 왕관을 쉽게 교체하지 마라. 새 패턴이 반복적으로 재등장하거나 더 상위 유지기제로 확인되고, 기존 왕관이 DONE/충분히 약화된 근거가 있을 때 우선순위를 바꾼다. " +
                "사용자가 이전 해석을 명시적으로 정정·부정했다면 그 정정을 최우선으로 반영하고, 잘못된 기존 축을 재강화하지 않는다. " +
                "이 응답은 '이번 새 대화 때문에 바뀌거나 추가될 필요가 있는 PT'만 반환한다. 아무 변화가 없으면 programs는 빈 배열이다. " +
                "같은 의미의 PT를 이름만 바꿔 새로 만들지 말고, 기존 PT와 같은 축이면 muscle_name을 정확히 동일하게 써라. " +
                "표면 행동이 조금 달라도 같은 유지기제와 같은 학습목표를 다루는 연속 단계라면 새 PT로 쪼개지 말고 기존 PT의 단계 갱신으로 처리한다. 다만 새 대화에서 패닉/과부하 시 되돌리기 어려운 결정을 실제로 미루는 행동원칙이 반복·수용되었다면, 이는 단순 해석 재평가와 다른 행동 제동 레버일 수 있으므로 기존 인지 PT에 자동 흡수하지 말고 별도 PT 추가 필요성을 검토한다. " +
                "특정 PT 이름을 미리 가정하지 말고 새 대화의 사용자 직접 진술, 수용된 통찰, 행동원칙에 근거한다. " +
                "새 PT를 만들 때는 이번 사건 이름을 그대로 PT로 만들기보다, 기존 누적 상담에서도 반복될 수 있는 더 상위의 재사용 가능한 능력인지 확인한다. 단, 현재 새 대화에만 나타난 일회성 기술이라면 사건 범위를 넘어 과장해서 일반화하지 않는다. " +
                "반드시 JSON 하나만 출력한다. 스키마: {\"title\":string,\"current_concern\":string,\"formulation\":string,\"priority_direction\":string,\"caution\":string," +
                "\"programs\":[{\"name\":string,\"mechanism\":string,\"muscle_name\":string,\"priority\":1-100,\"reason\":string,\"source\":\"DIRECT|EXPANSION\"," +
                "\"steps\":[{\"order\":1-4,\"mode\":\"TRAINING|RECOVERY|STABILIZE|REVIEW|MAINTENANCE\",\"exercise_type\":string,\"exercise_text\":string,\"success_criterion\":string,\"rationale\":string,\"difficulty\":1-3}]}]}";
        String user = "[기존 마음 PT]\n" + (existingProgramContext == null ? "" : existingProgramContext) + "\n\n[새 대화]\n" + clip(delta, 18000);
        String text = callResponses(apiKey, chosenModel, system, user, 2600);
        Analysis a = parse(new JSONObject(extractJsonObject(text)));
        a.discoveredCandidateCount = a.programs.size();
        a.groundedCandidateCount = a.programs.size();
        normalizeDisplayMuscleNames(a);
        deduplicatePrograms(a);
        java.util.Collections.sort(a.programs, (x,y) -> Integer.compare(y.priority, x.priority));
        return a;
    }


    /** v10.16.1: Coverage-gap pass for an already analyzed accumulated counseling DB.
     * Returns ONLY genuinely missing high-value PT axes. Existing PTs are never renamed or deleted here. */
    public static Analysis analyzeCoverageGaps(String apiKey, String model, String transcript, String existingProgramContext) throws Exception {
        if (apiKey == null || apiKey.trim().isEmpty()) throw new IllegalArgumentException("OpenAI API Key가 비어 있어.");
        String clean = transcript == null ? "" : transcript.trim();
        if (clean.length() < 120) throw new IllegalArgumentException("저장된 상담 원문이 너무 짧아 보강분석하기 어려워.");
        String existing = existingProgramContext == null ? "" : existingProgramContext.trim();
        String chosenModel = model == null || model.trim().isEmpty() ? "gpt-4.1-mini" : model.trim();
        String system =
                "너는 마음몬의 PT 커버리지 감사기다. 이미 저장된 마음 PT를 존중하고, 전체 누적 상담 원문에 명확한 직접근거가 있는데도 현재 PT 목록에서 빠진 '독립 행동축'만 찾아라. " +
                "기존 PT와 같은 유지기제/같은 학습목표/같은 행동이면 절대 새 PT를 만들지 말고 programs를 비워라. 이름만 바꾼 중복도 금지다. 기존 PT의 outcome_history와 learning_state를 실제 학습근거로 사용한다. MASTERY_CANDIDATE는 새 PT를 억지로 더 붙일 이유가 아니라 이미 익힌 축으로 보고, STABILIZING은 일반화가 더 필요한지 확인한다. NEEDS_GENTLER/NEEDS_REDESIGN은 동일 과제를 복제하지 말고 강도나 레버를 바꿔야 한다. HELPED가 반복된 축은 이미 학습된 정도를 인정하고, NO_CHANGE/WORSE가 반복된 축은 동일한 과제를 복제하지 말고 다른 레버가 정말 필요한지 확인한다. NO_OPPORTUNITY는 근거로 세지 않는다. " +
                "반대로 원문에서 사용자가 패닉·강한 불안·과부하 때 방 나가기, 차단, 손절, 장문 따지기, 퇴사처럼 되돌리기 어려운 결정을 충동적으로 하거나 하려 했고, 상담에서 24시간 보류·결정 미루기·알림 끄기·앱 닫기·잠깐 쉬기 같은 되돌릴 수 있는 거리두기를 행동원칙으로 실제 수용했다면, 이것은 '사실/해석 분리'나 '관계 경계'와 다른 행동 제동 기술이다. 현재 PT 목록에 이 행동 제동 축이 없다면 반드시 독립 PT 1개로 반환한다. " +
                "이 규칙은 원문에 직접근거가 있을 때만 적용하며, 안전 신호 자체를 PT로 만들지는 않는다. 현재 PT가 이미 같은 행동을 명시적으로 훈련하면 새로 만들지 않는다. " +
                "그 밖에도 전체 상담에서 반복되고 사용자가 수용한 중요한 행동축이 현재 PT에 분명히 빠져 있을 때만 최대 2개까지 반환한다. 억지로 숫자를 채우지 마라. " +
                "muscle_name은 생활언어의 자연스러운 '~하는 힘' 형태로 짧게 쓴다. 각 PT는 실제로 해볼 수 있는 1~3단계 행동으로 만들고 성공 기준은 관찰 가능한 행동으로 쓴다. " +
                "muscle_name은 가능하면 한 사람/한 사건/한 기관에 종속되지 않고 여러 비슷한 장면에서 재사용 가능한 상위 능력으로 쓴다. reason에는 원문에서 확인된 구체 사건을 그대로 남겨 근거를 잃지 않는다. 의료/연애/친구/직장 등 서로 다른 맥락에서 같은 유지기제와 같은 행동 기술이 확인되면 하나의 넓은 PT로 묶고, 행동 레버가 다르면 별도 PT로 둔다. " +
                "priority는 현재 기존 왕관보다 자동으로 높게 주지 말고 중요도에 맞게 1~100으로 평가한다. 반드시 JSON 하나만 출력한다. 마크다운 금지. " +
                "스키마: {\"title\":string,\"current_concern\":string,\"formulation\":string,\"priority_direction\":string,\"caution\":string," +
                "\"programs\":[{\"name\":string,\"mechanism\":string,\"muscle_name\":string,\"priority\":1-100,\"reason\":string,\"source\":\"DIRECT|EXPANSION\"," +
                "\"steps\":[{\"order\":1-3,\"mode\":\"TRAINING|RECOVERY|STABILIZE|REVIEW|MAINTENANCE\",\"exercise_type\":string,\"exercise_text\":string,\"success_criterion\":string,\"rationale\":string,\"difficulty\":1-3}]}]}";
        String user = "[현재 저장된 PT]\n" + existing + "\n\n[누적 상담 전체 원문]\n" + clip(clean, 45000);
        String out = callResponsesJson(apiKey, chosenModel, system +
                " programs는 최대 2개, 각 steps는 최대 3개로 제한하고 JSON을 반드시 끝까지 완결한다.",
                user, 5000, "maeummon_coverage_gap_v2", buildFinalProgramSchema());
        Analysis a = parse(new JSONObject(out));
        a.discoveredCandidateCount = a.programs.size();
        a.groundedCandidateCount = a.programs.size();
        normalizeDisplayMuscleNames(a);
        deduplicatePrograms(a);
        java.util.Collections.sort(a.programs, (x,y) -> Integer.compare(y.priority, x.priority));
        return a;
    }


    /** v10.16.2: Keep the existing PT axes, but rewrite vague/generic steps into concrete progressive behaviors. */
    public static Analysis refineExistingProgramSteps(String apiKey, String model, String transcript, String existingProgramContext) throws Exception {
        if (apiKey == null || apiKey.trim().isEmpty()) throw new IllegalArgumentException("OpenAI API Key가 비어 있어.");
        String clean = transcript == null ? "" : transcript.trim();
        if (clean.length() < 120) throw new IllegalArgumentException("저장된 상담 원문이 너무 짧아 단계 다듬기가 어려워.");
        String existing = existingProgramContext == null ? "" : existingProgramContext.trim();
        if (existing.isEmpty()) return new Analysis();
        String chosenModel = model == null || model.trim().isEmpty() ? "gpt-4.1-mini" : model.trim();
        String system =
                "너는 마음몬의 PT 단계 품질 편집기다. 이미 정해진 PT 축/이름/우선순위는 바꾸지 말고, 각 PT의 단계만 실제 생활에서 바로 실행할 수 있게 다듬는다. " +
                "입력 [현재 PT]의 muscle_name은 철자까지 그대로 유지한다. 새 PT를 추가하거나 기존 PT를 삭제/병합하지 않는다. priority도 그대로 유지한다. outcome_history와 learning_state가 있으면 단계 설계에 반드시 반영한다. MASTERY_CANDIDATE면 단순 반복보다 실제 핵심 상황에서 유지·일반화·재발예방 쪽으로 설계하고, NEEDS_GENTLER면 강도를 낮추며, NEEDS_REDESIGN이면 같은 형식의 과제를 반복하지 않는다. HELPED가 반복된 행동은 불필요하게 더 쉽게 되돌리지 않고 다음 일반화로 이어가며, PARTIAL은 같은 핵심을 더 작은 행동으로, NO_CHANGE는 과제 크기/맥락을 바꾸고, WORSE는 동일 강도 반복을 피하고 안정화를 우선한다. NO_OPPORTUNITY는 난이도 판단에서 제외한다. " +
                "각 PT는 보통 3단계로 만든다. 1단계는 가장 작은 행동, 2단계는 반복/일반화, 3단계는 실제 관계나 높은 불안에서도 적용하는 단계다. 단계가 올라갈수록 단순히 횟수만 늘리지 말고 상황의 난이도, 불확실성, 자기주도성의 깊이가 실제로 올라가야 한다. 이미 2단계가 충분히 자연스러운 PT는 2단계로 유지해도 된다. \"단계 상승 계약\"을 지킨다: 1단계는 낮은 위험/짧은 시간/보조도구 사용 가능, 2단계는 여러 장면에서 반복하며 확인행동이나 외부 안심에 덜 의존, 3단계는 실제 핵심 트리거에서 스스로 선택하고 사후 복기까지 한다. difficulty는 3단계라면 반드시 1→2→3으로 상승시킨다. 각 단계의 exercise_text 첫 문장만 읽어도 앞 단계보다 무엇이 더 어려워졌는지 보여야 한다. " +
                "각 단계는 누적 상담에서 실제로 확인된 트리거와 패턴에 연결한다. 원문에 나온 사람 이름이나 사건을 억지로 반복할 필요는 없지만, '무반응을 봤을 때', '가까운 사람이 무거운 표정일 때', '약속을 취소하고 싶은데 미안함이 올라올 때'처럼 사용자의 실제 생활 장면을 일반화한 조건을 넣어 개인맞춤으로 만든다. 근거가 없는 상황은 만들지 않는다. " +
                "단계 일반화 규칙: 1단계는 원문에서 가장 직접적으로 확인된 대표 장면에 가깝게 시작하고, 2단계는 같은 유지기제가 나타나는 다른 관계/장소/채널 중 원문 근거가 있는 범위로 넓히며, 3단계는 특정 사람이나 장소가 달라도 스스로 같은 능력을 꺼내 쓸 수 있게 만든다. 예: 의료진에게 상태 전달 → 가까운 사람에게 상태와 필요 전달 → 갈등 상황에서도 상태/욕구/경계를 유지. 예: 단톡 무반응에서 사실/해석 분리 → 대면 표정·말투에서도 적용 → 낯선 관계 신호에서도 판결을 보류. 단, 원문에서 그런 확장 근거가 없으면 단계 일반화를 억지로 만들지 않는다. 범용 상태전달 PT 검증: 입력 PT가 상태·감정·욕구·경계 전달을 다루고 원문에 의료/관계/직장 중 둘 이상의 맥락 근거가 있다면, 3단계 중 최소 2단계는 서로 다른 맥락 또는 상대에게 적용되어야 한다. 세 단계 중 2개 이상을 약 이름·용량·수면기록·의료기관 전달만으로 채우지 않는다. 1단계는 '내가 지금 어떤 상태이고 무엇이 필요한지'를 스스로 문장화, 2단계는 필요한 상대에게 구체적 사실+욕구/요청을 전달, 3단계는 상대 반응이 기대와 달라도 내 상태와 경계를 유지하면서 필요한 조정을 선택하는 흐름을 기본 골격으로 삼는다. 다만 원문에 의료 외 맥락 근거가 없으면 이 골격을 강제하지 않는다. " +
                "exercise_text는 짧은 구호가 아니라 1~3문장까지 허용한다. 반드시 '언제/어떤 신호가 왔을 때 → 무엇을 하고 → 무엇은 하지 않을지'가 보이게 쓴다. '연습해보면 좋겠다', '생각해본다', '알아차린다'만으로 끝내지 않는다. " +
                "success_criterion은 감정이 없어졌는지가 아니라 관찰 가능한 행동으로 1~2문장 쓴다. 완벽한 성공만 요구하지 말고 실제로 확인 가능한 최소 성공을 제시한다. 예: '충동이 올라온 뒤 30분 동안 방 나가기/차단/장문 전송을 하지 않았고, 그 뒤 다시 판단했다.' " +
                "rationale은 2~4문장까지 허용한다. (1) 상담에서 어떤 반복 패턴이 확인됐는지, (2) 이 단계가 그 유지기제의 어느 고리를 끊는지, (3) 앞/뒤 단계와 무엇이 다른지를 생활언어로 설명한다. 사용자가 읽고 '아 그래서 이 훈련을 하는구나'라고 이해할 수 있어야 한다. " +
                "단계끼리 같은 행동을 숫자만 바꿔 반복하지 않는다. 각 단계 rationale 마지막에는 \"이전 단계보다 더 어려운 점\"을 생활언어로 한 문장 명시한다. 2단계는 1단계보다 적용 장면 또는 불확실성이 넓어야 하고, 3단계는 2단계보다 외부 확인 없이 자기 선택을 유지하는 요소가 반드시 하나 이상 있어야 한다. 실패하거나 기회가 없었던 결과도 다음 단계 설계의 정보로 쓸 수 있게, 지나치게 완벽주의적인 성공기준은 피한다. " +
                "특히 행동 제동 PT라면 원문에 근거가 있을 때 1단계는 짧은 가역적 멈춤(예: 30분), 2단계는 되돌리기 어려운 관계 결정의 24시간 보류, 3단계는 쉬고 난 뒤 사실/욕구/경계를 다시 확인하고 선택하는 흐름처럼 점진적으로 설계한다. 단, 원문에 없는 행동을 임의로 끼워 넣지 않는다. " +
                "사실/해석 분리 PT라면 사실 한 줄/해석 한 줄 → 대안설명 추가 → 높은 불안 상황에서도 판결 보류처럼 점진화한다. 경계 PT라면 작은 거절/짧은 거리두기 → 설명 최소화 → 관계를 끊지 않고 경계 유지처럼 구체화한다. 상태전달 PT라면 몸/감정/필요를 짧게 전달 → 부탁 한 가지 추가 → 갈등 상황에서도 직접 전달처럼 구체화한다. " +
                "과거에 이미 DONE/ACTIVE/PENDING이 있을 수 있으므로 결과는 단계 내용만 개선하는 용도다. 반드시 JSON 하나만 출력한다. 마크다운 금지. " +
                "스키마: {\"title\":string,\"current_concern\":string,\"formulation\":string,\"priority_direction\":string,\"caution\":string," +
                "\"programs\":[{\"name\":string,\"mechanism\":string,\"muscle_name\":string,\"priority\":1-100,\"reason\":string,\"source\":\"DIRECT|EXPANSION\"," +
                "\"steps\":[{\"order\":1-4,\"mode\":\"TRAINING|RECOVERY|STABILIZE|REVIEW|MAINTENANCE\",\"exercise_type\":string,\"exercise_text\":string,\"success_criterion\":string,\"rationale\":string,\"difficulty\":1-3}]}]}";
        String user = "[현재 PT]\n" + existing + "\n\n[누적 상담 전체 원문]\n" + clip(clean, 45000);
        String out = callResponsesJson(apiKey, chosenModel, system +
                " programs는 현재 PT 개수를 넘지 말고 각 steps는 최대 3개로 제한하며, 긴 설명도 반드시 완결된 문자열로 끝낸다.",
                user, 6500, "maeummon_step_refine_v2", buildFinalProgramSchema());
        Analysis a = parse(new JSONObject(out));
        normalizeDisplayMuscleNames(a);
        deduplicatePrograms(a);
        return a;
    }

    /**
     * Long-transcript path: split the raw conversation into modest chunks, extract grounded candidates per chunk,
     * then synthesize once from the compact evidence ledger. The raw transcript remains stored by the caller.
     */
    private static Analysis analyzeLongTranscript(String apiKey, String model, String transcript) throws Exception {
        final int chunkSize = 5200;
        final int overlap = 500;
        JSONArray chunkReports = new JSONArray();
        JSONArray allCandidates = new JSONArray();
        JSONArray allFacts = new JSONArray();
        JSONArray allRejected = new JSONArray();
        String safety = "";

        int start = 0;
        int chunkIndex = 0;
        while (start < transcript.length() && chunkIndex < 10) {
            int end = Math.min(transcript.length(), start + chunkSize);
            String chunk = transcript.substring(start, end);
            String sys =
                    "너는 마음몬의 장문상담 구간 탐색기다. 이 구간에서 사용자 직접 진술, 사용자가 받아들인 통찰, 정정된 가설, 실제 행동원칙, 반복 장면을 분리한다. " +
                    "고정 PT 이름을 적용하지 말고 이 구간에서 실제로 보이는 훈련 레버만 찾는다. GPT 혼자 한 해석은 사용자 사실로 확정하지 않는다. " +
                    "후보마다 관찰 가능한 behavior_target을 넣고, 사용자 수용 여부와 근거 강도를 표시한다. 안전 신호는 직접 있을 때만 적는다. " +
                    "JSON 하나만 출력한다. 스키마: {\"chunk_summary\":string,\"user_facts\":[string],\"rejected_or_corrected_hypotheses\":[string],\"safety_signal\":string," +
                    "\"candidates\":[{\"label\":string,\"mechanism\":string,\"user_evidence\":[string],\"context\":string,\"distinct_from\":string," +
                    "\"behavior_target\":string,\"user_acceptance\":\"accepted|unclear|rejected\",\"evidence_strength\":\"strong|moderate|weak\",\"trainability\":\"high|medium|low\"}]}";
            String usr = "[전체 상담의 " + (chunkIndex + 1) + "번째 구간]\n" + chunk;
            String txt = callResponsesJson(apiKey, model, sys +
                    " 출력은 짧고 완결된 JSON이어야 한다. chunk_summary는 350자 이내, candidates는 최대 3개, user_evidence는 후보당 최대 2개로 제한한다.",
                    usr, 3200, "maeummon_chunk_report", buildChunkReportSchema());
            JSONObject report;
            try {
                report = new JSONObject(extractJsonObject(txt));
            } catch (Exception badJson) {
                String repairSystem =
                        "직전 응답 JSON이 잘렸거나 문법 오류가 났다. 같은 상담 구간을 다시 읽고 반드시 완결된 JSON 하나만 출력한다. " +
                        "설명/마크다운 금지. chunk_summary 250자 이내, user_facts 최대 6개, rejected_or_corrected_hypotheses 최대 4개, candidates 최대 3개, " +
                        "각 candidate의 user_evidence는 최대 2개로 제한한다. 배열과 문자열을 반드시 끝까지 닫는다. " +
                        "스키마는 직전 요청과 동일하다.";
                String retryTxt = callResponsesJson(apiKey, model, repairSystem, usr, 3200, "maeummon_chunk_report_retry", buildChunkReportSchema());
                report = new JSONObject(extractJsonObject(retryTxt));
            }
            report.put("chunk_index", chunkIndex + 1);
            chunkReports.put(report);
            appendStrings(report.optJSONArray("user_facts"), allFacts, 80);
            appendStrings(report.optJSONArray("rejected_or_corrected_hypotheses"), allRejected, 40);
            if (safety.isEmpty()) safety = report.optString("safety_signal", "").trim();
            JSONArray cs = report.optJSONArray("candidates");
            if (cs != null) {
                for (int i = 0; i < cs.length() && allCandidates.length() < 32; i++) {
                    JSONObject c = cs.optJSONObject(i);
                    if (c != null) {
                        c.put("chunk_index", chunkIndex + 1);
                        allCandidates.put(c);
                    }
                }
            }
            if (end >= transcript.length()) break;
            start = Math.max(start + 1, end - overlap);
            chunkIndex++;
        }

        JSONObject ledger = new JSONObject();
        ledger.put("transcript_length", transcript.length());
        ledger.put("chunk_count", chunkReports.length());
        ledger.put("user_facts", allFacts);
        ledger.put("rejected_or_corrected_hypotheses", allRejected);
        ledger.put("safety_signal", safety);
        ledger.put("candidates", allCandidates);
        ledger.put("chunk_reports", chunkReports);

        String finalSystem =
                "너는 마음몬의 장문상담 최종 편집자다. 입력은 상담 원문 전체가 아니라 각 구간에서 뽑은 근거 원장이다. " +
                "구간 순서는 시간 순서이며 뒤 구간의 사용자 정정이 앞선 GPT 가설보다 우선한다. 고정된 PT 목록을 사용하지 않는다. " +
                "사용자 직접 반복, 사용자가 수용한 통찰, 상담에서 합의된 행동원칙, 실제 반복 가능성, 행동으로 훈련 가능한지를 종합해 서로 다른 2~4개 마음 PT를 만든다. 최우선(왕관) PT의 priority는 단순 최신 주제가 아니라 '전체에서 중요하고 최근에도 살아 있는 핵심'을 뜻한다. 구간 전체에서의 반복성, 뒤 구간에서도 재등장하는 최근 활성도, 다른 문제 연쇄를 만들어내는 유지기제 중심성, 아직 충분히 해결되지 않은 정도를 함께 비교한다. 오래된 핵심이라도 최근 해결/약화되었으면 우선순위를 낮추고, 최근 한 구간에만 잠깐 나온 이슈는 장기 핵심을 쉽게 밀어내지 않는다. " +
                "같은 상황+같은 행동+같은 학습목표일 때만 병합하고, 행동 레버가 다르면 별도 PT로 보존한다. 특히 '애매한 신호를 어떻게 해석할지'와 '패닉 상태에서 되돌리기 어려운 결정을 실제로 미루는 행동'은 장면이 이어져도 학습목표와 행동 시점이 다르므로, 사용자 직접근거가 있으면 서로 다른 PT 축으로 보존한다. " +
                "GPT 제안만 있고 사용자 확인이 약하면 source=EXPANSION, 사용자 직접근거/수용이 있으면 DIRECT로 둔다. " +
                "각 PT는 1~4단계이며 성공 기준은 감정 소멸이 아니라 관찰 가능한 행동이어야 한다. muscle_name은 생활언어의 자연스러운 '~하는 힘'으로 새로 만든다. " +
                "PT 이름은 특정 사건의 문구를 복사하지 말고, 여러 구간에서 반복되는 장면들을 관통하는 재사용 가능한 상위 능력으로 만든다. reason은 오히려 구체 사건/관계 장면을 충분히 남겨 왜 일반화했는지 보이게 한다. 한 구간에서만 나타난 일회성 기술은 근거 없이 다른 관계까지 확장하지 않는다. 단계가 여러 개라면 1단계는 직접 장면, 2단계는 원문에 확인된 다른 맥락, 3단계는 같은 유지기제를 스스로 일반화해 쓰는 순서가 되도록 한다. 특히 상태·욕구·경계 전달 축이 여러 구간에서 의료진과 가까운 관계/직장 양쪽에 나타났다면, 해당 PT를 의료 기록 기술로 좁히지 말고 '자기 상태를 알아차리고 필요한 사람에게 정확히 전달하며 반응이 달라도 경계를 유지하는 능력'으로 합성한다. " +
                "반드시 JSON 하나만 출력한다. 스키마: {\"title\":string,\"current_concern\":string,\"formulation\":string,\"priority_direction\":string,\"caution\":string," +
                "\"programs\":[{\"name\":string,\"mechanism\":string,\"muscle_name\":string,\"priority\":1,\"reason\":string,\"source\":\"DIRECT|EXPANSION\"," +
                "\"steps\":[{\"order\":1,\"mode\":\"TRAINING|RECOVERY|STABILIZE|REVIEW|MAINTENANCE\",\"exercise_type\":string,\"exercise_text\":string,\"success_criterion\":string,\"rationale\":string,\"difficulty\":1}]}]}";
        String finalUser = "[장문 상담 근거 원장]\n" + ledger.toString();
        // v10.17.5.2: For long counseling, finish a compact core PT JSON first.
        // Deep 1→2→3 step wording is refined in a later pass; the first import must never fail because a huge JSON was truncated.
        String finalText;
        try {
            finalText = callResponsesJson(apiKey, model, finalSystem +
                    " 최종 JSON은 programs 최대 4개로 제한하고, 이 첫 생성에서는 각 program의 steps를 정확히 1개만 반환한다. " +
                    "핵심 PT 축/근거/왕관 판단을 먼저 안전하게 완결하는 것이 최우선이다. reason은 충분히 구체적으로 쓰되 mechanism/exercise_text/success_criterion/rationale은 같은 말을 반복하지 말고 각각 1~3문장 안에서 완결한다. " +
                    "나머지 2~3단계 심화는 후속 단계 편집기가 전체 상담 원문을 보고 확장하므로 여기서 억지로 길게 만들지 않는다. 반드시 배열과 객체를 끝까지 닫은 완결 JSON 하나만 출력한다.",
                    finalUser, 6200, "maeummon_final_programs_compact", buildFinalProgramSchema());
        } catch (Exception firstStructuredFailure) {
            // One compact retry with an even smaller payload. This catches token-limit/incomplete JSON without losing the saved raw transcript.
            String compactRepairSystem = finalSystem +
                    " 이전 구조화 응답이 완결되지 않았다. 이번에는 복구가 최우선이다. programs는 2~4개, 각 program의 steps는 정확히 1개만 반환한다. " +
                    "title/current_concern/formulation/priority_direction/caution은 각각 짧고 완결된 문장으로 쓰고, reason/mechanism/exercise_text/success_criterion/rationale도 각각 핵심 1~2문장만 쓴다. " +
                    "절대로 설명문이나 마크다운을 붙이지 말고 JSON 배열/객체를 반드시 모두 닫는다.";
            finalText = callResponsesJson(apiKey, model, compactRepairSystem, finalUser, 7600, "maeummon_final_programs_compact_retry", buildFinalProgramSchema());
        }

        Analysis result;
        try {
            result = parse(new JSONObject(finalText));
        } catch (Exception impossibleBrokenStructuredJson) {
            // callResponsesJson validates JSON before returning, so reaching here means an unexpected wrapper issue.
            throw new IllegalArgumentException("긴 상담의 PT 구조를 끝까지 읽지 못했어. 원문은 안전하게 저장돼 있어. 같은 링크를 한 번 더 누르면 저장된 원문으로 분석만 다시 이어갈게.", impossibleBrokenStructuredJson);
        }

        JSONObject discovery = new JSONObject();
        discovery.put("user_facts", allFacts);
        discovery.put("rejected_or_corrected_hypotheses", allRejected);
        discovery.put("safety_signal", safety);
        discovery.put("candidates", allCandidates);
        result.discoveredCandidateCount = allCandidates.length();
        result.groundedCandidateCount = groundedCandidateCount(discovery);
        preserveGroundedCandidates(discovery, result);
        restoreDistinctDiscoveryCandidates(discovery, result);
        // v10.15.0 semantic PT dedupe for long transcripts too.
        result = semanticDeduplicateAndRefillWithModel(apiKey, model, ledger.toString(), discovery, result);
        normalizeDisplayMuscleNames(result);
        deduplicatePrograms(result);
        java.util.Collections.sort(result.programs, (a,b) -> Integer.compare(b.priority, a.priority));
        while (result.programs.size() > 4) result.programs.remove(result.programs.size() - 1);
        return result;
    }

    /** Final safety-net: the model can occasionally return the same PT twice with
     * slightly different spacing/punctuation. Keep the stronger one and never show
     * duplicate muscle cards. This intentionally stays conservative: only near-identical
     * normalized names are merged; different behavioral levers remain separate. */
    private static void deduplicatePrograms(Analysis a) {
        if (a == null || a.programs == null || a.programs.size() < 2) return;
        java.util.LinkedHashMap<String, Program> kept = new java.util.LinkedHashMap<>();
        for (Program p : new java.util.ArrayList<>(a.programs)) {
            if (p == null) continue;
            String key = normalizeProgramKey(p.muscleName);
            if (key.isEmpty()) key = normalizeProgramKey(p.name);
            Program old = kept.get(key);
            if (old == null) { kept.put(key, p); continue; }
            if (p.priority > old.priority || (p.priority == old.priority && p.steps.size() > old.steps.size())) {
                kept.put(key, p);
            }
        }
        a.programs.clear();
        a.programs.addAll(kept.values());
    }

    private static String normalizeProgramKey(String s) {
        if (s == null) return "";
        return s.toLowerCase(java.util.Locale.KOREA)
                .replaceAll("[^0-9a-z가-힣]", "")
                .replace("마음pt", "")
                .replace("pt", "")
                .trim();
    }

    private static void appendStrings(JSONArray from, JSONArray to, int limit) {
        if (from == null || to == null) return;
        for (int i = 0; i < from.length() && to.length() < limit; i++) {
            String v = from.optString(i, "").trim();
            if (v.isEmpty()) continue;
            boolean dup = false;
            for (int j = 0; j < to.length(); j++) if (v.equals(to.optString(j, ""))) { dup = true; break; }
            if (!dup) to.put(v);
        }
    }


    /**
     * Structured JSON path for long-chat analysis. Responses API Structured Outputs prevents
     * free-form JSON from ending with an unterminated array/string on long analyses.
     */
    private static String callResponsesJson(String apiKey, String model, String systemText, String userText,
                                            int maxOutputTokens, String schemaName, JSONObject schema) throws Exception {
        final long[] waits = new long[]{0L, 2000L, 5000L, 10000L};
        Exception last = null;
        for (int attempt = 0; attempt < waits.length; attempt++) {
            if (waits[attempt] > 0L) {
                try { Thread.sleep(waits[attempt]); } catch (InterruptedException ie) { Thread.currentThread().interrupt(); throw ie; }
            }
            try {
                return callResponsesJsonOnce(apiKey, model, systemText, userText, maxOutputTokens, schemaName, schema);
            } catch (Exception e) {
                last = e;
                if (!isTransientNetworkError(e) || attempt == waits.length - 1) throw e;
            }
        }
        throw last == null ? new RuntimeException("OpenAI JSON 분석 실패") : last;
    }

    private static String callResponsesJsonOnce(String apiKey, String model, String systemText, String userText,
                                                int maxOutputTokens, String schemaName, JSONObject schema) throws Exception {
        URL url = new URL("https://api.openai.com/v1/responses");
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("POST");
        conn.setRequestProperty("Authorization", "Bearer " + apiKey.trim());
        conn.setRequestProperty("Content-Type", "application/json");
        conn.setDoOutput(true);
        conn.setConnectTimeout(20000);
        conn.setReadTimeout(90000);

        JSONObject body = new JSONObject();
        body.put("model", model);
        body.put("max_output_tokens", maxOutputTokens);
        JSONArray input = new JSONArray();
        JSONObject system = new JSONObject();
        system.put("role", "system");
        system.put("content", systemText);
        input.put(system);
        JSONObject user = new JSONObject();
        user.put("role", "user");
        user.put("content", userText);
        input.put(user);
        body.put("input", input);

        JSONObject format = new JSONObject();
        format.put("type", "json_schema");
        format.put("name", schemaName);
        format.put("strict", true);
        format.put("schema", schema);
        JSONObject text = new JSONObject();
        text.put("format", format);
        body.put("text", text);

        try {
            try (OutputStream os = conn.getOutputStream()) {
                os.write(body.toString().getBytes(StandardCharsets.UTF_8));
            }
            int code = conn.getResponseCode();
            InputStream is = code >= 200 && code < 300 ? conn.getInputStream() : conn.getErrorStream();
            String response = readAll(is);
            if (code < 200 || code >= 300) throw new RuntimeException("OpenAI API 오류 (" + code + "): " + response);
            JSONObject root = new JSONObject(response);
            String status = root.optString("status", "");
            if ("incomplete".equals(status)) {
                throw new RuntimeException("OpenAI 구조화 응답이 완성되기 전에 종료됐어: " + root.optJSONObject("incomplete_details"));
            }
            String out = extractOutputText(root).trim();
            if (out.isEmpty()) throw new IllegalArgumentException("AI 구조화 분석 응답이 비어 있어.");
            // Validate here so callers never receive broken JSON.
            new JSONObject(out);
            return out;
        } finally {
            conn.disconnect();
        }
    }


    private static JSONObject buildCrownOnlySchema() throws Exception {
        return objectSchema(
                new String[]{"crown_program_id","crown_reason"},
                new JSONObject()
                        .put("crown_program_id", integerSchema())
                        .put("crown_reason", stringSchema())
        );
    }

    private static JSONObject buildChunkReportSchema() throws Exception {
        JSONObject candidate = objectSchema(
                new String[]{"label","mechanism","user_evidence","context","distinct_from","behavior_target","user_acceptance","evidence_strength","trainability"},
                new JSONObject()
                        .put("label", stringSchema())
                        .put("mechanism", stringSchema())
                        .put("user_evidence", arrayOf(stringSchema()))
                        .put("context", stringSchema())
                        .put("distinct_from", stringSchema())
                        .put("behavior_target", stringSchema())
                        .put("user_acceptance", enumString("accepted","unclear","rejected"))
                        .put("evidence_strength", enumString("strong","moderate","weak"))
                        .put("trainability", enumString("high","medium","low"))
        );
        return objectSchema(
                new String[]{"chunk_summary","user_facts","rejected_or_corrected_hypotheses","safety_signal","candidates"},
                new JSONObject()
                        .put("chunk_summary", stringSchema())
                        .put("user_facts", arrayOf(stringSchema()))
                        .put("rejected_or_corrected_hypotheses", arrayOf(stringSchema()))
                        .put("safety_signal", stringSchema())
                        .put("candidates", arrayOf(candidate))
        );
    }

    private static JSONObject buildFinalProgramSchema() throws Exception {
        JSONObject step = objectSchema(
                new String[]{"order","mode","exercise_type","exercise_text","success_criterion","rationale","difficulty"},
                new JSONObject()
                        .put("order", integerSchema())
                        .put("mode", enumString("TRAINING","RECOVERY","STABILIZE","REVIEW","MAINTENANCE"))
                        .put("exercise_type", stringSchema())
                        .put("exercise_text", stringSchema())
                        .put("success_criterion", stringSchema())
                        .put("rationale", stringSchema())
                        .put("difficulty", integerSchema())
        );
        JSONObject program = objectSchema(
                new String[]{"name","mechanism","muscle_name","priority","reason","source","steps"},
                new JSONObject()
                        .put("name", stringSchema())
                        .put("mechanism", stringSchema())
                        .put("muscle_name", stringSchema())
                        .put("priority", integerSchema())
                        .put("reason", stringSchema())
                        .put("source", enumString("DIRECT","EXPANSION"))
                        .put("steps", arrayOf(step))
        );
        return objectSchema(
                new String[]{"title","current_concern","formulation","priority_direction","caution","programs"},
                new JSONObject()
                        .put("title", stringSchema())
                        .put("current_concern", stringSchema())
                        .put("formulation", stringSchema())
                        .put("priority_direction", stringSchema())
                        .put("caution", stringSchema())
                        .put("programs", arrayOf(program))
        );
    }

    private static JSONObject objectSchema(String[] required, JSONObject properties) throws Exception {
        JSONArray req = new JSONArray();
        for (String r : required) req.put(r);
        return new JSONObject().put("type", "object").put("properties", properties).put("required", req).put("additionalProperties", false);
    }

    private static JSONObject stringSchema() throws Exception { return new JSONObject().put("type", "string"); }
    private static JSONObject integerSchema() throws Exception { return new JSONObject().put("type", "integer"); }
    private static JSONObject arrayOf(JSONObject items) throws Exception { return new JSONObject().put("type", "array").put("items", items); }
    private static JSONObject enumString(String... values) throws Exception {
        JSONArray a = new JSONArray();
        for (String v : values) a.put(v);
        return new JSONObject().put("type", "string").put("enum", a);
    }

    private static String callResponses(String apiKey, String model, String systemText, String userText, int maxOutputTokens) throws Exception {
        final long[] waits = new long[]{0L, 2000L, 5000L, 10000L};
        Exception last = null;
        for (int attempt = 0; attempt < waits.length; attempt++) {
            if (waits[attempt] > 0L) {
                try { Thread.sleep(waits[attempt]); } catch (InterruptedException ie) { Thread.currentThread().interrupt(); throw ie; }
            }
            try {
                return callResponsesOnce(apiKey, model, systemText, userText, maxOutputTokens);
            } catch (Exception e) {
                last = e;
                if (!isTransientNetworkError(e) || attempt == waits.length - 1) throw e;
            }
        }
        throw last == null ? new RuntimeException("OpenAI API 연결 실패") : last;
    }

    private static String callResponsesOnce(String apiKey, String model, String systemText, String userText, int maxOutputTokens) throws Exception {
        URL url = new URL("https://api.openai.com/v1/responses");
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("POST");
        conn.setRequestProperty("Authorization", "Bearer " + apiKey.trim());
        conn.setRequestProperty("Content-Type", "application/json");
        conn.setDoOutput(true);
        conn.setConnectTimeout(20000);
        conn.setReadTimeout(70000);

        JSONObject body = new JSONObject();
        body.put("model", model);
        body.put("max_output_tokens", maxOutputTokens);
        JSONArray input = new JSONArray();
        JSONObject system = new JSONObject();
        system.put("role", "system");
        system.put("content", systemText);
        input.put(system);
        JSONObject user = new JSONObject();
        user.put("role", "user");
        user.put("content", userText);
        input.put(user);
        body.put("input", input);

        try {
            try (OutputStream os = conn.getOutputStream()) {
                os.write(body.toString().getBytes(StandardCharsets.UTF_8));
            }
            int code = conn.getResponseCode();
            InputStream is = code >= 200 && code < 300 ? conn.getInputStream() : conn.getErrorStream();
            String response = readAll(is);
            if (code < 200 || code >= 300) throw new RuntimeException("OpenAI API 오류 (" + code + "): " + response);
            String text = extractOutputText(new JSONObject(response)).trim();
            if (text.isEmpty()) throw new IllegalArgumentException("AI 분석 응답이 비어 있어. 잠시 후 다시 시도해줘.");
            return text;
        } finally {
            conn.disconnect();
        }
    }

    private static boolean isTransientNetworkError(Throwable t) {
        Throwable x = t;
        while (x != null) {
            if (x instanceof UnknownHostException || x instanceof SocketTimeoutException || x instanceof ConnectException) return true;
            String m = x.getMessage();
            if (m != null) {
                String q = m.toLowerCase();
                if (q.contains("unable to resolve host") || q.contains("no address associated with hostname") || q.contains("timeout") || q.contains("timed out")) return true;
            }
            x = x.getCause();
        }
        return false;
    }

    private static Analysis parse(JSONObject root) {
        Analysis a = new Analysis();
        a.title = root.optString("title", "상담 완전판").trim();
        a.currentConcern = root.optString("current_concern", "").trim();
        a.formulation = root.optString("formulation", "").trim();
        a.priorityDirection = root.optString("priority_direction", "").trim();
        a.caution = root.optString("caution", "").trim();
        JSONArray ps = root.optJSONArray("programs");
        if (ps != null) {
            for (int i = 0; i < ps.length() && i < 5; i++) {
                JSONObject p = ps.optJSONObject(i);
                if (p == null) continue;
                Program x = new Program();
                x.name = p.optString("name", "마음 PT 프로그램").trim();
                x.mechanism = p.optString("mechanism", "").trim();
                x.muscleName = p.optString("muscle_name", x.name).trim();
                x.priority = clamp(p.optInt("priority", 50), 1, 100);
                x.reason = p.optString("reason", "").trim();
                String src = p.optString("source", "DIRECT").trim().toUpperCase();
                x.source = "EXPANSION".equals(src) ? "EXPANSION" : "DIRECT";
                JSONArray ss = p.optJSONArray("steps");
                if (ss != null) {
                    for (int j = 0; j < ss.length() && j < 4; j++) {
                        JSONObject s = ss.optJSONObject(j);
                        if (s == null) continue;
                        Step st = new Step();
                        st.order = clamp(s.optInt("order", j + 1), 1, 4);
                        st.mode = normalizeMode(s.optString("mode", "TRAINING"));
                        st.exerciseType = emptyTo(s.optString("exercise_type", ""), "GPT_COUNSELING_PROGRAM");
                        st.exerciseText = s.optString("exercise_text", "").trim();
                        st.successCriterion = s.optString("success_criterion", "").trim();
                        st.rationale = s.optString("rationale", "").trim();
                        st.difficulty = clamp(s.optInt("difficulty", 1), 1, 3);
                        if (!st.exerciseText.isEmpty() && !st.successCriterion.isEmpty()) x.steps.add(st);
                    }
                }
                if (!x.muscleName.isEmpty() && !x.steps.isEmpty()) a.programs.add(x);
            }
        }
        if (a.programs.isEmpty()) throw new IllegalArgumentException("상담에서 실행 가능한 훈련 프로그램을 만들지 못했어. 링크가 전체 상담을 포함하는지 확인해줘.");
        return a;
    }


    private static boolean hasMuscleName(Analysis a, String name) {
        if (name == null) return false;
        String n = name.trim();
        for (Program p : a.programs) if (n.equals(p.muscleName)) return true;
        return false;
    }

    private static Program simpleProgram(String muscle, int priority, String reason, String exercise, String criterion, String rationale) {
        Program p = new Program();
        p.name = muscle;
        p.muscleName = muscle;
        p.mechanism = "SUPPORTED_SCENE_SKILL_DECOMPOSITION:" + muscle;
        p.source = "EXPANSION";
        p.priority = clamp(priority, 1, 100);
        p.reason = reason == null ? "" : reason;
        Step st = new Step();
        st.order = 1;
        st.mode = "TRAINING";
        st.exerciseType = "SUPPORTED_SCENE_SKILL_DECOMPOSITION";
        st.exerciseText = exercise;
        st.successCriterion = criterion;
        st.rationale = rationale;
        st.difficulty = 1;
        p.steps.add(st);
        return p;
    }

    private static int groundedCandidateCount(JSONObject discovery) {
        JSONArray candidates = discovery == null ? null : discovery.optJSONArray("candidates");
        int grounded = 0;
        if (candidates == null) return 0;
        for (int i = 0; i < candidates.length(); i++) {
            JSONObject c = candidates.optJSONObject(i);
            if (c == null) continue;
            String strength = c.optString("evidence_strength", "weak");
            String trainability = c.optString("trainability", "low");
            if (("strong".equals(strength) || "moderate".equals(strength)) && !"low".equals(trainability)) grounded++;
        }
        return grounded;
    }

    private static void preserveGroundedCandidates(JSONObject discovery, Analysis result) {
        JSONArray cs = discovery == null ? null : discovery.optJSONArray("candidates");
        if (cs == null || result == null) return;
        int target = Math.min(4, groundedCandidateCount(discovery));
        if (result.programs.size() >= target) return;
        for (int i = 0; i < cs.length() && result.programs.size() < target; i++) {
            JSONObject c = cs.optJSONObject(i); if (c == null) continue;
            String strength=c.optString("evidence_strength","weak"), train=c.optString("trainability","low");
            if (!("strong".equals(strength)||"moderate".equals(strength)) || "low".equals(train)) continue;
            String label=c.optString("label","").trim(), mech=c.optString("mechanism","").trim();
            if (represented(result,label,mech)) continue;
            Program p = fallbackProgramFromCandidate(c, 72 - result.programs.size()*6);
            if (p != null) result.programs.add(p);
        }
    }

    private static void restoreDistinctDiscoveryCandidates(JSONObject discovery, Analysis result) {
        JSONArray cs = discovery == null ? null : discovery.optJSONArray("candidates");
        if (cs == null || result == null || result.programs.size() >= 4) return;

        for (int i = 0; i < cs.length() && result.programs.size() < 4; i++) {
            JSONObject c = cs.optJSONObject(i);
            if (c == null) continue;
            String strength = c.optString("evidence_strength", "weak");
            String trainability = c.optString("trainability", "low");
            String acceptance = c.optString("user_acceptance", "unclear");
            if ("rejected".equals(acceptance) || "low".equals(trainability)) continue;
            if (!("strong".equals(strength) || "moderate".equals(strength))) continue;

            String behavior = c.optString("behavior_target", "").trim();
            String label = c.optString("label", "").trim();
            String mech = c.optString("mechanism", "").trim();
            if (represented(result, label, mech)) continue;
            if (!behavior.isEmpty() && behaviorAlreadyCovered(result, behavior)) continue;

            Program p = fallbackProgramFromCandidate(c, 76 - result.programs.size() * 5);
            if (p != null) result.programs.add(p);
        }
    }

    private static boolean behaviorAlreadyCovered(Analysis result, String candidateBehavior) {
        String cb = normalizeBehavior(candidateBehavior);
        if (cb.isEmpty()) return false;
        for (Program p : result.programs) {
            for (Step st : p.steps) {
                String eb = normalizeBehavior(st.exerciseText);
                if (eb.isEmpty()) continue;
                // 같은 행동을 표현만 바꾼 경우에만 중복으로 본다.
                if (eb.contains(cb) || cb.contains(eb)) return true;
                if (tokenOverlap(cb, eb) >= 0.72) return true;
            }
        }
        return false;
    }

    private static String normalizeBehavior(String s) {
        if (s == null) return "";
        return s.toLowerCase()
                .replaceAll("[\\p{Punct}\\s]+", "")
                .replace("한다", "")
                .replace("하기", "")
                .replace("적는다", "적기")
                .trim();
    }

    private static double tokenOverlap(String a, String b) {
        if (a.isEmpty() || b.isEmpty()) return 0.0;
        java.util.Set<String> sa = new java.util.HashSet<>();
        java.util.Set<String> sb = new java.util.HashSet<>();
        for (int i = 0; i < a.length() - 1; i++) sa.add(a.substring(i, i + 2));
        for (int i = 0; i < b.length() - 1; i++) sb.add(b.substring(i, i + 2));
        if (sa.isEmpty() || sb.isEmpty()) return 0.0;
        int inter = 0;
        for (String x : sa) if (sb.contains(x)) inter++;
        return inter / (double) Math.min(sa.size(), sb.size());
    }

    private static boolean represented(Analysis a, String label, String mech) {
        String key=(label+" "+mech).toLowerCase().replaceAll("\\s+","");
        for (Program p:a.programs){
            String pk=(p.name+" "+p.muscleName+" "+p.mechanism).toLowerCase().replaceAll("\\s+","");
            if (!label.isEmpty() && (pk.contains(label.toLowerCase().replaceAll("\\s+","")) || key.contains(p.muscleName.toLowerCase().replaceAll("\\s+","")))) return true;
            if (!mech.isEmpty() && pk.contains(mech.toLowerCase().replaceAll("\\s+",""))) return true;
        }
        return false;
    }

    private static Program fallbackProgramFromCandidate(JSONObject c, int priority) {
        String label = c.optString("label", "훈련 후보").trim();
        String mech = c.optString("mechanism", "").trim();
        String context = c.optString("context", "").trim();
        String behavior = c.optString("behavior_target", "").trim();
        String acceptance = c.optString("user_acceptance", "unclear").trim();
        Program p = new Program();
        p.name = label;
        p.mechanism = mech;
        p.priority = clamp(priority, 35, 88);
        p.source = "accepted".equals(acceptance) ? "DIRECT" : "EXPANSION";
        JSONArray ev = c.optJSONArray("user_evidence");
        p.reason = (ev != null && ev.length() > 0) ? ev.optString(0) : context;
        p.muscleName = naturalMuscleName(label);

        Step st = new Step();
        st.order = 1;
        st.mode = "TRAINING";
        st.difficulty = 1;
        st.exerciseType = "PRESERVED_DISCOVERY_CANDIDATE";
        if (!behavior.isEmpty()) {
            st.exerciseText = behavior;
            st.successCriterion = "다음 비슷한 상황에서 이 행동을 한 번 실제로 해봤다.";
            st.rationale = "상담에서 발견된 후보를 실제 상황에서 검증해보는 첫 단계야.";
        } else {
            st.exerciseText = "다음에 비슷한 상황이 생기면 상황 1줄, 자동으로 떠오른 반응 1줄, 내가 선택한 행동 1줄을 적는다.";
            st.successCriterion = "상황·반응·선택 행동을 각각 한 줄씩 기록했다.";
            st.rationale = "상담에서 발견된 패턴이 실제 생활에서도 반복되는지 먼저 확인하는 단계야.";
        }
        p.steps.add(st);
        return p;
    }

    private static String naturalMuscleName(String label) {
        String n = label == null ? "" : label.trim();
        if (n.isEmpty()) return "내 반응을 다루는 힘";
        if (n.endsWith("힘")) return n;
        if (n.endsWith("하기")) return n.substring(0, n.length() - 2) + "는 힘";
        if (n.length() <= 20) return n + "을 다루는 힘";
        return n;
    }

    private static Analysis improveCoverageWithModel(String apiKey, String model, String transcript, JSONObject discovery, Analysis current) throws Exception {
        if (current == null) return current;
        String system =
                "너는 마음몬의 최종 PT 편집자다. 특정 PT 이름이나 문제군을 미리 정하지 않는다. " +
                "상담 원문 전체, 1차 후보, 현재 프로그램을 함께 읽고 이 상담에서 사용자가 실제로 훈련할 가치가 높은 서로 다른 3~4개 축을 고른다. " +
                "중요도 판단 기준은 사용자 직접 반복, 사용자 수용/동의, 상담에서 합의된 행동원칙, 생활에서 반복될 가능성, 작은 행동으로 훈련 가능한지다. " +
                "사용자가 정정한 해석은 제외한다. GPT가 제안했지만 사용자가 확인하지 않은 내용은 가능하면 source=EXPANSION으로 표시한다. " +
                "같은 의미의 표현만 바꾼 중복 PT는 제거하고, 서로 다른 상담 핵심을 한 장면의 변형들로 채우지 않는다. " +
                "반대로 중요한 축이 여러 개면 한 개의 추상 능력으로 압축하지 않는다. 원문상 정말 1~2개뿐이면 억지로 3~4개를 만들지 않는다. " +
                "각 PT는 이름, 왜 중요한지, 실제로 해볼 행동, 성공 기준이 서로 구별되어야 한다. 특히 원문에 '패닉 때 방 나가기/차단/손절/퇴사/장문 따지기 같은 되돌리기 어려운 행동을 보류하고, 알림 끄기/앱 닫기/쉬기 같은 되돌릴 수 있는 거리두기를 쓰자'는 합의가 있으면 이를 독립 행동축 후보로 누락하지 않았는지 점검한다. 이 규칙은 해당 근거가 있을 때만 적용한다. muscle_name은 생활 언어의 자연스러운 '~하는 힘' 형태를 우선한다. " +
                "반드시 JSON 하나만 출력한다. 마크다운 금지. 스키마: " +
                "{\"title\":string,\"current_concern\":string,\"formulation\":string,\"priority_direction\":string,\"caution\":string," +
                "\"programs\":[{\"name\":string,\"mechanism\":string,\"muscle_name\":string,\"priority\":1-100,\"reason\":string,\"source\":\"DIRECT|EXPANSION\"," +
                "\"steps\":[{\"order\":1-4,\"mode\":\"TRAINING|RECOVERY|STABILIZE|REVIEW|MAINTENANCE\",\"exercise_type\":string,\"exercise_text\":string,\"success_criterion\":string,\"rationale\":string,\"difficulty\":1-3}]}]}";
        JSONObject cur = analysisToJson(current);
        String user = "[상담 원문]\n" + transcript + "\n\n[1차 후보]\n" + discovery.toString() + "\n\n[현재 프로그램]\n" + cur.toString();
        String text = callResponses(apiKey, model, system, user, 3400);
        Analysis edited = parse(new JSONObject(extractJsonObject(text)));
        // 모델이 오히려 중요한 직접근거 프로그램을 잃으면 현재 결과를 보존하고, 새 결과의 고유 축만 보탠다.
        mergeDirectPrograms(current, edited);
        if (edited.programs.isEmpty()) return current;
        return edited;
    }


    private static Analysis diversifyProgramsWithModel(String apiKey, String model, String transcript, JSONObject discovery, Analysis current) throws Exception {
        if (current == null || current.programs.isEmpty()) return current;
        String system =
                "너는 마음몬의 최종 다양성 편집자다. 특정 PT 이름, 진단, 문제군을 미리 정하지 않는다. " +
                "목표는 숫자를 채우는 것이 아니라 상담에서 실제로 서로 다른 훈련 레버를 보존하는 것이다. " +
                "현재 PT 둘이 (A) 같은 상황에서, (B) 같은 관찰 가능한 행동을 요구하고, (C) 같은 학습목표를 가진 경우에만 중복으로 보고 하나의 PT 안 단계로 합친다. 세 조건 중 하나라도 다르면 삭제하지 말고 별도 PT로 유지한다. " +
                "반대로 상황이 같아도 행동이 다르거나, 행동 시점이 다르거나, 바꾸려는 유지기제가 다르면 별도 PT로 유지한다. 예를 들어 '신호를 사실/해석으로 나누기'와 '패닉 때 실제 결정을 24시간 미루기'는 전자는 인지 판결 속도를 낮추는 기술이고 후자는 행동 실행을 지연하는 기술이므로, 원문에 둘 다 직접근거가 있으면 별도 PT다. " +
                "중복을 합쳐 PT 수가 줄었으면 상담 원문과 1차 후보를 다시 훑어 아직 프로그램으로 변환되지 않은 '다른 레버'가 있는지 찾는다. " +
                "다른 레버는 사용자가 직접 반복한 내용, 사용자가 수용한 통찰, 상담에서 합의된 행동원칙, 또는 원문 장면과 직접 연결된 확장 연습 중 하나여야 한다. " +
                "GPT 혼자 제안한 미확인 가설은 source=EXPANSION으로만 둘 수 있고, 사용자가 정정한 내용은 제외한다. " +
                "한 장면을 비슷한 말로 3~4개 쪼개지 말고, 반대로 서로 다른 유지기제를 하나의 추상적인 '마음관리'로 뭉개지도 마라. " +
                "각 PT의 첫 단계 exercise_text와 success_criterion만 읽어도 서로 다른 연습임이 보여야 한다. " +
                "최종 개수는 보통 2~4개다. 1개로 줄이려면 나머지 모든 후보가 실제 행동까지 동일하거나 근거가 약하다는 이유가 명확해야 한다. 중요한 건 비중복성과 상담 전체 커버리지다. " +
                "muscle_name은 상담에서 나온 의미를 생활언어의 짧은 '~하는 힘'으로 새로 붙인다. 고정 목록에서 선택하지 마라. " +
                "반드시 기존 최종 JSON 스키마 하나만 출력한다. 마크다운 금지.";
        String user = "[상담 원문]\n" + transcript + "\n\n[1차 후보]\n" + discovery.toString() +
                "\n\n[현재 PT]\n" + analysisToJson(current).toString();
        String text = callResponses(apiKey, model, system, user, 3600);
        Analysis edited = parse(new JSONObject(extractJsonObject(text)));
        if (edited.programs.isEmpty()) return current;
        // 모델 편집 결과가 프로그램을 과도하게 삭제하지 못하게 앱이 한 번 더 검증한다.
        // 삭제 허용 조건은 실제로 같은 상황 + 같은 행동 + 같은 학습목표일 때뿐이다.
        reconcileBehaviorDistinctPrograms(current, edited);
        deduplicatePrograms(edited);
        return edited;
    }

    /**
     * v10.15.0 Semantic dedupe pass.
     * Detects PTs that look different on the surface but train the same maintenance mechanism / learning goal.
     * When two PTs are one learning axis, it merges their useful steps into one program. If a slot opens,
     * it may refill it only with a grounded candidate that changes a genuinely different lever.
     */
    private static Analysis semanticDeduplicateAndRefillWithModel(String apiKey, String model, String evidenceText, JSONObject discovery, Analysis current) throws Exception {
        if (current == null || current.programs.size() < 2) return current;
        String system =
                "너는 마음몬의 의미중복 PT 편집자다. 지금 단계의 목표는 PT 개수를 늘리는 것이 아니라 '같은 핵심을 다른 말로 두 장 만든 중복'을 없애는 것이다. " +
                "PT 이름이 달라도 다음을 비교한다: (1) 같은 유지기제를 끊는가, (2) 사용자가 배우려는 핵심 학습목표가 같은가, (3) 한 PT의 행동이 다른 PT의 자연스러운 다음 단계/하위 단계인가. " +
                "이 셋 중 (1)+(2)가 같고 행동들이 한 축의 연속 단계라면 같은 PT로 병합한다. 예를 들어 '무반응과 해석을 분리하기'와 '신호를 바로 판결하지 않기'가 모두 애매한 신호를 곧바로 거절/배척으로 확정하지 않는 학습을 목표로 한다면 별도 카드 두 장이 아니라 하나의 PT 안 서로 다른 단계가 더 적절하다. " +
                "반대로 같은 관계 장면이라도 경계 말하기, 회복하기, 확인행동 늦추기처럼 바꾸는 레버나 학습목표가 실제로 다르면 별도 PT로 유지한다. 특히 '사실/해석 분리'와 '패닉에서 되돌릴 수 없는 결정을 보류'는 같은 불안 흐름에 있어도 하나는 해석 기술, 하나는 행동 제동 기술이므로 사용자 직접근거가 있으면 병합하지 않는다. " +
                "중복을 병합해 자리가 비었을 때만 1차 후보/상담 근거에서 아직 PT가 되지 않은 '다른 유지기제 또는 다른 행동 레버'를 보완한다. 근거가 없으면 억지로 숫자를 채우지 않는다. " +
                "왕관 priority는 유지한다는 뜻이 아니라 최종 PT들을 다시 비교해 '전체에서 중요하고 최근에도 살아 있으며 상위 유지기제를 끊는 미해결 축' 하나가 가장 높도록 한다. " +
                "사용자 정정/부정 가설은 제외하고, DIRECT 근거는 보존한다. muscle_name은 짧은 생활언어의 '~하는 힘'으로 쓰며, 서로 다른 PT의 이름만 읽어도 무엇이 다른지 보여야 한다. " +
                "최종 2~4개를 반환한다. 반드시 기존 최종 JSON 스키마 하나만 출력하고 마크다운은 금지한다.";
        String user = "[상담 근거]\n" + clip(evidenceText == null ? "" : evidenceText, 30000) +
                "\n\n[1차 후보]\n" + (discovery == null ? "{}" : discovery.toString()) +
                "\n\n[현재 PT]\n" + analysisToJson(current).toString();
        String text = callResponses(apiKey, model, system, user, 3400);
        Analysis edited = parse(new JSONObject(extractJsonObject(text)));
        if (edited.programs.isEmpty()) return current;
        // Keep at least two axes when the grounded discovery contains multiple genuinely trainable candidates.
        if (edited.programs.size() == 1 && groundedCandidateCount(discovery) >= 2) {
            restoreDistinctDiscoveryCandidates(discovery, edited);
        }
        deduplicatePrograms(edited);
        java.util.Collections.sort(edited.programs, (a,b) -> Integer.compare(b.priority, a.priority));
        while (edited.programs.size() > 4) edited.programs.remove(edited.programs.size() - 1);
        return edited;
    }

    private static void reconcileBehaviorDistinctPrograms(Analysis before, Analysis after) {
        if (before == null || after == null) return;
        for (Program p : before.programs) {
            if (p == null) continue;
            if (hasEquivalentBehaviorProgram(after, p)) continue;
            // 편집기가 다른 축을 새로 만들었더라도, 기존 PT와 첫 행동/학습목표가 다르면 보존한다.
            if (after.programs.size() < 4) after.programs.add(p);
        }
        // 4개를 넘으면 우선순위가 낮은 순으로 자르되, 추천 상위축은 보존한다.
        java.util.Collections.sort(after.programs, (a,b) -> Integer.compare(b.priority, a.priority));
        while (after.programs.size() > 4) after.programs.remove(after.programs.size() - 1);
    }

    private static boolean hasEquivalentBehaviorProgram(Analysis a, Program p) {
        if (a == null || p == null) return false;
        String pBehavior = firstExercise(p);
        String pGoal = firstCriterion(p);
        String pMechanism = normalizeKey(p.mechanism + " " + p.muscleName);
        for (Program q : a.programs) {
            if (q == null) continue;
            String qBehavior = firstExercise(q);
            String qGoal = firstCriterion(q);
            String qMechanism = normalizeKey(q.mechanism + " " + q.muscleName);
            boolean sameBehavior = textMeaningfullyOverlaps(pBehavior, qBehavior);
            boolean sameGoal = textMeaningfullyOverlaps(pGoal, qGoal);
            boolean sameMechanism = textMeaningfullyOverlaps(pMechanism, qMechanism);
            // 세 조건이 모두 맞을 때만 진짜 중복으로 본다.
            if (sameBehavior && sameGoal && sameMechanism) return true;
        }
        return false;
    }

    private static String firstExercise(Program p) {
        if (p == null || p.steps.isEmpty()) return "";
        return normalizeKey(p.steps.get(0).exerciseText);
    }

    private static String firstCriterion(Program p) {
        if (p == null || p.steps.isEmpty()) return "";
        return normalizeKey(p.steps.get(0).successCriterion);
    }

    private static String normalizeKey(String s) {
        if (s == null) return "";
        return s.toLowerCase().replaceAll("[^가-힣a-z0-9]", "");
    }

    private static boolean textMeaningfullyOverlaps(String a, String b) {
        if (a == null || b == null) return false;
        String x = normalizeKey(a), y = normalizeKey(b);
        if (x.isEmpty() || y.isEmpty()) return false;
        if (x.equals(y)) return true;
        if (x.length() >= 8 && y.contains(x)) return true;
        if (y.length() >= 8 && x.contains(y)) return true;
        // 짧은 핵심 토큰 두 개 이상이 겹칠 때만 유사하다고 본다.
        java.util.Set<String> tx = tokenSet(a), ty = tokenSet(b);
        int common = 0;
        for (String t : tx) if (ty.contains(t) && t.length() >= 2) common++;
        return common >= 2;
    }

    private static java.util.Set<String> tokenSet(String s) {
        java.util.Set<String> out = new java.util.HashSet<>();
        if (s == null) return out;
        for (String t : s.toLowerCase().split("[^가-힣a-z0-9]+")) {
            if (t.length() >= 2) out.add(t);
        }
        return out;
    }

    private static JSONObject analysisToJson(Analysis a) throws Exception {
        JSONObject root = new JSONObject();
        root.put("title", a.title);
        root.put("current_concern", a.currentConcern);
        root.put("formulation", a.formulation);
        root.put("priority_direction", a.priorityDirection);
        root.put("caution", a.caution);
        JSONArray ps = new JSONArray();
        for (Program p : a.programs) {
            JSONObject o = new JSONObject();
            o.put("name", p.name); o.put("mechanism", p.mechanism); o.put("muscle_name", p.muscleName);
            o.put("priority", p.priority); o.put("reason", p.reason); o.put("source", p.source);
            JSONArray ss = new JSONArray();
            for (Step st : p.steps) {
                JSONObject so = new JSONObject();
                so.put("order", st.order); so.put("mode", st.mode); so.put("exercise_type", st.exerciseType);
                so.put("exercise_text", st.exerciseText); so.put("success_criterion", st.successCriterion);
                so.put("rationale", st.rationale); so.put("difficulty", st.difficulty); ss.put(so);
            }
            o.put("steps", ss); ps.put(o);
        }
        root.put("programs", ps);
        return root;
    }

    private static void mergeDirectPrograms(Analysis base, Analysis edited) {
        if (base == null || edited == null) return;
        for (Program p : base.programs) {
            if (!"DIRECT".equals(p.source)) continue;
            if (!represented(edited, p.name, p.mechanism) && !hasMuscleName(edited, p.muscleName) && edited.programs.size() < 4) {
                edited.programs.add(p);
            }
        }
    }

    private static void normalizeDisplayMuscleNames(Analysis analysis) {
        if (analysis == null) return;
        for (Program p : analysis.programs) {
            String n = p.muscleName == null ? "" : p.muscleName.trim();
            if (n.isEmpty()) n = p.name == null ? "내 반응을 다루는 힘" : p.name.trim();
            p.muscleName = naturalMuscleName(n);
        }
    }

    private static String normalizeMode(String mode) {
        String m = mode == null ? "" : mode.trim().toUpperCase();
        if ("RECOVERY".equals(m) || "STABILIZE".equals(m) || "REVIEW".equals(m) || "MAINTENANCE".equals(m)) return m;
        return "TRAINING";
    }

    private static String extractOutputText(JSONObject json) {
        if (json == null) return "";
        String direct = json.optString("output_text", "");
        if (!direct.trim().isEmpty()) return direct;
        JSONArray output = json.optJSONArray("output");
        if (output == null) return "";
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < output.length(); i++) {
            JSONObject item = output.optJSONObject(i);
            if (item == null) continue;
            JSONArray content = item.optJSONArray("content");
            if (content == null) continue;
            for (int j = 0; j < content.length(); j++) {
                JSONObject c = content.optJSONObject(j);
                if (c == null) continue;
                String t = c.optString("text", "");
                if (!t.isEmpty()) b.append(t);
            }
        }
        return b.toString();
    }

    private static String extractJsonObject(String text) {
        int a = text.indexOf('{');
        int b = text.lastIndexOf('}');
        if (a < 0 || b <= a) throw new IllegalArgumentException("AI 분석 응답에서 JSON을 찾지 못했어.");
        return text.substring(a, b + 1);
    }

    private static String readAll(InputStream is) throws Exception {
        if (is == null) return "";
        BufferedReader br = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8));
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = br.readLine()) != null) sb.append(line);
        br.close();
        return sb.toString();
    }

    private static String clip(String s, int max) { return s.length() <= max ? s : s.substring(s.length() - max); }
    private static int clamp(int n, int min, int max) { return Math.max(min, Math.min(max, n)); }
    private static String emptyTo(String s, String fallback) { return s == null || s.trim().isEmpty() ? fallback : s.trim(); }
}
