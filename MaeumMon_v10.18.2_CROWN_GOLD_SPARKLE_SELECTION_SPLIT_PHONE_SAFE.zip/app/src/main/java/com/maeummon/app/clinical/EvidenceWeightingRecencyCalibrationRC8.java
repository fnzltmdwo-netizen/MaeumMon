package com.maeummon.app.clinical;

import android.content.Context;
import org.json.*;
import java.util.*;

public final class EvidenceWeightingRecencyCalibrationRC8 {
    private EvidenceWeightingRecencyCalibrationRC8(){}

    public static final class Result {
        public boolean adjusted=false;
        public String confidenceBand="LOW";
        public String rationale="";
        public double top=0.0;
        public double second=0.0;
        public final List<String> notes=new ArrayList<>();
    }

    public static Result calibrate(Context c){
        Result r=new Result();
        if(c==null)return r;

        JSONObject f=CentralTherapyProfile.loadFormulation(c);
        JSONArray hs=f.optJSONArray("alternative_hypotheses");
        if(hs==null||hs.length()==0){
            r.rationale="no hypotheses";
            return r;
        }

        long now=System.currentTimeMillis();
        double sum=0.0;

        for(int i=0;i<hs.length();i++){
            JSONObject h=hs.optJSONObject(i);
            if(h==null)continue;

            double base=h.optDouble("confidence",0.25);
            double support=scoreEvidence(h.optJSONArray("evidence_for"),now,true);
            double against=scoreEvidence(h.optJSONArray("evidence_against"),now,false);

            // Explicit retirement remains dominant.
            if(!h.optBoolean("active",true)){
                base=Math.min(base,0.08);
            }

            double adjusted=clamp(base + support - against);
            try{
                h.put("confidence_pre_calibration",base);
                h.put("confidence",adjusted);
                h.put("evidence_support_score",round(support));
                h.put("evidence_against_score",round(against));
            }catch(Exception ignored){}

            sum+=adjusted;
        }

        if(sum<=0)sum=1.0;

        // Normalize active hypotheses only; inactive remain tiny historical traces.
        double activeSum=0.0;
        for(int i=0;i<hs.length();i++){
            JSONObject h=hs.optJSONObject(i);
            if(h==null)continue;
            if(h.optBoolean("active",true))activeSum+=h.optDouble("confidence",0);
        }
        if(activeSum<=0)activeSum=1.0;

        for(int i=0;i<hs.length();i++){
            JSONObject h=hs.optJSONObject(i);
            if(h==null)continue;
            double conf=h.optDouble("confidence",0);
            if(h.optBoolean("active",true)){
                conf=conf/activeSum;
            }else{
                conf=Math.min(conf,0.05);
            }
            try{h.put("confidence",round(conf));}catch(Exception ignored){}
        }

        // Find top 2 active hypotheses.
        for(int i=0;i<hs.length();i++){
            JSONObject h=hs.optJSONObject(i);
            if(h==null||!h.optBoolean("active",true))continue;
            double v=h.optDouble("confidence",0);
            if(v>r.top){r.second=r.top;r.top=v;}
            else if(v>r.second)r.second=v;
        }

        double separation=Math.max(0,r.top-r.second);
        if(r.top>=0.72 && separation>=0.18){
            r.confidenceBand="HIGH";
        }else if(r.top>=0.48 && separation>=0.08){
            r.confidenceBand="MEDIUM";
        }else{
            r.confidenceBand="LOW";
        }

        try{
            f.put("alternative_hypotheses",hs);
            f.put("confidence",r.confidenceBand);
            f.put("evidence_calibrated_at",now);
            f.put("evidence_calibration_rationale",
                    "top="+round(r.top)+", second="+round(r.second)+", separation="+round(separation));
            CentralTherapyProfile.replaceFormulation(c,f);
            r.adjusted=true;
            r.rationale=f.optString("evidence_calibration_rationale","");
        }catch(Exception ignored){}

        return r;
    }

    private static double scoreEvidence(JSONArray a,long now,boolean support){
        if(a==null)return 0.0;
        double score=0.0;
        for(int i=0;i<a.length();i++){
            Object raw=a.opt(i);
            if(raw==null)continue;

            String text="";
            long time=0L;
            String source="";
            boolean explicit=false;
            boolean repeated=false;

            if(raw instanceof JSONObject){
                JSONObject o=(JSONObject)raw;
                text=o.optString("text",o.optString("note",""));
                time=o.optLong("time",0L);
                source=o.optString("source","");
                explicit=o.optBoolean("explicit",false);
                repeated=o.optBoolean("repeated",false);
            }else{
                text=String.valueOf(raw);
            }

            double w=0.04;

            // Source reliability.
            if(explicit || has(text,"explicit","직접","명시")) w+=0.05;
            if(has(source,"user","direct") || has(text,"user","사용자")) w+=0.03;
            if(repeated || has(text,"repeated","반복","여러 관계","항상","자주")) w+=0.03;

            // Corrections/negations are especially important evidence.
            if(has(text,"correction","정정","contradict","반증","absence","없음","no recent")) w+=0.05;

            // Pure inference is weaker.
            if(has(text,"inferred","추정","possible","가능성")) w-=0.02;

            // Recency calibration. If timestamp is absent, treat as medium recency.
            if(time>0){
                long ageDays=Math.max(0,(now-time)/(24L*60L*60L*1000L));
                if(ageDays<=7)w*=1.15;
                else if(ageDays<=30)w*=1.00;
                else if(ageDays<=90)w*=0.82;
                else w*=0.65;
            }else{
                w*=0.90;
            }

            // Cap each evidence item to prevent one phrase from dominating.
            w=Math.max(0.01,Math.min(0.14,w));
            score+=w;
        }

        // Multiple pieces help, but cap total contribution.
        return Math.min(0.28,score);
    }

    public static String instruction(Result r){
        if(r==null||!r.adjusted)return "";
        return "EVIDENCE_CALIBRATION=true. 오래된 추정과 최근 직접 확인된 사실을 같은 무게로 취급하지 않는다. "
                +"사용자 정정/명시적 반증/반복적으로 확인된 정보에 더 높은 비중을 둔다. "
                +"현재 confidence_band="+r.confidenceBand+".";
    }

    private static boolean has(String s,String... xs){
        if(s==null)return false;
        String t=s.toLowerCase();
        for(String x:xs)if(t.contains(x.toLowerCase()))return true;
        return false;
    }

    private static double clamp(double x){return Math.max(0.02,Math.min(0.95,x));}
    private static double round(double x){return Math.round(x*1000.0)/1000.0;}
}
