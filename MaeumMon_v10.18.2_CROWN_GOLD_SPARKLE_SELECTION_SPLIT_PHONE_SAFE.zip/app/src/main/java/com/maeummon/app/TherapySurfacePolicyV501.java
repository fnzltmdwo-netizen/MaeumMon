package com.maeummon.app;

/**
 * v5.0.1 shared surface policy.
 *
 * Every surface uses the same counseling formulation/V4 guard, then translates
 * only the depth and length for that surface. The surface is NOT allowed to
 * invent a new cause, diagnosis, third-party intent, or a different change target.
 */
public final class TherapySurfacePolicyV501 {
    private TherapySurfacePolicyV501() {}

    public static String prompt(String role) {
        String base = "[THERAPY_SURFACE_POLICY_V5.0.1] 모든 화면은 같은 CURRENT_FORMULATION과 OH_REASONING_RULES_V4를 공유한다. "
                + "화면이 달라져도 핵심 판단, 사실/해석 구분, 책임분리, 현재 변화목표를 바꾸지 않는다. "
                + "표현 길이만 역할에 맞게 번역한다. 새 원인·진단·상대 속마음·어린시절 가설을 이 화면에서 새로 만들지 않는다. "
                + "현재 핵심이 불확실하면 위로나 행동을 과도하게 구체화하지 말고, 이미 확인된 사실/연습만 사용한다. ";

        if ("widget".equals(role)) {
            return base + "위젯은 18~30자 안팎의 한 문장만 쓴다. 핵심 재정의 전체를 설명하지 말고 오늘의 CHANGE_TARGET 또는 PRACTICE 하나만 생활말로 압축한다. 말줄임표로 잘린 문장을 만들지 않는다.";
        }
        if ("mascot".equals(role)) {
            return base + "다마고치는 1~2문장, 쉬운 생활말만 쓴다. 분석 대신 현재 연습이나 허락 한 가지를 상기시킨다.";
        }
        if ("letter".equals(role)) {
            return base + "하루편지는 오늘 장면→왜 힘들었는지→현재의 새 관점→작은 다음 행동 순으로 따뜻하게 통합한다.";
        }
        if ("comfort".equals(role)) {
            return base + "해주고 싶은 말은 자기편의 언어로 번역하되 실제 책임은 지우지 않는다. 5줄 안에서 최근 장면과 연습을 연결한다.";
        }
        if ("report".equals(role)) {
            return base + "리포트는 반복상황, 자동 의미, 보호행동, 변화증거, 다음 연습을 구분한다. 한 기간의 감정을 성격으로 일반화하지 않는다.";
        }
        if ("checkin".equals(role)) {
            return base + "체크인은 점수를 평가하지 않고 오늘 여력에 맞춰 이미 정한 연습을 더 작게 조정한다.";
        }
        if ("coach".equals(role)) {
            return base + "집중코칭은 이미 확인된 formulation을 다시 설명하지 말고 CHANGE_TARGET을 행동 1개로 줄인다.";
        }
        return base + "상담 본문은 ASSESS→ASK_GATE→FORMULATE→V4_GUARD→INTERVENE→REVIEW 순서를 따른다.";
    }

    /** Hard-fit a widget sentence without leaving an ugly half sentence. */
    public static String compactWidgetText(String text, int maxChars) {
        if (text == null) return "";
        String s = text.replace('\r', ' ').replace('\n', ' ').replaceAll("\\s+", " ").trim();
        s = s.replaceAll("^[\\\"'“”‘’]+|[\\\"'“”‘’]+$", "").trim();
        if (s.length() <= maxChars) return s;

        int cut = Math.min(maxChars, s.length());
        int best = -1;
        char[] stops = new char[]{'.','!','?','。','！','？',',','，',';',';','·'};
        for (int i = Math.max(12, cut - 12); i < cut; i++) {
            char ch = s.charAt(i);
            for (char stop : stops) if (ch == stop) best = i + 1;
        }
        if (best >= 14) return s.substring(0, best).trim();

        int space = s.lastIndexOf(' ', cut);
        if (space >= Math.max(14, cut - 8)) cut = space;
        String out = s.substring(0, Math.max(1, cut)).trim();
        // Do not append ellipsis: the widget should look intentionally concise, not clipped.
        return out;
    }
}
