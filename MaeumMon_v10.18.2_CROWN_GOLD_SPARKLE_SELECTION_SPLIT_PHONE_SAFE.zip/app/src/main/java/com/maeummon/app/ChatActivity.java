package com.maeummon.app;

import com.maeummon.app.clinical.ClinicalBrainEngine;
import com.maeummon.app.clinical.ClinicalBrainRC7;
import com.maeummon.app.clinical.ClinicalDecisionRC7;
import com.maeummon.app.clinical.ClinicalDiagnosticsRC7;
import com.maeummon.app.clinical.ClinicalQaRC7;
import com.maeummon.app.clinical.ClinicalResponseQualityRC7;
import com.maeummon.app.clinical.ClinicalSelfCorrectionRC7;
import com.maeummon.app.clinical.ClinicalResponseComparatorRC7;
import com.maeummon.app.clinical.ClinicalConversationCoherenceRC7;
import com.maeummon.app.clinical.ClinicalMemoryConsolidatorRC7;
import com.maeummon.app.clinical.ClinicalMemoryRevisionRC7;
import com.maeummon.app.clinical.CentralTherapyProfile;
import com.maeummon.app.clinical.ResponseContradictionHallucinationGuardRC9;
import com.maeummon.app.clinical.TherapySurfaceContext;
import android.app.Activity;
import android.app.AlertDialog;
import android.Manifest;
import android.content.pm.PackageManager;
import android.content.ClipboardManager;
import android.content.ClipData;
import android.content.ClipDescription;
import android.media.MediaRecorder;
import android.content.SharedPreferences;
import android.content.Intent;
import android.os.Bundle;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.text.method.ScrollingMovementMethod;
import android.text.Selection;
import android.text.Spannable;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ContentInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.ArrayAdapter;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.PopupMenu;
import android.app.Dialog;

import android.net.Uri;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Base64;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.InputStream;
import java.io.FileOutputStream;
import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.List;
import java.nio.charset.Charset;


public class ChatActivity extends Activity {

    private static final int REQ_RECORD_AUDIO = 702;
    private static final int REQ_PICK_IMAGE = 703;
    private static final int REQ_PICK_TEXT = 704;
    private static final String KEY_CHAT_VOICE_SECTION_EXPANDED = "chat_voice_section_expanded";
    private static final String KEY_CHAT_TYPECAST_SECTION_EXPANDED = "chat_typecast_section_expanded";

    private LinearLayout chatContainer;
    private ScrollView chatScroll;
    private ScrollView chatHistoryScroll;
    private EditText chatInput;
    private TextView chatStatus;
    private TextView therapyFocusText;
    private TextView therapyPracticeText;
    private TextView therapyApproachText;
    private SharedPreferences prefs;
    private Switch voiceReplySwitch;
    private Switch autoSendVoiceSwitch;
    private Switch quietNightSwitch;
    private Switch overlayVoiceSwitch;
    private Switch typecastSwitch;
    private EditText typecastApiKeyInput;
    private EditText typecastVoiceIdInput;
    private TextView typecastStatusText;
    private TextView typecastSummaryText;
    private View imageAttachmentPreview;
    private LinearLayout imageAttachmentThumbs;
    private TextView imageAttachmentLabel;
    private Button attachImageButton;
    private Button removeImageButton;
    private final ArrayList<File> pendingImageFiles = new ArrayList<>();
    private final ArrayList<Uri> pendingImageUris = new ArrayList<>();
    private final ArrayList<File> pendingTextFiles = new ArrayList<>();
    private final ArrayList<String> pendingTextNames = new ArrayList<>();
    private static final int MAX_CHAT_IMAGES = 6;
    private static final int MAX_CHAT_TEXT_FILES = 3;
    private static final int MAX_TEXT_FILE_BYTES = 512 * 1024;
    private static final int MAX_TEXT_CHARS_PER_FILE = 40000;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private MediaRecorder recorder;
    private File recordedAudioFile;
    private boolean recording = false;
    private Button voiceButton;
    private View voiceSectionHeader;
    private View voiceSectionContent;
    private TextView voiceSectionArrow;
    private View typecastSectionHeader;
    private View typecastSectionContent;
    private TextView typecastSectionArrow;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat);
        UiInsets.apply(this, findViewById(R.id.chatRoot));

        prefs = getSharedPreferences(AppPrefs.PREFS, MODE_PRIVATE);

        chatContainer = findViewById(R.id.chatContainer);
        chatScroll = findViewById(R.id.chatRoot);
        chatHistoryScroll = findViewById(R.id.chatHistoryScroll);
        chatInput = findViewById(R.id.chatInput);
        chatStatus = findViewById(R.id.chatStatus);
        chatStatus.setLongClickable(true);
        chatStatus.setOnLongClickListener(v -> {
            ClinicalDiagnosticsRC7.show(this);
            return true;
        });
        imageAttachmentPreview = findViewById(R.id.imageAttachmentPreview);
        imageAttachmentThumbs = findViewById(R.id.imageAttachmentThumbs);
        imageAttachmentLabel = findViewById(R.id.imageAttachmentLabel);
        attachImageButton = findViewById(R.id.attachImageButton);
        removeImageButton = findViewById(R.id.removeImageButton);
        // 입력창은 3~6줄까지 자연스럽게 커지고, 더 길어질 때만 내부 스크롤한다.
        // 항상 보이던 세로 스크롤바는 숨겨서 입력 중 거슬리지 않게 한다.
        chatInput.setVerticalScrollBarEnabled(false);
        chatInput.setScrollbarFadingEnabled(true);
        chatInput.setMovementMethod(new ScrollingMovementMethod());
        chatInput.setOverScrollMode(View.OVER_SCROLL_NEVER);
        chatInput.setOnTouchListener((v, event) -> {
            if (event.getActionMasked() == MotionEvent.ACTION_DOWN || event.getActionMasked() == MotionEvent.ACTION_MOVE) {
                if (chatScroll != null) chatScroll.requestDisallowInterceptTouchEvent(true);
            } else if (event.getActionMasked() == MotionEvent.ACTION_UP || event.getActionMasked() == MotionEvent.ACTION_CANCEL) {
                if (chatScroll != null) chatScroll.requestDisallowInterceptTouchEvent(false);
            }
            return false;
        });
        // 일부 삼성/One UI 조합에서는 EditText의 기본 선택 툴바가 표시되지 않는 경우가 있다.
        // 길게 누르면 마음몬 자체 선택 메뉴를 띄워 '전체 선택'을 항상 사용할 수 있게 한다.
        chatInput.setLongClickable(true);
        // Android 12+에서는 삼성 키보드/클립보드에서 이미지 "붙여넣기"도 직접 받는다.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            chatInput.setOnReceiveContentListener(new String[]{"image/*"}, (view, payload) -> {
                ClipData clip = payload.getClip();
                boolean consumed = false;
                for (int i = 0; i < clip.getItemCount() && pendingImageFiles.size() < MAX_CHAT_IMAGES; i++) {
                    Uri uri = clip.getItemAt(i).getUri();
                    if (uri != null && attachImageUri(uri)) consumed = true;
                }
                return consumed ? null : payload;
            });
        }
        if (chatHistoryScroll != null) {
            chatHistoryScroll.setNestedScrollingEnabled(true);
            chatHistoryScroll.setVerticalScrollBarEnabled(true);
            chatHistoryScroll.setScrollbarFadingEnabled(false);
            chatHistoryScroll.setOnTouchListener((v, event) -> {
                if (event.getActionMasked() == MotionEvent.ACTION_DOWN || event.getActionMasked() == MotionEvent.ACTION_MOVE) {
                    if (chatScroll != null) chatScroll.requestDisallowInterceptTouchEvent(true);
                } else if (event.getActionMasked() == MotionEvent.ACTION_UP || event.getActionMasked() == MotionEvent.ACTION_CANCEL) {
                    if (chatScroll != null) chatScroll.requestDisallowInterceptTouchEvent(false);
                }
                return false;
            });
        }
        therapyFocusText = findViewById(R.id.therapyFocusText);
        therapyPracticeText = findViewById(R.id.therapyPracticeText);
        therapyApproachText = findViewById(R.id.therapyApproachText);
        findViewById(R.id.openChangeMapButton).setOnClickListener(v -> startActivity(new Intent(this, ChangeMapActivity.class)));
        Button sendButton = findViewById(R.id.sendButton);
        voiceButton = findViewById(R.id.voiceInputButton);
        voiceReplySwitch = findViewById(R.id.voiceReplySwitch);
        autoSendVoiceSwitch = findViewById(R.id.autoSendVoiceSwitch);
        quietNightSwitch = findViewById(R.id.quietNightSwitch);
        overlayVoiceSwitch = findViewById(R.id.overlayVoiceSwitch);
        typecastSwitch = findViewById(R.id.typecastSwitch);
        typecastApiKeyInput = findViewById(R.id.typecastApiKeyInput);
        typecastVoiceIdInput = findViewById(R.id.typecastVoiceIdInput);
        typecastStatusText = findViewById(R.id.typecastStatusText);
        typecastSummaryText = findViewById(R.id.typecastSummaryText);
        voiceSectionHeader = findViewById(R.id.voiceSectionHeader);
        voiceSectionContent = findViewById(R.id.voiceSectionContent);
        voiceSectionArrow = findViewById(R.id.voiceSectionArrow);
        typecastSectionHeader = findViewById(R.id.typecastSectionHeader);
        typecastSectionContent = findViewById(R.id.typecastSectionContent);
        typecastSectionArrow = findViewById(R.id.typecastSectionArrow);

        voiceReplySwitch.setChecked(prefs.getBoolean(AppPrefs.KEY_VOICE_REPLY, true));
        autoSendVoiceSwitch.setChecked(prefs.getBoolean(AppPrefs.KEY_VOICE_AUTO_SEND, true));
        quietNightSwitch.setChecked(prefs.getBoolean(AppPrefs.KEY_VOICE_QUIET_NIGHT, true));
        overlayVoiceSwitch.setChecked(prefs.getBoolean(AppPrefs.KEY_OVERLAY_VOICE, false));
        typecastSwitch.setChecked(prefs.getBoolean(AppPrefs.KEY_TYPECAST_ENABLED, false));
        typecastApiKeyInput.setText(prefs.getString(AppPrefs.KEY_TYPECAST_API_KEY, ""));
        typecastVoiceIdInput.setText(prefs.getString(AppPrefs.KEY_TYPECAST_VOICE_ID, ""));
        updateTypecastStatus();
        updateTypecastSummary();

        initCollapsibleSection(voiceSectionHeader, voiceSectionContent, voiceSectionArrow, KEY_CHAT_VOICE_SECTION_EXPANDED, false);
        initCollapsibleSection(typecastSectionHeader, typecastSectionContent, typecastSectionArrow, KEY_CHAT_TYPECAST_SECTION_EXPANDED, false);

        voiceReplySwitch.setOnCheckedChangeListener((buttonView, checked) ->
                prefs.edit().putBoolean(AppPrefs.KEY_VOICE_REPLY, checked).apply());
        autoSendVoiceSwitch.setOnCheckedChangeListener((buttonView, checked) ->
                prefs.edit().putBoolean(AppPrefs.KEY_VOICE_AUTO_SEND, checked).apply());
        quietNightSwitch.setOnCheckedChangeListener((buttonView, checked) ->
                prefs.edit().putBoolean(AppPrefs.KEY_VOICE_QUIET_NIGHT, checked).apply());
        overlayVoiceSwitch.setOnCheckedChangeListener((buttonView, checked) ->
                prefs.edit().putBoolean(AppPrefs.KEY_OVERLAY_VOICE, checked).apply());
        typecastSwitch.setOnCheckedChangeListener((buttonView, checked) -> {
            prefs.edit().putBoolean(AppPrefs.KEY_TYPECAST_ENABLED, checked).apply();
            updateTypecastStatus();
            updateTypecastSummary();
        });
        findViewById(R.id.saveTypecastButton).setOnClickListener(v -> saveTypecastSettings());
        findViewById(R.id.findTypecastChildVoicesButton).setOnClickListener(v -> findTypecastChildVoices());
        findViewById(R.id.typecastAdvancedButton).setOnClickListener(v -> showTypecastAdvancedSettings());
        findViewById(R.id.testTypecastButton).setOnClickListener(v -> testTypecastVoice());

        sendButton.setOnClickListener(v -> sendMessage());
        voiceButton.setOnClickListener(v -> startVoiceInput());
        attachImageButton.setOnClickListener(v -> showImageAttachMenu());
        removeImageButton.setOnClickListener(v -> clearPendingImages(true));

        renderMessages();
        updateTherapyProgressCard();
        scrollToLatestBubble(null);

        if (chatContainer.getChildCount() == 0) {
            addBubble("assistant", "승재야, 이제 나는 처음 만난 사람처럼 묻지 않을게. "
                    + "우리가 그동안 함께 본 관계 불안, 거절과 경계, 실수 뒤 자기비난 같은 반복 패턴은 시작점으로 기억하되, 오늘의 네 말을 가장 우선해서 계속 수정해갈게. "
                    + "지금 마음이 가장 크게 움직인 일 하나만 말해줘. 오늘도 위로에서 끝내지 않고, 네가 실제로 달라질 수 있는 지점 하나를 같이 찾아보자.");
        }
    }

    private void initCollapsibleSection(View header, View content, TextView arrow, String prefKey, boolean defaultExpanded) {
        boolean expanded = prefs.getBoolean(prefKey, defaultExpanded);
        setSectionExpanded(content, arrow, expanded);
        header.setOnClickListener(v -> {
            boolean next = content.getVisibility() != View.VISIBLE;
            setSectionExpanded(content, arrow, next);
            prefs.edit().putBoolean(prefKey, next).apply();
        });
    }

    private void setSectionExpanded(View content, TextView arrow, boolean expanded) {
        content.setVisibility(expanded ? View.VISIBLE : View.GONE);
        arrow.setText(expanded ? "▾" : "▸");
    }

    private void startVoiceInput() {
        if (recording) {
            stopRecordingAndTranscribe();
            return;
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_RECORD_AUDIO);
            return;
        }
        beginRecording();
    }

    private void beginRecording() {
        String apiKey = prefs.getString(AppPrefs.KEY_API_KEY, "").trim();
        if (apiKey.isEmpty()) {
            Toast.makeText(this, "GPT 음성인식을 쓰려면 먼저 OpenAI API Key가 필요해.", Toast.LENGTH_LONG).show();
            chatStatus.setText("OpenAI API Key를 먼저 설정해줘.");
            return;
        }
        try {
            recordedAudioFile = new File(getCacheDir(), "maeummon_voice_" + System.currentTimeMillis() + ".m4a");
            recorder = new MediaRecorder();
            recorder.setAudioSource(MediaRecorder.AudioSource.MIC);
            recorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);
            recorder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC);
            recorder.setAudioEncodingBitRate(128000);
            recorder.setAudioSamplingRate(44100);
            recorder.setOutputFile(recordedAudioFile.getAbsolutePath());
            recorder.prepare();
            recorder.start();
            recording = true;
            voiceButton.setText("⏹️ 녹음 끝내기");
            chatStatus.setText("GPT 음성인식용으로 듣고 있어… 다 말하면 다시 눌러줘.");
            handler.postDelayed(() -> {
                if (recording) stopRecordingAndTranscribe();
            }, 60000L);
        } catch (Exception e) {
            releaseRecorder();
            chatStatus.setText("녹음을 시작하지 못했어.");
            Toast.makeText(this, "마이크 사용 상태를 확인해줘.", Toast.LENGTH_LONG).show();
        }
    }

    private void stopRecordingAndTranscribe() {
        if (!recording) return;
        recording = false;
        voiceButton.setText("🎤 말하기");
        try {
            recorder.stop();
        } catch (Exception e) {
            releaseRecorder();
            if (recordedAudioFile != null) recordedAudioFile.delete();
            chatStatus.setText("녹음이 너무 짧았어. 다시 말해줘.");
            return;
        }
        releaseRecorder();
        final File audio = recordedAudioFile;
        if (audio == null || !audio.exists() || audio.length() < 512) {
            chatStatus.setText("녹음된 음성이 없어. 다시 말해줘.");
            return;
        }
        chatStatus.setText("GPT가 말한 내용을 받아쓰는 중이야…");
        String apiKey = prefs.getString(AppPrefs.KEY_API_KEY, "").trim();
        new Thread(() -> {
            try {
                String spoken = OpenAiClient.transcribeAudio(apiKey, audio);
                handler.post(() -> {
                    chatInput.setText(spoken);
                    chatInput.setSelection(chatInput.length());
                    chatStatus.setText("GPT 음성인식 완료");
                    if (autoSendVoiceSwitch.isChecked() && !spoken.trim().isEmpty()) {
                        handler.postDelayed(this::sendMessage, 180L);
                    }
                });
            } catch (Exception e) {
                handler.post(() -> {
                    chatStatus.setText("GPT 음성인식을 완료하지 못했어.");
                    Toast.makeText(this, e.getMessage() == null ? "음성인식 오류" : e.getMessage(), Toast.LENGTH_LONG).show();
                });
            } finally {
                try { audio.delete(); } catch (Exception ignored) {}
            }
        }).start();
    }

    private void releaseRecorder() {
        if (recorder != null) {
            try { recorder.reset(); } catch (Exception ignored) {}
            try { recorder.release(); } catch (Exception ignored) {}
            recorder = null;
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_RECORD_AUDIO) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                beginRecording();
            } else {
                Toast.makeText(this, "말하기 기능을 쓰려면 마이크 권한이 필요해.", Toast.LENGTH_LONG).show();
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_PICK_IMAGE && resultCode == RESULT_OK && data != null) {
            ClipData multi = data.getClipData();
            if (multi != null) {
                for (int i = 0; i < multi.getItemCount() && pendingImageFiles.size() < MAX_CHAT_IMAGES; i++) {
                    Uri uri = multi.getItemAt(i).getUri();
                    if (uri != null) attachImageUri(uri);
                }
            } else if (data.getData() != null) {
                attachImageUri(data.getData());
            }
        }
        if (requestCode == REQ_PICK_TEXT && resultCode == RESULT_OK && data != null) {
            ClipData multi = data.getClipData();
            if (multi != null) {
                for (int i = 0; i < multi.getItemCount() && pendingTextFiles.size() < MAX_CHAT_TEXT_FILES; i++) {
                    Uri uri = multi.getItemAt(i).getUri();
                    if (uri != null) attachTextUri(uri);
                }
            } else if (data.getData() != null) {
                attachTextUri(data.getData());
            }
        }
    }

    private void showImageAttachMenu() {
        java.util.ArrayList<String> items = new java.util.ArrayList<>();
        items.add("📋 클립보드 사진 붙여넣기");
        items.add("🖼️ 갤러리에서 사진 선택");
        items.add("📄 TXT 파일 선택");
        boolean hasAnything = !pendingImageFiles.isEmpty() || !pendingTextFiles.isEmpty();
        if (hasAnything) items.add("🗑️ 첨부 모두 지우기");
        new AlertDialog.Builder(this)
                .setTitle("상담에 파일 추가")
                .setItems(items.toArray(new String[0]), (dialog, which) -> {
                    if (which == 0) pasteImageFromClipboard();
                    else if (which == 1) openImagePicker();
                    else if (which == 2) openTextPicker();
                    else clearPendingAttachments(true);
                })
                .setNegativeButton("취소", null)
                .show();
    }

    private void pasteImageFromClipboard() {
        ClipboardManager clipboard = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
        if (clipboard == null || !clipboard.hasPrimaryClip()) {
            Toast.makeText(this, "클립보드에 복사된 사진이 없어.", Toast.LENGTH_SHORT).show();
            return;
        }
        ClipDescription desc = clipboard.getPrimaryClipDescription();
        ClipData clip = clipboard.getPrimaryClip();
        boolean looksLikeImage = desc != null && desc.hasMimeType("image/*");
        boolean added = false;
        if (clip != null) {
            for (int i = 0; i < clip.getItemCount() && pendingImageFiles.size() < MAX_CHAT_IMAGES; i++) {
                Uri uri = clip.getItemAt(i).getUri();
                if (uri != null && (looksLikeImage || isImageUri(uri)) && attachImageUri(uri)) added = true;
            }
        }
        if (!added) Toast.makeText(this, "복사된 사진을 찾지 못했어. 갤러리 선택을 사용해줘.", Toast.LENGTH_LONG).show();
    }

    private void openImagePicker() {
        // 삼성 갤러리/사진 앱에서 여러 장을 바로 고르기 쉽도록 ACTION_PICK을 우선 사용한다.
        // 여러 장 선택을 지원하지 않는 앱에서도 EXTRA_ALLOW_MULTIPLE을 무시할 뿐 앱은 정상 동작한다.
        Intent intent = new Intent(Intent.ACTION_PICK, android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        intent.setType("image/*");
        intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        try {
            startActivityForResult(Intent.createChooser(intent, "사진 여러 장 선택"), REQ_PICK_IMAGE);
        } catch (Exception first) {
            // 기기별 갤러리가 ACTION_PICK 다중선택을 지원하지 않으면 문서 선택기로 폴백한다.
            Intent fallback = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            fallback.addCategory(Intent.CATEGORY_OPENABLE);
            fallback.setType("image/*");
            fallback.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
            fallback.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
            startActivityForResult(fallback, REQ_PICK_IMAGE);
        }
    }

    private void openTextPicker() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("text/plain");
        intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        startActivityForResult(Intent.createChooser(intent, "TXT 파일 선택"), REQ_PICK_TEXT);
    }

    private boolean attachTextUri(Uri uri) {
        if (uri == null) return false;
        if (pendingTextFiles.size() >= MAX_CHAT_TEXT_FILES) {
            Toast.makeText(this, "TXT 파일은 한 번에 최대 " + MAX_CHAT_TEXT_FILES + "개까지 붙일 수 있어.", Toast.LENGTH_SHORT).show();
            return false;
        }
        try {
            File dir = new File(getCacheDir(), "chat_text_attachments");
            if (!dir.exists() && !dir.mkdirs()) throw new RuntimeException("cache mkdir failed");
            String displayName = getDisplayName(uri);
            if (displayName == null || displayName.trim().isEmpty()) displayName = "상담자료.txt";
            File target = new File(dir, "pending_" + System.currentTimeMillis() + ".txt");
            try (InputStream in = getContentResolver().openInputStream(uri);
                 FileOutputStream out = new FileOutputStream(target)) {
                if (in == null) throw new RuntimeException("text open failed");
                byte[] buffer = new byte[8192];
                int n;
                long total = 0L;
                while ((n = in.read(buffer)) != -1) {
                    total += n;
                    if (total > MAX_TEXT_FILE_BYTES) throw new RuntimeException("text too large");
                    out.write(buffer, 0, n);
                }
            }
            String previewText = readTextFile(target);
            if (previewText.trim().isEmpty()) {
                target.delete();
                Toast.makeText(this, "TXT 파일에 읽을 내용이 없어.", Toast.LENGTH_LONG).show();
                return false;
            }
            pendingTextFiles.add(target);
            pendingTextNames.add(displayName);
            addTextAttachmentChip(target, displayName);
            refreshAttachmentLabel();
            imageAttachmentPreview.setVisibility(View.VISIBLE);
            chatStatus.setText("첨부한 사진과 TXT 내용을 같이 읽을게. 필요한 설명을 적고 보내줘.");
            return true;
        } catch (Exception e) {
            Toast.makeText(this, "TXT 파일을 읽지 못했어. 일반 텍스트(.txt) 파일인지 확인해줘.", Toast.LENGTH_LONG).show();
            return false;
        }
    }

    private String getDisplayName(Uri uri) {
        android.database.Cursor cursor = null;
        try {
            cursor = getContentResolver().query(uri, new String[]{android.provider.OpenableColumns.DISPLAY_NAME}, null, null, null);
            if (cursor != null && cursor.moveToFirst()) {
                int idxName = cursor.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME);
                if (idxName >= 0) return cursor.getString(idxName);
            }
        } catch (Exception ignored) {
        } finally {
            if (cursor != null) try { cursor.close(); } catch (Exception ignored) {}
        }
        return uri.getLastPathSegment();
    }

    private String readTextFile(File file) throws Exception {
        try (InputStream in = new java.io.FileInputStream(file);
             ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[8192];
            int n;
            while ((n = in.read(buffer)) != -1) out.write(buffer, 0, n);
            byte[] bytes = out.toByteArray();
            String utf8 = new String(bytes, Charset.forName("UTF-8"));
            int replacement = 0;
            for (int i = 0; i < utf8.length(); i++) if (utf8.charAt(i) == '�') replacement++;
            String text = replacement > Math.max(2, utf8.length() / 100) ? new String(bytes, Charset.forName("MS949")) : utf8;
            if (text.length() > MAX_TEXT_CHARS_PER_FILE) text = text.substring(0, MAX_TEXT_CHARS_PER_FILE) + "\n…(이하 생략)";
            return text;
        }
    }

    private void addTextAttachmentChip(File file, String displayName) {
        if (imageAttachmentThumbs == null) return;
        FrameLayout item = new FrameLayout(this);
        LinearLayout.LayoutParams itemLp = new LinearLayout.LayoutParams(dp(118), dp(104));
        itemLp.setMarginEnd(dp(8));
        item.setLayoutParams(itemLp);

        TextView chip = new TextView(this);
        FrameLayout.LayoutParams chipLp = new FrameLayout.LayoutParams(dp(108), dp(96));
        chipLp.gravity = Gravity.START | Gravity.BOTTOM;
        chip.setLayoutParams(chipLp);
        chip.setGravity(Gravity.CENTER);
        chip.setPadding(dp(8), dp(8), dp(8), dp(8));
        chip.setText("📄 TXT\n" + shortenFileName(displayName, 15));
        chip.setTextColor(0xFF5A6175);
        chip.setTextSize(12f);
        chip.setBackgroundResource(R.drawable.bg_input);
        chip.setContentDescription(displayName + " TXT 첨부");
        item.addView(chip);

        TextView delete = new TextView(this);
        FrameLayout.LayoutParams delLp = new FrameLayout.LayoutParams(dp(30), dp(30));
        delLp.gravity = Gravity.TOP | Gravity.END;
        delete.setLayoutParams(delLp);
        delete.setText("×");
        delete.setTextSize(18f);
        delete.setGravity(Gravity.CENTER);
        delete.setTextColor(0xFF5A6175);
        delete.setBackgroundResource(R.drawable.bg_input);
        delete.setContentDescription("이 TXT 파일 삭제");
        delete.setOnClickListener(v -> {
            int idxFile = pendingTextFiles.indexOf(file);
            if (idxFile >= 0) {
                pendingTextFiles.remove(idxFile);
                if (idxFile < pendingTextNames.size()) pendingTextNames.remove(idxFile);
                try { file.delete(); } catch (Exception ignored) {}
            }
            imageAttachmentThumbs.removeView(item);
            refreshAttachmentLabel();
            if (pendingImageFiles.isEmpty() && pendingTextFiles.isEmpty()) imageAttachmentPreview.setVisibility(View.GONE);
        });
        item.addView(delete);
        imageAttachmentThumbs.addView(item);
    }

    private String shortenFileName(String name, int max) {
        if (name == null) return "파일.txt";
        if (name.length() <= max) return name;
        int dot = name.lastIndexOf('.');
        String ext = dot >= 0 ? name.substring(dot) : "";
        int keep = Math.max(4, max - ext.length() - 1);
        return name.substring(0, Math.min(keep, name.length())) + "…" + ext;
    }

    private boolean isImageUri(Uri uri) {
        try {
            String type = getContentResolver().getType(uri);
            return type != null && type.startsWith("image/");
        } catch (Exception e) {
            return false;
        }
    }

    private boolean attachImageUri(Uri uri) {
        if (uri == null) return false;
        try {
            File dir = new File(getCacheDir(), "chat_image_attachments");
            if (!dir.exists() && !dir.mkdirs()) throw new RuntimeException("cache mkdir failed");
            File target = new File(dir, "pending_" + System.currentTimeMillis() + ".img");
            try (InputStream in = getContentResolver().openInputStream(uri);
                 FileOutputStream out = new FileOutputStream(target)) {
                if (in == null) throw new RuntimeException("image open failed");
                byte[] buffer = new byte[8192];
                int n;
                long total = 0L;
                while ((n = in.read(buffer)) != -1) {
                    total += n;
                    if (total > 25L * 1024L * 1024L) throw new RuntimeException("image too large");
                    out.write(buffer, 0, n);
                }
            }
            Bitmap preview = BitmapFactory.decodeFile(target.getAbsolutePath());
            if (preview == null) {
                target.delete();
                Toast.makeText(this, "이 사진 형식은 읽지 못했어. PNG/JPG/WEBP로 다시 골라줘.", Toast.LENGTH_LONG).show();
                return false;
            }
            if (pendingImageFiles.size() >= MAX_CHAT_IMAGES) {
                target.delete();
                Toast.makeText(this, "사진은 한 번에 최대 " + MAX_CHAT_IMAGES + "장까지 붙일 수 있어.", Toast.LENGTH_SHORT).show();
                return false;
            }
            pendingImageFiles.add(target);
            pendingImageUris.add(uri);
            addAttachmentThumbnail(target, uri, preview);
            refreshAttachmentLabel();
            imageAttachmentPreview.setVisibility(View.VISIBLE);
            chatStatus.setText("사진 " + pendingImageFiles.size() + "장을 붙였어. 필요한 설명을 같이 적고 보내줘.");
            return true;
        } catch (Exception e) {
            Toast.makeText(this, "사진을 붙이지 못했어. 갤러리에서 다시 선택해줘.", Toast.LENGTH_LONG).show();
            return false;
        }
    }

    private void addAttachmentThumbnail(File file, Uri sourceUri, Bitmap preview) {
        if (imageAttachmentThumbs == null) return;

        FrameLayout item = new FrameLayout(this);
        LinearLayout.LayoutParams itemLp = new LinearLayout.LayoutParams(dp(112), dp(104));
        itemLp.setMarginEnd(dp(8));
        item.setLayoutParams(itemLp);

        ImageView iv = new ImageView(this);
        FrameLayout.LayoutParams imageLp = new FrameLayout.LayoutParams(dp(104), dp(96));
        imageLp.gravity = Gravity.START | Gravity.BOTTOM;
        iv.setLayoutParams(imageLp);
        iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
        iv.setImageBitmap(preview);
        iv.setContentDescription("첨부 사진 크게 보기");
        iv.setBackgroundResource(R.drawable.bg_input);
        iv.setPadding(dp(2), dp(2), dp(2), dp(2));
        iv.setOnClickListener(v -> openAttachmentImage(sourceUri, file));
        item.addView(iv);

        TextView delete = new TextView(this);
        FrameLayout.LayoutParams delLp = new FrameLayout.LayoutParams(dp(30), dp(30));
        delLp.gravity = Gravity.TOP | Gravity.END;
        delete.setLayoutParams(delLp);
        delete.setText("×");
        delete.setTextSize(18f);
        delete.setGravity(Gravity.CENTER);
        delete.setTextColor(0xFF5A6175);
        delete.setBackgroundResource(R.drawable.bg_input);
        delete.setContentDescription("이 사진 삭제");
        delete.setOnClickListener(v -> {
            int index = pendingImageFiles.indexOf(file);
            if (index >= 0) {
                pendingImageFiles.remove(index);
                if (index < pendingImageUris.size()) pendingImageUris.remove(index);
                try { file.delete(); } catch (Exception ignored) {}
            }
            imageAttachmentThumbs.removeView(item);
            refreshAttachmentLabel();
            if (pendingImageFiles.isEmpty() && pendingTextFiles.isEmpty()) imageAttachmentPreview.setVisibility(View.GONE);
        });
        item.addView(delete);

        imageAttachmentThumbs.addView(item);
    }

    private void openAttachmentImage(Uri sourceUri, File cacheFile) {
        // 1순위: 사용자가 고른 원본 사진을 시스템 갤러리/사진 앱에서 연다.
        if (sourceUri != null) {
            try {
                Intent view = new Intent(Intent.ACTION_VIEW);
                view.setDataAndType(sourceUri, "image/*");
                view.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                startActivity(view);
                return;
            } catch (Exception ignored) {}
        }

        // 원본 URI를 다른 앱에서 열 수 없는 클립보드 이미지라면 앱 안에서 크게 보여준다.
        try {
            Bitmap full = cacheFile == null ? null : BitmapFactory.decodeFile(cacheFile.getAbsolutePath());
            if (full == null) throw new RuntimeException("preview failed");
            Dialog dialog = new Dialog(this, android.R.style.Theme_Black_NoTitleBar_Fullscreen);
            ImageView large = new ImageView(this);
            large.setBackgroundColor(0xFF000000);
            large.setScaleType(ImageView.ScaleType.FIT_CENTER);
            large.setImageBitmap(full);
            large.setContentDescription("첨부 사진 크게 보기 · 눌러서 닫기");
            large.setOnClickListener(v -> dialog.dismiss());
            dialog.setContentView(large, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            dialog.show();
        } catch (Exception e) {
            Toast.makeText(this, "사진을 크게 열지 못했어.", Toast.LENGTH_SHORT).show();
        }
    }

    private void refreshAttachmentLabel() {
        if (imageAttachmentLabel == null) return;
        int images = pendingImageFiles.size();
        int texts = pendingTextFiles.size();
        if (images <= 0 && texts <= 0) {
            imageAttachmentLabel.setText("첨부 없음");
            return;
        }
        StringBuilder sb = new StringBuilder();
        if (images > 0) sb.append("사진 ").append(images).append("장 첨부됨");
        if (texts > 0) {
            if (sb.length() > 0) sb.append("\n");
            sb.append("TXT ").append(texts).append("개 첨부됨");
        }
        imageAttachmentLabel.setText(sb.toString());
    }

    private void clearPendingImages(boolean deleteFiles) {
        clearPendingAttachments(deleteFiles);
    }

    private void clearPendingAttachments(boolean deleteFiles) {
        if (deleteFiles) {
            for (File f : new ArrayList<>(pendingImageFiles)) {
                try { f.delete(); } catch (Exception ignored) {}
            }
            for (File f : new ArrayList<>(pendingTextFiles)) {
                try { f.delete(); } catch (Exception ignored) {}
            }
        }
        pendingImageFiles.clear();
        pendingImageUris.clear();
        pendingTextFiles.clear();
        pendingTextNames.clear();
        if (imageAttachmentThumbs != null) imageAttachmentThumbs.removeAllViews();
        refreshAttachmentLabel();
        if (imageAttachmentPreview != null) imageAttachmentPreview.setVisibility(View.GONE);
    }

    private String buildTextAttachmentContext(List<File> files, List<String> names) {
        if (files == null || files.isEmpty()) return "";
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < files.size(); i++) {
            File f = files.get(i);
            String name = (names != null && i < names.size()) ? names.get(i) : "첨부.txt";
            try {
                String content = readTextFile(f);
                sb.append("\n\n[첨부 TXT: ").append(name).append("]\n").append(content);
            } catch (Exception e) {
                sb.append("\n\n[첨부 TXT: ").append(name).append(" - 읽기 실패]");
            }
        }
        return sb.toString();
    }

    private JSONArray imageFilesToDataUrls(List<File> files) throws Exception {
        JSONArray arr = new JSONArray();
        if (files == null) return arr;
        for (File f : files) {
            if (f != null && f.exists()) arr.put(imageFileToDataUrl(f));
        }
        return arr;
    }

    private String imageFileToDataUrl(File file) throws Exception {
        if (file == null || !file.exists()) return "";
        BitmapFactory.Options bounds = new BitmapFactory.Options();
        bounds.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(file.getAbsolutePath(), bounds);
        int sample = 1;
        int maxSide = Math.max(bounds.outWidth, bounds.outHeight);
        while (maxSide / sample > 2400) sample *= 2;
        BitmapFactory.Options opts = new BitmapFactory.Options();
        opts.inSampleSize = Math.max(1, sample);
        Bitmap bitmap = BitmapFactory.decodeFile(file.getAbsolutePath(), opts);
        if (bitmap == null) throw new RuntimeException("사진을 읽지 못했어.");

        int w = bitmap.getWidth();
        int h = bitmap.getHeight();
        int largest = Math.max(w, h);
        if (largest > 1800) {
            float scale = 1800f / largest;
            Bitmap scaled = Bitmap.createScaledBitmap(bitmap, Math.max(1, Math.round(w * scale)), Math.max(1, Math.round(h * scale)), true);
            if (scaled != bitmap) bitmap.recycle();
            bitmap = scaled;
        }
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.JPEG, 86, out);
        bitmap.recycle();
        String b64 = Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP);
        return "data:image/jpeg;base64," + b64;
    }

    private void sendMessage() {
        String text = chatInput.getText().toString().trim();
        final ArrayList<File> imagesToSend = new ArrayList<>(pendingImageFiles);
        final ArrayList<File> textFilesToSend = new ArrayList<>(pendingTextFiles);
        final ArrayList<String> textNamesToSend = new ArrayList<>(pendingTextNames);
        final boolean hasImage = !imagesToSend.isEmpty();
        final boolean hasTextFile = !textFilesToSend.isEmpty();
        if (text.isEmpty() && !hasImage && !hasTextFile) return;
        if (text.isEmpty()) {
            if (hasImage && hasTextFile) text = "첨부한 사진과 TXT 내용을 함께 읽고 상담해줘.";
            else if (hasImage) text = "이 사진을 보고, 사진에 실제로 보이는 내용과 내가 붙인 해석을 구분하면서 상담해줘.";
            else text = "첨부한 TXT 파일 내용을 읽고 상담해줘.";
        }
        final String userTypedText = text;
        final String textFileContext = buildTextAttachmentContext(textFilesToSend, textNamesToSend);
        final String requestText = userTypedText + textFileContext;
        StringBuilder storedBuilder = new StringBuilder(userTypedText);
        if (hasImage) storedBuilder.append("\n📷 [상담 사진 ").append(imagesToSend.size()).append("장 첨부]");
        if (hasTextFile) storedBuilder.append("\n📄 [상담 TXT ").append(textFilesToSend.size()).append("개 첨부: ").append(android.text.TextUtils.join(", ", textNamesToSend)).append("]");
        final String storedText = storedBuilder.toString();

        ChatStorage.addDiaryRecord(this, storedText);
        ChatStorage.addMessage(this, "user", storedText);
        ChatStorage.addCounselingTimeline(this, "user", storedText);
        CompanionProfile.addAffection(this, 1);
        addBubble("user", storedText);
        chatInput.setText("");
        pendingImageFiles.clear();
        pendingImageUris.clear();
        pendingTextFiles.clear();
        pendingTextNames.clear();
        if (imageAttachmentThumbs != null) imageAttachmentThumbs.removeAllViews();
        refreshAttachmentLabel();
        if (imageAttachmentPreview != null) imageAttachmentPreview.setVisibility(View.GONE);
        chatStatus.setText("GPT가 상황을 먼저 이해하고 있어…");

        String apiKey = prefs.getString(AppPrefs.KEY_API_KEY, "").trim();
        final String contextModel = prefs.getString(AppPrefs.KEY_CONTEXT_MODEL, "gpt-5.6-terra");
        final String counselingModel = prefs.getString(AppPrefs.KEY_COUNSELING_MODEL, "gpt-5.6-terra");
        final TextView pendingBubble = apiKey.isEmpty() ? null : addBubble("assistant", "생각을 정리해서 말해줄게…");

        if (apiKey.isEmpty()) {
            String reply = LocalCounselor.reply(requestText) + (hasImage ? "\n\n(사진 내용 분석은 OpenAI API 연결이 있을 때 가능해.)" : "");
            ChatStorage.addMessage(this, "assistant", reply);
            ChatStorage.addCounselingTimeline(this, "assistant", reply);
            addBubble("assistant", reply);
            chatStatus.setText("기본 상담 모드");
            speakReplyIfEnabled(reply);
            for (File f : imagesToSend) {
                try { f.delete(); } catch (Exception ignored) {}
            }
            for (File f : textFilesToSend) {
                try { f.delete(); } catch (Exception ignored) {}
            }
            return;
        }

        new Thread(() -> {
            String reply;
            OpenAiClient.CounselingResult counselingResult = null;
            ClinicalDecisionRC7 rc7DecisionForQuality = null;
            try {
                JSONArray history = ChatStorage.getMessages(this);
                ClinicalMemoryRevisionRC7.Result memoryRevision =
                        ClinicalMemoryRevisionRC7.apply(this, requestText);
                ClinicalQaRC7.recordMemoryRevision(this, memoryRevision);
                String therapyContext = TherapyMemoryManager.buildContext(this) + "\n\n"
                        + TherapySurfaceContext.forSurface(this, TherapySurfaceContext.COUNSELING)
                        + "\n\n" + ClinicalMemoryConsolidatorRC7.buildContext(this)
                        + "\n\n" + LongTermConversationMemory.build(this, requestText);
                JSONArray imageDataUrls = hasImage ? imageFilesToDataUrls(imagesToSend) : new JSONArray();

                // v3.5: GPT는 먼저 상담 없이 '문맥 이해'만 한다.
                String previousContext = ConversationContextMemory.get(this);
                String understoodContext = OpenAiClient.understandConversationContext(
                        apiKey, history, requestText, imageDataUrls, previousContext, contextModel);
                ConversationContextMemory.save(this, understoodContext);

                // v3.5.2: 100개 상담원리 DB에서 현재 사건과 관련된 규칙만 5~8개 선택한다.
                String ruleContext = CounselingRuleEngine.buildContext(requestText, understoodContext);
                String decisionBetaContext = DecisionRulesBeta.buildContext(this, requestText);
                String therapistBrainContext = TherapistBrainStack.buildContext(this, requestText);

                // v5.5 Clinical Brain: FDU/QDU/IDU/SDU 기반의 구조화 판단 보조층.
                // 기존 MetaCounselDecision을 대체하지 않고, 후보 가설/핵심 정보공백/추천 질문·개입을 입력으로 제공한다.
                ClinicalBrainEngine.Snapshot clinicalSnapshot = ClinicalBrainEngine.analyze(
                        this, requestText, ChatStorage.getRecentText(this, 20));
                String clinicalBrainContext = clinicalSnapshot.toPromptBlock();

                // v6.0 / RC7 Production Clinical Brain.
                // 556 canonical REAL/source-derived units를 Android assets에서 직접 로드하며,
                // Safety / Alliance Repair / high-value ASK를 기존 Meta Counselor보다 앞에서 결정한다.
                ClinicalDecisionRC7 rc7Decision = ClinicalBrainRC7.decide(
                        this, requestText, ChatStorage.getRecentText(this, 30));
                rc7DecisionForQuality = rc7Decision;
                ClinicalQaRC7.stageDecision(this, requestText, rc7Decision);
                String rc7Context = rc7Decision.toPromptBlock();
                Log.d("MaeumMonRC7", "move=" + rc7Decision.move
                        + " target=" + rc7Decision.target
                        + " unit=" + rc7Decision.unitId
                        + " safety=" + rc7Decision.safetyOverride
                        + " rupture=" + rc7Decision.allianceRupture);

                // v4.0: Cognitive Engine이 RESPONSE_NEED → ASSESS → HYPOTHESIS → ASK GATE → FORMULATION을 판단한다.
                // ASK / FORMULATE / STABILIZE / REVIEW는 여기서 직접 출력하고 일반 상담엔진 호출을 금지한다.
                // INTERVENE일 때만 기존 상담기법 엔진을 호출하되, 핵심 개입 하나만 허용한다.
                OpenAiClient.MetaCounselDecision metaDecision = null;
                boolean rc7DirectRoute = rc7Decision != null
                        && (rc7Decision.isAsk() || rc7Decision.isStabilize() || rc7Decision.isAllianceRepair());
                if (!rc7DirectRoute) {
                    try {
                        String stateMemory = CounselingStateMemory.snapshot(this)
                                + "\n\n" + TherapyThreadManager.snapshot(this)
                                + "\n\n" + decisionBetaContext
                                + "\n\n" + therapistBrainContext
                                + "\n\n" + clinicalBrainContext
                                + "\n\n" + rc7Context;
                        metaDecision = OpenAiClient.getMetaCounselDecision(
                                apiKey, history, requestText, understoodContext, ruleContext, therapyContext, stateMemory, counselingModel);
                        Log.d("MaeumMonV4", "state=" + metaDecision.action + " need=" + metaDecision.responseNeed + " formulation=" + metaDecision.formulationType
                                + " qValue=" + metaDecision.questionValue
                                + " direction=" + metaDecision.directionChangeScore
                                + " uncertainty=" + metaDecision.uncertaintyScore
                                + " novelty=" + metaDecision.noveltyScore
                                + " burden=" + metaDecision.burdenScore
                                + " highImpact=" + metaDecision.highImpactUnknownExists
                                + " sufficient=" + metaDecision.evidenceSufficient
                                + " reason=" + metaDecision.reason);
                    } catch (Exception metaError) {
                        Log.w("MaeumMonMeta", "State Counselor fallback: " + metaError.getMessage());
                    }
                } else {
                    Log.d("MaeumMonRC7", "Meta Counselor skipped for authoritative direct route=" + rc7Decision.move);
                }

                if (rc7Decision != null && (rc7Decision.isAsk() || rc7Decision.isStabilize() || rc7Decision.isAllianceRepair())) {
                    // RC7 authoritative direct routes: 질문 하나 / 안전확인 / 상담관계 수리.
                    reply = rc7Decision.directText;
                    if (reply == null || reply.trim().isEmpty()) {
                        reply = rc7Decision.isStabilize()
                                ? "지금은 분석보다 안전부터 확인할게. 지금 당장 스스로를 다치게 할 계획이나 실행 가능성이 있어?"
                                : "내가 지금 어디서 너랑 어긋났는지 먼저 맞출게. 제일 답답했던 부분이 뭐였어?";
                    }
                    Log.d("MaeumMonRC7", "DIRECT_RC7_REPLY=" + rc7Decision.move + " text=" + reply);
                } else if (metaDecision != null && !metaDecision.isIntervene()) {
                    // RC7이 FORMULATE/REVIEW를 선호할 때 Meta Counselor는 rc7Context를 최우선 directive로 받는다.
                    reply = metaDecision.directReply();
                    CounselingStateMemory.record(this, metaDecision);
                    TherapyThreadManager.recordMeta(this, metaDecision, requestText);
                    if (metaDecision.isAsk() && clinicalSnapshot != null && !clinicalSnapshot.recommendedQuestionId.isEmpty()) {
                        ClinicalBrainEngine.recordQuestionUsed(this, clinicalSnapshot.recommendedQuestionId, clinicalSnapshot.recommendedTarget);
                    }
                    Log.d("MaeumMonMeta", "DIRECT_STATE_REPLY=" + metaDecision.action + " text=" + reply);
                } else {
                    String therapyWithRules = therapyContext
                            + "\n\n" + ruleContext
                            + "\n\n" + decisionBetaContext
                            + "\n\n" + therapistBrainContext
                            + "\n\n" + clinicalBrainContext
                            + "\n\n" + rc7Context
                            + (metaDecision == null ? "" : "\n\n" + metaDecision.asDirective())
                            + "\n[강제 출력 원칙] 이번 턴은 INTERVENE다. 이미 확인된 사례개념화를 다시 길게 설명하지 않는다. "
                            + "질문을 추가하지 않는다. CBT/DBT/ACT 등 여러 기법을 나열하지 않는다. 현재 핵심에 맞는 개입 하나만 기본 2~3문장, 특별히 복잡해도 4문장을 넘기지 않는다. 같은 뜻의 설명을 반복하지 않는다. [MICRO-TUNE] 첫 문장에서 핵심이 잡혔으면 사건을 다시 길게 요약하지 않는다. 사용자의 감정 의미가 근거로 분명할 때만 생활어 한 문장으로 왜 불편했는지를 연결하고, 상담용어는 쓰지 않는다. "
                            + "이미 확인된 두려움/욕구가 행동 제안과 직접 연결될 때만 인간적인 연결 설명을 한 문장 이내로 허용한다. 예: '그 순간엔 바로 거절해 어색해지는 것보다 여지를 남기는 게 덜 불편했던 거야. 하지만 다음엔…'처럼 이해→변화로 연결한다. 새 원인 분석은 금지한다. "
                            + "가능하면 실제 생활에서 바로 해볼 수 있는 작은 행동 또는 한 문장을 하나만 고른다. 상대 의도가 확인되지 않았으면 의도를 단정하지 말고 사용자가 받은 영향 중심으로 표현한다. "
                            + "[FORMULATION→CHANGE BRIDGE] 행동을 갑자기 던지지 않는다. 앞에서 확인한 CORE_SENTENCE/THREAD의 두려움·욕구·보호전략과 이번 행동이 왜 연결되는지 생활어 한 문장으로 다리를 놓는다. 가능하면 '그래서 네가 바꿔야 할 건 X 자체가 아니라 Y야' 또는 같은 의미의 자연스러운 문장으로 변화 목표를 명시한 뒤 행동 하나를 준다. 단, 새 원인/과거를 발명하지 않고 이미 확인된 근거만 쓴다. "
                            + "[THERAPIST DISCIPLINE] 최종 답이 앞 상담과 이어지는지, 흔한 GPT 조언으로 새는지, 상대 의도를 사실처럼 단정하는지, 사용자를 고정된 성격으로 규정하는지, 같은 뜻을 반복하는지 점검하고 위반 문장은 삭제/수정한다. "
                            + "[OH_BIGDATA_V2 + v5.2 SESSION CONTINUITY 출력 적용] Meta directive의 ENDING_TYPE을 따른다. ACTION_ENDING은 행동 하나, SCRIPT_ENDING은 복사해 쓸 문장 하나, BOUNDARY_ENDING은 감정 인정과 행동 한계를 짧게 분리하고, PRACTICE_ENDING은 문장 하나만 연습시키고, REGULATION_ENDING은 즉각 안정, INSIGHT_ENDING은 핵심 이해로 닫고, FOLLOWUP_ENDING은 관찰 지표를 남긴다. CONTINUATION_ENDING은 한 답변의 마침표와 상담주제 종료를 구분한다: 새 핵심정보나 high-impact formulation gap이 남았을 때만, 앞의 이해를 짧게 연결한 뒤 방향을 가르는 질문 하나로 같은 주제를 이어간다. 단순히 대화를 계속하기 위한 질문은 금지한다. "
                            + "CONFIDENCE_TARGET/CONFIDENCE_LANGUAGE를 그대로 반영한다. 상대 의도는 낮은 확신 언어, 반복 패턴·관찰 가능한 상호작용은 근거만큼 중간~높은 확신, 행동 경계와 사실/해석 구분은 필요하면 단호하게 말하되 감정적 공격성은 낮게 유지한다. "
                            + "CORE_EMOTION은 translation_confidence가 LOW이면 사실처럼 말하지 않는다. EMOTION_DELIVERY가 ATTACK/PRESSURE이면 감정 자체와 표현 방식을 분리한다. INTERACTION_BREAKDOWN=true이면 누가 나쁜지보다 고리를 먼저 짚는다.";

                    counselingResult = OpenAiClient.getTherapyReply(
                            apiKey, history, requestText, therapyWithRules, new JSONArray(), understoodContext, counselingModel);
                    reply = counselingResult.reply;
                    TherapyMemoryManager.save(this, counselingResult);
                    TherapyThreadManager.recordResult(this, counselingResult);
                    if (metaDecision != null) {
                        CounselingStateMemory.record(this, metaDecision);
                        TherapyThreadManager.recordMeta(this, metaDecision, requestText);
                    }
                }
            } catch (Exception structuredError) {
                // 복잡한 Structured Outputs 요청이 실패해도 바로 로컬 상담으로 떨어지지 않고,
                // 같은 상담 맥락을 유지한 일반 Responses API로 한 번 더 시도한다.
                try {
                    JSONArray history = ChatStorage.getMessages(this);
                    String therapyContext = TherapyMemoryManager.buildContext(this) + "\n\n" + LongTermConversationMemory.build(this, requestText);
                    JSONArray imageDataUrls = hasImage ? imageFilesToDataUrls(imagesToSend) : new JSONArray();
                    String understoodContext = "";
                    try {
                        understoodContext = OpenAiClient.understandConversationContext(
                                apiKey, history, requestText, imageDataUrls, ConversationContextMemory.get(this), contextModel);
                        ConversationContextMemory.save(this, understoodContext);
                    } catch (Exception ignored) {}

                    if (!understoodContext.isEmpty()) {
                        String ruleContext = CounselingRuleEngine.buildContext(requestText, understoodContext);
                        String decisionBetaContext = DecisionRulesBeta.buildContext(this, requestText);
                        String therapistBrainContext = TherapistBrainStack.buildContext(this, requestText);
                        String groundedTherapyContext = therapyContext
                                + "\n\n[GPT 문맥 이해 레이어 결과]\n" + understoodContext
                                + "\n상담은 기존 마음몬 기법으로 수행하고, 인물/화자/사건 사실은 위 결과를 우선해. possible_interpretations는 가설로만 다뤄."
                                + "\n\n" + ruleContext
                                + "\n\n" + decisionBetaContext
                                + "\n\n" + therapistBrainContext;
                        reply = OpenAiClient.getTherapyFallbackReply(
                                apiKey, history, requestText, groundedTherapyContext, new JSONArray(), counselingModel);
                    } else {
                        reply = OpenAiClient.getTherapyFallbackReply(
                                apiKey, history, requestText, therapyContext, imageDataUrls, counselingModel);
                    }
                } catch (Exception fallbackError) {
                    // v4.3.5: 선택한 모델/요청이 실패해도 바로 로컬 상담으로 떨어지지 않는다.
                    // 가장 단순한 Responses API 요청을 gpt-4.1-mini로 한 번 더 시도해
                    // 모델 접근권한/특정 모델 일시 오류와 전체 API 연결 실패를 구분한다.
                    try {
                        JSONArray retryHistory = ChatStorage.getMessages(this);
                        String retryContext = TherapyMemoryManager.buildContext(this)
                                + "\n\n" + LongTermConversationMemory.build(this, requestText)
                                + "\n\n[API RECOVERY MODE] 앞선 고급 상담 요청이 실패했다. "
                                + "상담 원칙은 유지하되 복잡한 구조화 출력 없이 쉬운 한국어 2~4문장으로 답한다.";
                        JSONArray retryImages = hasImage ? imageFilesToDataUrls(imagesToSend) : new JSONArray();
                        reply = OpenAiClient.getTherapyFallbackReply(
                                apiKey, retryHistory, requestText, retryContext, retryImages, "gpt-4.1-mini");
                        final String recovered = "GPT-5.6 요청이 실패해 GPT-4.1 mini로 자동 복구했어.";
                        handler.post(() -> chatStatus.setText(recovered));
                    } catch (Exception emergencyError) {
                        final String debug = shortApiError(structuredError, fallbackError, emergencyError);
                        reply = LocalCounselor.reply(requestText)
                                + "\n\n(지금은 OpenAI API 연결이 되지 않아 임시 기본 상담으로 답했어.)"
                                + "\n[연결 진단] " + debug;
                        handler.post(() -> chatStatus.setText(debug));
                    }
                }
            }

            String originalReplyForQuality = reply;
            ClinicalResponseQualityRC7.Result originalQuality =
                    ClinicalResponseQualityRC7.evaluate(requestText, originalReplyForQuality, rc7DecisionForQuality);
            String coherenceContext = ChatStorage.getRecentText(this, 20);
            ClinicalConversationCoherenceRC7.Result originalCoherence =
                    ClinicalConversationCoherenceRC7.evaluate(
                            coherenceContext,
                            requestText,
                            originalReplyForQuality,
                            rc7DecisionForQuality == null ? "" : rc7DecisionForQuality.move,
                            rc7DecisionForQuality == null ? "" : rc7DecisionForQuality.target);
            String revisedReplyForQuality = null;
            ClinicalResponseQualityRC7.Result revisedQuality = null;
            ClinicalResponseComparatorRC7.Result comparatorQuality = null;
            ClinicalConversationCoherenceRC7.Result revisedCoherence = null;
            String correctionSelected = "ORIGINAL";

            ClinicalSelfCorrectionRC7.Inspection correction =
                    ClinicalSelfCorrectionRC7.inspect(
                            rc7DecisionForQuality == null ? "" : rc7DecisionForQuality.move,
                            rc7DecisionForQuality == null ? "" : rc7DecisionForQuality.target,
                            originalReplyForQuality,
                            originalQuality);

            if (correction.correctionNeeded) {
                try {
                    JSONArray repairHistory = ChatStorage.getMessages(this);
                    String repairContext = TherapyMemoryManager.buildContext(this)
                            + "\n\n" + LongTermConversationMemory.build(this, requestText)
                            + "\n\n" + correction.repairInstruction;
                    revisedReplyForQuality = OpenAiClient.getTherapyFallbackReply(
                            apiKey, repairHistory, requestText, repairContext, new JSONArray(), counselingModel);
                    revisedQuality = ClinicalResponseQualityRC7.evaluate(
                            requestText, revisedReplyForQuality, rc7DecisionForQuality);
                    comparatorQuality = ClinicalResponseComparatorRC7.compare(
                            requestText,
                            originalReplyForQuality,
                            revisedReplyForQuality,
                            rc7DecisionForQuality == null ? "" : rc7DecisionForQuality.move,
                            rc7DecisionForQuality == null ? "" : rc7DecisionForQuality.target);

                    revisedCoherence = ClinicalConversationCoherenceRC7.evaluate(
                            coherenceContext,
                            requestText,
                            revisedReplyForQuality,
                            rc7DecisionForQuality == null ? "" : rc7DecisionForQuality.move,
                            rc7DecisionForQuality == null ? "" : rc7DecisionForQuality.target);

                    boolean revisedPreferred =
                            ClinicalResponseComparatorRC7.shouldPreferRevised(
                                    originalQuality, revisedQuality, comparatorQuality)
                            && ClinicalConversationCoherenceRC7.acceptable(revisedCoherence)
                            && (originalCoherence == null || revisedCoherence.score >= originalCoherence.score - 5);

                    if (revisedPreferred) {
                        reply = revisedReplyForQuality;
                        correctionSelected = "REVISED";
                    } else {
                        reply = originalReplyForQuality;
                        correctionSelected = "ORIGINAL_SEMANTIC_GUARD";
                    }
                    Log.d("MaeumMonRC7", "SELF_CORRECTION original="
                            + originalQuality.score + "/" + originalQuality.grade
                            + " revised=" + (revisedQuality == null ? "NA" : revisedQuality.score + "/" + revisedQuality.grade)
                            + " selected=" + correctionSelected);
                } catch (Exception repairError) {
                    Log.w("MaeumMonRC7", "Self-correction skipped after repair error: " + repairError.getMessage());
                }
            }

            final String finalReply = reply;
            final OpenAiClient.CounselingResult finalResult = counselingResult;
            ClinicalMemoryConsolidatorRC7.observe(
                    this, requestText, rc7DecisionForQuality, finalReply);
            CentralTherapyProfile.updateFromClinicalTurn(
                    this, requestText, rc7DecisionForQuality, finalReply);
            ClinicalQaRC7.recordFinalWithCorrection(
                    this, requestText, finalReply,
                    finalResult != null ? "GPT_THERAPY" : "DIRECT_META_OR_FALLBACK",
                    originalReplyForQuality, originalQuality,
                    revisedReplyForQuality, revisedQuality, correctionSelected, comparatorQuality,
                    originalCoherence, revisedCoherence);
            handler.post(() -> {
                ChatStorage.addMessage(this, "assistant", finalReply);
                ChatStorage.addCounselingTimeline(this, "assistant", finalReply);
                if (pendingBubble != null) {
                    pendingBubble.setText(finalReply);
                    scrollToLatestBubble(pendingBubble);
                } else {
                    addBubble("assistant", finalReply);
                }
                updateTherapyProgressCard();
                if (finalReply.contains("[연결 진단]")) {
                    // 실패 원인을 이미 표시했으므로 일반 성공 상태로 덮어쓰지 않는다.
                } else if (chatStatus.getText() != null
                        && chatStatus.getText().toString().contains("자동 복구")) {
                    // gpt-4.1-mini 자동 복구 상태를 유지한다.
                } else if (finalResult != null && "urgent".equals(finalResult.riskLevel)) {
                    chatStatus.setText("지금은 변화보다 안전을 먼저 확인하고 있어.");
                } else {
                    chatStatus.setText("변화상담 · 다음 대화에도 오늘 발견을 이어갈게.");
                }
                speakReplyIfEnabled(finalReply);
            });
            for (File f : imagesToSend) {
                try { f.delete(); } catch (Exception ignored) {}
            }
            for (File f : textFilesToSend) {
                try { f.delete(); } catch (Exception ignored) {}
            }
        }).start();
    }

    private String shortApiError(Exception primary, Exception fallback) {
        return shortApiError(primary, fallback, null);
    }

    private String shortApiError(Exception primary, Exception fallback, Exception emergency) {
        String a = primary == null || primary.getMessage() == null ? "" : primary.getMessage();
        String b = fallback == null || fallback.getMessage() == null ? "" : fallback.getMessage();
        String c = emergency == null || emergency.getMessage() == null ? "" : emergency.getMessage();
        String raw = !c.isEmpty() ? c : (!b.isEmpty() ? b : a);
        String lower = raw.toLowerCase();

        if (raw.contains("401")) return "401 · API Key 인증 실패. 키가 맞는지 다시 확인해줘.";
        if (raw.contains("403")) return "403 · 이 API Key/프로젝트에서 요청이 허용되지 않았어.";
        if (raw.contains("404") || lower.contains("model_not_found"))
            return "모델 접근 오류 · 선택한 모델을 이 API 프로젝트에서 사용할 수 있는지 확인해줘.";
        if (raw.contains("429"))
            return "429 · API 크레딧/사용 한도 또는 속도 제한에 걸렸어.";
        if (raw.contains("400"))
            return "400 · OpenAI가 요청 형식을 거절했어. 고급 요청과 단순 요청 모두 실패했어.";
        if (raw.contains("500") || raw.contains("502") || raw.contains("503") || raw.contains("504"))
            return "OpenAI 서버가 일시적으로 응답하지 않았어. 잠시 뒤 다시 보내줘.";
        if (lower.contains("timeout") || lower.contains("timed out"))
            return "시간초과 · OpenAI 응답이 너무 늦었어. 다시 보내면 재시도할게.";
        if (lower.contains("unknownhost") || lower.contains("unable to resolve host"))
            return "네트워크/DNS 오류 · 인터넷, VPN, Private DNS를 확인해줘.";
        if (lower.contains("ssl") || lower.contains("certificate"))
            return "SSL 연결 오류 · 네트워크 보안/VPN 영향을 확인해줘.";

        // 너무 긴 서버 원문/키 정보는 UI에 노출하지 않는다.
        return "OpenAI 연결 실패 · 인터넷/VPN/API Key/API 결제 상태를 확인해줘.";
    }

    private void updateTherapyProgressCard() {
        if (therapyFocusText != null) {
            therapyFocusText.setText("변화 여정 " + TherapyJourneyManager.shortLabel(this) + "\n현재 초점 · " + TherapyMemoryManager.getCurrentFocus(this));
        }
        if (therapyPracticeText != null) {
            therapyPracticeText.setText("이번 생활 연습 · " + TherapyMemoryManager.getActiveExperiment(this));
        }
        if (therapyApproachText != null) {
            therapyApproachText.setText("이번 상담에서 집중한 것 · " + ChangeMapManager.lastApproach(this));
        }
    }

    private void speakReplyIfEnabled(String reply) {
        if (!voiceReplySwitch.isChecked()) return;
        if (TtsManager.isQuietHour(this)) {
            chatStatus.setText("밤에는 음성 답변을 조용히 쉬게 했어 🌙");
            return;
        }
        TtsManager.speak(this, reply, new TtsManager.SpeakListener() {
            @Override public void onEngine(String engineName) {
                handler.post(() -> chatStatus.setText(engineName));
            }
            @Override public void onError(String message) {
                handler.post(() -> chatStatus.setText(message));
            }
        });
    }

    private void saveTypecastSettings() {
        String key = typecastApiKeyInput.getText().toString().trim();
        String voiceId = typecastVoiceIdInput.getText().toString().trim();
        prefs.edit()
                .putString(AppPrefs.KEY_TYPECAST_API_KEY, key)
                .putString(AppPrefs.KEY_TYPECAST_VOICE_ID, voiceId)
                .putString(AppPrefs.KEY_TYPECAST_MODEL_ID, "ssfm-v30")
                .putBoolean(AppPrefs.KEY_TYPECAST_ENABLED, typecastSwitch.isChecked())
                .apply();
        updateTypecastStatus();
        updateTypecastSummary();
        Toast.makeText(this, "Typecast 설정 저장 완료", Toast.LENGTH_SHORT).show();
    }

    private void findTypecastChildVoices() {
        String key = typecastApiKeyInput.getText().toString().trim();
        if (key.isEmpty()) {
            typecastStatusText.setText("먼저 Typecast API Key를 입력해줘.");
            return;
        }
        typecastStatusText.setText("남자 어린이 목소리를 불러오는 중…");
        TypecastClient.listChildMaleVoices(key, new TypecastClient.VoicesListener() {
            @Override public void onSuccess(java.util.List<TypecastClient.Voice> voices) {
                if (voices == null || voices.isEmpty()) {
                    typecastStatusText.setText("현재 API에서 남자 어린이 목소리를 찾지 못했어. Voice ID를 직접 넣어도 돼.");
                    return;
                }
                String[] labels = new String[voices.size()];
                for (int i = 0; i < voices.size(); i++) labels[i] = voices.get(i).toString();
                new AlertDialog.Builder(ChatActivity.this)
                        .setTitle("어린 승재 목소리 고르기")
                        .setItems(labels, (dialog, which) -> {
                            TypecastClient.Voice voice = voices.get(which);
                            typecastVoiceIdInput.setText(voice.id);
                            prefs.edit().putString(AppPrefs.KEY_TYPECAST_VOICE_NAME, voice.name).apply();
                            typecastSwitch.setChecked(true);
                            saveTypecastSettings();
                            typecastStatusText.setText(voice.name + " 선택 완료 · 목소리 테스트를 눌러봐.");
                        })
                        .setNegativeButton("닫기", null)
                        .show();
            }
            @Override public void onError(String message) {
                typecastStatusText.setText(message);
            }
        });
    }

    private void testTypecastVoice() {
        saveTypecastSettings();
        if (!TtsManager.canUseTypecast(this)) {
            typecastStatusText.setText("Typecast 사용을 켜고 API Key와 Voice ID를 입력해줘.");
            return;
        }
        typecastStatusText.setText("어린 승재 목소리를 만들고 있어…");
        TtsManager.speak(this, "승재야, 오늘은 어땠어? 천천히 이야기해줘. 내가 옆에서 들어줄게.",
                new TtsManager.SpeakListener() {
                    @Override public void onEngine(String engineName) {
                        handler.post(() -> typecastStatusText.setText(engineName));
                    }
                    @Override public void onError(String message) {
                        handler.post(() -> typecastStatusText.setText(message));
                    }
                });
    }

    private void showTypecastAdvancedSettings() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        int pad = dp(18);
        box.setPadding(pad, dp(8), pad, dp(4));

        Switch smartSwitch = new Switch(this);
        smartSwitch.setText("✨ 스마트 이모션 자동 적용");
        smartSwitch.setChecked(prefs.getBoolean(AppPrefs.KEY_TYPECAST_SMART_EMOTION, true));
        box.addView(smartSwitch);

        TextView hqNote = dialogLabel("v1.6.7 웹 에디터 맞춤: ssfm-v30 · WAV 원본 · 앱 강제증폭 없음");
        hqNote.setTextColor(0xFF4F8E82);
        box.addView(hqNote);

        TextView emotionLabel = dialogLabel("감정 프리셋");
        box.addView(emotionLabel);
        Spinner emotionSpinner = new Spinner(this);
        String[] emotionLabels = {"기본", "기쁨", "슬픔", "화남", "속삭임", "톤 업", "톤 다운"};
        String[] emotionValues = {"normal", "happy", "sad", "angry", "whisper", "toneup", "tonedown"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, emotionLabels);
        emotionSpinner.setAdapter(adapter);
        String savedPreset = prefs.getString(AppPrefs.KEY_TYPECAST_EMOTION_PRESET, "normal");
        int selected = 0;
        for (int i = 0; i < emotionValues.length; i++) if (emotionValues[i].equals(savedPreset)) selected = i;
        emotionSpinner.setSelection(selected);
        box.addView(emotionSpinner);

        TextView intensityValue = dialogLabel("");
        SeekBar intensityBar = addSettingSeek(box, "감정 강도", 0, 20,
                Math.round(prefs.getFloat(AppPrefs.KEY_TYPECAST_EMOTION_INTENSITY, 1.0f) * 10f), intensityValue,
                v -> String.format(java.util.Locale.KOREA, "%.1f", v / 10f));

        TextView tempoValue = dialogLabel("");
        SeekBar tempoBar = addSettingSeek(box, "속도", 50, 200,
                Math.round(prefs.getFloat(AppPrefs.KEY_TYPECAST_TEMPO, 1.0f) * 100f), tempoValue,
                v -> String.format(java.util.Locale.KOREA, "%.2fx", v / 100f));

        TextView pitchValue = dialogLabel("");
        SeekBar pitchBar = addSettingSeek(box, "피치", -12, 12,
                prefs.getInt(AppPrefs.KEY_TYPECAST_PITCH, 0), pitchValue,
                v -> (v > 0 ? "+" : "") + v);

        TextView volumeValue = dialogLabel("");
        SeekBar volumeBar = addSettingSeek(box, "음량", 0, 200,
                prefs.getInt(AppPrefs.KEY_TYPECAST_VOLUME, 100), volumeValue,
                String::valueOf);

        Runnable updateEnabled = () -> {
            boolean manual = !smartSwitch.isChecked();
            emotionSpinner.setEnabled(manual);
            intensityBar.setEnabled(manual);
            emotionLabel.setAlpha(manual ? 1f : 0.45f);
            emotionSpinner.setAlpha(manual ? 1f : 0.45f);
            intensityBar.setAlpha(manual ? 1f : 0.45f);
            intensityValue.setAlpha(manual ? 1f : 0.45f);
        };
        smartSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> updateEnabled.run());
        updateEnabled.run();

        ScrollView scroll = new ScrollView(this);
        scroll.addView(box);
        scroll.setFillViewport(true);

        new AlertDialog.Builder(this)
                .setTitle("🎛 Typecast 세부 음성 설정 · HQ")
                .setView(scroll)
                .setNegativeButton("취소", null)
                .setPositiveButton("저장", (dialog, which) -> {
                    int pos = emotionSpinner.getSelectedItemPosition();
                    prefs.edit()
                            .putBoolean(AppPrefs.KEY_TYPECAST_SMART_EMOTION, smartSwitch.isChecked())
                            .putString(AppPrefs.KEY_TYPECAST_EMOTION_PRESET, emotionValues[Math.max(0, pos)])
                            .putFloat(AppPrefs.KEY_TYPECAST_EMOTION_INTENSITY, intensityBar.getProgress() / 10f)
                            .putFloat(AppPrefs.KEY_TYPECAST_TEMPO, tempoBar.getProgress() / 100f)
                            .putInt(AppPrefs.KEY_TYPECAST_PITCH, pitchBar.getProgress())
                            .putInt(AppPrefs.KEY_TYPECAST_VOLUME, volumeBar.getProgress())
                            .apply();
                    updateTypecastSummary();
                    Toast.makeText(this, "세부 음성 설정을 저장했어.", Toast.LENGTH_SHORT).show();
                })
                .show();
    }

    private interface ValueFormatter { String format(int value); }

    private SeekBar addSettingSeek(LinearLayout box, String title, int min, int max, int current,
                                   TextView valueView, ValueFormatter formatter) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        TextView label = dialogLabel(title);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        row.addView(label, lp);
        valueView.setText(formatter.format(current));
        row.addView(valueView);
        box.addView(row);

        SeekBar bar = new SeekBar(this);
        if (android.os.Build.VERSION.SDK_INT >= 26) bar.setMin(min);
        bar.setMax(max);
        bar.setProgress(current);
        bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                valueView.setText(formatter.format(progress));
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {}
        });
        box.addView(bar, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(44)));
        return bar;
    }

    private TextView dialogLabel(String text) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextColor(0xFF5F6877);
        tv.setTextSize(14f);
        tv.setPadding(0, dp(7), 0, dp(3));
        return tv;
    }

    private void updateTypecastSummary() {
        if (typecastSummaryText == null) return;
        String voiceName = prefs.getString(AppPrefs.KEY_TYPECAST_VOICE_NAME, "").trim();
        boolean smart = prefs.getBoolean(AppPrefs.KEY_TYPECAST_SMART_EMOTION, true);
        String preset = prefs.getString(AppPrefs.KEY_TYPECAST_EMOTION_PRESET, "normal");
        String emotion = smart ? "스마트 이모션" : emotionLabel(preset);
        float intensity = prefs.getFloat(AppPrefs.KEY_TYPECAST_EMOTION_INTENSITY, 1.0f);
        float tempo = prefs.getFloat(AppPrefs.KEY_TYPECAST_TEMPO, 1.0f);
        int pitch = prefs.getInt(AppPrefs.KEY_TYPECAST_PITCH, 0);
        int volume = prefs.getInt(AppPrefs.KEY_TYPECAST_VOLUME, 100);
        String prefix = voiceName.isEmpty() ? "" : voiceName + " · ";
        String detail = smart ? emotion : emotion + " " + String.format(java.util.Locale.KOREA, "%.1f", intensity);
        typecastSummaryText.setText("현재 적용: " + prefix + detail + " · "
                + String.format(java.util.Locale.KOREA, "%.2fx", tempo)
                + " · 피치 " + (pitch > 0 ? "+" : "") + pitch + " · 음량 " + volume);
    }

    private String emotionLabel(String value) {
        if ("happy".equals(value)) return "기쁨";
        if ("sad".equals(value)) return "슬픔";
        if ("angry".equals(value)) return "화남";
        if ("whisper".equals(value)) return "속삭임";
        if ("toneup".equals(value)) return "톤 업";
        if ("tonedown".equals(value)) return "톤 다운";
        return "기본";
    }

    private void updateTypecastStatus() {
        if (typecastStatusText == null) return;
        boolean enabled = prefs.getBoolean(AppPrefs.KEY_TYPECAST_ENABLED, false);
        boolean hasKey = !prefs.getString(AppPrefs.KEY_TYPECAST_API_KEY, "").trim().isEmpty();
        boolean hasVoice = !prefs.getString(AppPrefs.KEY_TYPECAST_VOICE_ID, "").trim().isEmpty();
        if (enabled && hasKey && hasVoice) {
            typecastStatusText.setText("Typecast 준비 완료 · 상담 답변과 홈 위로 답변에서 우선 사용해.");
        } else if (enabled) {
            typecastStatusText.setText("API Key를 넣고 ‘어린이 목소리 찾기’를 눌러 Voice ID를 선택해줘.");
        } else {
            typecastStatusText.setText("Typecast를 켜면 어린이 음성 목록에서 목소리를 골라 사용할 수 있어.");
        }
    }


    private void renderMessages() {
        chatContainer.removeAllViews();
        JSONArray arr = ChatStorage.getMessages(this);
        for (int i = 0; i < arr.length(); i++) {
            JSONObject obj = arr.optJSONObject(i);
            if (obj == null) continue;
            addBubble(obj.optString("role", "assistant"), obj.optString("text", ""));
        }
    }

    private TextView addBubble(String role, String text) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextSize(16f);
        tv.setTextColor(0xFF4F5569);
        tv.setPadding(dp(14), dp(12), dp(14), dp(12));
        // One UI/Android 기본 텍스트 선택 UI를 그대로 사용한다.
        // 길게 누르면 선택 핸들 + 복사/전체선택 메뉴가 시스템 방식으로 열린다.
        tv.setTextIsSelectable(true);
        tv.setLongClickable(true);

        LinearLayout wrapper = new LinearLayout(this);
        wrapper.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ));
        wrapper.setPadding(0, dp(6), 0, dp(6));

        LinearLayout.LayoutParams bubbleParams = new LinearLayout.LayoutParams(
                (int)(getResources().getDisplayMetrics().widthPixels * 0.78f),
                ViewGroup.LayoutParams.WRAP_CONTENT
        );

        if ("user".equals(role)) {
            wrapper.setGravity(Gravity.END);
            tv.setBackgroundResource(R.drawable.bg_chat_user);
        } else {
            wrapper.setGravity(Gravity.START);
            tv.setBackgroundResource(R.drawable.bg_chat_ai);
        }

        wrapper.addView(tv, bubbleParams);
        chatContainer.addView(wrapper);

        scrollToLatestBubble(tv);
        return tv;
    }

    private void scrollToLatestBubble(View bubble) {
        if (chatHistoryScroll == null) return;

        // pending 말풍선이 실제 GPT 답변으로 바뀌면 높이가 크게 달라질 수 있다.
        // 레이아웃 계산 전에 좌표를 읽으면 맨 위로 튀는 경우가 있어서,
        // 레이아웃이 끝난 뒤 항상 상담창의 진짜 마지막으로 이동한다.
        Runnable goBottom = () -> {
            if (chatHistoryScroll == null) return;
            chatHistoryScroll.fullScroll(View.FOCUS_DOWN);
        };
        chatHistoryScroll.post(goBottom);
        handler.postDelayed(goBottom, 90L);
        handler.postDelayed(goBottom, 260L);
    }

    private int dp(int value) {
        float density = getResources().getDisplayMetrics().density;
        return (int) (value * density + 0.5f);
    }
    @Override
    protected void onDestroy() {
        if (recording) {
            try { recorder.stop(); } catch (Exception ignored) {}
            recording = false;
        }
        releaseRecorder();
        TtsManager.stop();
        super.onDestroy();
    }


    private String applyResponseFactGuardRC9(String userText,String reply,ClinicalDecisionRC7 decision){
        ResponseContradictionHallucinationGuardRC9.Check factCheck =
                ResponseContradictionHallucinationGuardRC9.inspect(this,userText,reply);

        if(decision!=null){
            decision.responseFactGuardSummary=factCheck.summary;
            decision.responseRewriteRequired=factCheck.rewriteRequired;
        }

        if(factCheck.pass)return reply;

        // Do not invent a second independent clinical route here.
        // Attach a strict rewrite directive; the existing one-shot correction loop may repair it.
        if(decision!=null){
            decision.responseInstruction=(decision.responseInstruction==null?"":decision.responseInstruction+" ")
                    +factCheck.instruction;
        }
        return reply;
    }

}
