package com.maeummon.app;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.util.AttributeSet;
import android.view.animation.LinearInterpolator;
import android.widget.ImageView;

import java.util.Random;

public class AnimatedYoungSeungjaeView extends ImageView {

    public enum State {
        IDLE, WALK, WAVE, THINK, SIT, JUMP, SLEEP
    }

    private static final int MOTION_IDLE = 0;
    private static final int MOTION_WALK = 1;
    private static final int MOTION_WAVE = 2;
    private static final int MOTION_THINK = 3;
    private static final int MOTION_SIT = 4;
    private static final int MOTION_JUMP = 5;
    private static final int MOTION_SLEEP = 6;

    private static final int IDLE_START = 0;
    private static final int IDLE_END = 19;
    private static final int WALK_START = 20;
    private static final int WALK_END = 39;
    private static final int WAVE_START = 40;
    private static final int WAVE_END = 54;
    private static final int THINK_START = 55;
    private static final int THINK_END = 69;
    private static final int SIT_START = 70;
    private static final int SIT_END = 84;
    private static final int JUMP_START = 85;
    private static final int JUMP_END = 94;
    private static final int SLEEP_START = 95;
    private static final int SLEEP_END = 99;

    private static class PoseSpec {
        final int primaryRes;
        final int secondaryRes;
        final boolean faceRight;
        final int motionStyle;
        final float bobAmp;
        final float rotAmp;
        final float scaleAmp;
        final float hopAmp;

        PoseSpec(int primaryRes, int secondaryRes, boolean faceRight, int motionStyle,
                 float bobAmp, float rotAmp, float scaleAmp, float hopAmp) {
            this.primaryRes = primaryRes;
            this.secondaryRes = secondaryRes;
            this.faceRight = faceRight;
            this.motionStyle = motionStyle;
            this.bobAmp = bobAmp;
            this.rotAmp = rotAmp;
            this.scaleAmp = scaleAmp;
            this.hopAmp = hopAmp;
        }
    }

    private static PoseSpec pose(int primaryRes, int secondaryRes, boolean faceRight, int motionStyle,
                                 float bobAmp, float rotAmp, float scaleAmp, float hopAmp) {
        return new PoseSpec(primaryRes, secondaryRes, faceRight, motionStyle, bobAmp, rotAmp, scaleAmp, hopAmp);
    }

    private static PoseSpec[] createPoseLibrary() {
        PoseSpec[] arr = new PoseSpec[100];
        int i = 0;

        int[] idleBases = new int[]{
                R.drawable.young_seungjae_idle,
                R.drawable.young_seungjae_idle,
                R.drawable.young_seungjae_wave,
                R.drawable.young_seungjae_think,
                R.drawable.young_seungjae_sit
        };
        for (int n = 0; n < 20; n++) {
            int base = idleBases[n % idleBases.length];
            int alt = base == R.drawable.young_seungjae_wave ? R.drawable.young_seungjae_idle : 0;
            int motion = base == R.drawable.young_seungjae_wave ? MOTION_WAVE
                    : (base == R.drawable.young_seungjae_sit ? MOTION_SIT
                    : (base == R.drawable.young_seungjae_think ? MOTION_THINK : MOTION_IDLE));
            arr[i++] = pose(base, alt, n % 2 == 0, motion,
                    1.3f + (n % 5) * 0.45f,
                    0.20f + (n % 4) * 0.18f,
                    0.008f + (n % 3) * 0.003f,
                    7f + (n % 4) * 1.5f);
        }

        for (int n = 0; n < 20; n++) {
            boolean right = n % 2 == 0;
            int primary = right ? R.drawable.young_seungjae_walk_1 : R.drawable.young_seungjae_walk_2;
            int secondary = right ? R.drawable.young_seungjae_walk_2 : R.drawable.young_seungjae_walk_1;
            arr[i++] = pose(primary, secondary, right, MOTION_WALK,
                    3.5f + (n % 6) * 0.45f,
                    0.9f + (n % 4) * 0.25f,
                    0.007f + (n % 3) * 0.003f,
                    10f + (n % 5) * 1.4f);
        }

        int[] waveBases = new int[]{
                R.drawable.young_seungjae_wave,
                R.drawable.young_seungjae_wave,
                R.drawable.young_seungjae_idle,
                R.drawable.young_seungjae_jump,
                R.drawable.young_seungjae_wave
        };
        for (int n = 0; n < 15; n++) {
            int base = waveBases[n % waveBases.length];
            int alt = base == R.drawable.young_seungjae_idle ? R.drawable.young_seungjae_wave : 0;
            int motion = base == R.drawable.young_seungjae_jump ? MOTION_JUMP : MOTION_WAVE;
            arr[i++] = pose(base, alt, n % 3 != 0, motion,
                    1.8f + (n % 4) * 0.55f,
                    0.35f + (n % 4) * 0.20f,
                    0.010f + (n % 3) * 0.004f,
                    12f + (n % 3) * 2.0f);
        }

        int[] thinkBases = new int[]{
                R.drawable.young_seungjae_think,
                R.drawable.young_seungjae_sit,
                R.drawable.young_seungjae_idle,
                R.drawable.young_seungjae_think,
                R.drawable.young_seungjae_wave
        };
        for (int n = 0; n < 15; n++) {
            int base = thinkBases[n % thinkBases.length];
            int motion = base == R.drawable.young_seungjae_sit ? MOTION_SIT
                    : (base == R.drawable.young_seungjae_wave ? MOTION_WAVE : MOTION_THINK);
            arr[i++] = pose(base, 0, n % 2 == 0, motion,
                    1.0f + (n % 5) * 0.35f,
                    0.25f + (n % 3) * 0.16f,
                    0.006f + (n % 4) * 0.002f,
                    7f + (n % 4) * 1.2f);
        }

        int[] sitBases = new int[]{
                R.drawable.young_seungjae_sit,
                R.drawable.young_seungjae_sit,
                R.drawable.young_seungjae_sleep,
                R.drawable.young_seungjae_jump,
                R.drawable.young_seungjae_think
        };
        for (int n = 0; n < 15; n++) {
            int base = sitBases[n % sitBases.length];
            int motion = base == R.drawable.young_seungjae_sleep ? MOTION_SLEEP
                    : (base == R.drawable.young_seungjae_jump ? MOTION_JUMP : MOTION_SIT);
            arr[i++] = pose(base, 0, n % 2 != 0, motion,
                    0.8f + (n % 4) * 0.30f,
                    0.12f + (n % 4) * 0.10f,
                    0.006f + (n % 3) * 0.002f,
                    6f + (n % 4) * 1.0f);
        }

        for (int n = 0; n < 10; n++) {
            int base = (n % 3 == 0) ? R.drawable.young_seungjae_wave : R.drawable.young_seungjae_jump;
            arr[i++] = pose(base, R.drawable.young_seungjae_idle, n % 2 == 0, MOTION_JUMP,
                    1.8f + (n % 3) * 0.35f,
                    0.45f + (n % 4) * 0.18f,
                    0.015f + (n % 3) * 0.004f,
                    16f + (n % 5) * 2.2f);
        }

        for (int n = 0; n < 5; n++) {
            int base = (n % 2 == 0) ? R.drawable.young_seungjae_sleep : R.drawable.young_seungjae_sit;
            arr[i++] = pose(base, 0, true, MOTION_SLEEP,
                    0.6f + n * 0.15f,
                    0.18f + n * 0.04f,
                    0.004f + n * 0.001f,
                    4f + n * 0.8f);
        }

        return arr;
    }

    private static final PoseSpec[] POSE_LIBRARY = createPoseLibrary();

    private final Random random = new Random();
    private ValueAnimator animator;
    private float phase = 0f;
    private State state = State.IDLE;
    private boolean facingRight = true;
    private String outfit = "hoodie";
    private int currentRes = -1;
    private PoseSpec currentPose = POSE_LIBRARY[0];
    private int lastPoseIndex = -1;

    public AnimatedYoungSeungjaeView(Context context) {
        super(context);
        init();
    }

    public AnimatedYoungSeungjaeView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    private void init() {
        setScaleType(ScaleType.FIT_CENTER);
        setAdjustViewBounds(true);
        animator = ValueAnimator.ofFloat(0f, 1f);
        animator.setDuration(1100L);
        animator.setRepeatCount(ValueAnimator.INFINITE);
        animator.setInterpolator(new LinearInterpolator());
        animator.addUpdateListener(animation -> {
            phase = (float) animation.getAnimatedValue();
            updateFrame();
        });
        animator.start();
        currentPose = randomPoseForState(state);
        updateFrame();
    }

    public void setState(State newState) {
        state = newState == null ? State.IDLE : newState;
        currentPose = randomPoseForState(state);
        currentRes = -1;
        updateFrame();
    }

    public void setFacingRight(boolean value) {
        facingRight = value;
        invalidate();
    }

    public void setOutfit(String value) {
        outfit = value == null ? "hoodie" : value;
        updateFrame();
    }

    private PoseSpec randomPoseForState(State targetState) {
        int start;
        int end;
        switch (targetState) {
            case WALK:
                start = WALK_START;
                end = WALK_END;
                break;
            case WAVE:
                start = WAVE_START;
                end = WAVE_END;
                break;
            case THINK:
                start = THINK_START;
                end = THINK_END;
                break;
            case SIT:
                start = SIT_START;
                end = SIT_END;
                break;
            case JUMP:
                start = JUMP_START;
                end = JUMP_END;
                break;
            case SLEEP:
                start = SLEEP_START;
                end = SLEEP_END;
                break;
            case IDLE:
            default:
                start = IDLE_START;
                end = IDLE_END;
                break;
        }

        int range = end - start + 1;
        int index = start + random.nextInt(range);
        if (range > 1 && index == lastPoseIndex) {
            index = start + ((index - start + 1 + random.nextInt(range - 1)) % range);
        }
        lastPoseIndex = index;
        return POSE_LIBRARY[index];
    }

    private int chooseRes() {
        if (currentPose == null) currentPose = POSE_LIBRARY[0];

        switch (currentPose.motionStyle) {
            case MOTION_WALK:
                return phase < 0.5f ? currentPose.primaryRes : currentPose.secondaryRes;
            case MOTION_WAVE:
                if (currentPose.secondaryRes != 0) {
                    return phase < 0.55f ? currentPose.primaryRes : currentPose.secondaryRes;
                }
                return currentPose.primaryRes;
            case MOTION_JUMP:
                if (currentPose.secondaryRes != 0) {
                    return phase < 0.7f ? currentPose.primaryRes : currentPose.secondaryRes;
                }
                return currentPose.primaryRes;
            default:
                return currentPose.primaryRes;
        }
    }

    private void updateFrame() {
        int res = chooseRes();
        if (res != currentRes) {
            setImageResource(res);
            currentRes = res;
        }
        invalidate();
    }

    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        if (animator != null) animator.cancel();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        if (currentPose == null) {
            currentPose = POSE_LIBRARY[0];
        }

        canvas.save();
        float cx = getWidth() / 2f;
        float cy = getHeight() / 2f;

        boolean drawFacingRight = state == State.WALK ? facingRight : currentPose.faceRight;
        if (!drawFacingRight) {
            canvas.scale(-1f, 1f, cx, cy);
        }

        float wave = (float) Math.sin(phase * Math.PI * 2f);
        float pulse = (float) Math.abs(Math.sin(phase * Math.PI));

        float translateY = 0f;
        float rotation = 0f;
        float scaleX = 1f;
        float scaleY = 1f;

        switch (currentPose.motionStyle) {
            case MOTION_WALK:
                translateY = wave * currentPose.bobAmp;
                rotation = wave * currentPose.rotAmp;
                scaleY = 1f + pulse * currentPose.scaleAmp * 0.25f;
                break;
            case MOTION_WAVE:
                translateY = wave * currentPose.bobAmp;
                rotation = wave * currentPose.rotAmp;
                scaleX = 1f + pulse * currentPose.scaleAmp * 0.25f;
                scaleY = 1f + pulse * currentPose.scaleAmp * 0.18f;
                break;
            case MOTION_THINK:
                translateY = wave * currentPose.bobAmp * 0.65f;
                rotation = wave * currentPose.rotAmp * 0.45f;
                scaleX = 1f + wave * currentPose.scaleAmp * 0.30f;
                scaleY = 1f - wave * currentPose.scaleAmp * 0.10f;
                break;
            case MOTION_SIT:
                translateY = currentPose.bobAmp + Math.abs(wave) * currentPose.bobAmp * 0.25f;
                rotation = wave * currentPose.rotAmp * 0.35f;
                scaleX = 1f + pulse * currentPose.scaleAmp * 0.15f;
                scaleY = 1f + pulse * currentPose.scaleAmp * 0.08f;
                break;
            case MOTION_JUMP:
                translateY = -pulse * currentPose.hopAmp;
                rotation = wave * currentPose.rotAmp * 0.55f;
                scaleX = 1f + pulse * currentPose.scaleAmp * 0.55f;
                scaleY = 1f + pulse * currentPose.scaleAmp * 0.30f;
                break;
            case MOTION_SLEEP:
                translateY = wave * currentPose.bobAmp * 0.40f;
                rotation = -0.6f + wave * currentPose.rotAmp * 0.20f;
                scaleX = 1f + pulse * currentPose.scaleAmp * 0.10f;
                scaleY = 1f + pulse * currentPose.scaleAmp * 0.05f;
                break;
            case MOTION_IDLE:
            default:
                translateY = wave * currentPose.bobAmp;
                rotation = wave * currentPose.rotAmp;
                scaleX = 1f + wave * currentPose.scaleAmp;
                scaleY = 1f + wave * currentPose.scaleAmp * 0.75f;
                break;
        }

        canvas.translate(0f, translateY);
        canvas.scale(scaleX, scaleY, cx, cy);
        if (rotation != 0f) canvas.rotate(rotation, cx, cy);

        super.onDraw(canvas);
        canvas.restore();
    }
}
