package com.maeummon.app;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class ChatStorage {

    public static void addMessage(Context context, String role, String text) {
        try {
            SharedPreferences prefs = context.getSharedPreferences(AppPrefs.PREFS, Context.MODE_PRIVATE);
            JSONArray arr = new JSONArray(prefs.getString(AppPrefs.KEY_MESSAGES, "[]"));
            JSONObject obj = new JSONObject();
            obj.put("role", role);
            obj.put("text", text);
            obj.put("time", new SimpleDateFormat("yyyy.MM.dd HH:mm", Locale.KOREA).format(new Date()));
            arr.put(obj);

            while (arr.length() > 1000) {
                JSONArray trimmed = new JSONArray();
                for (int i = 1; i < arr.length(); i++) trimmed.put(arr.getJSONObject(i));
                arr = trimmed;
            }

            prefs.edit().putString(AppPrefs.KEY_MESSAGES, arr.toString()).apply();
        } catch (Exception ignored) {}
    }

    public static JSONArray getMessages(Context context) {
        try {
            SharedPreferences prefs = context.getSharedPreferences(AppPrefs.PREFS, Context.MODE_PRIVATE);
            return new JSONArray(prefs.getString(AppPrefs.KEY_MESSAGES, "[]"));
        } catch (Exception e) {
            return new JSONArray();
        }
    }


    public static String getRecentText(Context context, int maxMessages) {
        try {
            JSONArray arr = getMessages(context);
            int start = Math.max(0, arr.length() - Math.max(1, maxMessages));
            StringBuilder sb = new StringBuilder();
            for (int i = start; i < arr.length(); i++) {
                JSONObject o = arr.optJSONObject(i);
                if (o == null) continue;
                sb.append(o.optString("role", "user"))
                  .append(": ")
                  .append(o.optString("text", ""))
                  .append("\n");
            }
            return sb.toString();
        } catch (Exception e) {
            return "";
        }
    }

    public static void addCounselingTimeline(Context context, String role, String text) {
        try {
            SharedPreferences prefs = context.getSharedPreferences(AppPrefs.PREFS, Context.MODE_PRIVATE);
            JSONArray arr = new JSONArray(prefs.getString(AppPrefs.KEY_COUNSELING_TIMELINE, "[]"));
            JSONObject obj = new JSONObject();
            obj.put("time", new SimpleDateFormat("yyyy.MM.dd HH:mm", Locale.KOREA).format(new Date()));
            obj.put("role", role == null ? "user" : role);
            obj.put("text", text == null ? "" : text);
            arr.put(obj);
            while (arr.length() > 1200) {
                JSONArray trimmed = new JSONArray();
                for (int i = 1; i < arr.length(); i++) trimmed.put(arr.optJSONObject(i));
                arr = trimmed;
            }
            prefs.edit().putString(AppPrefs.KEY_COUNSELING_TIMELINE, arr.toString()).apply();
            DailyMoodInsightManager.invalidateToday(context);
        } catch (Exception ignored) {}
    }

    public static JSONArray getCounselingTimeline(Context context) {
        try {
            SharedPreferences prefs = context.getSharedPreferences(AppPrefs.PREFS, Context.MODE_PRIVATE);
            return new JSONArray(prefs.getString(AppPrefs.KEY_COUNSELING_TIMELINE, "[]"));
        } catch (Exception e) {
            return new JSONArray();
        }
    }

    public static void addDiaryRecord(Context context, String text) {
        try {
            SharedPreferences prefs = context.getSharedPreferences(AppPrefs.PREFS, Context.MODE_PRIVATE);
            JSONArray records = new JSONArray(prefs.getString(AppPrefs.KEY_RECORDS, "[]"));

            JSONObject record = new JSONObject();
            record.put("time", new SimpleDateFormat("yyyy.MM.dd HH:mm", Locale.KOREA).format(new Date()));
            record.put("text", text);

            JSONArray updated = new JSONArray();
            updated.put(record);
            for (int i = 0; i < records.length() && i < 49; i++) {
                updated.put(records.getJSONObject(i));
            }

            prefs.edit().putString(AppPrefs.KEY_RECORDS, updated.toString()).apply();
            LiveMindManager.onMindChanged(context);
            DailyMoodInsightManager.invalidateToday(context);
        } catch (Exception ignored) {}
    }


    public static JSONArray getDiaryRecords(Context context) {
        try {
            SharedPreferences prefs = context.getSharedPreferences(AppPrefs.PREFS, Context.MODE_PRIVATE);
            return new JSONArray(prefs.getString(AppPrefs.KEY_RECORDS, "[]"));
        } catch (Exception e) {
            return new JSONArray();
        }
    }

    public static String getRecentDiaryPreview(Context context) {
        try {
            SharedPreferences prefs = context.getSharedPreferences(AppPrefs.PREFS, Context.MODE_PRIVATE);
            JSONArray records = new JSONArray(prefs.getString(AppPrefs.KEY_RECORDS, "[]"));
            if (records.length() == 0) return "아직 기록이 없어.";

            StringBuilder sb = new StringBuilder();
            int max = Math.min(records.length(), 8);
            for (int i = 0; i < max; i++) {
                JSONObject r = records.getJSONObject(i);
                sb.append(r.optString("time"))
                  .append("\n")
                  .append(r.optString("text"))
                  .append("\n\n");
            }
            return sb.toString().trim();
        } catch (Exception e) {
            return "기록을 불러오지 못했어.";
        }
    }
}
