@echo off
setlocal
set GRADLE_VERSION=8.9
set APP_HOME=%~dp0
set DIST=%USERPROFILE%\.gradle\maeummon-gradle\gradle-%GRADLE_VERSION%\bin\gradle.bat
if exist "%DIST%" (
  call "%DIST%" %*
  exit /b %ERRORLEVEL%
)
echo MaeumMon requires Gradle %GRADLE_VERSION%.
echo On Windows, open the project in Android Studio once so Gradle can be downloaded.
exit /b 1
