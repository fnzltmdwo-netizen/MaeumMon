package com.mandarin.chiyeondebt;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final String[] TARGET_PACKAGES = {
            "com.realbyteapps.moneya",
            "com.realbyteapps.moneymanagerfree",
            "com.realbyteapps.moneymanager",
            "com.realbyte.money"
    };

    private TextView accessibilityStatus;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(255, 253, 249));
        getWindow().setNavigationBarColor(Color.WHITE);
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        setContentView(buildScreen());
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshPermissionState();
    }

    private View buildScreen() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(Color.rgb(255, 253, 249));

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(22), dp(30), dp(22), dp(32));
        scroll.addView(root, new ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView eyebrow = text("CHIYEON OVERLAY · V115", 12, Color.rgb(174, 112, 82), true);
        root.addView(eyebrow);

        TextView title = text("치연 메모 자리를\n내 부채 탭으로", 30, Color.rgb(35, 35, 38), true);
        title.setLineSpacing(0, 1.08f);
        root.addView(title, margins(dp(0), dp(8), dp(0), dp(10)));

        TextView body = text("정상 실행되는 V113은 그대로 보존해. 머니매니저가 열리면 오른쪽 아래에 ‘내 부채’ 탭만 안전하게 덮어씌워.", 15, Color.rgb(104, 104, 110), false);
        body.setLineSpacing(dp(3), 1f);
        root.addView(body, margins(0, 0, 0, dp(24)));

        accessibilityStatus = statusCard(root, "① 접근성 서비스", "확인 중");
        Button accessButton = actionButton("접근성 서비스 켜기", true);
        accessButton.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        root.addView(accessButton, margins(0, dp(18), 0, dp(10)));

        Button debtButton = actionButton("내 부채 화면 미리보기", false);
        debtButton.setOnClickListener(v -> openDebt());
        root.addView(debtButton, margins(0, 0, 0, dp(10)));

        Button moneyButton = actionButton("머니매니저 열기", false);
        moneyButton.setOnClickListener(v -> openMoneyManager());
        root.addView(moneyButton, margins(0, 0, 0, dp(22)));

        TextView how = text("사용 순서", 17, Color.rgb(42, 42, 46), true);
        root.addView(how, margins(0, 0, 0, dp(9)));
        TextView steps = text("1. 접근성 서비스에서 ‘치연 내 부채 오버레이’를 켜기\n2. 머니매니저를 열기\n3. 기존 ‘치연 메모’ 자리에 표시된 ‘내 부채’ 누르기", 14, Color.rgb(94, 94, 101), false);
        steps.setLineSpacing(dp(5), 1f);
        root.addView(steps);

        TextView safety = text("V113의 base.apk와 데이터는 수정하거나 삭제하지 않아.", 12,
                Color.rgb(150, 108, 87), true);
        root.addView(safety, margins(0, dp(24), 0, 0));
        return scroll;
    }

    private TextView statusCard(LinearLayout root, String label, String initialValue) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.HORIZONTAL);
        card.setGravity(Gravity.CENTER_VERTICAL);
        card.setPadding(dp(16), dp(15), dp(16), dp(15));
        card.setBackground(roundRect(Color.WHITE, dp(18), Color.rgb(238, 230, 224)));

        TextView left = text(label, 14, Color.rgb(58, 58, 62), true);
        card.addView(left, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        TextView right = text(initialValue, 13, Color.rgb(145, 145, 151), true);
        card.addView(right);
        root.addView(card, margins(0, 0, 0, dp(9)));
        return right;
    }

    private void refreshPermissionState() {
        if (accessibilityStatus == null) return;
        boolean access = isAccessibilityEnabled();
        accessibilityStatus.setText(access ? "켜짐" : "꺼짐");
        accessibilityStatus.setTextColor(access ? Color.rgb(40, 151, 91) : Color.rgb(218, 75, 91));
    }

    private boolean isAccessibilityEnabled() {
        String enabled = Settings.Secure.getString(getContentResolver(),
                Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        if (enabled == null) return false;
        String expected = new ComponentName(this, ChiyeonAccessibilityService.class)
                .flattenToString();
        for (String service : enabled.split(":")) {
            if (expected.equalsIgnoreCase(service)) return true;
        }
        return false;
    }

    private void openDebt() {
        startActivity(new Intent(this, DebtActivity.class));
    }

    private void openMoneyManager() {
        for (String pkg : TARGET_PACKAGES) {
            Intent launch = getPackageManager().getLaunchIntentForPackage(pkg);
            if (launch != null) {
                startActivity(launch);
                return;
            }
        }
        Toast.makeText(this, "머니매니저 앱을 찾지 못했어.", Toast.LENGTH_SHORT).show();
    }

    private Button actionButton(String label, boolean primary) {
        Button button = new Button(this);
        button.setText(label);
        button.setTextSize(15);
        button.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        button.setAllCaps(false);
        button.setGravity(Gravity.CENTER);
        button.setPadding(dp(15), 0, dp(15), 0);
        button.setTextColor(primary ? Color.WHITE : Color.rgb(49, 49, 53));
        button.setBackground(roundRect(primary ? Color.rgb(40, 40, 44) : Color.WHITE,
                dp(15), primary ? Color.rgb(40, 40, 44) : Color.rgb(226, 222, 219)));
        button.setMinHeight(dp(52));
        return button;
    }

    private TextView text(String value, int sp, int color, boolean bold) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextSize(sp);
        view.setTextColor(color);
        if (bold) view.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return view;
    }

    private GradientDrawable roundRect(int fill, int radius, int stroke) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(fill);
        drawable.setCornerRadius(radius);
        drawable.setStroke(dp(1), stroke);
        return drawable;
    }

    private LinearLayout.LayoutParams margins(int left, int top, int right, int bottom) {
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        params.setMargins(left, top, right, bottom);
        return params;
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
}
