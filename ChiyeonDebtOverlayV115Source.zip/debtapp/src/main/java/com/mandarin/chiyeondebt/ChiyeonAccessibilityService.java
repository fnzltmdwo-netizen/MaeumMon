package com.mandarin.chiyeondebt;

import android.accessibilityservice.AccessibilityService;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.List;

public class ChiyeonAccessibilityService extends AccessibilityService {
    private static final String[] TARGET_PACKAGES = {
            "com.realbyteapps.moneya",
            "com.realbyteapps.moneymanagerfree",
            "com.realbyteapps.moneymanager",
            "com.realbyte.money"
    };

    private WindowManager windowManager;
    private View debtTab;
    private WindowManager.LayoutParams tabParams;
    private boolean tabAttached;
    private boolean targetInForeground;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable refreshOverlay = this::showDebtTab;

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event == null) return;
        String pkg = event.getPackageName() == null ? "" : event.getPackageName().toString();
        boolean target = isTargetPackage(pkg);

        if (event.getEventType() == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            targetInForeground = target;
            if (targetInForeground) scheduleRefresh();
            else hideDebtTab();
        } else if (target) {
            targetInForeground = true;
            scheduleRefresh();
        }

        if (target && event.getEventType() == AccessibilityEvent.TYPE_VIEW_CLICKED
                && looksLikeMemoClick(event)) {
            openDebtScreen();
        }
    }

    @Override
    public void onInterrupt() {
        hideDebtTab();
    }

    @Override
    public void onDestroy() {
        hideDebtTab();
        super.onDestroy();
    }

    private boolean isTargetPackage(String pkg) {
        for (String target : TARGET_PACKAGES) {
            if (target.equals(pkg)) return true;
        }
        return false;
    }

    private boolean looksLikeMemoClick(AccessibilityEvent event) {
        AccessibilityNodeInfo source = event.getSource();
        if (source == null) return false;
        try {
            CharSequence className = source.getClassName();
            boolean isMemoToggle = className != null
                    && className.toString().endsWith("AppCompatToggleButton");
            if (!isMemoToggle) return false;
            if (containsMemo(source.getText()) || containsMemo(source.getContentDescription())) return true;
            List<CharSequence> eventText = event.getText();
            if (eventText != null) {
                for (CharSequence item : eventText) {
                    if (containsMemo(item)) return true;
                }
            }
            return false;
        } finally {
            source.recycle();
        }
    }

    private boolean containsMemo(CharSequence text) {
        if (text == null) return false;
        String value = text.toString().trim();
        return value.contains("치연 메모") || value.contains("치연메모")
                || value.equalsIgnoreCase("Memo");
    }

    private void scheduleRefresh() {
        handler.removeCallbacks(refreshOverlay);
        handler.postDelayed(refreshOverlay, 120L);
    }

    private void showDebtTab() {
        if (!targetInForeground || windowManager == null) return;
        if (debtTab == null) debtTab = buildDebtTab();

        Rect bounds = findMemoTabBounds();
        if (bounds == null) {
            hideDebtTab();
            return;
        }

        if (tabAttached && tabParams != null) {
            applyBounds(tabParams, bounds);
            try {
                windowManager.updateViewLayout(debtTab, tabParams);
            } catch (RuntimeException ignored) {
                tabAttached = false;
            }
            return;
        }

        tabParams = new WindowManager.LayoutParams(
                bounds.width(),
                bounds.height(),
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        tabParams.gravity = Gravity.TOP | Gravity.START;
        applyBounds(tabParams, bounds);
        tabParams.setTitle("치연 내 부채 탭");

        try {
            windowManager.addView(debtTab, tabParams);
            tabAttached = true;
        } catch (RuntimeException ignored) {
            tabAttached = false;
        }
    }

    private void hideDebtTab() {
        handler.removeCallbacks(refreshOverlay);
        if (tabAttached && debtTab != null && windowManager != null) {
            try {
                windowManager.removeView(debtTab);
            } catch (RuntimeException ignored) {
                // Window may already have been removed by the system.
            }
        }
        tabAttached = false;
        tabParams = null;
    }

    private Rect findMemoTabBounds() {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return null;
        try {
            List<AccessibilityNodeInfo> matches = root.findAccessibilityNodeInfosByText("치연 메모");
            if (matches == null || matches.isEmpty()) {
                matches = root.findAccessibilityNodeInfosByText("치연메모");
            }
            if (matches == null || matches.isEmpty()) return null;

            int screenHeight = getResources().getDisplayMetrics().heightPixels;
            AccessibilityNodeInfo node = null;
            int bestScore = Integer.MIN_VALUE;
            for (AccessibilityNodeInfo match : matches) {
                Rect candidateBounds = new Rect();
                match.getBoundsInScreen(candidateBounds);
                if (candidateBounds.bottom < Math.round(screenHeight * 0.70f)) continue;
                CharSequence className = match.getClassName();
                CharSequence text = match.getText();
                int score = candidateBounds.bottom;
                if (className != null && className.toString().endsWith("AppCompatToggleButton")) score += 10000;
                if (text != null && "치연 메모".contentEquals(text)) score += 1000;
                if (score > bestScore) {
                    if (node != null) node.recycle();
                    node = AccessibilityNodeInfo.obtain(match);
                    bestScore = score;
                }
            }
            for (AccessibilityNodeInfo match : matches) match.recycle();
            if (node == null) return null;

            Rect best = new Rect();
            node.getBoundsInScreen(best);
            AccessibilityNodeInfo cursor = node;
            int screenWidth = getResources().getDisplayMetrics().widthPixels;
            try {
                for (int depth = 0; depth < 4; depth++) {
                    AccessibilityNodeInfo parent = cursor.getParent();
                    if (parent == null) break;
                    Rect parentBounds = new Rect();
                    parent.getBoundsInScreen(parentBounds);
                    boolean plausibleTab = parentBounds.width() >= dp(52)
                            && parentBounds.width() <= screenWidth / 2
                            && parentBounds.height() >= dp(40)
                            && parentBounds.height() <= dp(120);
                    cursor.recycle();
                    cursor = parent;
                    if (plausibleTab) best.set(parentBounds);
                    else if (parentBounds.width() > screenWidth / 2) break;
                }
            } finally {
                cursor.recycle();
            }
            if (best.width() < dp(52) || best.height() < dp(40)) {
                int centerX = best.centerX();
                int width = Math.max(dp(76), screenWidth / 5);
                int bottom = best.bottom + dp(12);
                best.set(centerX - width / 2, bottom - dp(72), centerX + width / 2, bottom);
            }
            clampToScreen(best);
            return best;
        } finally {
            root.recycle();
        }
    }

    private void clampToScreen(Rect bounds) {
        int screenWidth = getResources().getDisplayMetrics().widthPixels;
        int screenHeight = getResources().getDisplayMetrics().heightPixels;
        int width = Math.min(bounds.width(), screenWidth);
        int height = Math.min(bounds.height(), screenHeight);
        int left = Math.max(0, Math.min(bounds.left, screenWidth - width));
        int top = Math.max(0, Math.min(bounds.top, screenHeight - height));
        bounds.set(left, top, left + width, top + height);
    }

    private void applyBounds(WindowManager.LayoutParams params, Rect bounds) {
        params.width = Math.max(dp(52), bounds.width());
        params.height = Math.max(dp(44), bounds.height());
        params.x = bounds.left;
        params.y = bounds.top;
    }

    private View buildDebtTab() {
        LinearLayout tab = new LinearLayout(this);
        tab.setOrientation(LinearLayout.VERTICAL);
        tab.setGravity(Gravity.CENTER);
        tab.setPadding(dp(4), dp(5), dp(4), dp(6));
        tab.setElevation(dp(8));

        GradientDrawable background = new GradientDrawable();
        background.setColor(Color.WHITE);
        background.setCornerRadii(new float[]{dp(15), dp(15), 0, 0, 0, 0, dp(15), dp(15)});
        background.setStroke(dp(1), Color.rgb(238, 235, 232));
        tab.setBackground(background);

        TextView icon = new TextView(this);
        icon.setText("₩");
        icon.setTextSize(21);
        icon.setTextColor(Color.rgb(225, 82, 104));
        icon.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        icon.setGravity(Gravity.CENTER);
        tab.addView(icon, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));

        TextView label = new TextView(this);
        label.setText("내 부채");
        label.setTextSize(11);
        label.setTextColor(Color.rgb(41, 41, 45));
        label.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        label.setGravity(Gravity.CENTER);
        tab.addView(label, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        tab.setContentDescription("내 부채 열기");
        tab.setOnClickListener(v -> openDebtScreen());
        return tab;
    }

    private void openDebtScreen() {
        targetInForeground = false;
        hideDebtTab();
        Intent intent = new Intent(this, DebtActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(intent);
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
}
