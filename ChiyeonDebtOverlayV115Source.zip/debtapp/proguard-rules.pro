-keepclassmembers class com.mandarin.chiyeondebt.DebtActivity$DebtBridge {
    @android.webkit.JavascriptInterface <methods>;
}
